//  BESOM-lab Ver.3
//  Copyright (c) 2013, 2014 National Institute of Advanced Industrial Science and Technology(AIST), All Rights Reserved.
//  Author: Yuuji Ichisugi

/*
�� ���R�摜�̓���

*/

package image;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


import lab.Lab;
import lab.Lab.LabCode;
import b.B;
import b.B.BMainCode1;
import b.B.InputCode;
import b.B.Net;
import b.B.Node;


/*
�����R�摜�̓��́B
�t�H�[�}�b�g�ɂ��Ẳ���B

�E Java �� byte �^��[-128, 127] �̒l��ێ��B
�����ł̓������ߖ�̂��� [0,255] �� int �̒l�� byte �ɃL���X�g���ĕێ����Ă���B
����� int �̉��ʂW�r�b�g�ȊO���P�ɖ��������炵���B
  �� (b & 0xff) �ɂ��A���Ƃ� [0,255] �� int �̒l�ɖ߂���B

�E�摜��ێ�����t�H�[�}�b�g�F
�O���C�X�P�[���F

byte[row][col]
col �� x ���W�A row �� y ���W�A(0,0) �͍���B

int �ɕϊ������Ƃ��̂O�����A255������\���Ă���B
�iJava �̂q�f�a�̕\���ɍ��킹�Ă���B�j

�J���[���e�F�ɂ��ē��l�̃t�H�[�}�b�g�ŕێ��B

�E���̓t�H�[�}�b�g�F
BESOM-lab �̃t���[�����[�N�ɍ��킹�A�O�𔒁A�����P�ŕ\�����邱�Ƃœ���B
    data[y * imageSize + x]
�Ƃ����z�����̓f�[�^�Ƃ��ĕԂ��B
�i����̃s�N�Z�����O�Ԗڂ̗v�f�B�j

 */

public class Image {
    // jpg �摜��u���t�H���_�B
    public static String imageDataDir = "";

    public static void main(String[] args){
        Lab.addSelectableClass(B.class);
        Lab.addSelectableClass(Image.class);
        System.out.println(Lab.selectableClasses+ "");
        
        LabCode labCode = new LabCode();
        labCode.main(BMainCode1.class);
        //labCode.main();
    }
    public static void paintImage(lab.Lab.LabEnv env, String label, byte[][] image){
//        // �Ƃ肠�����W���o�͂ցB
//        System.out.println(label);
//        for (int row = 0; row < image.length; row++) {
//            for (int col = 0; col < image[row].length; col++) {
//                System.out.print(Lab.toChar((image[row][col] & 0xff) / 256.0f));
//            }
//            System.out.println();
//        }
        // �o�̓p�l���ցB
        env.viewPanel.paint(label, new lab.Lab.GrayImagePainter(image));
    }
    public static byte[][] imageToGrayImage(BufferedImage image){
        int height = image.getHeight();
        int width = image.getWidth();
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                ret[row][col] = Image.rgbToGray(image.getRGB(col, row));
            }
        }
        return ret;
    }
    public static byte rgbToGray(int rgb){
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = (rgb >> 0) & 0xFF;
        //// �O���C�X�P�[���B
        int v = ((r + g + b) / 3);
        return (byte)v;
    }
    public static byte[][] imageToYBImage(BufferedImage image){
        int height = image.getHeight();
        int width = image.getWidth();
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                ret[row][col] = Image.rgbToYB(image.getRGB(col, row));
            }
        }
        return ret;
    }
    public static boolean diffColor = true; // �D�F�Ƃ̍����ŐF��\���B
    public static float emphasizeColor = 2f; // �F�M���������B
    public static byte rgbToYB(int rgb){
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = (rgb >> 0) & 0xFF;
        if (diffColor){
            // ���Ɛ̎��B�D�F�͂P�Q�W�B
            //int v = 128 + (r+g)/2 - b;
            int v = 128 + (int)(((r+g)/2 - b) * emphasizeColor);
            if (v > 255) v = 255;
            if (v < 0) v = 0;
            return (byte)v;
        } else {
            int v = (r+g)/2;
            return (byte)v;
        }
    }
    public static byte[][] imageToMGImage(BufferedImage image){
        int height = image.getHeight();
        int width = image.getWidth();
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                ret[row][col] = Image.rgbToMG(image.getRGB(col, row));
            }
        }
        return ret;
    }
    public static byte rgbToMG(int rgb){
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = (rgb >> 0) & 0xFF;
        if (diffColor){
            // �}�[���^�Ɨ΂̎��B�D�F�͂P�Q�W�B
            //int v = 128 + (r+b)/2 - g;
            //int v = 128 + (int)(((r+b)/2 - g) * emphasizeColor);
            // �ԗ΂̎��ɕύX�I
            int v = 128 + (int)((r-g) * emphasizeColor);
            if (v > 255) v = 255;
            if (v < 0) v = 0;
            return (byte)v;
        } else {
            int v = (r+b)/2;
            return (byte)v;
        }
    }
    /**
     * �摜�T�C�Y������������B
     * BUG: ���܂͒P���ɊԈ����Ă���̂ŃW���M�[���ڗ��B
     *  n x n �̃s�N�Z���̕��ςɒu��������悤�ɂ���΂悢�Ǝv���B
     */
    public static byte[][] shrinkImage(byte[][] image, int shrink){
        int height = image.length / shrink;
        int width = image[0].length / shrink;
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                ret[row][col] = image[row * shrink][col * shrink];
            }
        }
        return ret;
    }
    /**
     * �摜�� kernel �ł����݂��ށB
     * �������A [0,255] �̃O���C�X�P�[���̉摜���������� [-128,127] �ɕϊ��������̂ɑ΂���
     * �����݂��݉��Z���s���B
     */
    public static byte[][] convoluteImage(byte[][] image, int[][] kernel){
        int height = image.length - kernel.length;
        int width = image[0].length - kernel[0].length;
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                ret[row][col] = convolute1(image, row, col, kernel);
            }
        }
        return ret;
    }
    public static byte convolute1(byte[][] image, int row, int col, int[][] kernel){
        int val = 0;
        for (int y = 0; y < kernel.length; y++) {
            for (int x = 0; x < kernel[y].length; x++) {
                val += ((image[row + y][col + x] & 0xff) - 128) * kernel[y][x];
            }
        }
        //val /= 8;
        val /= 16;
        val += 128;
        if (val < 0) val = 0;
        if (val > 255) val = 255;
        return (byte)val;
    }
    /**
     * �Q�̉摜�𑫂����킹��B
     */
    public static byte[][] addImage(byte[][] i1, byte[][] i2){
        int height = i1.length;
        int width = i1[0].length;
        Lab.assertTrue(height == i2.length);
        Lab.assertTrue(width == i2[0].length);
        byte[][] ret = new byte[height][];
        for (int row = 0; row < height; row++) {
            ret[row] = new byte[width];
            for (int col = 0; col < width; col++) {
                int val = i1[row][col] + i2[row][col];
                if (val < -128) val = -128;
                if (val > 127) val = 127;
                ret[row][col] = (byte)val;
            }
        }
        return ret;
    }
    public static abstract class InputImage extends InputCode {
        public int nodeSize = 2;
        public Node[] inputNodes;
        public Node[] hintNodes;
        public abstract int getInputDim();
        public int getHintDim() {return 0;}
        public abstract float[] getInputData();
        
        public Node[] addInputNodes(Net net) {
            int inputDim = getInputDim();
            inputNodes = new Node[inputDim];
            for (int i = 0; i < inputNodes.length; i++) {
                inputNodes[i] = net.createNode("I" + i, nodeSize);
                inputNodes[i].analogInputNodeFlag = true;
                //inputNodes[i].inputNodeFlag = true;
            }
            return inputNodes;
        }
        public Node[] addHintNodes(Net net) {return new Node[0]; }

        public float[] input(){
            float[] inputData = getInputData();
            encodeInput(inputNodes, inputData);
            return inputData;
        }

        public void encodeInput(Node[] inputNodes, float[] data) {
            for (int i = 0; i < data.length; i++) {
                inputNodes[i].inputNodeFlag = true;
                float v = data[i];
                //inputNodes[i].winnerID = Lab.rand() < v ? 1 : 0;
                net.analogInput(inputNodes[i], v);
            }
        }
    }

    public static class InputNatural1 extends InputImage {
        int imageSize = panel.getInt("imageSize", 12, 1, 32);
        //int shrink = panel.getInt("shrink", 1, 1, 8);
        int maxNumImage = panel.getInt("maxNumImage", 1, 1, 100);
        int numImage;
        BufferedImage[] images;
        byte[][][] grayImages;
        byte[][][] shrinkedImages;
        byte[][][] convolutedImages;
        byte[][][] inputImages;
        // ���v���V�A���ɃI���W�i���摜�𑫂������́B�s��̒��S�̒l�������傫�����Ă���B
        int[][] kernelPlusOrig = {
                {-1, -3, -4, -3, -1},
                {-3,  0,  6,  0, -3},
                {-4,  6, 25,  6, -4},
                {-3,  0,  6,  0, -3},
                {-1, -3, -4, -3, -1},
        };
        // 5x5 ���v���V�A���J�[�l���B
        int[][] kernel = {
                {-1, -3, -4, -3, -1},
                {-3,  0,  6,  0, -3},
                {-4,  6, 20,  6, -4},
                {-3,  0,  6,  0, -3},
                {-1, -3, -4, -3, -1},
        };
        // 3x3 ���v���V�A���J�[�l��
        int[][] kernelxx = {
                {-1,-1,-1},
                {-1,8,-1},
                {-1,-1,-1},
        };
        public void init(Net net){
            this.net = net;
            File[] files = new File(imageDataDir).listFiles();
            int c = 0;
            for (int i = 0; i < files.length; i++) {
                if (isImageFile(files[i])) c++;
            }
            numImage = Lab.min(c, maxNumImage);
            System.out.println("numImage="+ numImage);
            images = new BufferedImage[numImage];
            grayImages = new byte[numImage][][];
            shrinkedImages = new byte[numImage][][];
            convolutedImages = new byte[numImage][][];
            inputImages = new byte[numImage][][];
           try {
               readImages(files);
               for (int i = 0; i < numImage; i++){
//                   images[i] = ImageIO.read(new File(imageDataDir
//                           + i+ ".jpg"));
                   grayImages[i] = Image.imageToGrayImage(images[i]);
                   //Image.paintImage(env, "gray"+ i, grayImages[i]);
                   //shrinkedImages[i] = Image.shrinkImage(grayImages[i], shrink);
                   //Image.paintImage(env, "shrink"+ i, shrinkedImages[i]);
                   //inputImages[i] = Image.convoluteImage(shrinkedImages[i], kernel);
                   convolutedImages[i] = Image.convoluteImage(grayImages[i], kernel);

                   if (panel.flag("No Laplacian")){
                       inputImages[i] = grayImages[i];
                   } else {
                       inputImages[i] = convolutedImages[i];
                   }
                   if (panel.flag("Paint images")){
                       Image.paintImage(env, "input"+ i, inputImages[i]);
                   }
               }
           } catch (Exception e) {
               e.printStackTrace();
           }
        }
        public void readImages(File[] files) throws IOException {
            int c = 0;
            for (int i = 0; i < numImage; i++) {
                while (! isImageFile(files[c])) { c++; }
                System.out.println("Reading "+ files[c]);
                images[i] = ImageIO.read(files[c]);
                c++;
            }
        }
        public boolean isImageFile(File file){
            return file.getName().endsWith(".jpg") ||
                    file.getName().endsWith(".JPG");
        }
        
        public int getInputDim() {
            return imageSize * imageSize;
        }
        // �����p
        public byte[][] inputSample = new byte[imageSize][imageSize];
        // �Ԓl�p
        public float[] data = new float[imageSize * imageSize];  
        public float[] getInputDataOrig() {
            int img = Lab.irand(inputImages.length); 
            int row = Lab.irand(inputImages[img].length - imageSize);
            int col = Lab.irand(inputImages[img][row].length - imageSize);
            for (int y = 0; y < imageSize; y++) {
                for (int x = 0; x < imageSize; x++) {
                    byte b = inputImages[img][row + y][col + x];
                    inputSample[y][x] = b;
                    // ���͂O�A���͂P�œ��́B
                    // �i�b�o�s�̉����͍����P�ɓ��ꂷ�邱�Ƃɂ����̂ŁB�j
                    data[y * imageSize + x] = 1 - (b & 0xff) / 256.0f;
                }
            }
            Image.paintImage(env, "input", inputSample);
            return data;
        }
        //  �k�Q�ɕ��G�^�זE���o�������邽�߂� "denoising" �Ή����݁B �� �Â��H
        int lastImg;
        int lastRow;
        int lastCol;
        public float[] getInputData() {
            int img, row, col;
            if (net.translateInputFlag && net.reuseLastInputFlag){
                img = lastImg;
                row = lastRow;
                col = lastCol;
                // shift
                float r = panel.getFloat("Max shift ratio +-", 0.3f, 0, 1); 
                int smax = (int)(r * imageSize);
                int srow = Lab.irand(smax * 2) - smax; 
                int scol = Lab.irand(smax * 2) - smax;
                row += srow;
                col += scol;
            } else {
                img = Lab.irand(inputImages.length);
                // �ő� imageSize �����V�t�g����̂ŏ]����������ɑ傫���}�[�W�����Ƃ�B
                row = Lab.irand(inputImages[img].length - imageSize*3)+imageSize;
                col = Lab.irand(inputImages[img][row].length - imageSize*3)+imageSize;
                lastImg = img;
                lastRow = row;
                lastCol = col;
            }
            for (int y = 0; y < imageSize; y++) {
                for (int x = 0; x < imageSize; x++) {
                    byte b = inputImages[img][row + y][col + x];
                    // ���͂O�A���͂P�œ��́B
                    // �i�b�o�s�̉����͍����P�ɓ��ꂷ�邱�Ƃɂ����̂ŁB�j
                    data[y * imageSize + x] = 1 - (b & 0xff) / 256.0f;
                }
            }
            // BUG: ����C���X�^���X�𐶐�����K�v�͂Ȃ��B
            env.viewPanel.paint("inputData", new lab.Lab.GrayImageDataPainter(data, imageSize));
            return data;
        }
    }
    
    // �l���摜�̓��͗p
    public abstract static class InputImage2 extends InputImage {
        int imageSize = panel.getInt("imageSize", 12, 1, 32);
        // �����p
        public byte[][] inputSample;
        public void init(Net net) {
            this.net = net;
            data = new float[imageSize * imageSize];
            inputSample = new byte[imageSize][imageSize];
        }
        public int getInputDim() {
            return imageSize * imageSize;
        }
        float[] data; 
        public float[] getInputData() {
            Lab.initVec(data, 0);
            plotImage();
            for (int y = 0; y < imageSize; y++) {
                for (int x = 0; x < imageSize; x++) {
                    // Image.paintImage �ł̕\���ɕϊ��B
                    // 255 ���|����̂́A paintImage �� [0,1] �ł͂Ȃ� [0,1) �̒l��
                    // byte �ɕϊ��������̂�z�肵�Ă��邽�߁B
                    byte b = (byte)(int)((1 - data[y*imageSize + x]) * 255);
                    inputSample[y][x] = b;
                }
            }
            Image.paintImage(env, "input", inputSample);
            return data;
        }
        public abstract void plotImage();
        public void plot(float[] buf, float x, float y, float contrast){
            int ix = (int)(x * imageSize);
            if (ix < 0 || ix >= imageSize) return;
            int iy = (int)(y * imageSize);
            if (iy < 0 || iy >= imageSize) return;
            float d = buf[ix + iy*imageSize];
            if (d < contrast) buf[ix + iy*imageSize] = contrast;
        }
    }
    /*
     * �O���b�h�זE�e�X�g�p�B�i�������j
     */
    public static class InputFor1DGrid extends InputImage2 {
//        Int imagesize = panel.getint("imagesize", 12, 1, 32);
//        // �����p
//        public byte[][] inputsample;
//        public void init(net net) {
//            this.net = net;
//            data = new float[imagesize * imagesize];
//            inputsample = new byte[imagesize][imagesize];
//        }
//        public int getinputdim() {
//            return imagesize * imagesize;
//        }
//        float[] data; 
        public void plotImage() {
            float y = Lab.rand();
            plot(data, 0.2f, y, 1);
            plot(data, 0.2f, y+0.1f, 1);
            plot(data, 0.8f, y, 1);
        }
    }
    /*
     * �����摜�������_���ɓ��͂���B(������)
     */
    public static class InputLines extends InputImage2 {
        float contrast1 = panel.getFloat("Contrast 1", 1, 0, 1);
        float len1 = panel.getFloat("Length 1", 0.8f, 0, 1);
        float thickness1 = panel.getFloat("Thickness 1", 0.02f, 0, 1);
        float prob = panel.getFloat("prob", 0.5f, 0, 1);
        int numLine = panel.getInt("numLine", 2, 1, 5);
        public void plotImage() {
            if (panel.flag("Manual params")){
                float x1 = panel.getFloat("x1", 0.5f, 0, 1);
                float y1 = panel.getFloat("y1", 0.5f, 0, 1);
                float degree1 = panel.getFloat("Degree 1", 0, 0, 180);
                plotLine1(data, contrast1, x1, y1, len1, thickness1, degree1);
            } else {
                for (int i = 0; i < numLine; i++) {
                    if (prob > Lab.rand()){
                        float x1 = Lab.rand();
                        float y1 = Lab.rand();
                        float degree1 = Lab.rand() * 180;
                        plotLine1(data, contrast1, x1, y1, len1, thickness1, degree1);
                    }
                }
            }
        }
        public void plotLine1(float[] buf,
                float contrast, float x, float y, float len, float thickness, float degree){
            // lenMax x thiMax �̓_��łB�A���`�G���A�V���O�Ȃ��B
            int lenMax = 100;
            int thiMax = 30;
            for (int i = 0; i < lenMax; i++) {
                for (int j = 0; j < thiMax; j++) {
                    // ��]�O�̃o�[��̂P�_�́A�o�[�̒��S����̑��΍��W�B
                    float bx = len * ((i+0f) / lenMax - 0.5f);
                    float by = thickness * ((j+0f) / thiMax - 0.5f);
                    // ��]�B
                    float rad = (float)Math.toRadians(degree); 
                    float rx = (float)(bx * Math.cos(rad) - by * Math.sin(rad)); 
                    float ry = (float)(bx * Math.sin(rad) + by * Math.cos(rad));
                    // ���s�ړ�
                    float px = rx + x;
                    float py = ry + y;
                    // plot
                    plot(buf, px, py, contrast);
                }
            }
            
        }
    }
}
