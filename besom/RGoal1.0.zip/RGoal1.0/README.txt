	RGoal : Hierarchical Reinforcement Learning with Unlimited Recursive Subroutine Calls
					Author Yuuji Ichisugi	2021-11


This program aims to reproduce the experiments described in RGoal papers to help other researchers better understand the architecture.


Java source:
	lab\Lab.java		Immediate Mode GUI library
	tmm1\RGoal.java		RGoal performance evaluation
	tmm1\InfLearn.java	Learning values of inference rules using RGoal


How to run RGoal.java (on Windows):
	> javac tmm1\RGoal.java
	> java tmm1.RGoal

	Then, push "Stop" button, select "Main" menu and push "Start" button.

How to run InfLearn.java (on Windows):
	> javac tmm1\InfLearn.java
	> java tmm1.InfLearn

	Then, select a task from "Task" menu and push "Start" button.


Paper of RGoal:
Ichisugi Y., Takahashi N., Nakada H., Sano T.,
Hierarchical Reinforcement Learning with Unlimited Recursive Subroutine Calls. In Artificial Neural Networks and Machine Learning - ICANN 2019: Deep Learning, Lecture Notes in Computer Science, vol 11728, pp. 103--114, Springer, Cham, 2019.
https://doi.org/10.1007/978-3-030-30484-3_9

Paper of learning values of inference rules using RGoal (In Japanese):
Ichisugi Y., Nakada H., Takahashi N., Sano T.,
Learning Values of Inference Rules using Recursive Reinforcement Learning
In. Proc. of The Japanese Society for Artificial Intelligence Workshop SIG-AGI, 2019.
https://doi.org/10.11517/jsaisigtwo.2020.AGI-014_09


This program is distributed under the 3-clause BSD license. See License.txt .
This work was supported by JSPS KAKENHI Grant Number JP18K11488.
The file Lab.java is a part of BESOM-lab Ver.3 distributed under the same license as this program.
