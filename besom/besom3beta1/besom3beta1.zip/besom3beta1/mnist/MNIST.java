//  BESOM-lab Ver.3
//  Copyright (c) 2013 National Institute of Advanced Industrial Science and Technology(AIST), All Rights Reserved.
//  Author: Yuuji Ichisugi

package mnist;

import image.Image;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

import lab.Lab;
import lab.Lab.LabCode;
import b.B;
import b.B.BMainCode1;
import b.B.CPTmodelCode;
import b.B.EvalCode;
import b.B.HiddenCode;
import b.B.HiddenForImage;
import b.B.ICACode;
import b.B.InputCode;
import b.B.Net;
import b.B.Node;
import b.B.RecogCode;
import b.B.WinRateCode;

/*
�� MNIST �菑�������f�[�^���g�����e�X�g�v���O����

byte xxxImages[i][row][col] �ɂ́A
 [0,255] �� int ��  byte �ɃL���X�g���� [-128,127] �̒l������B
 ���̒l b �����Ƃ� int �ɖ߂��ɂ� (b & 0xff) �Ƃ���B
 �Ȃ��A���Ƃ� [0,255] �̒l�́A�w�i���O�ŕ��������̒l�ŕ\����Ă���B 
�����ł͔w�i�����ŕ��������Ɖ��߂���B

�E Image.java �Ƃ̓s�N�Z���\�����������]���Ă���̂Œ��ӁB

 */


public class MNIST {
    public static void main(String[] args){
        Lab.addSelectableClass(B.class);
        Lab.addSelectableClass(MNIST.class);
        Lab.addSelectableClass(B.Hidden4.class); // �f�t�H���g
        System.out.println(Lab.selectableClasses+ "");
        
        LabCode labCode = new LabCode();
        labCode.main(BMainCode1.class);
        //labCode.main(MainDeepNetConfigTest.class);
        //labCode.main();
    }
    
    // �f�[�^�̃t�@�C������̃��[�h�A�ێ����s�����߂� static method ���W�߂������̃N���X�B
    // �K�v�ɉ����� lazy �Ƀf�[�^�����[�h�B
    public static class DataLoader {
        public String mnistDataDir = "";
        public int imageSize = 28;
        public byte trainImages[][][] = null;
        public int trainLabels[] = null;
        public byte testImages[][][] = null;
        public int testLabels[] = null;
        public void initTrainImages(Lab.LabEnv env, boolean readFull) {
            int dataSize = readFull ? 60000 : 1000;
            if (trainImages == null || trainImages.length < dataSize) {
                System.out.println("Reading "+ dataSize+ " training data...");
                trainLabels = readLabels(env, mnistDataDir+
                        "train-labels-idx1-ubyte.gz", dataSize);
                trainImages = readImages(env, mnistDataDir+
                        "train-images-idx3-ubyte.gz", dataSize);
                System.out.println("Done.");
            }
            int testDataSize = readFull ? 10000 : 1000;
            if (testImages == null || testImages.length < testDataSize) {
                System.out.println("Reading "+ testDataSize+ " test data...");
                testLabels = readLabels(env, mnistDataDir+
                        "t10k-labels-idx1-ubyte.gz", testDataSize);
                testImages = readImages(env, mnistDataDir+
                        "t10k-images-idx3-ubyte.gz", testDataSize);
                System.out.println("Done.");
            }
            if (false){
                // �ǂݍ��� trainImages �� print �B
                for (int i = 0; i < trainImages.length; i++) {
                    env.checkStop();
                    System.out.println("i="+ i+ ", label="+ trainLabels[i]);
                    for (int row = 0; row < trainImages[i].length; row++) {
                        for (int col = 0; col < trainImages[i][row].length; col++) {
                            System.out.print(Lab.toChar((trainImages[i][row][col] & 0xff) / 256.0f));
                        }
                        System.out.println();
                    }
                }
            }
        }
        public int[] readLabels(Lab.LabEnv env, String fileName, int dataSize){
            try {
                FileInputStream fin = new FileInputStream(fileName);
                BufferedInputStream bin = new BufferedInputStream(fin);
                GZIPInputStream gin = new GZIPInputStream(bin);
                Lab.assertTrue(readInt(gin) == 0x00000801);
                //Lab.assertTrue(readInt(gin) == dataSize);
                Lab.assertTrue(readInt(gin) >= dataSize);
                int[] labels = new int[dataSize];
                for (int i = 0; i < dataSize; i++) {
                    env.checkStop();
                    labels[i] = gin.read();
                }
                //Lab.assertTrue(gin.read() == -1);
                return labels;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                throw new Error(""+ e);
            } catch (IOException e) {
                e.printStackTrace();
                throw new Error(""+ e);
            }
        }
        public byte[][][] readImages(Lab.LabEnv env, String fileName, int dataSize){
            try {
                byte[][][] images = new byte[dataSize][][]; 
                FileInputStream fin = new FileInputStream(fileName);
                BufferedInputStream bin = new BufferedInputStream(fin);
                GZIPInputStream gin = new GZIPInputStream(bin);
                Lab.assertTrue(readInt(gin) == 0x00000803);
                //Lab.assertTrue(readInt(gin) == dataSize);
                Lab.assertTrue(readInt(gin) >= dataSize);
                Lab.assertTrue(readInt(gin) == imageSize);
                Lab.assertTrue(readInt(gin) == imageSize);
                for (int i = 0; i < dataSize; i++) {
                    env.checkStop();
                    env.viewPanel.print1("Reading images...", ""+ i);
                    //System.out.println("data:"+ i+ ", label="+ trainLabels[i]);
                    images[i] = new byte[imageSize][];
                    for (int row = 0; row < imageSize; row++) {
                        images[i][row] = new byte[imageSize];
                        for (int col = 0; col < imageSize; col++) {
                            //System.out.print(gin.read()+ ", ");
                            //System.out.print(Lab.toChar(gin.read() / 256.0f));
                            images[i][row][col] = (byte)gin.read();
                        }
                        //System.out.println();
                    }
                }
                //Lab.assertTrue(gin.read() == -1);
                return images;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                throw new Error(""+ e);
            } catch (IOException e) {
                e.printStackTrace();
                throw new Error(""+ e);
            }
        }
        public int readInt(GZIPInputStream gin) throws IOException{
            return gin.read() * 256 * 256 * 256
            + gin.read() * 256 * 256
            + gin.read() * 256
            + gin.read();
        }
    }
    public static DataLoader dataLoader = new DataLoader();
    
    public static class InputMNIST1 extends InputCode {
        public boolean inputLabels = panel.flag("inputLabels", true);
        public boolean readFull = panel.flag("readFull");
        public int imageSize = MNIST.dataLoader.imageSize;

        public int pixelNodeSize = 2;
        public Node[] inputNodes;
        public Node[] hintNodes;

        //float[] buf; 
        float[] labelBuf;
        public void init(Net net) {
            this.net = net;
            //buf = new float[imageSize * imageSize];
            labelBuf = new float[inputLabels ? 1 : 0];
            MNIST.dataLoader.initTrainImages(env, readFull);
        }
        public int getInputDim() {
            return imageSize * imageSize;
        }
        public int getHintDim(){
            return inputLabels ? 1 : 0;
        }
        public Node[] addInputNodes(Net net) {
            int inputDim = getInputDim();
            inputNodes = new Node[inputDim];
            for (int i = 0; i < inputNodes.length; i++) {
                inputNodes[i] = net.createNode("I" + i, pixelNodeSize);
                inputNodes[i].analogInputNodeFlag = true;
                //inputNodes[i].inputNodeFlag = true;
            }
            return inputNodes;
        }
        public Node[] addHintNodes(Net net) {
            int dim  = getHintDim();
            hintNodes = new Node[dim];
            for (int i = 0; i < hintNodes.length; i++) {
                hintNodes[i] = net.createNode("T" + i, hintNodeSize);
                //hintNodes[i].inputNodeFlag = true;
            }
            return hintNodes;
        }
        
        // �����p �� �p�~�\��H
        public byte[][] inputSample = new byte[imageSize][imageSize];
        // �Ԓl�p
        public float[] data = new float[imageSize * imageSize];
        public int selectedImageID;
        public boolean giveImage;
        public boolean giveLabel; // Not used.
        public float[] input(){
            resultGraphX++;
            return input1(panel.flag("Give label", true), false);
        }
        public float[] input1(boolean giveLabel, boolean inputTestData){
            giveImage = panel.flag("Give image", true);
            float[] inputData;
            if (panel.flag("Artificial stimulus")){
                inputData = artificialStimulus();
            } else {
                inputData = getInputData(inputTestData);
            }
            // BUG: ����C���X�^���X�𐶐�����K�v�͂Ȃ��B
            env.viewPanel.paint("inputData", new lab.Lab.GrayImageDataPainter(inputData, imageSize));
            encodeInput(inputNodes, inputData);
            float[] hintData = getHintData(inputTestData);
            encodeHint(hintNodes, hintData, giveLabel);
            return inputData;
        }
        public float[] getInputData(boolean inputTestData) {
            // BUG: "Input one digit only" �ł��e�X�g�̂Ƃ��͂P�O�̂����͂����B
            if (panel.flag("Input one digit only")){
                for(;;){
                    int digit = panel.getInt("Input digit", 2, 0, 9);
                    if (inputTestData){
                        selectedImageID = Lab.irand(MNIST.dataLoader.testImages.length);
                    } else{
                        selectedImageID = Lab.irand(MNIST.dataLoader.trainImages.length);
                    }
                    int label = MNIST.dataLoader.trainLabels[selectedImageID];
                    if (label == digit) break;
                }
            } else if (net.translateInputFlag){
                // Do nothing. Reuse previous selectedImageID again.
            } else {
                if (inputTestData){
                    selectedImageID = Lab.irand(MNIST.dataLoader.testImages.length);
                } else{
                    selectedImageID = Lab.irand(MNIST.dataLoader.trainImages.length);
                }
            }
            for (int y = 0; y < imageSize; y++) {
                for (int x = 0; x < imageSize; x++) {
                    byte b;
                    if (inputTestData){
                        b = MNIST.dataLoader.testImages[selectedImageID][y][x];
                    } else {
                        b = MNIST.dataLoader.trainImages[selectedImageID][y][x];
                    }
                    //inputSample[y][x] = b;
                    // Image.paintImage �ł͂O�����A�P�����B�Ȃ̂Ŕ������]�B
                    //inputSample[y][x] = (byte)(255-(b & 0xff));
                    // ���͂O�A���͂P�œ��́B
                    data[y * imageSize + x] = (b & 0xff) / 256.0f;
                }
            }
            if (net.translateInputFlag){
                // �摜�������_���ɕ��s�ړ��E��]�B
                float sx = panel.getFloat("Shift x range +-", 0.05f, 0, 1)
                    * (Lab.rand() * 2 - 1); 
                float sy = panel.getFloat("Shift y range +-", 0.05f, 0, 1)
                    * (Lab.rand() * 2 - 1); 
                float degree = panel.getInt("Rotate range +-", 5, 0, 180)
                    * (Lab.rand() * 2 - 1); 
                transformImage(data, sx, sy, degree);
            } else if (panel.flag("Shift image manually")){ // for debug
                float sx = panel.getFloat("Shift x", 0, -1, 1); 
                float sy = panel.getFloat("Shift y", 0, -1, 1);
                float degree = panel.getInt("Rotate", 0, -180, 180);
                transformImage(data, sx, sy, degree);
            } else {
                // Do nothing.
            }
            //env.viewPanel.paint("inputSample", new lab.Lab.GrayImagePainter(inputSample));
            return data;
        }
        public void inputOneOrAllDigit(boolean inputTestData){
            if (panel.flag("Input one digit only")){
                for(;;){
                    int digit = panel.getInt("Input digit", 2, 0, 9);
                    inputOneDigit(inputTestData);
                    int label = MNIST.dataLoader.trainLabels[selectedImageID];
                    if (label == digit) break;
                }
            } else {
                inputOneDigit(inputTestData);
            }
        }
        public void inputOneDigit(boolean inputTestData){
            if (inputTestData){
                selectedImageID = Lab.irand(MNIST.dataLoader.testImages.length);
            } else{
                selectedImageID = Lab.irand(MNIST.dataLoader.trainImages.length);
            }
        }
        public float[] tmpBufferForTransformImage = null;
        public void transformImage(float[] data, float sx, float sy, float degree){
            if (tmpBufferForTransformImage == null || 
                    tmpBufferForTransformImage.length != data.length){
                tmpBufferForTransformImage = new float[data.length];
            }
            float[] buf = tmpBufferForTransformImage; // Just use a short name.
            Lab.initVec(buf, 0);
            // �܂��͈ړ��ʂ̓X���C�_�ŁB
            float rad = (float)Math.toRadians(degree); 
            for (int y = 0; y < imageSize; y++) {
                for (int x = 0; x < imageSize; x++) {
                    // �摜�̒��S����̑��΍��W
                    float bx = ((x + 0f) / imageSize) - 0.5f;
                    float by = ((y + 0f) / imageSize) - 0.5f;
                    // ���s�ړ��O�̍��W�B
                    float px = bx - sx;
                    float py = by - sy;
                    // ��]�O�̍��W�B
                    float rx = (float)(px * Math.cos(-rad) - py * Math.sin(-rad)); 
                    float ry = (float)(px * Math.sin(-rad) + py * Math.cos(-rad));
                    // plot
                    int ix = Math.round((rx + 0.5f) * imageSize);
                    int iy = Math.round((ry + 0.5f) * imageSize);
                    if (0 <= ix && ix < imageSize &&
                            0 <= iy && iy < imageSize){
                        buf[y * imageSize + x] 
                            = data[iy * imageSize + ix];
                    }
                }
            }
            for (int i = 0; i < data.length; i++) {
                data[i] = buf[i];
            }
        }
        public int selectedImageLabel;
        public float[] getHintData(boolean inputTestData) {
            if (inputLabels){
                if (inputTestData){
                    selectedImageLabel = MNIST.dataLoader.testLabels[selectedImageID];
                } else {
                    selectedImageLabel = MNIST.dataLoader.trainLabels[selectedImageID];
                }
                labelBuf[0] = selectedImageLabel / 10.0f;
            }
            return labelBuf;
        }
        public int hintNodeSize = 11;

        public void encodeInput(Node[] inputNodes, float[] data) {
            if (panel.flag("Give image", true)){
                for (int i = 0; i < data.length; i++) {
                    inputNodes[i].inputNodeFlag = true;
                    // 0, 1 �̒l������邽�߁B
                    float v = data[i] * 0.98f + 0.01f; 
                    //inputNodes[i].winnerID = Lab.rand() < v ? 1 : 0;
                    net.analogInput(inputNodes[i], v);
                }
            } else {
                for (int i = 0; i < data.length; i++) {
                    inputNodes[i].inputNodeFlag = false;
                }
            }
        }

        // data �̗v�f�͂O�`�X�̐������P�O�Ŋ��������̂������Ă���Ɖ���B
        // ���̐������Ӓl�Ɋ��蓖�Ăē��͂���B
        public void encodeHint(Node[] nodes, float[] data, boolean giveLabel) {
            if (giveLabel){
                for (int i = 0; i < data.length; i++) {
                    hintNodes[i].inputNodeFlag = true;
                    nodes[i].winnerID = (int)(data[i] * 10 + 1);
                }
            } else {
                for (int i = 0; i < data.length; i++) {
                    hintNodes[i].inputNodeFlag = false;
                }
            }
        }
        public void decodeHint(Node[] nodes, float[] data) {
            for (int i = 0; i < data.length; i++) {
                data[i] = (hintNodes[0].winnerID - 1) / 10.0f;
            }
        }
        public void paintPosterior(){
            if (! giveImage){
                StringBuffer buf = new StringBuffer();
                for (int row = 0; row < imageSize; row++) {
                    for (int col = 0; col < imageSize; col++) {
                        buf.append(Lab.toChar(inputNodes[row * imageSize + col].bel[1]));
                    }
                    buf.append(Lab.lineSeparator);
                }
                buf.append(Lab.lineSeparator);
                buf.append(Lab.lineSeparator);
                System.out.println(buf);
            }
//            if (! giveLabel){
//                for (int i = 0; i < hintNodes.length; i++) {
//                    env.viewPanel.paint(hintNodes[i].nodeName+ ".bel", 
//                            hintNodes[i].bel);
//                }
//            }
        }
        int counter = 0;
        int resultGraphX = 0; // input() ���Ă΂�邽�тɑ�����悤�ɂ����B
        public void evalRecogResult(Net net, 
                RecogCode selectedRecogCode, CPTmodelCode cptModelCode, 
                WinRateCode winRateCode, ICACode icaCode){
            int evalInterval = panel.getInt("Eval interval", 100, 1, 1000);
            counter++;
            if (counter < evalInterval) return;
            counter = 0;

            int inputsForEval = panel.getInt("Inputs for eval", 10, 0, 1000);
//            boolean currentGiveLabelFlag = giveLabel;
//            giveLabel = false;
            boolean currentFlag = net.noPenaltyFlag;
            net.noPenaltyFlag = panel.flag("No penalty when eval", true);
            
            int correct = 0;
            float sum = 0;
            for (int i = 0; i < inputsForEval; i++) {
                env.viewPanel.print1("Evaluating inputs", "" + i);
                
                float[] inputData = this.input1(false, true);
                selectedRecogCode.calcMPE(net);
                int result = hintNodes[0].winnerID - 1;
                //System.out.println(selectedImageLabel+ ", "+ result);
                if (selectedImageLabel == result) correct++;
                
                sum += b.B.EvalCode.evalLikelihood(net, cptModelCode, 
                        winRateCode, icaCode);
            }
            float correctRate = (correct + 0f) / inputsForEval; 
            env.viewPanel.scatterPlotFixedY("MNIST Correct rate", 
                    resultGraphX, correctRate, 0, 1);
            float mean = sum / inputsForEval;
            env.viewPanel.scatterPlot("Test data log score", resultGraphX, mean);
            //resultGraphX++; 

//            giveLabel = currentGiveLabelFlag;
            net.noPenaltyFlag = currentFlag;
        }
        public void evalRecogResultOld(InputCode inputCode){
            if (! giveImage){
                for (int row = 0; row < imageSize; row++) {
                    for (int col = 0; col < imageSize; col++) {
                        System.out.print(inputNodes[row * imageSize + col].winnerID);
                    }
                    System.out.println();
                }
                System.out.println();
            }
            if (! giveLabel){
                int result = hintNodes[0].winnerID - 1;
                
                env.viewPanel.print1("Recog Result",
                        "input,result="+ selectedImageLabel+
                        ", "+ result
                        );
            }
        }
        public float[] stimulus = null;
        public float[] artificialStimulus(){
            float contrast1 = panel.getFloat("Contrast 1", 1, 0, 1);
            float x1 = panel.getFloat("x1", 0.5f, 0, 1);
            float y1 = panel.getFloat("y1", 0.5f, 0, 1);
            float len1 = panel.getFloat("Length 1", 0.3f, 0, 1);
            float thickness1 = panel.getFloat("Thickness 1", 0.1f, 0, 1);
            float degree1 = panel.getFloat("Degree 1", 0, 0, 180);
            if (stimulus == null){
                stimulus = new float[imageSize * imageSize];
            }
            Lab.initVec(stimulus, 0);
            artificialStimulus1(stimulus, contrast1, x1, y1, len1, thickness1, degree1);
            
            return stimulus;
        }
        public void artificialStimulus1(float[] buf,
                float contrast, float x, float y, float len, float thickness, float degree){
            // lenMax x thiMax �̓_��łB�A���`�G���A�V���O�Ȃ��B
            int lenMax = 100;
            int thiMax = 30;
            for (int i = 0; i < lenMax; i++) {
                for (int j = 0; j < thiMax; j++) {
                    // ��]�O�̃o�[��̂P�_�́A�o�[�̒��S����̑��΍��W�B
                    float bx = len * ((i+0f) / lenMax - 0.5f);
                    float by = thickness * ((j+0f) / thiMax - 0.5f);
                    // ��]�B
                    float rad = (float)Math.toRadians(degree); 
                    float rx = (float)(bx * Math.cos(rad) - by * Math.sin(rad)); 
                    float ry = (float)(bx * Math.sin(rad) + by * Math.cos(rad));
                    // ���s�ړ�
                    float px = rx + x;
                    float py = ry + y;
                    // plot
                    int ix = (int)(px * imageSize);
                    int iy = (int)(py * imageSize);
                    if (0 <= ix && ix < imageSize &&
                            0 <= iy && iy < imageSize){
                        buf[iy * imageSize + ix] = contrast;
                    }
                }
            }
            
        }
    }

    //-------------------------------------------------------------
    // �S�w�a�d�r�n�l�B�Ǐ���e��o�[�W�����B�i�k�P�m�[�h�͋Ǐ���e������B�j
    // �ŏ�ʑw�Ƀq���g�m�[�h��u���B
    // ���͂ɂ��Ă� n x n �̉摜�ł���Ɖ���B
    public static class Hidden4p extends b.B.Hidden3p {

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            hiddenNodes1 = new Node[numNodes1 * 4];
            for (int i = 0; i < numNodes1 * 4; i++) {
                hiddenNodes1[i] = net.createNode("L1." + i, nodeSize1);
            }
            // ���͑w�Ƃk�P�̊Ԃ͋Ǐ���e��
            imageSize = (int)Math.sqrt(inputNodes.length);
            Lab.assertTrue(imageSize * imageSize == inputNodes.length);
            int halfSize = imageSize / 2;
            if (halfSize * 2 != imageSize){
                throw new Error("Sorry, imageSize should be even number.");
            }
            for (int i = 0; i < numNodes1; i++) {
                for (int y = 0; y < halfSize; y++) {
                    for (int x = 0; x < halfSize; x++) {
                        // ����
                        net.addEdge(hiddenNodes1[i], 
                                inputNodes[y * imageSize 
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 + i], 
                                inputNodes[y * imageSize
                                           + halfSize + x]);
                        // ����
                        net.addEdge(hiddenNodes1[numNodes1 * 2 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 * 3 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + halfSize + x]);
                        
                    }
                }
            }

            hiddenNodes2 = new Node[numNodes2];
            for (int i = 0; i < numNodes2; i++) {
                hiddenNodes2[i] = net.createNode("L2." + i, nodeSize2);
            }
            // ����
            for (int i = 0; i < hiddenNodes2.length; i++) {
                for (int j = 0; j < hiddenNodes1.length; j++) {
                    // �����̓t�������B
                    net.addEdge(hiddenNodes2[i], hiddenNodes1[j]);
                }
            }
            for (int i = 0; i < hintNodes.length; i++) {
                // �����̓t�������B
                for (int j = 0; j < hiddenNodes2.length; j++) {
                    net.addEdge(hintNodes[i], hiddenNodes2[j]);
                }
            }

            
            for (int i = 0; i < 4; i++) {
                icaCode.fullConnectLateralEdges(partialL1Nodes[i]);
            }
            icaCode.fullConnectLateralEdges(hiddenNodes2);
            icaCode.initICA(net);
            
//            allHiddenNodes = new Node[hiddenNodes1.length + hiddenNodes2.length];
//            {
//                int c = 0;
//                for (int i = 0; i < hiddenNodes1.length; i++) {
//                    allHiddenNodes[c++] = hiddenNodes1[i];
//                }
//                for (int i = 0; i < hiddenNodes2.length; i++) {
//                    allHiddenNodes[c++] = hiddenNodes2[i];
//                }
//            }
            visualizableNodes = Node.append(Node.append(hiddenNodes1, hiddenNodes2),
                    hintNodes);
        }
    }
    // �R�w�a�d�r�n�l�B�Ǐ���e��o�[�W�����B�i�k�P�m�[�h�͋Ǐ���e������B�j
    // �k�Q�̓q���g�m�[�h�B
    public static class HiddenH3p extends b.B.Hidden3p {
        // �����̃X���C�_���p������邪�A�����B
//        // �Q�w��
//        public int numNodes2 = panel.getInt("numNodes2", 4, 1, 30);
//        public int nodeSize2 = panel.getInt("nodeSize2", 20, 2, 100);

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            hiddenNodes1 = new Node[numNodes1 * 4];
            for (int i = 0; i < numNodes1 * 4; i++) {
                hiddenNodes1[i] = net.createNode("L1." + i, nodeSize1);
            }
            // ���͑w�Ƃk�P�̊Ԃ͋Ǐ���e��
            imageSize = (int)Math.sqrt(inputNodes.length);
            Lab.assertTrue(imageSize * imageSize == inputNodes.length);
            int halfSize = imageSize / 2;
            if (halfSize * 2 != imageSize){
                throw new Error("Sorry, imageSize should be even number.");
            }
            for (int i = 0; i < numNodes1; i++) {
                for (int y = 0; y < halfSize; y++) {
                    for (int x = 0; x < halfSize; x++) {
                        // ����
                        net.addEdge(hiddenNodes1[i], 
                                inputNodes[y * imageSize 
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 + i], 
                                inputNodes[y * imageSize
                                           + halfSize + x]);
                        // ����
                        net.addEdge(hiddenNodes1[numNodes1 * 2 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 * 3 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + halfSize + x]);
                        
                    }
                }
            }

            hiddenNodes2 = new Node[0]; // dummy
            // ����
            for (int i = 0; i < hintNodes.length; i++) {
                for (int j = 0; j < hiddenNodes1.length; j++) {
                    // �����̓t�������B
                    net.addEdge(hintNodes[i], hiddenNodes1[j]);
                }
            }

            for (int i = 0; i < 4; i++) {
                icaCode.fullConnectLateralEdges(partialL1Nodes[i]);
            }
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(hiddenNodes1, hintNodes);
            
            hiddenNodes2 = hintNodes; // pre-training �𓮂������߁B
        }
    }
}
