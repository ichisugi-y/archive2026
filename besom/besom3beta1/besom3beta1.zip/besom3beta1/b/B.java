//  BESOM-lab Ver.3
//  Copyright (c) 2013 National Institute of Advanced Industrial Science and Technology(AIST), All Rights Reserved.
//  Author: Yuuji Ichisugi

package b;

import image.Image;
import image.Image.InputNatural1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.Date;

import b.B.Net;

import com.sun.jmx.trace.Trace;

import lab.Lab;
import lab.Lab.LabCode;
import mnist.MNIST;

/*
 

 ���R�[�f�B���O�K��
 �E�������ȊO�� new ���Ȃ����ƁB
 �E�������ȊO�͂ł��邾�������񉉎Z���Ȃ����ƁB �i�ꎞ�I�ȃf�o�b�O�ړI�͗�O�B�j 
 �E���Z�͂��ׂ� float �B�i�萔�� f ������K�v����B�j
 �E ���\�b�h�͌��� public �B �i���B�؂����_���D��B�j
 �E continue �͌����g��Ȃ��B���G�ȃA���S���Y���̉��ǎ��̃o�O�̂��ƁB 
 �E '/', '*', '*' �Ŏn�܂� JavaDoc �R�����g�������Ă�����
  Eclipse �� tooltips �ŏo���Ă���ĕ֗��Ȃ̂ŁA�ϋɓI�ɏ����B
 �E�����̃}���`�X���b�h���ɂ��Ȃ��Ăł��邾�� thread safe �ɏ����Ă����B 
 
 �E�z��̃C���f�b�N�X�̕ϐ����ɂ��āB
  �����Ƃ��āA�q�m�[�h�� l �i�G���̏������j, �e�m�[�h�� k , 
  node �̃��j�b�g�� i �A �e�m�[�h�A�q�m�[�h�̃��j�b�g�� j ���g���B

 �E�f�t�h�c�[���L�b�g���g������ꍇ�̓��b�N�Ƃd�c�s�ɍאS�̒��ӂ𕥂����ƁB
 
 �� Java ����o��
 �E float ���� int �ւ̃L���X�g�́A�[���̕����̐����l�ւ̊ۂ߁B
 �E NaN �Ƃ̕s������r�͏�� false �B
 �E NaN == NaN �� false �B
 �E float �͈̔́F -3.40282�~10^38�`3.40282�~10^38

���V�~�����[�V�����������Ȃ����ɍl�����錴��
    �����̃o�O�B
    �I�[�o�[�t���[�E�A���_�[�t���[�Ȃǌv�Z��̐����B�i���̎����̃o�O�B�j
    �A���S���Y���̃o�O�B
    ���̕����A���S���Y���Ƃ̊��B�i���̃A���S���Y���̃o�O�B�j
    �p�����^�����s���B
    �Ǐ����B
    �����̒x���B�i���̃A���S���Y���̃o�O�B�j
    ���z�@�ɂ����Č��z���قڂO�B�i���̋Ǐ����B�j
    �i�Ǐ����̖��������ɂ́A���������s�����A
     �Ȃ�炩�� pre-training ���邢�͏����l�Ƃ��ċߎ�����^����K�v������B�j
   �ߓK���B
    
 */

public class B {
    public static void main(String[] args) {
        //IncrementalSorter.test(1000000);
        
        Lab.addSelectableClass(MNIST.class);
        Lab.addSelectableClass(B.class);
        //Lab.addSelectableClass(Som.class);
        Lab.addSelectableClass(Image.class);
        Lab.addSelectableClass(Hidden2.class);
        System.out.println(Lab.selectableClasses + "");

        LabCode labCode = new LabCode();
        labCode.main(BMainCode1.class);
        //labCode.main(MainCompare3.class);
        //labCode.main();
    }

    public static class NetCode1 extends NetCode {
        public Net createEmptyNet() {
            //return new Net(winRateC);
            return new Net();
        }
    }

    /**
     * BESOM network ����ѓ���ɕK�v�ȃA���S���Y����ێ�����I�u�W�F�N�g�B 
     * �Ƃ����Ă��l�b�g���[�N�̃G�b�W�̏��� Node �I�u�W�F�N�g�����B
     * Net �́A�S�m�[�h�̔z���ێ����邾���B
     * 
     * BUGS:
     *  getInputNodes, getHiddenNodes �͖���z������̂Œx���B 
     */
    public static class Net {
        /**
         * �l�b�g���[�N���ɂ��邷�ׂẴm�[�h�̔z��B
         */
        public Node[] allNodes = new Node[0];

        /**
         * �A�i���O���͂����邩�ǂ�����\���t���O�B
         * analogInputNodeFlag �� true �̃m�[�h�ɑ΂��āA
         *   false �̏ꍇ�� winnerID ���g���ē��́B
         *   true �̏ꍇ�� lambda[i], newLambda[i] ���g���ē��́B
         * �F���A���S���Y���A�w�K�A���S���Y���A���̓A���S���Y����
         * �����̓��͕��@�ɑΉ�����K�v������B
         */
        public boolean analogInputFlag = false;
        public void analogInput(Node node, float v){
            Lab.assertTrue(node.analogInputNodeFlag == true);
            Lab.assertTrue(node.nodeSize == 2);
            node.winnerID = Lab.rand() < v ? 1 : 0;
            node.lambda[0] = 1 - v;
            node.lambda[1] = v;
            node.newLambda[0] = 1 - v;
            node.newLambda[1] = v;
        }
        /**
         * �����y�i���e�B�A���}���̌��ʂ��I�t�ɂ���B
         */
        public boolean noPenaltyFlag = false;
        /**
         * "Denoising Test" �̂��߂̃t���O�B
         *
         */
        public boolean translateInputFlag = false;

        /**
         * ���̓m�[�h�݂̂��܂ޔz�������ĕԂ��B 
         * ���̓f�[�^�� InputCode ���������邽�т� inputNodeFlag ��
         * �ݒ肵�������̂ŁA���̒���ł݂̂��̃��\�b�h�Ăяo���͈Ӗ�������B
         */
        public Node[] getInputNodes() {
            int size = 0;
            for (int i = 0; i < allNodes.length; i++) {
                if (allNodes[i].inputNodeFlag)
                    size++;
            }
            Node[] nodes = new Node[size];
            int c = 0;
            for (int i = 0; i < allNodes.length; i++) {
                if (allNodes[i].inputNodeFlag) {
                    nodes[c++] = allNodes[i];
                }
            }
            return nodes;
        }

        /**
         * �B��m�[�h�݂̂��܂ޔz�������ĕԂ��B
         * ���̓f�[�^�� InputCode ���������邽�т� inputNodeFlag ��
         * �ݒ肵�������̂ŁA���̒���ł݂̂��̃��\�b�h�Ăяo���͈Ӗ�������B
         */
        public Node[] getHiddenNodes() {
            int size = 0;
            for (int i = 0; i < allNodes.length; i++) {
                if (!allNodes[i].inputNodeFlag)
                    size++;
            }
            Node[] nodes = new Node[size];
            int c = 0;
            for (int i = 0; i < allNodes.length; i++) {
                if (!allNodes[i].inputNodeFlag) {
                    nodes[c++] = allNodes[i];
                }
            }
            return nodes;
        }

        /**
         * �m�[�h���l�b�g���[�N�ɒǉ�����B 
         */
        public Node createNode(String nodeName, int nodeSize) {
            Node node = new Node(nodeName, nodeSize);
            addNode(node);
            return node;
        }

        public void addNode(Node node) {
            allNodes = Node.append(allNodes, node);
        }

        public void addEdge(Node parent, Node child) {
            for (int i = 0; i < parent.children.length; i++) {
                // ���ł� edge ������ꍇ�� return �B
                if (parent.children[i] == child)
                    return;
            }
            parent.children = Node.append(parent.children, child);
            child.parents = Node.append(child.parents, parent);
            parent.indexAtChildren = Node.append(parent.indexAtChildren,
                    child.parents.length - 1);
            child.indexAtParents = Node.append(child.indexAtParents,
                    parent.children.length - 1);
        }

        public void normalizeWeights() {
            for (int i = 0; i < allNodes.length; i++) {
                allNodes[i].normalizeWeights();
            }
        }


        /**
         * MPE �̔z���Ԃ��B�F���A���S���Y���̕]���p�B
         * ���ׂẲB��ϐ��� winnerID �̒l�̔z�������ĕԂ��B
         */
        public int[] getMPE(){
            Node[] hiddenNodes = getHiddenNodes();
            int[] mpe = new int[hiddenNodes.length];
            for (int i = 0; i < mpe.length; i++) {
                Node node = hiddenNodes[i];
                mpe[i] = node.winnerID;
                //System.out.println(node.winnerID);
            }
            return mpe;
        }
        //-----------------------------------------------------------------
        public void print() {

            //System.out.println("Net.print(): time="+ time);
            for (int i = 0; i < allNodes.length; i++) {
                Node node = allNodes[i];
                node.print();
            }
        }

        public String toString() {
            StringBuffer buf = new StringBuffer();
            for (int i = 0; i < allNodes.length; i++) {
                Node node = allNodes[i];
                buf.append(node.toString());
            }
            return buf.toString();
        }

        public String toCompactString() {
            StringBuffer buf = new StringBuffer();
            for (int i = 0; i < allNodes.length; i++) {
                Node node = allNodes[i];
                buf.append(node.toCompactString());
            }
            return buf.toString();
        }

        public String cptToString() {
            StringBuffer buf = new StringBuffer();
            for (int i = 0; i < allNodes.length; i++) {
                Node node = allNodes[i];
                buf.append(node.cptToString());
            }
            return buf.toString();
        }

        //-----------------------------------------------------------------
        // ���͂ƉB��ϐ��̒l�̑ΐ������m����Ԃ��B node.interpID ���e�m�[�h�̒l�Ƃ���B
        // P(X=xj|Uk=ui) == X.parents[k].weights[i][X.indexAtParents[k]][j]

        public float calcLikelihood(Net net, CPTmodelCode cptModelCode,
                WinRateCode winRateCode, ICACode icaCode) {
            float val = 0;
            for (int i = 0; i < this.allNodes.length; i++) {
                Node node = this.allNodes[i];
                if (!node.inputNodeFlag) { // �K�v�H
                    if (! net.noPenaltyFlag){
//                        val += -winRateC
//                        * (float)Math.log(node.winRates[node.interpID]);
                        float winRateP =
                                winRateCode.calcLogWinRatePenalty(node, node.interpID);
                        if (winRateP != winRateP) System.out.println("winRateP = NaN!");
                        icaCode.env.viewPanel.print1("winRateP", ""+ winRateP);
                        val += winRateP;
                    }
                }
                float pval = cptModelCode.calcCP(node);
                //System.out.println("pval="+ pval);
                Lab.assertTrue(1 >= pval && pval >= 0);
                val = logMul(val, pval);
            }
            if (! net.noPenaltyFlag){
                float icaP = icaCode.logPenalty(net);
                if (icaP != icaP) System.out.println("icaP = NaN!");
                icaCode.env.viewPanel.print1("icaP", ""+ icaP);
                val += icaP; // ���}���h�b�`
            }
            //System.out.println(val);
            return val;
        }

        public final float logMul(float val, float expVal) {
            //if (expVal < Lab.epsilon) System.out.println("expVal < Lab.epsilon");
            return (float) (val + Math.log(expVal)); // �ΐ��ǂ����̑����Z 
        }
    }
    

    public static class Node {
        /**
         * �m�[�h�̖��O�B�f�o�b�O�p�B
         */
        public String nodeName;

        /**
         * �m�[�h�̃T�C�Y�A���Ȃ킿���j�b�g�̐��B
         */
        public int nodeSize;

        /**
         * �����x wights[i][l][j] = P(ylj|xi)
         *  weights[nodeSize][children.length][sizeofYl]
         */
        public float[][][] weights;

        /**
         * Not used yet.
         * �p�~�\��B

         * �����x wightTs[i][k][j] = P(xi|ukj)
         *  weightTs[nodeSize][parents.length][sizeofUk]
         *  weights �̓]�u�s��B
         */
        //public float[][][] weightTs;

        public IncrementalSorter childEdges = new IncrementalSorter();
        public boolean[] validChildEdgeFlag;
        public boolean[] validParentEdgeFlag;
        public int numValidEdges = 10000; // �\���傫�Ȑ������Ă����B
        
        /**
         * U �����}�����󂯂�Z��m�[�h V �B�������g�͊܂܂Ȃ��B
         * lateralNodes[v]
         */
        public Node[] lateralNodes = new Node[0];

        /**
         * ���}���Ɏg�������t���m���B correlation[v][i][j] = P(ui|vj)
         * ���j�b�g ui �����j�b�g vj ����}�����󂯂�B
         */
        public float[][][] correlation;

        /**
         * �����t�̊����x�B conditionalActiveRate[v] = P(V��v��|U��u��)/s
         */
        public float[] conditionalActiveRate;
        
        public IncrementalSorter lateralEdges = new IncrementalSorter();

        public float sparseness = 0; // �p�~�\��
        public float winRateTarget = 0;

        public float lambda[]; // lambda[nodeSize]

        public float pi[]; // pi[nodeSize]

        public float rho[]; // rho[nodeSize]
        
        public float kappaUk[][]; // kappaUk[parents.length][nodeSize]

        public float bel[]; // bel[nodeSize]

        public float newLambda[]; // lambda[nodeSize]

        public float newPi[]; // pi[nodeSize]

        public float newRho[]; // rho[nodeSize] 

        public float newKappaUk[][]; // kappaUk[parents.length][nodeSize]

        public float newBel[]; // bel[nodeSize]

        //
        public float piYl[][]; // piYl[children.length][nodeSize]

        public float lambdaX[][]; // lambdaX[parents.length][sizeofUk]

        public float newPiYl[][]; // newPiYl[children.length][nodeSize]

        public float newLambdaX[][]; // newLambdaX[parents.length][sizeofUk]

        //
        public float tmpFloatVec[]; // tmpFloatVec[nodeSize]

        public int winnerID; // ���҃��j�b�g�iMAP���茋�ʁj�B���̓m�[�h�ɑ΂��Ă͓��͒l�B

        public int interpID; // �ޓx�v�Z�Ώۂ̉��߁B�e�F���A���S���Y�����g���ꎞ�ϐ��B

        public float erValue; // ���j�b�g�̏o�͒l 

        //
        /**
         * �Ǐ��w�K���B
         *  alpha[nodeSize]
         */
        public float alpha[];

        /**
         * ���җ��B P(X=xi)
         */
        public float winRates[]; // winRate[nodeSize]

        /**
         * P(X��x��) / s ���w�K�B s=nodeSize-1 �B�h�b�`�A���S���Y���Ŏg���B
         */
        public float activeRate;

        /**
         * �����m���v�Z�ɂ����ē������g�����ǂ����������t���O�B
         * validFeatureFlag[nodeSize][children.length]
         */
        public boolean[][] validFeatureFlag = null;

        /**
         * ���ʊ֌W�̋����Ń\�[�g���������i�q�m�[�h�j�̂h�c�̃��X�g�B
         * sortedFeatureID[nodeSize][children.length]
         */
        public int[][] sortedFeatureID;

        /**
         * �����̃X�R�A���\�[�g�����z��B�C���f�b�N�X�������������l���傫���B
         * sortedFeatureVal[nodeSize][children.length];
         */
        public float[][] sortedFeatureVal;

        /**
         * �q�m�[�h
         */
        public Node[] children = new Node[0];

        /**
         * �e�m�[�h�B
         */
        public Node[] parents = new Node[0];

        /**
         * node.indexAtParents[i] �́A node �̐e�m�[�h parents[i] ������
         * �z�� children �ɂ����� node �̃C���f�b�N�X�B
         *   node.parents[i].children[node.indexAtParents[i]] == node
         *   P(X=xi|Uk=uj) == X.parents[k].weights[j][X.indexAtParents[k]][i]
         *                 == X.weightTs[i][k][j]
         */
        public int[] indexAtParents = new int[0];

        /**
         * node.indexAtChildren[i] �́A node �̎q�m�[�h children[i] ������
         * �z�� parents �ɂ����� node �̃C���f�b�N�X�B
         *   node.children[i].parents[node.indexAtChildren[i]] == node
         *   P(Yl=yj|X=xi) == X.children[l].weightTs[j][X.indexAtChildren[l]][i]
         *                 == X.weights[i][l][j]
         */
        public int[] indexAtChildren = new int[0];

        /** 
         * �F�����Ɋϑ��f�[�^���^������m�[�h���ǂ�����\���t���O�B
         * ���̃t���O�� false �Ȃ�ΉB��m�[�h���Ӗ�����B
         */
        public boolean inputNodeFlag = false;
        /**
         * �摜���͂̍ۂ̑�O�w�̃m�[�h�B
         * net.analogInputFlag �� true �̂Ƃ��́A
         * �ϑ��l�Ƃ��ăs�N�Z���Z�x�����͂����B
         */
        public boolean analogInputNodeFlag = false;

        // �ȉ��Q�̕ϐ��� 2012-04 ���݁A�g���ĂȂ��B
        // ���ӂ̐��K�����f���̍Č��̗\�������Ŏg�����B
        public boolean rootNodeFlag = false;
        public float[] attentions = null; // attentions[nodeSize]

        // �Q�����r�n�l�p
        public int[][] unitID = null; // unitiD[nodeSizeY][nodeSizeX]
        
        // �����p
        public float[][] meanInputs;  // meanInput[nodeSize][inputDataSize]

        public Node(String nodeName, int nodeSize) {
            this.nodeName = nodeName;
            this.nodeSize = nodeSize;
        }

        public void makeMessageArray() {
            // ���b�Z�[�W�̋L����̊��蓖�āB
            lambda = new float[nodeSize];
            pi = new float[nodeSize];
            rho = new float[nodeSize];
            bel = new float[nodeSize];
            newLambda = new float[nodeSize];
            newPi = new float[nodeSize];
            newRho = new float[nodeSize];
            newBel = new float[nodeSize];
            //
            piYl = new float[children.length][];
            newPiYl = new float[children.length][];
            for (int l = 0; l < children.length; l++) {
                piYl[l] = new float[nodeSize];
                newPiYl[l] = new float[nodeSize];
            }
            kappaUk = new float[parents.length][];
            newKappaUk = new float[parents.length][];
            lambdaX = new float[parents.length][];
            newLambdaX = new float[parents.length][];
            for (int k = 0; k < parents.length; k++) {
                kappaUk[k] = new float[nodeSize];
                newKappaUk[k] = new float[nodeSize];
                lambdaX[k] = new float[parents[k].nodeSize];
                newLambdaX[k] = new float[parents[k].nodeSize];
            }
            //
            tmpFloatVec = new float[nodeSize];
            alpha = new float[nodeSize];
            Lab.initVec(alpha, 0.5f);
            winRates = new float[nodeSize];
            //Lab.initVec(winRates, 0.5f);
            // �����_���ɏ�����
            for (int i = 0; i < winRates.length; i++) {
                winRates[i] = 0.5f + Lab.rand() * 0.1f; 
            }
            // �f�t�H���g�ł͋ϓ��Ƃ���B
            winRateTarget = 1f / nodeSize;
            
            meanInputs = new float[nodeSize][];
        }

        // TODO: �����l�ɂ͑Ó��Ȓl������悤�ɋC�����邱�ƁI���͓K���B
        public void initMessages(Net net) {

            // �����_���Ȓl�ɏ������B
            if (net.analogInputFlag && this.analogInputNodeFlag){
                // Do nothing.
            } else {
                for (int i = 0; i < lambda.length; i++)
                    lambda[i] = messageInitVal();
            }
            for (int i = 0; i < rho.length; i++)
                rho[i] = messageInitVal();
            for (int i = 0; i < bel.length; i++)
                bel[i] = messageInitVal();

            for (int i = 0; i < piYl.length; i++) {
                for (int j = 0; j < piYl[i].length; j++) {
                    piYl[i][j] = messageInitVal();
                }
            }
            for (int i = 0; i < lambdaX.length; i++) {
                for (int j = 0; j < lambdaX[i].length; j++) {
                    lambdaX[i][j] = messageInitVal();
                }
            }
        }
        public float messageInitVal(){
            // �ǂ����������l���悢���͂܂��]�����ĂȂ��B
            if (true){
                return 0.99f + 0.01f * Lab.rand();
            } else {
                return Lab.rand();
            }
        }

        //-------------------------------------------------
        /**
         * �f�o�b�O�p�ɁA�m�[�h�̒��g��W���o�͂ɏo�́B
         */
        public void print() {
            if (children == null) {
                //// printCPT �̃{�^���������ƂQ��Ɉ�񂾂� print �����݂����B
                //Lab.paintln(this.activeRates);
                return;
            }

            System.out.print("nodeName=" + nodeName + ", children={");
            for (int i = 0; i < children.length; i++) {
                System.out.print(children[i].nodeName + " ");
            }
            System.out.print("}, parents={");
            for (int i = 0; i < parents.length; i++) {
                System.out.print(parents[i].nodeName + " ");
            }
            System.out.println("}");

            System.out.println("weights:");
            Lab.print(weights);
        }

        public String toString() {
            return toString(false);
        }

        public String toCompactString() {
            return toString(true);
        }

        public String toString(boolean compactFlag) {
            StringBuffer buf = new StringBuffer();
            if (children == null) {
                return "";
            }

            buf.append("nodeName=" + nodeName + ", children={");
            for (int i = 0; i < children.length; i++) {
                buf.append(children[i].nodeName + " ");
            }
            buf.append("}, parents={");
            for (int i = 0; i < parents.length; i++) {
                buf.append(parents[i].nodeName + " ");
            }
            buf.append("}");
            buf.append(Lab.lineSeparator);

            buf.append("weights:");
            buf.append(Lab.lineSeparator);
            //Lab.print(weights);
            if (compactFlag) {
                buf.append(Lab.toCompactString(weights));
            } else {
                buf.append(Lab.toString(weights));
            }
            return buf.toString();
        }

        /**
         * �����t�m���\���P�v�f�P�����̃R���p�N�g�ȕ�����ɕϊ��B
         * ���͂Əo�͂� winnerID ���\���B
         */
        public String cptToString() {
            if (children.length == 0)
                return "";

            StringBuffer buf = new StringBuffer();
            buf.append("nodeName=" + nodeName + ", children={");
            for (int i = 0; i < children.length; i++) {
                buf.append(children[i].nodeName + " ");
            }
            buf.append("}, parents={");
            for (int i = 0; i < parents.length; i++) {
                buf.append(parents[i].nodeName + " ");
            }
            buf.append("}");
            buf.append(Lab.lineSeparator);

            // lambda
            buf.append(" in=");
            for (int l = 0; l < children.length; l++) {
                for (int i = 0; i < children[l].lambda.length; i++) {
                    buf.append(Lab.toChar(children[l].lambda[i]));
                }
                buf.append(" ");
            }
            buf.append(Lab.lineSeparator);
            // winnerID
            buf.append("wID=");
            for (int l = 0; l < children.length; l++) {
                for (int j = 0; j < children[l].nodeSize; j++) {
                    if (children[l].winnerID == j) {
                        buf.append('*');
                    } else {
                        buf.append('.');
                    }
                }
                buf.append(" ");
            }
            buf.append(Lab.lineSeparator);

            // weights
            for (int i = 0; i < nodeSize; i++) {
                buf.append("U" + (i / 10 % 10) + (i % 10) + "=");
                for (int l = 0; l < children.length; l++) {
                    for (int j = 0; j < weights[i][l].length; j++) {
                        buf.append(Lab.toChar(weights[i][l][j]));
                    }
                    buf.append(" ");
                }
                if (winnerID == i) {
                    buf.append('*');
                } else {
                    buf.append('.');
                }
                buf.append(Lab.lineSeparator);
            }
            return buf.toString();
        }

        /**
         * �����z�� a �� n �����łɊ܂܂�Ă��Ȃ���� a �� n �ɒǉ������z�������ĕԂ��B 
         */
        public static Node[] addToSet(Node[] a, Node n) {
            for (int i = 0; i < a.length; i++) {
                if (a[i] == n)
                    return a;
            }
            return append(a, n);
        }

        public static Node[] append(Node[] a, Node n) {
            Node[] newA = new Node[a.length + 1];
            for (int i = 0; i < a.length; i++)
                newA[i] = a[i];
            newA[a.length] = n;
            return newA;
        }

        public static Node[] append(Node[] a, Node[] b) {
            Node[] newA = new Node[a.length + b.length];
            int j = 0;
            for (int i = 0; i < a.length; i++)
                newA[j++] = a[i];
            for (int i = 0; i < b.length; i++)
                newA[j++] = b[i];
            return newA;
        }

        public static int[] append(int[] a, int n) {
            int[] newA = new int[a.length + 1];
            for (int i = 0; i < a.length; i++)
                newA[i] = a[i];
            newA[a.length] = n;
            return newA;
        }

        /**
         *  �ݒ�ς݂� parents, children, nodeSize �ɏ]����
         *  weights, weightTs �ɔz������蓖�Ă�B
         */
        public void makeCPTarray() {
            weights = new float[nodeSize][][];
            //weightTs = new float[nodeSize][][];
            for (int i = 0; i < nodeSize; i++) {
                weights[i] = new float[children.length][];
                for (int l = 0; l < children.length; l++) {
                    weights[i][l] = new float[children[l].nodeSize];
                }
            }
        }

        // ������ weights �̒��g�𐳋K������B�B
        public void normalizeWeights() {
            for (int i = 0; i < weights.length; i++) {
                for (int l = 0; l < children.length; l++) {
                    Lab.normalizeVec(weights[i][l]);
                }
            }
        }


        // xxx �� newXXX �����ւ���B
        // �p�~���� swapLoopyMessageBuffers �Ɠ�������\��B
        public void swapApproxMessageBuffers() {
            float[] t;
            t = lambda;
            lambda = newLambda;
            newLambda = t;
            t = pi;
            pi = newPi;
            newPi = t;
            t = rho;
            rho = newRho;
            newRho = t;
            t = bel;
            bel = newBel;
            newBel = t;
        }

        public void swapLoopyMessageBuffers() {
            swapApproxMessageBuffers();
            float[][] t;
            t = piYl;
            piYl = newPiYl;
            newPiYl = t;
            t = lambdaX;
            lambdaX = newLambdaX;
            newLambdaX = t;
            t = kappaUk;
            kappaUk = newKappaUk;
            newKappaUk = t;
        }
    }

    //------------------------------------------
    // abstract classes
    /**
     * �x�C�W�A���l�b�g�̍\�z�B�b�o�s�̓���ꏊ�����B
     * �F���A���S���Y���]���c�[���Ŏg����B
     */
    public static abstract class InitNetCode extends Lab.Code {
        Net net;

        int inputNodeSize = panel.getInt("inputNodeSize", 10, 1, 30);
        int hiddenNodeSize = panel.getInt("hiddenNodeSize", 10, 1, 30);
        int nodeSize = panel.getInt("nodeSize", 4, 2, 30);
        int edgeNumber = panel.getInt("edgeNumber", 5, 1, 20); // �ő�q�m�[�h���B
        int numLayers = panel.getInt("numLayers", 2, 2, 10);
        // edgeNumber �̒l���X���C�_�ŕύX���Ă� rootPrior �̒l�͘A�����ĕς��Ȃ��̂Œ��ӁB
        float rootPrior = panel.getFloat("P(R=i)", 1f/nodeSize, 0f, 1f/(nodeSize - 1));

        public abstract Net makeNet();

        public Net makeUninitializedNet(int inputNodeSize, int hiddenNodeSize,
                int nodeSize) {
            NetCode netCode = new NetCode1(); // ���߂����ŃR�[�h�I�u�W�F�N�g�����B
            Net net = netCode.createEmptyNet();
            for (int i = 0; i < inputNodeSize; i++) {
                Node node = net.createNode("I" + i, nodeSize);
                node.inputNodeFlag = true;
            }
            for (int i = 0; i < hiddenNodeSize; i++) {
                Node node = net.createNode("H" + i, nodeSize);
            }
            return net;
        }
    }

    /**
     * CPT �̏������B
     */
    public static abstract class InitCPTCode extends Lab.Code {
        public abstract void initCPT(Net net);
    }

    /**
     * �l�o�d�̌v�Z�B
     */
    public static abstract class RecogCode extends Lab.Code {
        public CPTmodelCode cptModelCode;
        public WinRateCode winRateCode;
        public ICACode icaCode;

        public void inject(CPTmodelCode cptModelCode, WinRateCode winRateCode, ICACode icaCode) {
            this.cptModelCode = cptModelCode;
            this.winRateCode = winRateCode;
            this.icaCode = icaCode;
        }

        //public int[] mpe = null; // �F�����ʁB

        public int convergenceTime = 0; // �����X�e�b�v���B�U������ꍇ��  -1 �B

        public int usedTimeMillis = 0; // ���s�ɗv�������ԁB�i�]�����Ԃ́u�ɗ́v���������́B�j

        //Net net;
        public void updateParams() {
        }

        public void calcMPE(Net net) {
            calcMPEinit(net);
            calcMPEmain(net);
        }

        // TODO: init �� main �ɕ�����Ă���Ӗ��͂Ȃ��Ǝv���B init �͔p�~�B
        public abstract void calcMPEinit(Net net);

        public abstract void calcMPEmain(Net net);
        
        /**
         * winnerID �����܂����l�b�g���[�N����t�� BEL* �̒l�����߂�B
         * �m�[�h�� n �ɑ΂��� O(n^2) ���x�̌v�Z�ʁB
         */
        public void calcBELfromMPE(Net net){
            Node[] nodes = net.allNodes;
            for (int i = 0; i < nodes.length; i++) {
                nodes[i].interpID = nodes[i].winnerID;
            }
            for (int n = 0; n < nodes.length; n++) {
                Node node = nodes[n];
                if (! node.inputNodeFlag){ // �������̂��ߓ��̓m�[�h�͌v�Z���Ȃ����ƂɁB
                    for (int i = 0; i < node.nodeSize; i++) {
                        node.interpID = i;
                        node.bel[i] = net.calcLikelihood(net, cptModelCode, winRateCode, icaCode);
                        node.interpID = node.winnerID;
                    }
                    Lab.rescaleAndExp(node.bel);
                }
            }
        }
    }

    /**
     * �b�o�s���f���B
     *   P(x|u1, ..., um) = 1/m ��k w(x, uk) �Ƃ����`������B
     *   ���K���W�� m ���萔�ł��邱�Ƃ����肵�Ă���_�ɒ��ӁB
     *   calcCPT �́A�����Ȃl�o�d�v�Z��R�o��@�A�w�K���ʂ̑ΐ��ޓx�v�Z�Ŏg����B
     *   belief propagation ����� calcCPT ���g�킸���\�b�h w �𒼐ڌĂԁB
     */
    public static abstract class CPTmodelCode extends Lab.Code {
        /**
         * P(x|u1,...,um) = 1/m ��k w(x,uk) �̒l���v�Z�B 
         * x, u1, ..., um �̒l�� node.interpID �ŗ^����B
         * �G�b�W�I��Ή��B
         * ���K���W���͒萔 m �ł���Ɖ���B
         */
        public float calcCP(Node node) {
            float val = 0;
            int parentNum = 0;
            for (int k = 0; k < node.parents.length; k++) {
                if (node.validParentEdgeFlag[k]){
                    parentNum++;
                    //val += node.weightTs[node.interpID][k][node.parents[k].interpID];
                    val += w(node, node.interpID, k, node.parents[k].interpID);
                }
            }
            if (parentNum == 0){
//                if (node.interpID == 0){
//                    val = 1 - node.winRateTarget * (node.nodeSize - 1);
//                } else {
//                    val = node.winRateTarget;
//                }
                return WinRateCode.nodePrior(node, node.interpID);
            } else {
                // ���K���B
                return val / parentNum;
            }
        }

        /**
         * �m�[�h X �� w(x_i, u^k_j) ��Ԃ��B
         */
        public float w(Node node, int i, int k, int j){
            return wt(node.parents[k], j, node.indexAtParents[k], i);
        }
        /**
         * �m�[�h Yl �� w(y^l_j, x_i) ��Ԃ��B
         * w(node.children[l], j, node.indexAtChildren[l], i) �Ɠ����B
         */
        public abstract float wt(Node node, int i, int l, int j);
    }

    //------------------------------------------
    /**
     * �R�̔F���A���S���Y�������s�B���ʂ��o�́B���ʂ̒�ʓI�]���͂��������Ȃ��B
     * �P�߂ƂQ�߂̔F���A���S���Y���́A�قȂ郁�b�Z�[�W�����l�̂��Ƃ� try# ����s�B
     */
    public static class MainCompare3 extends Lab.MainCode {
        public InitNetCode initNetCode = panel.getCode("InitNetCode",
                InitNetCode.class, InitNetCode1.class);
        public InitCPTCode initCPTCode = panel.getCode("InitCPTCode",
                InitCPTCode.class, InitCPTCode1.class);
        public CPTmodelCode cptModelCode = panel.getCode("CPTmodelCode",
                CPTmodelCode.class, CPTsigma.class);
        public SelectEdgesCode selectEdgesCode = panel.getCode("SelectEdges",
                SelectEdgesCode.class);
        public RecogCode recogCode1 = panel.getCode("Recog. 1",
                RecogCode.class, RecogOOBP.class);
        public RecogCode recogCode2 = panel.getCode("Recog. 2",
                RecogCode.class, RecogLoopyBRlog.class);
        public RecogCode recogCode3 = panel.getCode("Recog. 3",
                RecogCode.class, RecogMPE.class);
        public void main() {
            //netCode.updateParams();
            Net net = initNetCode.makeNet();
            net.noPenaltyFlag = true;

            // CPT �̒l�̐ݒ�B
            //initCPTCode.net = net;
            initCPTCode.initCPT(net);
            if (panel.flag("Pr CPT"))
                net.print();

            // �G�b�W�I���֌W�̏�����
            selectEdgesCode.initChildEdges(net);
            this.updateNumValidEdges(net);
            selectEdgesCode.selectEdges(net); // �m�[�h�P��

            // �����_���Ȓl����́B
            Node[] inputNodes = net.getInputNodes();
            for (int i = 0; i < inputNodes.length; i++) {
                Node node = inputNodes[i];
                node.winnerID = Lab.irand(node.nodeSize);
            }

            //int tryNum = panel.getInt("try#", 3, 1, 20);
            int tryNum = panel.getInt("try#", 1, 1, 20);

            // MPE �v�Z�A���S���Y���̑I���B
            recogCode1.inject(cptModelCode, null, null);
            for (int trial = 0; trial < tryNum; trial++) {
                recogCode1.calcMPE(net);
                Lab.printArray("mpe1=", net.getMPE());
            }
            // MPE �v�Z�A���S���Y���̑I���B
            recogCode2.inject(cptModelCode, null, null);
            for (int trial = 0; trial < tryNum; trial++) {
                recogCode2.calcMPE(net);
                Lab.printArray("mpe2=", net.getMPE());
            }

            // �����l�o�d�v�Z
            recogCode3.inject(cptModelCode, null, null);
            recogCode3.calcMPE(net);

            Lab.printArray("mpe3=", net.getMPE());

        }
        public void updateNumValidEdges(Net net){
            int numValidEdges = panel.getInt("numValidEdges", 10, 1, 10);
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                node.numValidEdges = numValidEdges;
            }
        }
    }

    // ���w�l�b�g���[�N�̍\�z�B
    //   hiddenLayers x hiddenNodeSize �̉B��m�[�h�B
    // ��F
    //     hiddenLayers = 2,  hiddenNodeSize = 3, inputNodeSize = 3 ���ƁA
    //  H0 H1 H2
    //  H3 H4 H5
    //  I0 I1 I2
    // �Ƃ����K�w�\���ɂȂ�B
    public static class InitNetCode1 extends InitNetCode {
        public Net makeNet() {
            int hiddenLayers = numLayers - 1;
            Lab.assertTrue(hiddenLayers >= 1);
            // �l�b�g���[�N�̍쐬�B
            Net net = this.makeUninitializedNet(inputNodeSize, hiddenNodeSize
                    * hiddenLayers, nodeSize);
            Node[][] layers = new Node[hiddenLayers + 1][];
            Node[] hiddenNodes = net.getHiddenNodes();
            for (int i = 0; i < layers.length - 1; i++) {
                Node[] layer = new Node[hiddenNodeSize];
                for (int j = 0; j < hiddenNodeSize; j++) {
                    layer[j] = hiddenNodes[i * hiddenNodeSize + j];
                }
                layers[i] = layer;
            }
            layers[layers.length - 1] = net.getInputNodes();

            // �G�b�W�𒣂�B

            if (panel.flag("Connect Full")) {
                for (int i = 0; i < layers.length - 1; i++) {
                    for (int j = 0; j < layers[i].length; j++) {
                        for (int k = 0; k < layers[i + 1].length; k++) {
                            net.addEdge(layers[i][j], layers[i + 1][k]);
                        }
                    }
                }
            } else {
                // �e�m�[�h���� edgeNumber �{�����_���Ɏq�m�[�h�ƃG�b�W���͂�B
                // �e�m�[�h�̐e�m�[�h�̐��͂O�`�������A�q�m�[�h�̐��͍ő� edgeNumber �{�ɂȂ�B
                for (int i = 0; i < layers.length - 1; i++) {
                    for (int j = 0; j < layers[i].length; j++) {
                        for (int k = 0; k < edgeNumber; k++) {
                            net.addEdge(layers[i][j], layers[i + 1][Lab
                                    .irand(layers[i + 1].length)]);
                        }
                    }
                }
            }

            // �G�b�W�ɑΉ�����b�o�s�̓���ꏊ�����蓖�āB
            for (int i = 0; i < net.allNodes.length; i++) {
                net.allNodes[i].makeCPTarray();
                net.allNodes[i].makeMessageArray();
            }
            for (int n = 0; n < net.allNodes.length; n++) {
                Node node = net.allNodes[n];
                node.winRateTarget = rootPrior;
            }
            //net.print();
            return net;
        }
    }

    public static class InitCPTCode1 extends InitCPTCode {
        public void updateParams() {
        }

        public void initCPT(Net net) {
            for (int i = 0; i < net.allNodes.length; i++) {
                setRandomCPT(net.allNodes[i]);
            }
        }

        public void setRandomCPT(Node node) {
            for (int i = 0; i < node.nodeSize; i++) {
                for (int l = 0; l < node.children.length; l++) {
                    for (int j = 0; j < node.children[l].nodeSize; j++) {
                        node.weights[i][l][j] = Lab.rand() + 0.1f;
                    }
                    Lab.normalizeVec(node.weights[i][l]);
                }
            }
        }
    }

    public static class InitCPTCodeSparseCPT extends InitCPTCode {
        public void updateParams() {
        }

        public void initCPT(Net net) {
            for (int i = 0; i < net.allNodes.length; i++) {
                setRandomSparseCPT(net.allNodes[i]);
            }
        }

        // �X�p�[�X�Ȃb�o�s
        public void setRandomSparseCPT(Node node) {
            for (int i = 0; i < node.nodeSize; i++) {
                for (int l = 0; l < node.children.length; l++) {
                    for (int j = 0; j < node.children[l].nodeSize; j++) {
                        // �X�p�[�X�ɁB
                        //weights[i][l][j] = Lab.rand() * Lab.rand() + 0.01f;
                        // �b�o�s�̒l�Ƀo�C�A�X�������Ă݂�B
                        // ���̓m�[�h���O�����₷������B
                        if (j == 0) {
                            if (Lab.rand() < 0.3f) {
                                node.weights[i][l][j] = 0.01f;
                            } else {
                                node.weights[i][l][j] = 1f;
                            }
                        } else {
                            node.weights[i][l][j] = Lab.rand() * 0.2f + 0.01f;
                        }
                    }
                    Lab.normalizeVec(node.weights[i][l]);
                }
            }
        }
    }

    /**
     * �Ǐ����̃e�X�g�p�B���ׂẴm�[�h�̂b�o�s�𓯂��l�ɐݒ�B 
     */
    public static class InitCPTCodeSymmetric extends InitCPTCode {
        public void updateParams() {
        }

        public void initCPT(Net net) {
            for (int i = 0; i < net.allNodes.length; i++) {
                setCPT(net.allNodes[i]);
            }
        }

        public void setCPT(Node node) {
            for (int i = 0; i < node.nodeSize; i++) {
                for (int l = 0; l < node.children.length; l++) {
                    node.weights[i][l][0] = i == 0 ? 1 : 0.1f;
                    for (int j = 1; j < node.children[l].nodeSize; j++) {
                        node.weights[i][l][j] = i == 0 ? 0.1f : 1;
                    }
                    Lab.normalizeVec(node.weights[i][l]);
                }
            }
        }
    }


    public static class CPTsigma extends CPTmodelCode {
//        public float w(Node node, int i, int k, int j) {
//            return node.weightTs[i][k][j];
//        }
        public float wt(Node node, int i, int l, int j){
            return node.weights[i][l][j];
        }
    }

    /**
     * ���K���s�v�� meanOR ���f���B 
     * 2012-10-03 ��
    P(x|u1,...,um) = 1/m ��k w(x,uk)
    w(x��,u��)=1/(s+1)
    w(xi,u��)=1/(s+1)
    w(x��,uj)=P(x��|uj)
    w(xi,uj)=P(xi|uj)
     */
    public static class CPTmeanOR extends CPTmodelCode {
        public float wt(Node node, int i, int l, int j) {
            if (i == 0) {
                return 1f / node.children[l].nodeSize;
            } else {
                return node.weights[i][l][j];
            }
        }
    }



    public static abstract class AbstractBR extends RecogCode {
        // ���b�Z�[�W�`�d�̉�
        public int iterTimes;

        public Node[] hiddenNodes;

        // TODO: calcMPEinit �͔p�~�\��B
        // calcMPEmain �̐擪�Ɉړ����ׂ��B
        public void calcMPEinit(Net net) {
            sigmaRescaleFlag = panel.flag("Sigma rescale", true);
            hiddenNodes = net.getHiddenNodes();
            for (int i = 0; i < hiddenNodes.length; i++) {
                hiddenNodes[i].winnerID = -1;
            }
            if (panel.flag("Init messages every time", true)){
                for (int i = 0; i < net.allNodes.length; i++) {
                    net.allNodes[i].initMessages(net);
                }
            }
        }

        public boolean sigmaRescaleFlag;

        // TODO: �e�X�g�p�z��𖈉� new ���Ă���B�g���񂵂����B
        public void calcMPEmain(Net net) {
            bpFlag = panel.flag("BP", true);
            iterTimes = panel.getInt("iterTimes", 10, 1, 100);
            boolean plotLflag = panel.flag("Plot L for each step");
            boolean changedFlag = true; // �X�e�b�v���s��A�l���ς��� true �ɁB
            int[] h = new int[hiddenNodes.length];
            h[0] = -1; // dummy. �ŏ��̂P�X�e�b�v�̎��s��ɕK�� h �̒l���ς��悤�ɂ��邽�߁B
            this.convergenceTime = -1; // ���������Ǝv���鎞�_�ł̃X�e�b�v���B
            this.usedTimeMillis = 0;
            for (int c = 0; c < iterTimes; c++) { // �Ƃ肠�����萔�񃋁[�v
                env.checkStop();
                long startTime = System.currentTimeMillis();
                this.oneStep(net);
                this.usedTimeMillis += (int) (System.currentTimeMillis() - startTime);

                if (panel.flag("Pr Msgs")) {
                    System.out.println("BR:c=" + c);
                    for (int i = 0; i < net.allNodes.length; i++) {
                        Node node = net.allNodes[i];
                        Lab.printCompact("bel=", node.bel);
                        Lab.printArray("rho=", node.rho);
                        Lab.printArray("lambda=", node.lambda);
                        Lab.printArray("pi=", node.pi);
                        for (int k = 0; k < node.lambdaX.length; k++) {
                            Lab.printArray(" lambdaX[" + k + "]=",
                                    node.lambdaX[k]);
                        }
                        for (int l = 0; l < node.piYl.length; l++) {
                            Lab.printArray(" piYl[" + l + "]=", node.piYl[l]);
                        }
                        System.out.println(" " + node.nodeName + "="
                                + Lab.argmax(node.bel));
                    }
                    System.out.println();
                }
                // �����X�e�b�v���̔���B
                boolean someValueChanged = false;
                for (int i = 0; i < h.length; i++) {
                    int max = Lab.argmax(hiddenNodes[i].bel);
                    if (h[i] != max)
                        someValueChanged = true;
                    h[i] = max;
                    hiddenNodes[i].interpID = max; // �ΐ��ޓx�o�͂̂��߁B
                }
                Node[] inputNodes = net.getInputNodes();
                for (int i = 0; i < inputNodes.length; i++) {
                    // �ΐ��ޓx�o�͂̂��߂� interpID ��ݒ�B
                    // ���� loopy BR �A���S���Y���͖��X�e�b�v interpID ���󂵂Ă��܂��̂Œ��ӁB
                    inputNodes[i].interpID = inputNodes[i].winnerID;
                }
                //this.mpe = h; // �e�R�[�h���g���B
                if (panel.flag("Pr h")) {
                    Lab.printArray("   h=", h);
                }
                if (someValueChanged == false) {
                    if (changedFlag == true) {
                        convergenceTime = c;
                    }
                } else {
                    convergenceTime = -1;
                }
                changedFlag = someValueChanged;

                //                for (int i = 0; i < net.allNodes.length; i++) {
                //                    Node node = net.allNodes[i];
                //                    System.out.print(node.nodeName+":"+ node.interpID+ ",");
                //                }
                //                System.out.println();
                if (plotLflag) {
                    float logL = net.calcLikelihood(net, this.cptModelCode,
                            winRateCode, icaCode);
                    //System.out.println(" L=" + logL);
                    //lab.viewPanel.println(" L=", ""+ net.calcLikelihoodSigma());
                    env.viewPanel.linePlot(this.getClass().getName()
                            + " Log likelihood " + tryID, c, logL);
                }
            }
            //System.out.println("convergenceTime="+ convergenceTime);
            //lab.viewPanel.println("convergenceTime:", ""+convergenceTime);
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                if (!node.inputNodeFlag) {
                    node.winnerID = Lab.argmax(node.bel);
                }
            }
            tryID++;
        }

        public static int tryID = 0; // �ΐ��ޓx�̃O���t�𕪂��邽�߂̂h�c�B

        public abstract void oneStep(Net net);

        // �Ή����Ă���F���A���S���Y���̓�����a�q����a�o�ɐ؂�ւ���B
        public boolean bpFlag;
        public float maxOrSigma(float[] vec){
            if (bpFlag){
                float sum = 0;
                for (int i = 0; i < vec.length; i++) {
                    sum += vec[i];
                }
                return sum;
            } else {
                return Lab.max(vec);
            }
        }

        /*
         * �����t���m����p���鑤�}���h�b�`�Ή��ŁB���}�����b�Z�[�W�̑ΐ���Ԃ��B  
         * ��S12(x1) = ��_x2 S(x1,x2)BEL(x2)
         * ���̃��\�b�h�� RecogOOBP �Ȃǂ���g����B
         */
        public float calcLogLateralInhibition(Node node, int i) {
            int numEdge = Lab.min(icaCode.numValidLateralEdge, node.lateralNodes.length); 

            float logLateralInhibition = 0;
            for (int r = 0; r < numEdge; r++) {
                int vID = node.lateralEdges.ids[r];
                Node lateralNode = node.lateralNodes[vID];
                float tmpVal;
                if (bpFlag){
                    tmpVal = 0;
                } else {
                    tmpVal = -1f / 0; // -Infinity
                }
                for (int j = 0; j < lateralNode.nodeSize; j++) {
                    float val = (float)Math.exp(icaCode.logS(node, i, vID, j))
                              * lateralNode.bel[j];
                    if (bpFlag){
                        tmpVal += val;
                    } else {
                        if (val > tmpVal) {
                            tmpVal = val;
                        }
                    }
                }
                logLateralInhibition += Math.log(tmpVal);
            }
            // System.out.println(penalty);
            return logLateralInhibition;
        }
    }
    
    /**
     * �œK���a�o�B�e�m�[�h�̐����\�������Ƃ��������u������ O(m) �œ���B 
     * explaining away ���N���₷���Ȃ邱�Ƃ��˂炤�B
     * �G�b�W�I�� �Ή����݁B
     * �e�m�[�h k �q�m�[�h l �ɑ΂��邷�ׂẴ��[�v�� valid �ȃG�b�W���ǂ����`�F�b�N���Ă���B
     * �������F  max-pooling �� �� ���̂����ł͐��x���o�ĂȂ��B
     * maxPoolingFlag == true �Ȃ�΃�Yl(x) �̌v�Z�� sigma �ł͂Ȃ� max ���g���B 
     */
    public static class RecogOOBP extends RecogABRlog {
        public boolean maxPoolingFlag = panel.flag("Max-pooling");
        // ���b�Z�[�W�`�d���P�X�e�b�v���s�B
        public void oneStep(Net net) {
            lateralInhibition = panel.flag("lateralInhibition", true);
            for (int i = 0; i < net.allNodes.length; i++) {
                this.oneStepApproxBR(net.allNodes[i], net);
            }
            for (int i = 0; i < net.allNodes.length; i++) {
                //net.allNodes[i].swapApproxMessageBuffers();
                net.allNodes[i].swapLoopyMessageBuffers();
            }
        }
        public void oneStepApproxBR(Node node, Net net) {
            if (node.inputNodeFlag) {
                for (int i = 0; i < node.nodeSize; i++) {
                    float z;
                    if (node.analogInputNodeFlag && net.analogInputFlag) {
                        Lab.assertTrue(node.children.length == 0);
                        // Do nothing. 
                        // node.newLambda[i] should be input value.
                        z = node.newLambda[i];
                    } else {
                        z =  i == node.winnerID ? 1 : 0;
                        node.newLambda[i] = z;
                    }
                    for (int l = 0; l < node.children.length; l++) {
                        if (node.validChildEdgeFlag[l]) {
                            node.newPiYl[l][i] = z;
                        }
                    }
                }
            } else {
//                // �Ӓl���j�b�g���g��Ȃ��ꍇ�͂O�����Ă����B
//                if (startUnit == 1){
//                    node.newBel[0] = node.newLambda[0] = node.newRho[0] = node.newPi[0] = 0;
//                }
                calcLambda(net, node);
            }
            int s0 = node.inputNodeFlag ? 0 : startUnit;
            calcPi(net, node, s0);
            
            for (int i = s0; i < node.nodeSize; i++) {
                node.newBel[i] = node.newRho[i] 
                   = node.newLambda[i] * node.newPi[i];
            }
            if (sigmaRescaleFlag) {
                Lab.normalizeVec(node.newBel);
            } else {
                Lab.rescaleVec(node.newBel);
            }
        }
        public void calcLambda(Net net, Node node){
            node.newLambda[0] = Float.NEGATIVE_INFINITY;
            for (int i = startUnit; i < node.nodeSize; i++) {
                float tmpLambda = 0;
                for (int l = 0; l < node.children.length; l++) {
                    if (node.validChildEdgeFlag[l]) {
                        node.children[l].tmpFloatVec[0] = 0;
                        int s0 = node.children[l].inputNodeFlag ? 0 : startUnit;
                        for (int j = s0; j < node.children[l].nodeSize; j++) {
                            float w;
//                            w = cptModelCode.w(node.children[l], j,
//                                    node.indexAtChildren[l], i);
                            w = cptModelCode.wt(node, i, l, j);
                            float kappaUk
                            = node.children[l].kappaUk[node.indexAtChildren[l]][j]; 
                            node.children[l].tmpFloatVec[j] 
                                = node.children[l].lambda[j] *
                                (node.children[l].pi[j]
                                    - kappaUk 
                                    + w);
                        }
                        //
                        float lambdaYlx;
                        if (maxPoolingFlag){ // test
                            lambdaYlx = Lab.max(node.children[l].tmpFloatVec);
                        } else {
                            lambdaYlx= maxOrSigma(node.children[l].tmpFloatVec);
                        }
                        node.newPiYl[l][i] = 1f / lambdaYlx;
                        tmpLambda += (float)Math.log(lambdaYlx);
                    }
                }
                if (!node.inputNodeFlag) { // ���̍s�A����Ȃ��̂ł́H
                    tmpLambda += - node.sparseness; // �p�~�\��B
                    if (! net.noPenaltyFlag){
                        tmpLambda += winRateCode.calcLogWinRatePenalty(node, i);
                        if (lateralInhibition) {
                            tmpLambda += calcLogLateralInhibition(node, i);
                        }
                    }
                }
                node.newLambda[i] = tmpLambda;
            }
            // newLambda �� rescale ������� log ����{���̒l�ɖ߂� �B
            Lab.rescaleAndExp(node.newLambda);
        }
        public void calcPi(Net net, Node node, int s0){
            for (int i = s0; i < node.nodeSize; i++) {
                int parentNum = 0;
                float tmpPi = 0;
                for (int k = 0; k < node.parents.length; k++) {
                    if (node.validParentEdgeFlag[k]) {
                        parentNum++;
                        node.parents[k].tmpFloatVec[0] = 0;
                        for (int j = startUnit; j < node.parents[k].nodeSize; j++) {
                            float w = cptModelCode.w(node, i, k, j);
                            //node.parents[k].tmpFloatVec[j]
                            //               = w * node.parents[k].bel[j];
                            // 
//                            float piXuk = node.parents[k].bel[j] 
//                                        / node.lambdaX[k][j];
                            float piXuk
                              = node.parents[k].piYl[node.indexAtParents[k]][j];
                            node.parents[k].tmpFloatVec[j]
                                       = w * piXuk;
                        }
                        float kappaUk = maxOrSigma(node.parents[k].tmpFloatVec);
                        node.newKappaUk[k][i] = kappaUk;
                        tmpPi += kappaUk;
                    }
                }
                if (parentNum == 0) {
                    // root node �̎��O���z
                    tmpPi = WinRateCode.nodePrior(node, i);
                }
                node.newPi[i] = tmpPi;
                for (int l = 0; l < node.children.length; l++) {
                    // ���F newPiYl �� calcLambda �ŏ��������݁B
                    node.newPiYl[l][i] *= node.newLambda[i];
                    node.newPiYl[l][i] *= tmpPi;
                }
            }
            // newPiYl �𐳋K���B
            for (int l = 0; l < node.children.length; l++) {
                if (node.validChildEdgeFlag[l]) {
                    if (sigmaRescaleFlag){
                        Lab.normalizeVec(node.newPiYl[l]);
                    } else {
                        Lab.rescaleVec(node.newPiYl[l]);
                    }
                }
            }
        }
    
    }


    /**
     * ���`���Ԃœ��삷��ߎ��a�q�B lambda �̌v�Z�ɂ͑ΐ����g�p�B
     * �i�q�m�[�h�̐��������Ă��I�[�o�[�t���[�E�A���_�[�t���[���ɂ������邽�߁B�j
     * �G�b�W�I��Ή��B 
     * �B��m�[�h�̃Ӓl���j�b�g�͖�������@�\������B�i���゠�܂�g��Ȃ��\��B�j
     */
    public static class RecogABRlog extends AbstractBR {
        public boolean lateralInhibition; // debug �p�B�p�~�\��H

        /**
         * ���b�Z�[�W�v�Z�ɂ����ăӒl�������ꍇ�� 1, �����ꍇ�� 0 �B 
         * ���̓m�[�h�ɑ΂��Ă͎g��Ȃ��悤�ɒ��ӁB
         * �i���゠�܂�g��Ȃ��\��B�j
         */
        public int startUnit = panel.flag("No phi-value", false) ? 1 : 0;

        // ���b�Z�[�W�`�d���P�X�e�b�v���s�B
        public void oneStep(Net net) {
            lateralInhibition = panel.flag("lateralInhibition", true);
            for (int i = 0; i < net.allNodes.length; i++) {
                this.oneStepApproxBR(net.allNodes[i], net);
            }
            for (int i = 0; i < net.allNodes.length; i++) {
                net.allNodes[i].swapApproxMessageBuffers();
            }
        }
        public void oneStepApproxBR(Node node, Net net) {
            if (node.inputNodeFlag) {
                if (node.analogInputNodeFlag && net.analogInputFlag) {
                    Lab.assertTrue(node.children.length == 0);
                    // Do nothing. 
                    // node.newLambda[i] should be input value.
                } else {
                    for (int i = 0; i < node.nodeSize; i++) {
                        node.newLambda[i] = i == node.winnerID ? 1 : 0;
                    }
                }
            } else {
//                // �Ӓl���j�b�g���g��Ȃ��ꍇ�͂O�����Ă����B
//                if (startUnit == 1){
//                    node.newBel[0] = node.newLambda[0] = node.newRho[0] = node.newPi[0] = 0;
//                }
                calcLambda(net, node);
            }
            int s0 = node.inputNodeFlag ? 0 : startUnit;
            calcPi(net, node, s0);
            
            for (int i = s0; i < node.nodeSize; i++) {
                node.newBel[i] = node.newRho[i] 
                   = node.newLambda[i] * node.newPi[i];
            }
            if (sigmaRescaleFlag) {
                // System.out.println("rescale pi");
                Lab.normalizeVec(node.newPi); // �s�v�H
                // System.out.println("rescale bel");
                Lab.normalizeVec(node.newBel);
            } else {
                // System.out.println("rescale pi");
                Lab.rescaleVec(node.newPi); // �s�v�H
                // System.out.println("rescale bel");
                Lab.rescaleVec(node.newBel);
            }
        }
        // �ΐ���
        public void calcLambda(Net net, Node node){
            node.newLambda[0] = Float.NEGATIVE_INFINITY;
            for (int i = startUnit; i < node.nodeSize; i++) {
                float tmpLambda = 0;
                for (int l = 0; l < node.children.length; l++) {
                    if (node.validChildEdgeFlag[l]) {
                        node.children[l].tmpFloatVec[0] = 0;
                        int s0 = node.children[l].inputNodeFlag ? 0 : startUnit;
                        for (int j = s0; j < node.children[l].nodeSize; j++) {
                            float w;
                            // w = node.weights[i][l][j];
//                            w = cptModelCode.w(node.children[l], j,
//                                    node.indexAtChildren[l], i);
                            w = cptModelCode.wt(node, i, l, j);
                            node.children[l].tmpFloatVec[j] 
                                = node.children[l].rho[j]
                                    + node.children[l].lambda[j] * w;
                        }
                        tmpLambda += (float)Math.log(maxOrSigma(node.children[l].tmpFloatVec));
                    }
                }
                if (!node.inputNodeFlag && i != 0) {
                    tmpLambda += - node.sparseness;
                    if (! net.noPenaltyFlag){
//                        tmpLambda += - net.winRateC * Math.log(node.winRates[i]);
                        tmpLambda += winRateCode.calcLogWinRatePenalty(node, i);
                        if (lateralInhibition) {
                            tmpLambda += calcLogLateralInhibition(node, i);
                        }
                    }
                }
                node.newLambda[i] = tmpLambda;
            }
            //System.out.println("begin:"+ node.nodeName);
            // System.out.println("rescale lambda");
            //Lab.rescaleVec(node.newLambda);
            Lab.rescaleAndExp(node.newLambda);
            //System.out.println("end:"+ node.nodeName);
        }
        public void calcPi(Net net, Node node, int s0){
            for (int i = s0; i < node.nodeSize; i++) {
                int parentNum = 0;
                float tmpPi = 0;
                for (int k = 0; k < node.parents.length; k++) {
                    if (node.validParentEdgeFlag[k]) {
                        parentNum++;
                        node.parents[k].tmpFloatVec[0] = 0;
                        for (int j = startUnit; j < node.parents[k].nodeSize; j++) {
                            float w = cptModelCode.w(node, i, k, j);
                            node.parents[k].tmpFloatVec[j]
                               = w * node.parents[k].bel[j];
                        }
                        tmpPi += maxOrSigma(node.parents[k].tmpFloatVec);
                    }
                }
                if (parentNum == 0) {
                    // root node �̎��O���z
//                    if (i == 0){
//                        tmpPi = 1 - node.winRateTarget * (node.nodeSize - 1);
//                    } else {
//                        tmpPi = node.winRateTarget;
//                    }
                    tmpPi = WinRateCode.nodePrior(node, i);
                }
                node.newPi[i] = tmpPi;
            }
        }

        /*
         * ��S12(x1) = ��_x2 S(x1,x2)BEL(x2)
         */
        public float calcLateralInhibitionOld(Node node, int i) {
            if (node.lateralNodes == null)
                return 0; // ���̓m�[�h�Ȃ�
            if (i == 0)
                return 0; // �Ӓl�͖����B

            if (icaCode.numValidLateralEdge > node.lateralNodes.length) {
//                System.out.println("node.lateralNodes.length="
//                        + node.lateralNodes.length);
                icaCode.numValidLateralEdge = node.lateralNodes.length;
            }

            float penalty = 0;
            // for (int v = 0; v < node.correlation.length; v++) {
            for (int r = 0; r < icaCode.numValidLateralEdge; r++) {
                int v = node.lateralEdges.ids[r];
                Node lateralNode = node.lateralNodes[v];
                float[][] col = node.correlation[v];
                // �Ӓl�͖����B
                float ret;
                if (bpFlag){
                    ret = 0;
                } else {
                    ret = -1f / 0;
                }
                for (int j = 1; j < col[i].length; j++) {
                    float c = col[i][j];
                    float target = node.conditionalActiveRate[v]
                            / (col[i].length - 1);
                    float val = (c - target) * lateralNode.bel[j];
                    if (bpFlag){
                        ret += val;
                    } else {
                        if (val > ret) {
                            ret = val;
                        }
                    }
                }
                penalty += ret;
            }
            // System.out.println(penalty);
            return penalty;
        }
    }


    /**
     * loopy belief revision �̑f���Ȏ����A�������Z�̈ꕔ�ɑΐ����g�p�B
     * �A�i���O���͂ɂ͖��Ή��B
     * TODO: �G�b�W�I���ɖ��Ή��B �� ���Ƃ܂킵�B
     * �ŐV�̑��}���ɑΉ����݁B�i�e�X�g�s�\���B�j
     * sparseness �͑Ή����݁B(�Â�) 
     */
    public static class RecogLoopyBRlog extends AbstractBR {
        public void calcMPE(Net net) {
            super.calcMPE(net);
        }

        // ���b�Z�[�W�`�d���P�X�e�b�v���s�B
        public void oneStep(Net net) {
            for (int i = 0; i < net.allNodes.length; i++) {
                oneStepLoopyBR(net, net.allNodes[i]);
            }
            for (int i = 0; i < net.allNodes.length; i++) {
                net.allNodes[i].swapLoopyMessageBuffers();
            }
        }
        public void oneStepLoopyBR(Net net, Node node) {
            if (node.inputNodeFlag) {
                //Lab.assertTrue(net.analogInputFlag == false); // ���Ή�
                for (int i = 0; i < node.nodeSize; i++) {
                    // X �����̓m�[�h���Ƃ���ƁA
                    //  ��(x) = ��Z(x) �ƂȂ�B
                    // ��Z(x) �ɂ��Ă� [Pearl 1988] p.256 �Q�ƁB
                    int z =  i == node.winnerID ? 1 : 0;
                    node.newLambda[i] = z;
                    float pi = calcPi(node, i);
                    node.newBel[i] = node.newRho[i] = node.newLambda[i] * pi;
                    for (int l = 0; l < node.children.length; l++) {
                        node.newPiYl[l][i] = z;
                    }
                }
            } else {
                for (int i = 0; i < node.nodeSize; i++) {
                    float val = 0;
                    for (int l = 0; l < node.children.length; l++) {
                        val += (float)Math.log(node.children[l].lambdaX[node.indexAtChildren[l]][i]);
                    }
                    if (!node.inputNodeFlag && i != 0) {
                        //val *= (float) Math.exp(-node.sparseness);
                        val += penalty(net, node, i);
                    }
                    node.newLambda[i] = val;
                }
                Lab.rescaleAndExp(node.newLambda);
                
                for (int i = 0; i < node.nodeSize; i++) {
                    // newRho �̓e�X�g�ɂ̂ݎg���B
                    float pi = calcPi(node, i);
                    node.newBel[i] = node.newRho[i] = node.newLambda[i] * pi;
                    for (int l = 0; l < node.children.length; l++) {
                        float val = (float)Math.log(pi);
                        for (int j = 0; j < node.children.length; j++) {
                            if (j != l) {
                                val += (float)Math.log(node.children[j].lambdaX[node.indexAtChildren[j]][i]);
                            }
                        }
                        if (!node.inputNodeFlag) {
                            //val *= (float) Math.exp(-node.sparseness);
                            val += penalty(net, node, i);
                        }
                        node.newPiYl[l][i] = val;
                        //System.out.println(nodeName+ ":piYl["+ l + "]");
                    }
                }
                for (int l = 0; l < node.children.length; l++) {
                    // �����ł� sigmaRescaleFlag �����ĂȂ��B�ǂ���ł��֌W�Ȃ��͂��B
                    Lab.rescaleAndExp(node.newPiYl[l]);
                }
            }
            
            //System.out.println(nodeName+ ":bel");
            if (sigmaRescaleFlag) {
                Lab.normalizeVec(node.newBel);
            } else {
                Lab.rescaleVec(node.newBel);
            }

            for (int k = 0; k < node.parents.length; k++) {
                for (int ukID = 0; ukID < node.parents[k].nodeSize; ukID++) {
                    env.checkStop();
                    node.newLambdaX[k][ukID] = calcLambdaX(node, k, ukID);
                    //newLambdaX[k][ukID] = calcLambdaXapprox(k, ukID);
                }
                //System.out.println(nodeName+ ":lambdaX["+ k + "]");
                Lab.rescaleVec(node.newLambdaX[k]);
            }
        }

        // returns max_X ��(x) max P(x|u1,...,um)��i��k ��(ui)
        public float calcLambdaX(Node node, int k, int ukID) {
            float ret = 0;
            for (int i = 0; i < node.nodeSize; i++) {
                node.interpID = i;
                resetParentsInterpID(node);
                boolean endFlag = false;
                while ((!endFlag) && (!skipUkID(node, k, ukID))) {
                    float val = calcLambdaX1(node, k);
                    if (bpFlag){
                        ret += val;
                    } else {
                        if (val > ret) {
                            ret = val;
                        }
                    }
                    endFlag = incParentsInterpID(node);
                }
            }
            return ret;
        }

        public float calcLambdaX1(Node node, int xk) {
            Lab.assertTrue(node.parents.length != 0);
            float val = calcCP(node);
            for (int k = 0; k < node.parents.length; k++) {
                if (k != xk) {
                    val *= node.parents[k].piYl[node.indexAtParents[k]][node.parents[k].interpID];
                }
            }
            return node.newLambda[node.interpID] * val;
        }

        public float calcPi(Node node, int unitID) {
            resetParentsInterpID(node);
            node.interpID = unitID;
            float ret = 0;
            boolean endFlag = false;
            while (!endFlag) {
                float val = calcPi1(node);
                if (bpFlag){
                    ret += val;
                } else {
                    if (val > ret) {
                        ret = val;
                    }
                }
                endFlag = incParentsInterpID(node);
            }
            return ret;
        }

        // returns P(xi|u1,...um)��k ��X(uk) 
        public float calcPi1(Node node) {
            //Lab.assertTrue(node.parents.length != 0);
            float val = calcCP(node);
            for (int k = 0; k < node.parents.length; k++) {
                val *= node.parents[k].piYl[node.indexAtParents[k]][node.parents[k].interpID];
            }
            return val;
        }

        // returns P(xi|u1,...,um)
        public float calcCP(Node node) {
            return cptModelCode.calcCP(node);
        }

        public void resetParentsInterpID(Node node) {
            for (int k = 0; k < node.parents.length; k++) {
                node.parents[k].interpID = 0;
            }
        }

        public boolean skipUkID(Node node, int k, int ukID) {
            while (node.parents[k].interpID != ukID) {
                if (incParentsInterpID(node))
                    return true;
            }
            return false;
        }

        public boolean incParentsInterpID(Node node) {
            return incParentsInterpIDRec(node, 0);
        }

        public boolean incParentsInterpIDRec(Node node, int k) {
            if (k == node.parents.length)
                return true;
            if (incParentsInterpIDRec(node, k + 1)) {
                node.parents[k].interpID++;
                if (node.parents[k].interpID == node.parents[k].nodeSize) {
                    node.parents[k].interpID = 0;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
        
        // lambda, PiYl �Ɋ|����y�i���e�B�� log �ŕԂ��B
        public float penalty(Net net, Node node, int i){
            float val = 0;
            if (! net.noPenaltyFlag){
//                val += - net.winRateC * Math.log(node.winRates[i]);
                val += winRateCode.calcLogWinRatePenalty(node, i);
//                val += -icaCode.icaC
//                * calcLateralInhibition(node, i);
                val += calcLogLateralInhibition(node, i); 
            }
            return val;
        }
    }
    
    
    /** 
     * MPE ��T���B O(2^n) �̃A���S���Y���B
     *  �m�[�h�Ɂu���߁v�i�l�o�d���ƂȂ�ϐ��̒l�j����������B
     *  inputNode �ȊO�̉��߂����Ԃɓ������Ă����A���ׂẲ��߂̖ޓx���v�Z�B
     *  winnerID ���A���̎��_�ōł��ޓx�̍������߁B�ŏI�I��MPE�ɂȂ�B
     *  interpID �́A�ޓx���v�Z���悤�Ƃ�����߁B
     */
    public static class RecogMPE extends RecogCode {
        // net �̕ϐ��ւ̃A�N�Z�X���y�ɂ��邽�߁A�l���C���X�^���X�ϐ��ɃR�s�[����B
        // �^�X�N���ς���Ă����̃C���X�^���X�͐V���� new ����Ȃ��̂Œ��ӁB
        // oneStep ���Ă΂�邽�я��������邱�Ƃɂ���B
        public Node[] hiddenNodes; // hidden variables

        public Net net;

        public void calcMPEinit(Net net) {
        }
        public void calcMPEmain(Net net) {
            if (panel.flag("Test MPE and MPM", false)){ // test
                calcMPM(net);
                Lab.printArray("MPM=", net.getMPE());
                calcMPE1(net);
                Lab.printArray("MPE=", net.getMPE());
            } else {
                if (panel.flag("BP")){
                    calcMPM(net);
                } else {
                    calcMPE1(net);
                }
            }
        }

        // �m�[�h���Ƃ̎��ӎ���m���������v�Z����B
        // �I�[�o�[�t���[�E�A���_�[�t���[�A���Z�덷�̋��ꂪ����̂Œ��ӁB
        public void calcMPM(Net net) {
            //Lab.assertTrue(net.analogInputFlag == false);
            this.net = net;
            hiddenNodes = net.getHiddenNodes();
            long startTime = System.currentTimeMillis();
            
            for (int n = 0; n < hiddenNodes.length; n++) {
                Node node = hiddenNodes[n];
                Lab.initVec(node.bel, 0);
            }

            resetInterp();
            boolean endFlag = false;
            //System.out.println("Start loop:"); // for debug
            while (!endFlag) {
                env.checkStop();
                //printInterp();  // for debug
                // �ΐ������m��
                float logVal = net.calcLikelihood(net, this.cptModelCode, 
                        winRateCode, icaCode);
                float val = (float)Math.exp(logVal);
                for (int n = 0; n < hiddenNodes.length; n++) {
                    Node node = hiddenNodes[n];
                    node.bel[node.interpID] += val;
                }
                endFlag = incInterp();
            }
            for (int n = 0; n < hiddenNodes.length; n++) {
                Node node = hiddenNodes[n];
                Lab.normalizeVec(node.bel); // �A���_�[�t���[�E�I�[�o�[�t���[�`�F�b�N�B
                node.winnerID = Lab.argmax(node.bel);
            }
            this.usedTimeMillis = (int) (System.currentTimeMillis() - startTime);
//            mpe = new int[hiddenNodes.length];
//            for (int i = 0; i < mpe.length; i++) {
//                Node node = hiddenNodes[i];
//                mpe[i] = node.winnerID;
//                //System.out.println(node.winnerID);
//            }
            if (panel.flag("Pr L")) {
                System.out.println(" L="+ "not implemented");
                //env.viewPanel.plot("L", maxVal);
            }
        }

        public void calcMPE1(Net net) {
            //Lab.assertTrue(net.analogInputFlag == false);
            this.net = net;
            hiddenNodes = net.getHiddenNodes();
            long startTime = System.currentTimeMillis();

            // MPE ��I���B winnerID ��ݒ�B
            resetInterp();
            updateMPE(); // val �� -Inf �ł����Ƀ��[�v�𔲂���ꍇ������B
            float maxVal = -Float.MAX_VALUE; // likelihood
            //System.out.println("maxVal="+ maxVal);
            boolean endFlag = false;
            //System.out.println("Start loop:"); // for debug
            while (!endFlag) {
                env.checkStop();
                //printInterp();  // for debug
                // �ޓx�v�Z
                float val = net.calcLikelihood(net, this.cptModelCode, 
                        winRateCode, icaCode);
                //System.out.println("val="+ val);
                if (val > maxVal) {
                    //System.out.println("updateMPE!val="+ val+ ", maxVal="+ maxVal);
                    updateMPE();
                    maxVal = val;
                }
                endFlag = incInterp();
            }
            this.usedTimeMillis = (int) (System.currentTimeMillis() - startTime);
            //printWinnerID(); System.out.println("--");
            //            for (int i = 0; i < net.allNodes.length; i++) {
            //                Node node = net.allNodes[i];
            //                System.out.print(node.nodeName+":"+ node.interpID+ ",");
            //            }
//            mpe = new int[hiddenNodes.length];
//            for (int i = 0; i < mpe.length; i++) {
//                Node node = hiddenNodes[i];
//                mpe[i] = node.winnerID;
//                //System.out.println(node.winnerID);
//            }

            calcBELfromMPE(net);
            if (panel.flag("Pr L")) {
                System.out.println(" L="+ maxVal);
                //env.viewPanel.plot("L", maxVal);
            }
        }

        //int c = 0; // for scatterPlot of "L" 
        public void resetInterp() {
            for (int i = 0; i < hiddenNodes.length; i++)
                hiddenNodes[i].winnerID = -1;
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                if (node.inputNodeFlag) {
                    // winnerID �͐ݒ�ς݂Ƃ���B�����ς��Ȃ��B
                    node.interpID = node.winnerID;
                } else {
                    node.interpID = 0;
                }
            }
        }

        public void updateMPE() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                hiddenNodes[i].winnerID = hiddenNodes[i].interpID;
            }
        }

        // ���̉��߂ɕς���B���ׂẲ��߂̒T�����I�������ꍇ�� true ��Ԃ��B
        public boolean incInterp() {
            return incInterpRec(0);
        }

        // �u�J��オ��v������� true ��Ԃ��B
        public boolean incInterpRec(int i) {
            if (i == hiddenNodes.length)
                return true;
            if (incInterpRec(i + 1)) {
                hiddenNodes[i].interpID++;
                if (hiddenNodes[i].interpID == hiddenNodes[i].nodeSize) {
                    hiddenNodes[i].interpID = 0;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        // �f�o�b�O�p
        public void printInterp() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                System.out.print(hiddenNodes[i].nodeName + " = "
                        + hiddenNodes[i].interpID + ", ");
            }
            System.out.println();
        }

        public void printWinnerID() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                System.out.print("winnerID:" + hiddenNodes[i].nodeName + " = "
                        + hiddenNodes[i].winnerID + ", ");
            }
            System.out.println();
        }

    }

    /**
     * �R�o��@
     */
    public static class RecogHill extends RecogCode {
        // net �̕ϐ��ւ̃A�N�Z�X���y�ɂ��邽�߁A�l���C���X�^���X�ϐ��ɃR�s�[����B
        // �^�X�N���ς���Ă����̃C���X�^���X�͐V���� new ����Ȃ��̂Œ��ӁB
        // oneStep ���Ă΂�邽�я��������邱�Ƃɂ���B
        Node[] hiddenNodes; // hidden variables

        Net net;

        public void calcMPEinit(Net net) {
        }

        public void calcMPEmain(Net net) {
            //Lab.assertTrue(net.analogInputFlag == false);
            this.net = net;
            hiddenNodes = net.getHiddenNodes();

            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                if (node.inputNodeFlag) {
                    node.interpID = node.winnerID;
                }
            }
            if (panel.flag("Reset interpID every time", true)){
                for (int i = 0; i < hiddenNodes.length; i++) {
                    //hnodes[i].interpID = 0;
                    // �����l���I�[���Ӓl�̏�Ԃ��ƁA�� meanOR �̎R�o��̂P�X�e�b�v�ڂɂ�����
                    //������J�ڌ��̃X�R�A���O�ɂȂ鎖�Ԃ���������B
                    // ���������邽�߂ɏ����l���I�[���P�̏�Ԃ���͂��߂�B
                    hiddenNodes[i].interpID = 1;
                    //hnodes[i].interpID = Util.irand(hnodes[i].nodeSize);
                    //hnodes[i].interpID = Util.irand(hnodes[i].nodeSize - 1)+1;
                }
            }
            float maxVal = net.calcLikelihood(net, cptModelCode, 
                    winRateCode, icaCode);
            while (true) {
                env.checkStop();
                float val = climb(hiddenNodes);
                //System.out.println(newP);
                if (!(val > maxVal))
                    break;
                maxVal = val;
            }
            updateMPE();
            calcBELfromMPE(net);
            //printWinnerID(); System.out.println("--");
//            mpe = new int[hiddenNodes.length];
//            for (int i = 0; i < mpe.length; i++) {
//                Node node = hiddenNodes[i];
//                mpe[i] = node.winnerID;
//                //System.out.println(node.winnerID);
//            }
            if (panel.flag("Pr L")) {
                System.out.println(" L="+ maxVal);
                //env.viewPanel.plot("L", maxVal);
            }
        }

        public float climb(Node[] hnodes) {

            int maxNode = -1;
            int maxUnit = -1;
            //float maxScore = -Float.MAX_VALUE; // �����m���i�ɔ�Ⴗ��l�j�B
            float maxScore = Float.NEGATIVE_INFINITY; // �����m���i�ɔ�Ⴗ��l�j�B
            for (int nodeID = 0; nodeID < hnodes.length; nodeID++) {
                Node node = hnodes[nodeID];
                int oldInterpID = node.interpID;
                for (int unitID = 0; unitID < node.nodeSize; unitID++) {
                    //for (int unitID = 1; unitID < node.nodeSize; unitID++){
                    node.interpID = unitID;
                    float val = net.calcLikelihood(net, cptModelCode,
                            winRateCode, icaCode);
                    //System.out.println(val);
                    //if (val > maxScore) {
                    if (val >= maxScore) {
                        maxScore = val;
                        maxNode = nodeID;
                        maxUnit = unitID;
                    }
                    node.interpID = oldInterpID;
                }
            }

            hnodes[maxNode].interpID = maxUnit;
            return maxScore;
        }

        public void updateMPE() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                hiddenNodes[i].winnerID = hiddenNodes[i].interpID;
            }
        }

        // �f�o�b�O�p
        public void printInterp() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                System.out.print(hiddenNodes[i].nodeName + " = "
                        + hiddenNodes[i].interpID + ", ");
            }
            System.out.println();
        }

        public void printWinnerID() {
            for (int i = 0; i < hiddenNodes.length; i++) {
                System.out.print("winnerID:" + hiddenNodes[i].nodeName + " = "
                        + hiddenNodes[i].winnerID + ", ");
            }
            System.out.println();
        }
    }


    /**
     * �_�~�[�B�Ȃɂ��v�Z���Ȃ��B 
     */
    public static class RecogNull extends RecogMPE {
        public void calcMPE(Net net) {
            Node[] hiddenNodes = net.getHiddenNodes();
            for (int i = 0; i < hiddenNodes.length; i++) {
                hiddenNodes[i].winnerID = -1;
            }
            int[] mpe = new int[hiddenNodes.length];
            for (int i = 0; i < mpe.length; i++) {
                mpe[i] = -1; // dummy
            }
            // Do nothing.
        }
    }

    //-----------------------------------------------------------------------
    public static class MainAutoEvalBR extends Lab.MainCode {
        public String[] paramNames = { "edgeNumber", "layerNodeSize",
                "hiddenNodeSize", "nodeSize", "numLayers", };

        public String paramName;

        public int paramBegin;

        public int paramEnd;

        public int paramStep;

        public void updateParams() {
            paramName = (String) panel
                    .getSelectedValue("paramName", paramNames);
            paramBegin = panel.getInt("begin", 1, 1, 20);
            paramEnd = panel.getInt("end", 15, 1, 20);
            paramStep = panel.getInt("step", 1, 1, 20);
        }

        {
            updateParams();
        }

        // �܂��� inner panel �𐶐����邽�߂� getCode ����B
        MainEvalRecog currentCode = panel.getCode("EvalCode",
                MainEvalRecog.class, MainEvalRecog1.class);

        public void main() {
            env.viewPanel.println("log", "" + new Date());
            env.viewPanel.println("log", "randState=" + Lab.randState);
            if (paramName.equals("numLayers") && paramBegin < 2) {
                env.viewPanel.println("log",
                        "Warning: paramBegin for numLayers is less than 2."
                                + "paramBegin is set to 2.");
                paramBegin = 2;
            }
            env.viewPanel.println("log", "Start.");
            //            for (int i = 6; i < 8; i++) {
            //                currentCode.panel.getCode("InitNetCode")
            //                  .panel.setInt("hiddenNodeSize", i);
            //                currentCode.main();
            //            }
            //int begin = 1;
            //int end = 15;
            ////float[] vals = new float[paramEnd];
            for (int i = paramBegin; i <= paramEnd; i += paramStep) {
                if (paramName.equals("layerNodeSize")) {
                    currentCode.panel.getCode("InitNetCode", InitNetCode.class).panel
                            .setInt("inputNodeSize", i);
                    currentCode.panel.getCode("InitNetCode", InitNetCode.class).panel
                            .setInt("hiddenNodeSize", i);
                } else {
                    currentCode.panel.getCode("InitNetCode", InitNetCode.class).panel
                            .setInt(this.paramName, i);
                    //currentCode.initNetCode.panel.setInt(this.paramName, i);
                }
                // �ēx getCode ���Ȃ������Ƃ� currentCode �̃C���X�^���X����蒼���B
                // �C���X�^���X���������ɐݒ肵���l���ǂ݂��܂��͂��B
                currentCode = panel.getCode("EvalCode", MainEvalRecog.class);
                currentCode.main();
                //vals[i] = currentCode.correctRate;
                env.viewPanel.linePlotFixedY("correctRate", i,
                        currentCode.correctRate, 0, 1);
                env.viewPanel.linePlotFixedY("convergenceRate", i,
                        currentCode.convergenceRate, 0, 1);
                env.viewPanel.linePlot("convergenceTime", i,
                        currentCode.convergenceTime);
                env.viewPanel.linePlot("usedTimeMillis", i,
                        currentCode.usedTimeMillis);
            }
            System.out.println("Result:");
            //            for (int i = paramBegin; i < paramEnd; i += paramStep) {
            //                System.out.println(i+ " "+ vals[i]);
            //            }
            env.viewPanel.println("log", "End.");
        }
    }

    /**
     *  �F���A���S���Y���̕]���c�[�� 
     */
    public static abstract class MainEvalRecog extends Lab.MainCode {
        // �X���C�_�̒l�̃Z�b�g�̂��� MetaCode ����A�N�Z�X�����B
        public InitNetCode initNetCode = panel.getCode("InitNetCode",
                InitNetCode.class, InitNetCode1.class);
        public InitCPTCode initCPTCode = panel.getCode("InitCPTCode",
                InitCPTCode.class, InitCPTCode1.class);
        public CPTmodelCode cptModelCode = panel.getCode("CPTmodelCode",
                CPTmodelCode.class, CPTsigma.class);
        public SelectEdgesCode selectEdgesCode = panel.getCode("SelectEdges",
                SelectEdgesCode.class);

        public float correctRate; // �]���l�B MetaCode ����A�N�Z�X�����B

        public float convergenceTime; // �]���l�B MetaCode ����A�N�Z�X�����B

        public float convergenceRate; // �]���l�B MetaCode ����A�N�Z�X�����B

        public float usedTimeMillis; // �]���l�B MetaCode ����A�N�Z�X�����B
    }

    /**
     * IJCNN 2011 �̘_���Ɏg�����]���c�[���B
     * �Q�̃A���S���Y���̌��ʂ��r�B������J�Ԃ��āA�]���l�̕��ϒl���v�Z�B 
     */
    public static class MainEvalRecog1 extends MainEvalRecog {
//        {
//            initNetCode = panel.getCode("InitNetCode", InitNetCode.class,
//                    InitNetCode1.class);
//        }

        public void main() {
            int tryNum = panel.getInt("try#", 3, 1, 20);
            // ���𗦌v�Z�p�B
            int correctVals = 0;
            int totalVals = 0;
            // �������v�Z�p�B
            int convergedNum = 0;
            // ���ώ����X�e�b�v���v�Z�p�B
            int totalSteps = 0;
            // ���ώ��s���Ԍv���p�B
            int totalUsedTimeMillis = 0;

            for (int trial = 0; trial < tryNum; trial++) {
                env.viewPanel.print1("trial", "" + trial);
                //netCode.updateParams();
                Net net = initNetCode.makeNet();
                net.noPenaltyFlag = true;

                // CPT �̒l�̐ݒ�B
//                InitCPTCode initCPTCode = panel.getCode("InitCPTCode",
//                        InitCPTCode.class, InitCPTCode1.class);
                initCPTCode.initCPT(net);
                if (panel.flag("Pr CPT")) {
                    env.viewPanel.setText("CPT", "");
                    env.viewPanel.print("CPT", net.toString());
                    env.viewPanel.setText("CPT(compact)", "");
                    env.viewPanel.print("CPT(compact)", net.toCompactString());
                }

                // �G�b�W�I���֌W�̏�����
                selectEdgesCode.initChildEdges(net);
                this.updateNumValidEdges(net);
                selectEdgesCode.selectEdges(net); // �m�[�h�P��

                // �����_���Ȓl����́B
                Node[] inputNodes = net.getInputNodes();
                for (int i = 0; i < inputNodes.length; i++) {
                    Node node = inputNodes[i];
                    node.winnerID = Lab.irand(node.nodeSize);
                }

                // CPT model �̐ݒ�B
//                CPTmodelCode cptModelCode = panel.getCode("CPTmodelCode",
//                        CPTmodelCode.class, CPTsigma.class);

                // MPE �v�Z�A���S���Y���̑I���B
                RecogCode recognitionCode1 = panel.getCode("Recog. 1",
                        RecogCode.class, RecogABRlog.class);
                recognitionCode1.inject(cptModelCode, null, null);
                recognitionCode1.calcMPE(net);
                //int[] calcedMPE = recognitionCode1.mpe;
                int[] calcedMPE = net.getMPE();
                Lab.printArray("mpe1=", calcedMPE);
                if (recognitionCode1.convergenceTime != -1) {
                    convergedNum++;
                    totalSteps += recognitionCode1.convergenceTime;
                }
                totalUsedTimeMillis += recognitionCode1.usedTimeMillis;

                // �������̌v�Z
                RecogCode recognitionCode2 = panel.getCode("Recog. 2",
                        RecogCode.class, RecogMPE.class);
                recognitionCode2.inject(cptModelCode, null, null);
                recognitionCode2.calcMPE(net);
                //int[] strictMPE = recognitionCode2.mpe;
                int[] strictMPE = net.getMPE();
                Lab.printArray("mpe2=", strictMPE);

                // ���𗦂�]���B
                Lab.assertTrue(strictMPE.length == calcedMPE.length);
                for (int i = 0; i < strictMPE.length; i++) {
                    if (strictMPE[i] == calcedMPE[i])
                        correctVals++;
                    totalVals++;
                }
            }
            this.correctRate = (correctVals + 0.0f) / totalVals;
            System.out.println("correctRate=" + this.correctRate);
            this.convergenceRate = (convergedNum + 0.0f) / tryNum;
            System.out.println("convergenceRate=" + this.convergenceRate);
            if (convergedNum == 0) {
                this.convergenceTime = -1; // �C�t�����ɂ��̂܂܃O���t�ɂ��Ȃ��悤���ӁE�E�E�B
            } else {
                this.convergenceTime = (totalSteps + 0.0f) / convergedNum;
            }
            System.out.println("convergenceTime=" + this.convergenceTime);
            this.usedTimeMillis = (totalUsedTimeMillis + 0.0f) / tryNum;
            System.out.println("usedTimeMillis=" + this.usedTimeMillis);
        }
        public void updateNumValidEdges(Net net){
            int numValidEdges = panel.getInt("numValidEdges", 10, 1, 10);
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                node.numValidEdges = numValidEdges;
            }
        }
    }

    // ----------------------------------------------------------------

    // Learning
    public static abstract class LearnCode extends Lab.Code {
        public BlurCode blurCode;
        public NetCode netCode;
        public SelectEdgesCode selectEdgesCode;

        public void inject(BlurCode blurCode, NetCode netCode,
                SelectEdgesCode selectEdgesCode) {
            this.blurCode = blurCode;
            this.netCode = netCode;
            this.selectEdgesCode = selectEdgesCode;
        }

        public abstract void learn(Net net);
    }
    

    /**
     *  �Ӓl���j�b�g�����ʂɊw�K����o�[�W�����B�i�ߖT�w�K�̑Ώۂɂ͂Ȃ�Ȃ��B�j 
     */
    public static class Learn2 extends LearnCode {
        public void learn(Net net) {
            Node[] nodes = net.allNodes;
            for (int i = 0; i < nodes.length; i++) {
                learn(net, nodes[i]);
            }
        }

        public void learn(Net net, Node node) {
            if (node.children.length == 0)
                return;
            int winnerID = node.winnerID;
            float winnerAlpha = node.alpha[winnerID];
            float rZn = calcRZn(blurCode, winnerAlpha, winnerID, node.nodeSize,
                    node.nodeSize);
            for (int unitID = 0; unitID < node.nodeSize; unitID++) {
                float dx = unitID - winnerID;
                if (dx < 0) dx = -dx;
                float n;
                if (winnerID == 0) {
                    // ���҃��j�b�g���Ӓl�̂Ƃ��͋ߖT�w�K���Ȃ��B
                    if (unitID == 0){
                        n = 1;
                    } else {
                        n = 0;
                    }
                } else {
                    if (unitID == 0) {
                        n = 0;
                    } else {
                        n = rZn * blurCode.neighborFunc(winnerAlpha, dx,
                                        node.nodeSize);
                        Lab.assertTrue(n >= 0);
                        //System.out.println(n);
                    }
                }
                // �w�K���ő��؂�B
                if (n < Lab.epsilon) {
                    // Do nothing.
                } else {
                    float learningRate = winnerAlpha * n; // �w�K��
                    learn1unit(net, node, winnerAlpha, unitID, dx, learningRate);
                }
            }
        }

        private void learn1unit(Net net, Node node, float winnerAlpha,
                int unitID, float dx, float learningRate) {
            for (int l = 0; l < node.children.length; l++) {
                float[] weightVec = node.weights[unitID][l];
                // winner �̏��҂̋ߖT�� MPE �̒l���ڂ����Ċw�K
                Node child = node.children[l];

                int cWinner = child.winnerID;
                float rZb;
                if (cWinner == 0) {
                    rZb = -1; // dummy 
                } else {
                    rZb = calcRZb(blurCode, winnerAlpha, dx, cWinner,
                            child.nodeSize, child.nodeSize, node.nodeSize);
                }
                float totalWeight = 0;
                // ��Ӓl�� targetID �ɑ΂��Ă̂݊w�K�B
                for (int targetID = 1; targetID < weightVec.length; targetID++) {
                    float v; // target value v_j^l
                    if (net.analogInputFlag && child.analogInputNodeFlag){
                        v = child.lambda[1];
                    } else {
                        if (cWinner == 0) {
                            // cWinner �� 0 �i�Ӓl�j�̂Ƃ��͂ڂ����Ȃ��B
                            v = 0;
                        } else {
                            float dy = targetID - cWinner;
                            if (dy < 0)
                                dy = -dy;

                            v = rZb
                                    * blurCode.blurFunc(winnerAlpha, dx, dy,
                                            child.nodeSize);
                            Lab.assertTrue(v >= 0);
                    }
                    }
                    float w = weightVec[targetID];
                    w = w + learningRate * (v - w);
                    if (w < 0)
                        w = 0;
                    totalWeight += w;
                    weightVec[targetID] = w;

                }
                if (totalWeight >= 1)
                    totalWeight = 1;
                weightVec[0] = 1 - totalWeight;
            }
        }

        // ���K���萔 Zb �̋t����Ԃ��B
        // scale �̓X�P�[���p�����^�i�Q�����r�n�l�̏ꍇ�͒Z�ӂ̃T�C�Y�H�A s �͑S���j�b�g���j
        public float calcRZb(BlurCode somFunc, float alpha, float dx,
                float yWinner, int scale, int s, int nodeSize) {
            float total = 0;
            for (int i = 1; i < s; i++) {
                float dy = i - yWinner;
                if (dy < 0)
                    dy = -dy;
                total += somFunc.blurFunc(alpha, dx, dy, scale);
            }
            Lab.assertTrue(total > Lab.epsilon);
            //// �d�݂̍Œ�l * nodeSize = Net.mininumCP * 2 �������Ă����B 
            //return (1 - Net.mininumCP * 2 * nodeSize) / total;
            return 1 / total;
        }

        // ���K���萔 Zn �̋t����Ԃ��B �� �Œ�l�P��Ԃ��B 
        public float calcRZn(BlurCode somFunc, float alpha, float xWinner,
                int scale, int s) {
            return 1;
        }
    }

    public static abstract class BlurCode extends Lab.Code {
        NetCode netCode;

        public void inject(NetCode netCode) {
            this.netCode = netCode;
        }

        // s �̓X�P�[���p�����^�B�P�����r�n�l�̏ꍇ��  nodeSize �A�Q�����r�n�l�̏ꍇ�͒Z�ӂ̃T�C�Y�H
        public abstract float blurFunc(float alpha, float dx, float dy,
                int scale);

        public abstract float neighborFunc(float alpha, float dx, int scale);

        // �Q�����r�n�l�ɑΉ����邽�߂̃C���^�[�t�F�[�X�B
        public int nX, nY, uX, uY;

        // �ߖT���a�� [0,1] �͈̔͂ŕԂ��B
        public float radius(float alpha) {
            return alpha;
        }

        public void resetPos(Net net, int nX, int nY, int uX, int uY,
                float alpha) {
            System.out.println("Not implemented.");
        }

        public boolean nextPos() {
            System.out.println("Not implemented.");
            return false;
        }
    }

    public static class BlurGauss extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            //return g(dy, alpha * s + 0.5f);
            return g(dy, alpha * s + 1);
        }

        public float neighborFunc(float alpha, float dx, int s) {
            //return g(dx, alpha * s + 0.5f);
            return g(dx, alpha * s + 1);
        }

        public float g(float x, float sigma) {
            return (float) Math.exp(-x * x / (2 * sigma * sigma));
        }
    }

    public static class Blur20100721 extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            return dy < 1 ? 1 : 0;
            //return smoothStep(dy, alpha * s + 2, alpha);
            //return smoothStep(dy, alpha * s * 3f + 0.0f, alpha);
        }

        public float neighborFunc(float alpha, float dx, int s) {
            //return smoothStep(dx, alpha * s + 2, alpha);
            //return smoothStep(dx, alpha * s + 2f, alpha);
            return smoothStep(dx, alpha * s + 1f, alpha);
        }

        public float smoothStep(float d, float r, float alpha) {
            float ret;
            if (d < 1) {
                ret = 1; // r �������������ׂĂ̒l���O�ɂȂ�̂������B
            } else {
                // +-------+--+---> d
                // 0      r-1 r
                // <-- 1 -->  <-- 0 --
                //         <--> r-d
                if (d < r) {
                    if (d < r - 1) {
                        ret = 1;
                    } else {
                        // ���E��B
                        ret = r - d;
                    }
                } else {
                    ret = 0;
                }
            }
            return ret;
        }
    }

    public static class BlurSmoothStep extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            return smoothStep(dy, alpha * s + 2, alpha);
        }

        public float neighborFunc(float alpha, float dx, int s) {
            return smoothStep(dx, alpha * s + 2, alpha);
        }

        public float smoothStep(float d, float r, float alpha) {
            float ret;
            if (d < 1) {
                ret = 1; // r �������������ׂĂ̒l���O�ɂȂ�̂������B
            } else {
                // +-------+--+---> d
                // 0      r-1 r
                // <-- 1 -->  <-- 0 --
                //         <--> r-d
                if (d < r) {
                    if (d < r - 1) {
                        ret = 1;
                    } else {
                        // ���E��B
                        ret = r - d;
                    }
                } else {
                    ret = 0;
                }
            }
            // �Œ�l�� 0.5*alpha �Ƃ���B���̕Ԓl������ɐ��K�������B
            //return ret + 0.5f * alpha + Net.mininumCP;
            // �o�O�����I�Ԓl���P�𒴂��邪�A���͋ߖT�֐��̐��K������߂Ă���̂�Y��Ă����B
            // TODO: �ߖT�֐��̍ő�l���P�ɂȂ�悤�ɃX�P�[����������R�[�h�������B
            // �Ƃ肠�����A ���� ret ��Ԃ��悤�ɖ߂����B
            return ret;
        }
    }

    public static class BlurStep extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            return step(dy, alpha * s + 2);
        }

        public float neighborFunc(float alpha, float dx, int s) {
            return step(dx, alpha * s + 2);
        }

        public float step(float d, float r) {
            if (d < 1)
                return 1; // ���ׂĂ̒l���O�ɂȂ�̂������B
            if (d < r) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    public static class BlurNoBlur extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            return dy < 1 ? 1 : 0;
        }

        public float neighborFunc(float alpha, float dx, int s) {
            return g(dx, alpha * s + 2);
        }

        public float g(float x, float sigma) {
            return (float) Math.exp(-x * x / (2 * sigma * sigma));
        }
    }

    public static class VQ extends BlurCode {
        public float blurFunc(float alpha, float dx, float dy, int s) {
            if (dy < 1) {
                return 1;
            } else {
                return 0;
            }
        }

        public float neighborFunc(float alpha, float dx, int s) {
            if (dx < 1) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    public static abstract class WinRateCode extends Lab.Code {
        /**
         * �����y�i���e�B�̋����B
         * �i�m�[�h���Ƃɐݒ�ł���悤�ɂ��Ȃ��Ă������̂��H�j
         */
        public float winRateC;
        public void inject() {
        }

        public abstract void updateWinRates(Net net);
        public abstract float calcLogWinRatePenalty(Node node, int i);
        
        /**
         * �z�� nodes �Ɋ܂܂��e�m�[�h��  winRateTarget �̒l��ݒ肷��B
         * ���҂ɂȂ��Ӓl���j�b�g�̐������ς��� activeNodes �ɂȂ�悤�Ȓl�ɐݒ�B
         */
        public static final void setWinRateTargets(Node[] nodes, float activeNodes){
            if (activeNodes > nodes.length) activeNodes = nodes.length; 
            float t = activeNodes / countNonPhiUnits(nodes);
            for (int i = 0; i < nodes.length; i++) {
                nodes[i].winRateTarget = t;
            }
        }
        public static final int countNonPhiUnits(Node[] nodes){
            int c = 0;
            for (int i = 0; i < nodes.length; i++) {
                c += nodes[i].nodeSize - 1;
            }
            return c;
        }
        /**
         * �m�[�h X �̎��O���z  P(X=i) �B
         * root node �̎��O���z��A�X�p�[�X�������E���}���h�b�`�̖ڕW�l�v�Z�ŗp������B 
         */
        //TODO: �ڕW�l�ł͂Ȃ��A�w�K�œ������ۂ̒l�̕����悢�̂ł͂Ȃ����B
        // �����y�i���e�B�v�Z�ł͖ڕW�l�A root node, ���}���h�b�`�ł͎����l�ɂ��ׂ��B
        public static float nodePrior(Node node, int i){
            if (i == 0){
                float ret = 1 - node.winRateTarget * (node.nodeSize - 1);
                //Lab.assertTrue(Math.abs(ret + node.winRateTarget * (node.nodeSize - 1) - 1) < Lab.epsilon);
                Lab.assertTrue(0 <= ret && ret <= 1);
                return ret;
            } else {
                return node.winRateTarget;
            }            
        }
    }

    /**
     *  �����m�[�h���X���C�_���g�����V�����X�p�[�X�������Ή��ŁB
     *  TODO: �ߖT�w�K�Ή��B
     *  XXX: �Ӓl���j�b�g�̊w�K���͔�Ӓl���j�b�g���}���ɏ������Ȃ邪�A�����̂��낤���B
     */
    public static class WinRate2 extends WinRate1 {
        public float calcLogWinRatePenalty(Node node, int i){
            //env.viewPanel.print1("node.winRateTarget", ""+ node.winRateTarget);
            float target = WinRateCode.nodePrior(node, i);
            //float diff = node.winRates[i] - target;
            float diff = node.winRates[i] / target - 1;
            float bigValue = 1e3f;
            diff = Lab.clip(-bigValue, diff, bigValue);
            //env.viewPanel.print1("diff", ""+ diff);
            return - winRateC * diff;
        }
    }
    public static class WinRate1 extends WinRateCode {
        //float alpha = panel.getFloat("WinRate alpha", 0.01f, 0, 0.1f);
        public void updateWinRates(Net net) {
            Node[] nodes = net.allNodes;
            for (int n = 0; n < nodes.length; n++) {
                Node node = nodes[n];

                // �Ǐ��w�K�����X�V�B
                float winnerAlpha = node.alpha[node.winnerID];
                winnerAlpha = winnerAlpha / (winnerAlpha + 1);
                //float leastAlpha = panel.getFloat("Least alpha", 0.01f, 0, 1); 
                float leastAlpha = panel.getFloat("Least alpha", 1e-5f, 0, 1); 
                winnerAlpha += leastAlpha * leastAlpha;
                node.alpha[node.winnerID] = winnerAlpha;
                if (panel.flag("Pr winnerAlpha")) {
                    env.viewPanel.print1("winnerAlpha", "" + winnerAlpha);
                }

                // winRates ���X�V�B
                for (int i = 0; i < node.winRates.length; i++) {
                    float r = node.winRates[i];
                    node.winRates[i] += node.alpha[i]
                            * ((node.winnerID == i ? 1 : 0) - r);
                }
                if (panel.flag("Pr all winRates")) {
                    //env.viewPanel.paint(""+ node.nodeName, node.alpha);
                    env.viewPanel.paint("" + node.nodeName, node.winRates);
                }
            }
            if (panel.flag("Pr all winRateTarget")){
                for (int i = 0; i < nodes.length; i++) {
                    System.out.println(nodes[i].nodeName+ ".winRateTarget="+
                           nodes[i].winRateTarget);
                }
            }
        }
        public float calcLogWinRatePenalty(Node node, int i){
            return - winRateC * (float)Math.log(node.winRates[i]);
        }
    }
        

    public static abstract class SelectEdgesCode extends Lab.Code {
        public void inject() {
        }
        /**
         * winnerID �� CPT �̒l�ɏ]���A�G�b�W�I�������Ȃ����B 
         */
        public abstract void selectEdges(Net net);
        
        /**
         * �G�b�W�I���̂��߂̃f�[�^�\���̏�����
         */
        public abstract void initChildEdges(Net net);
    }

    public static class SelectEdges1 extends SelectEdgesCode {
        // �G�b�W�I���̂��߂̃f�[�^�\���̏�����
        public void initChildEdges(Net net){
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                node.childEdges.init(node.children.length);
                for (int l = 0; l < node.children.length; l++) {
                    node.childEdges.updateVal(l, calcChildScore(node, l));
                }
                node.validChildEdgeFlag = new boolean[node.children.length];
                node.validParentEdgeFlag = new boolean[node.parents.length];
            }
            updateValidFlags(net);
        }
        // ���ݏ��ʂɊ�Â����G�b�W�̃X�R�A���v�Z�B
        // returns ��i��j  p(yj|X=xi) log p(yj|X=xi)/p(yj)
        // y�� ����ʈ������Ȃ��B
        // p(yj) �� node.winRates[j] ���w�K���Ă���Ɖ���B
        public float calcChildScore(Node node, int childID) {
            float val = 0;
            // ������ x�� �͓��ʈ����B�i���̎����ł����̂��H�H�j
            for (int i = 1; i < node.nodeSize; i++) {
                for (int j = 0; j < node.children[childID].nodeSize; j++) {
                    // TODO: contiune ���g��Ȃ��X�^�C���ŏ������������B
                    // epsilon �̎g�������Ȃ񂩂ւ�B
                    float a = node.children[childID].winRates[j];
                    //System.out.println(a);
                    //a = 0.1f; // test
                    if (a < Lab.epsilon)
                        continue;
                    // ������ CPTmodelCode �������ׂ��Ƃ���ł͂Ȃ��̂Œ��ӁB
                    // P(yj|xi) ���̂��̂��K�v�B
                    float w = node.weights[i][childID][j];
                    if (w > Lab.epsilon) {
                        val += (float) (w * Math.log(w / a));
                    }
                }
            }
            return val;
        }
        public void selectEdges(Net net){
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                if (node.winnerID != 0){
                    for (int l = 0; l < node.children.length; l++) {
                        //System.out.println(node.nodeName+ ": l="+ l+ ", score="+ calcChildScore(node, l));
                        node.childEdges.updateVal(l, calcChildScore(node, l));
                    }
                }
            }
            updateValidFlags(net);
        }
        // O(n^2) �̊ȈՎ����B�v�Z�ʂ͔F���ɕK�v�Ȍv�Z�ʂ��\���������A���Ȃ��Ǝv���B
        // �i�m�[�h�� n �������傫���Ȃ�Ȃ�����́B�j
        public void updateValidFlags(Net net){
//            int numValidEdges = panel.getInt("numValidEdges", 4, 1, 10);
//            float validRatioL1 = panel.getFloat("validRatioL1", 1, 0, 1);
            // �܂� false �ŏ������B
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                fillFalse(node.validChildEdgeFlag);
                fillFalse(node.validParentEdgeFlag);
            }
            // �L���ȃG�b�W�̃t���O���Z�b�g�B
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                int maxEdges;
                maxEdges = node.numValidEdges;
                if (maxEdges > node.children.length) maxEdges = node.children.length;
                //System.out.println(maxEdges);
                for (int r = 0; r < maxEdges; r++) {
                    int l = node.childEdges.ids[r];
                    node.validChildEdgeFlag[l] = true;
                    Node child = node.children[l];
                    child.validParentEdgeFlag[node.indexAtChildren[l]] = true;
                }
            }
            if (panel.flag("Pr valid flags", false)){
                if (true){
                    // leaf �m�[�h�� print ���Ȃ��B
                    for (int i = 0; i < net.allNodes.length; i++) {
                        Node node = net.allNodes[i];
                        if (node.children.length != 0){
                            env.viewPanel.print1(node.nodeName+ " valid children", 
                                    Lab.toCompactString(node.validChildEdgeFlag));
                        }
                    }
                } else {
                    // �S�m�[�h print �B�{�g���A�b�v�̃G�b�W�� print �B
                    for (int i = 0; i < net.allNodes.length; i++) {
                        Node node = net.allNodes[i];
                        env.viewPanel.print1(node.nodeName+ " valid parents", 
                                Lab.toCompactString(node.validParentEdgeFlag));
                        env.viewPanel.print1(node.nodeName+ " valid children", 
                                Lab.toCompactString(node.validChildEdgeFlag));
                    }
                }
            }
            // for debug
            if (false){
                Node[] hnodes = net.getHiddenNodes();
                for (int i = 0; i < hnodes.length; i++) {
                    System.out.println(hnodes[i].nodeName);
                    System.out.println(hnodes[i].childEdges);
                }
            }
        }
        public void fillFalse(boolean[] vec){
            for (int i = 0; i < vec.length; i++) {
                vec[i] = false;
            }
        }

        
        //---------------------------------------------
        // �ȉ��A���j�b�g�P�ʂ̓����I���B
        
        // �Ƃ肠����
        public float validRatio;

        public void sortEdges1(Node node, Net net) {
            // �z��� lazy �ȃA���P�[�V�����B
            if (node.validFeatureFlag == null) {
                int len = node.children.length;
                node.validFeatureFlag = new boolean[node.nodeSize][];
                node.sortedFeatureID = new int[node.nodeSize][];
                node.sortedFeatureVal = new float[node.nodeSize][];
                for (int i = 0; i < node.nodeSize; i++) {
                    node.validFeatureFlag[i] = new boolean[len];
                    node.sortedFeatureID[i] = new int[len];
                    node.sortedFeatureVal[i] = new float[len];
                    for (int l = 0; l < node.children.length; l++) {
                        node.sortedFeatureID[i][l] = l;
                        node.sortedFeatureVal[i][l] = calcFeatureScore(node, i,
                                l);
                    }
                }
            }
            // ���ʊ֌W���v�Z�B
            for (int i = 0; i < node.sortedFeatureID.length; i++) {
                for (int l = 0; l < node.sortedFeatureVal[i].length; l++) {
                    node.sortedFeatureVal[i][l] = calcFeatureScore(node, i,
                            node.sortedFeatureID[i][l]);

                }
                // �\�[�g�B
                sortArrays(node.sortedFeatureID[i], node.sortedFeatureVal[i]);
                // �������L�����ǂ����̃t���O�ݒ�B
                for (int l = 0; l < node.validFeatureFlag[i].length; l++) {
                    node.validFeatureFlag[i][l] = false;
                }
                if (false) { // ������S���I��
                    for (int l = 0; l < node.validFeatureFlag[i].length; l++) {
                        node.validFeatureFlag[i][node.sortedFeatureID[i][l]] = true;
                    }
                } else {
                    for (int l = 0; l < node.validFeatureFlag[i].length
                            * validRatio; l++) {
                        node.validFeatureFlag[i][node.sortedFeatureID[i][l]] = true;
                    }
                }

                if (false) {
                    int c = 0;
                    for (int l = 0; l < node.validFeatureFlag[i].length; l++) {
                        if (node.validFeatureFlag[i][l])
                            c++;
                    }
                    Lab.assertTrue(c == node.validFeatureFlag[i].length
                            * validRatio
                            || c == node.validFeatureFlag[i].length);
                }
                if (false) {
                    for (int l = 0; l < node.validFeatureFlag[i].length; l++) {
                        System.out.print(node.validFeatureFlag[i][l] + ", ");
                    }
                    System.out.println();
                }
            }
        }

        // ���ݏ��ʂɊ�Â��������̃X�R�A���v�Z�B
        // returns ��j  p(yj|X=xi) log p(yj|X=xi)/p(yj)
        // y�� ����ʈ������Ȃ��B
        // �����ł͂Q�w�a�d�r�n�l�����ߑł��B
        // p(yj) �� node.winRates[j] ���w�K���Ă���Ɖ���B
        // �i���̎����ł͓��͑w�ƉB��w�ł� winRates �̈Ӗ����Ⴄ�̂Œ��ӁB �� �C���ς݁H�j
        public float calcFeatureScore(Node node, int unitID, int childID) {
            float val = 0;
            for (int j = 0; j < node.children[childID].nodeSize; j++) {
                float a = node.children[childID].winRates[j];
                if (a < Lab.epsilon)
                    continue;
                float w = node.weights[unitID][childID][j];
                if (w > Lab.epsilon) {
                    val += (float) (w * Math.log(w / a));
                }
            }
            return val;
        }

        // �}���\�[�g�B
        // �v�Z�ʂ� O(n^2) �����A�قڃ\�[�g����Ă���z��ɑ΂��Ă͑����B�ق� O(n) �B
        // �O��̃\�[�g���ʂ��c���Ă���̂ŁA �����̂ł͂Ȃ����H
        // vals ��l�̑傫�����Ƀ\�[�g�B����ɍ��킹�� ids ������ւ���B
        public void sortArrays(int[] ids, float[] vals) {
            Lab.assertTrue(ids.length >= 1);
            Lab.assertTrue(ids.length == vals.length);
            for (int i = 1; i < vals.length; i++) {
                int tmpid = ids[i];
                float tmpval = vals[i];
                if (vals[i - 1] < tmpval) {
                    int j = i;
                    do {
                        ids[j] = ids[j - 1];
                        vals[j] = vals[j - 1];
                        j--;
                    } while (j > 0 && vals[j - 1] < tmpval);
                    ids[j] = tmpid;
                    vals[j] = tmpval;
                }
            }
            if (false) {
                for (int i = 0; i < vals.length; i++) {
                    System.out.print(vals[i] + ", ");
                }
                System.out.println();
            }
        }
    }
    
    /**
     * �����I�\�[�g�A���S���Y���B 
     */
    public static class IncrementalSorter {
        /**
         * �e�h�c�̏��ʂ��L������z��B
         * ranks[id] == rank
         */
        public int[] ranks;
        /**
         * �h�c��l�̑傫���̏��ɋL������z��B
         * ids[rank] == id
         */
        public int[] ids;

        /**
         * �l���\�[�g�����z��B�C���f�b�N�X�������������l���傫���B
         * vals[rank] == val
         */
        public float[] vals;

        public void init(int size) {
            ranks = new int[size];
            ids = new int[size];
            vals = new float[size];
            for (int r = 0; r < size; r++) {
                ranks[r] = r;
                ids[r] = r;
                vals[r] = -r;  // �����l 
            }
        }
        /**
         * id �ɑΉ�����l�� val �ɍX�V�B
         */
        public void updateVal(int id, float val){
            int r = ranks[id]; // Current rank
            // �O��̒l�Ɣ�r�B
            if (r-1 >= 0 && vals[r-1] < val){
                // val �̕����傫���̂őO�̏��ʂɈړ��B
                do {
                    vals[r] = vals[r-1];
                    ids[r] = ids[r-1];
                    ranks[ids[r]]++;
                    r--;
                } while (r-1 >= 0 && vals[r-1] < val);
                vals[r] = val;
                ranks[id] = r;
                ids[r] = id;
            } else if (r+1 < vals.length && vals[r+1] > val){
                // val �̕����������̂Ō��̏��ʂɈړ��B
                do {
                    vals[r] = vals[r+1];
                    ids[r] = ids[r+1];
                    ranks[ids[r]]--;
                    r++;
                } while (r+1 < vals.length && vals[r+1] > val);
                vals[r] = val;
                ranks[id] = r;
                ids[r] = id;
            } else {
                vals[r] = val;
            }
        }
        public static void test(int times){
            IncrementalSorter sorter = new IncrementalSorter();
            int size = 5;
            sorter.init(size);
            for (int i = 0; i < times; i++) {
                int id = Lab.irand(size);
                float val = Lab.rand();
                sorter.updateVal(id, val);
                System.out.println("i="+ i);
                System.out.println("id="+ id+ ", val="+ val);
                System.out.println("ranks="+ Lab.toString(sorter.ranks));
                System.out.println("ids="+ Lab.toString(sorter.ids));
                System.out.println("vals="+ Lab.toString(sorter.vals));
                Lab.assertTrue(sorter.ids[sorter.ranks[id]] == id);
                Lab.assertTrue(sorter.vals[sorter.ranks[id]] == val);
                for (int r = 0; r < sorter.vals.length; r++) {
                    if (r > 0){
                        Lab.assertTrue(sorter.vals[r-1] >= sorter.vals[r]);
                    }
                    Lab.assertTrue(sorter.ranks[sorter.ids[r]] == r);
                }
                for (int ii = 0; ii < size; ii++) {
                    Lab.assertTrue(sorter.ids[sorter.ranks[ii]] == ii);
                }
            }
        }
        public String toString(){
            StringBuffer buf = new StringBuffer();
            buf.append("ranks="+ Lab.toString(ranks));
            buf.append(Lab.lineSeparator);
            buf.append("ids="+ Lab.toString(ids));
            buf.append(Lab.lineSeparator);
            buf.append("vals="+ Lab.toString(vals));
            buf.append(Lab.lineSeparator);
            return buf.toString();
        }
    }

    public static abstract class ICACode extends Lab.Code {
        /**
         * ���}���̋��������߂�p�����^
         */
        public float icaC;
        //public int numValidLateralEdge = panel.getInt("numValidLateralEdge", 100, 0, 10);
        public int numValidLateralEdge;
        public boolean useWinRates = panel.flag("Use winRates");

        /**
         * ���}���̊w�K�� �� �p�~
         */
        //public float icaAlpha = panel.getFloat("icaAlpha", 0.001f, 0, 10);

        public NetCode netCode;

        public void inject(NetCode netCode) {
            this.netCode = netCode;
        }

        /**
         * �m�[�h�Ԃ� lateral edge �𒣂�I���������ɂ��̃��\�b�h���Ă΂Ȃ���΂Ȃ�Ȃ��B 
         * �ĂіY�꒍�ӁB
         */
        public abstract void initICA(Net net);

        public abstract float logPenalty(Net net);
        public float logS(Node u, int ui, int vID, int vj){
            Lab.assertTrue(false);
            return 0;
        }

        public abstract void updateCTable(Net net);
        
        public void addLateralEdge(Node fromNode, Node toNode){
//            if (toNode.lateralNodes == null){
//                toNode.lateralNodes = new Node[0];
//            }
            toNode.lateralNodes = Node.append(toNode.lateralNodes, fromNode);
        }
        /**
         *  nodes �Ԃ� n(n-1) �{�̑��}���������͂�B
         */
        public void fullConnectLateralEdges(Node[] nodes){
            for (int i = 0; i < nodes.length; i++) {
                for (int j = 0; j < nodes.length; j++) {
                    if (i != j){
                        addLateralEdge(nodes[i], nodes[j]);
                    }
                }
            }
        }
        
        /**
         * ���ʂ̎q�m�[�h�����e�m�[�h���m�� lateral edge ��ǉ��B 
         * �w���̃m�[�h���� n �Ƃ���� O(n^4) �̌v�Z�ʁB
         * TODO: n ���傫���Ȃ�ꍇ�̓n�b�V���\���g���ȂǍH�v����K�v������B
         */
        public void connectOver��appingLateralNodes(Node[] parents, Node[] childlen){
            System.out.println("connectOver��appingLateralNodes: parents.length="+
                    parents.length+ ", childlen.length="+ childlen.length);
            for (int c = 0; c < childlen.length; c++) {
                Node[] nodes = childlen[c].parents;
                for (int i = 0; i < nodes.length; i++) {
                    for (int j = 0; j < nodes.length; j++) {
                        if (i != j){
                            addNonDuplicateLateralEdge(nodes[i], nodes[j]);
                        }
                    }
                }
            }
        }
        /**
         * formNode ���� toNode �� lateral edge �𒣂邪�A���łɂ���ꍇ�͒���Ȃ��B
         */
        public void addNonDuplicateLateralEdge(Node fromNode, Node toNode){
            for (int i = 0; i < toNode.lateralNodes.length; i++) {
                if (fromNode == toNode.lateralNodes[i]) return;
            }
            toNode.lateralNodes = Node.append(toNode.lateralNodes, fromNode);
        }
    }

    public static class ICA0 extends ICACode {
        public void initICA(Net net) {
        }

        public float logPenalty(Net net) {
            return 0;
        }

        public void updateCTable(Net net) {
        }
    }

    /**
     *  �����t�m����p���鑤�}���h�b�`�B  
     * ���}���̃G�b�W�I��������B
     * �F���A���S���Y���������}���̃G�b�W�I���ɑΉ����Ă���K�v������B
     */
    public static class ICAo1 extends ICACode {
        public void initICA(Net net) {
            for (int u = 0; u < net.allNodes.length; u++) {
                Node node = net.allNodes[u];
                if (node.lateralNodes != null){
                    float[][][] cols = new float[node.lateralNodes.length][][];
                    node.correlation = cols;
                    for (int v = 0; v < node.lateralNodes.length; v++) {
                        cols[v] = new float[node.nodeSize][];
                        for (int i = 0; i < cols[v].length; i++) {
                            cols[v][i] = new float[node.lateralNodes[v].nodeSize];
                            Lab.initVec(cols[v][i], 1f / node.nodeSize);
                        }
                    }
                    // 
                    node.lateralEdges.init(node.lateralNodes.length);
                    for (int v = 0; v < node.lateralNodes.length; v++) {
                        node.lateralEdges.updateVal(v, calcEdgeScore(node, v));
                    }
                }
            }
        }
        //---------------------------------

        // �Ƃ肠�����u�P���ɏd�݂̑��a�ŃX�R�A���ߎ��v�Z����v�Ƃ������Ƃɂ���B
        // �Ӓl�A�������g�͊܂܂Ȃ��B
        // TODO: �Ӓl����ʈ������Ȃ��悤�ɁB����ɑ��ݏ��ʂł܂��߂ɃX�R�A�v�Z����悤�ɂ��ׂ��B
        public float calcEdgeScore(Node node, int v) {
            float val = 0;
            for (int i = 1; i < node.nodeSize; i++) {
                for (int j = 1; j < node.correlation[v][i].length; j++) {
                    val += node.correlation[v][i][j];
                }
            }
            return val;
        }

        // �e�m�[�h�̒l node.interpID �̊Ԃ̑��}���y�i���e�B�̑��ς̑ΐ���Ԃ��B 
        // calcLikelihood ����Ă΂��B
        public float logPenalty(Net net) {
            float logPenalty = 0;
            for (int u = 0; u < net.allNodes.length; u++) {
                Node node = net.allNodes[u];
                logPenalty += logPenalty1(node);
            }
            //if (logPenalty != logPenalty) System.out.println(logPenalty);
            //Util.paintln(penalty);
            return logPenalty;
        }
        // ���̃m�[�h����̗}���̑��ς�ΐ��ŕԂ��B
        public float logPenalty1(Node node) {
            int numEdge = Lab.min(this.numValidLateralEdge, node.lateralNodes.length); 
            //System.out.println("numValidLateralEdge="+ numValidLateralEdge);
            float logPenalty = 0;
            for (int r = 0; r < numEdge; r++) {
                int vID = node.lateralEdges.ids[r]; 
                Node lateralNode = node.lateralNodes[vID];
                int i = node.interpID;
                int j = lateralNode.interpID;
                logPenalty += logS(node, i, vID, j);
                //System.out.println(r+ ":"+ logPenalty);
            }
            //if (logPenalty != logPenalty) System.out.println(logPenalty);
            //System.out.println(logPenalty);
            return logPenalty;
        }
        /**
         * vj ���� ui �ւ̑��}��  log s(ui,vj) ��Ԃ��B
         * s(ui,vj) = e^( -icaC * i(ui,vj))
         * i(ui,vj) = P(ui,vj)/P(ui)P(vj) log P(ui,vj)/P(ui)P(vj) 
         *        = P(ui|vj)/P(ui) log P(ui|vj)/P(ui)
         *  P(ui|vj)/P(ui)=1 �t�߂���`�ߎ�����Ɖ��L�̂悤�ɂȂ�B
         *  i(ui,vj) ��  P(ui|vj)/P(ui) - 1
         *  
         */
        public float logS(Node u, int ui, int vID, int vj){
            if (simplePenalty){
                float[][] col = u.correlation[vID];
                float c = col[ui][vj]; //  P(ui|vj)
                float pui = WinRateCode.nodePrior(u, ui);
                //float iuv = c - pui; // i(ui,uj) = P(ui|vj) - P(ui)
                float iuv = c / pui - 1; // i(ui,uj) = P(ui|vj)/P(ui) - 1
                // iuv �̒l�͂Ƃ��ǂ� Infinity �ɂȂ�B 
                float bigValue = 1e3f;
                iuv = Lab.clip(-bigValue, iuv, bigValue);
                return -icaC * iuv;
            } else {
                float[][] col = u.correlation[vID];
                float c = col[ui][vj]; //  P(ui|vj)
                float pui = WinRateCode.nodePrior(u, ui);
                float ratio = c / pui;
                //System.out.println("ratio="+ ratio);
                // i(ui,vj) = P(ui|vj)/P(ui) log P(ui|vj)/P(ui)
                float iuv = (float)(ratio * Math.log(ratio));
                return -icaC * iuv;
            }
        }
        public boolean simplePenalty = panel.flag("Simple penalty", true);

        // �s����X�V�B 
        // allNodes[u].correlation[v][ui][vj] �� P(ui|vj) ���w�K������̂Ƃ���B
        // allNodes[u].conditionalActiveRate �͔p�~�B
        // TODO: �ߖT�w�K�ɑΉ��������B
        public void updateCTable(Net net) {
            for (int u = 0; u < net.allNodes.length; u++) {
                Node node = net.allNodes[u];

                    for (int v = 0; v < node.lateralNodes.length; v++) {
                        int vw = node.lateralNodes[v].winnerID;
                        float[][] c = node.correlation[v];
                        for (int ui = 0; ui < node.nodeSize; ui++) {
                            // w =  P(ui|vj)
                            float w = c[ui][vw];
                            float target = ui == node.winnerID ? 1 : 0;
                            c[ui][vw] = w + node.lateralNodes[v].alpha[vw] * (target - w);
                        }
                        node.lateralEdges.updateVal(v, calcEdgeScore(node, v));
                    }
//              }
            }
            if (panel.flag("Pr C tables")) {
                for (int u = 0; u < net.allNodes.length; u++) {
                    Node node = net.allNodes[u];
                    if (node.lateralNodes.length > 0){
                        for (int v = 0; v < node.lateralNodes.length; v++) {
                            env.viewPanel.setText(node.nodeName+ 
                                    " correlation[" + node.lateralNodes[v].nodeName+ "]", 
                                    Lab.toCompactString(node.correlation[v]));
                        }
                    }
                }
            }
        }
    }

    public static abstract class InputCode extends Lab.Code {
        public Net net;
        public void inject() {}

//        public abstract int getInputDim();
//        public int getHintDim() { return 0; }

        public abstract void init(Net net);

        //public abstract float[] getInputData();
        // �Ԓl�� inputData �B�����Ɏg���B�����͔p�~�������B
        public abstract float[] input();
//        private float[] defaultHindData = {};
//        public float[] getHintData(){ return defaultHindData; }

        public abstract Node[] addInputNodes(Net net);
        public abstract Node[] addHintNodes(Net net);
        
        public void paintPosterior(){}
//        public void evalRecogResult(Net net, RecogCode recogCode, CPTmodelCode cptModelCode, ICACode icaCode){}
        public int counter = 0;
        public int resultGraphX = 0;
        public void evalRecogResult(Net net,
                RecogCode selectedRecogCode, CPTmodelCode cptModelCode, 
                WinRateCode winRateCode, ICACode icaCode){
            int evalInterval = panel.getInt("Eval interval", 100, 1, 1000);
            counter++;
            if (counter < evalInterval) return;
            counter = 0;

            int inputsForEval = panel.getInt("Inputs for eval", 10, 0, 1000);
//            boolean currentGiveLabelFlag = giveLabel;
//            giveLabel = false;

            boolean currentFlag = net.noPenaltyFlag;
            net.noPenaltyFlag = true;
            
            float sum = 0;
            for (int i = 0; i < inputsForEval; i++) {
                env.viewPanel.print1("Evaluating inputs", "" + i);
                
                float[] inputData = this.input();
                selectedRecogCode.calcMPE(net);
                
                sum += b.B.EvalCode.evalLikelihood(net, cptModelCode, 
                        winRateCode, icaCode);
            }
            float mean = sum / inputsForEval;
            env.viewPanel.scatterPlot("Log score", resultGraphX, mean);
            resultGraphX++;

//            giveLabel = currentGiveLabelFlag;
            net.noPenaltyFlag = currentFlag;
        }
    }

    public static class Input1 extends InputCode {
        public void init(Net net) {
            this.net = net;
        }

        public int getInputDim() {
            return 2;
        }

        float[] buf = new float[2];

        public float[] getInputData() {
            float x = Lab.rand();
            float y = (2 * x - 1) * (2 * x - 1);
            buf[0] = x;
            buf[1] = y;
            return buf;
        }
        public float[] input(){
            float[] data = getInputData();
            throw new Error("not implemented"); // �V�`�o�h�ɖ��Ή��B
            // return data;
        }
        public Node[] addInputNodes(Net net){
            throw new Error("not implemented"); // �V�`�o�h�ɖ��Ή��B
        }
        public Node[] addHintNodes(Net net) {return new Node[0]; }
    }

    public static abstract class HiddenCode extends Lab.Code {
        public NetCode netCode;

        public InputCode inputCode; // �����̎��Ɏg���B

        public ICACode icaCode;

        public void inject(NetCode netCode, InputCode inputCode, ICACode icaCode) {
            this.netCode = netCode;
            this.inputCode = inputCode;
            this.icaCode = icaCode;
        }

        public abstract void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes);

        public void updateSparseness() {
        }
        public void updateNumValidEdges(Net net){}
        public void setNumValidEdges(Node[] nodes, int numValidEdges){
            for (int i = 0; i < nodes.length; i++) {
                nodes[i].numValidEdges = numValidEdges;
            }
        }
        
        /**
         * ���ϓ��͉摜�̊w�K�B�����p�B
         * TODO: ���t�@�N�^�����O 
         */
        public void learnMeanInput(float[] data) {
        }
        /**
         * �S���j�b�g�̉����B
         * �i�\�Ȃ�΁A���j�b�g�����҂ɂȂ������̓��͉摜�̕��ς��y�C���g����A�ȂǁB�j
         */
        public void paintUnits() {
        }

        /**
         * �e���j�b�g�̏����t�m���\�̉����B
         * �\�Ȃ�΁A�k�P�ɂ�����b�o�s����͉摜�Ɠ����T�C�Y�̔Z�W�Ńy�C���g����B 
         */
        public void paintCPT(Net net) {
            env.viewPanel.print1("paintCPT", "Not implemented.");
        }
        /**
         * "Denoising Test" �̂��߂̃��\�b�h�B
         * ���͉摜��ό`���Ȃ��ŔF�����钼�O�̃m�[�h�̏�Ԑݒ�B
         */
        public void prepareNormalRecog(){ Lab.assertTrue(false); }
        /**
         * "Denoising Test" �̂��߂̃��\�b�h�B
         * ���͉摜��ό`�������̂�F�����钼�O�̃m�[�h�̏�Ԑݒ�B
         */
        public void preparePostTransRecog(){ Lab.assertTrue(false); }
    }

    // �B��m�[�h�m�[�h�P�̂݁B
    public static class Hidden1 extends Hidden2 {
        {
            panel.setInt("numNodes", 1);
            //panel.setInt("nodeSize", 30);
        }
    }
    
    /**
     * �����m�[�h���X���C�_���g�����V�����X�p�[�X�������Ή��ŁB
     * TODO: �����Ɠ������� HiddenForImageOld �͔p�~�������B
     */
    public static abstract class HiddenForImage extends HiddenForImageOld {
        public void updateSparseness() {
            super.updateSparseness(); 
            
            float activeNodes = panel.getFloat("L1 active nodes", 4, 1, 10);
//            float t = activeNodes / countNonPhiUnits(hiddenNodes1);
//            for (int i = 0; i < hiddenNodes1.length; i++) {
//                hiddenNodes1[i].winRateTarget = t;
//            }
            WinRateCode.setWinRateTargets(hiddenNodes1, activeNodes);
        }
    }
    
    /**
     * �摜���w�K����B��w�̂��߂̒��ۃN���X�B
     */
    public static abstract class HiddenForImageOld extends HiddenCode {
        
        /**
         * �k�P�̉B��m�[�h
         */
        public Node[] hiddenNodes1;

        public Node[] visualizableNodes;
        public Node[] pixelNodes;
        public Node[] hintNodes;
        // ���͑w
        public int imageSize;

        public void updateSparseness() {
            float sparseness = panel.getFloat("L1 sparseness", 0f, -100, 100);
            for (int i = 0; i < hiddenNodes1.length; i++) {
                hiddenNodes1[i].sparseness = sparseness;
            }
            float inSparseness = panel.getFloat("pixelNodes sparseness", 5f, -10, 10);
            for (int i = 0; i < pixelNodes.length; i++) {
                pixelNodes[i].sparseness = inSparseness;
            }
        }

        
        // �e���j�b�g�����҂ɂȂ������̓��͂̕��ς��w�K�B
        public void learnMeanInput(float[] data){
            for (int i = 0; i < visualizableNodes.length; i++) {
                learnMeanInput1(visualizableNodes[i], data);
            }
        }
        public void learnMeanInput1(Node node, float[] data){
            if (node.meanInputs[0] == null){
                for (int i = 0; i < node.nodeSize; i++) {
                    node.meanInputs[i] = new float[data.length];
                }
            }
            for (int i = 0; i < data.length; i++) {
                float w = node.meanInputs[node.winnerID][i];
                w += node.alpha[node.winnerID] * (data[i] - w);
                node.meanInputs[node.winnerID][i] = w;
            }
        }
        public MeanImagePainter meanImagePainter = null;
        public void paintUnits(){
            if (meanImagePainter == null){
                meanImagePainter = panel.getCode("MeanImagePainter", MeanImagePainter.class);
                meanImagePainter.imageSize = imageSize;
                meanImagePainter.setNodes(visualizableNodes);
            }
            env.viewPanel.paint("Mean images", meanImagePainter);
        }

        public BasisImagePainter basisImagePainter = null;

        public void paintCPT(Net net) {
            if (basisImagePainter == null) {
                basisImagePainter = panel.getCode("BasisImagePainter",
                        BasisImagePainter.class);
                basisImagePainter.imageSize = ((int) Math
                        .sqrt(hiddenNodes1[0].children.length));
                basisImagePainter.setNodes(hiddenNodes1);
            }
            env.viewPanel.paint("Basis images", basisImagePainter);

            // �p�~�\��
            //printRecalledData();
        }
        // �p�~
        public void printRecalledData(){
            if (pixelNodes.length > 0 && ! pixelNodes[0].inputNodeFlag){
                for (int row = 0; row < imageSize; row++) {
                    for (int col = 0; col < imageSize; col++) {
                        System.out.print(pixelNodes[row * imageSize + col].winnerID);
                        //System.out.println(""+Lab.toCompactString(inputNodes[row * imageSize + col].bel));
                        //System.out.print(Lab.toChar(inputNodes[row * imageSize + col].bel[1]));
                    }
                    System.out.println();
                }
                System.out.println();
            }
            if (hintNodes.length > 0 && ! hintNodes[0].inputNodeFlag){
                env.viewPanel.paint(hintNodes[0].nodeName+ ".bel", hintNodes[0].bel);
                System.out.println(hintNodes[0].nodeName+ ".winnerID - 1 : "+
                        (hintNodes[0].winnerID - 1));
            }
        }
        public void updateNumValidEdges(Net net){
            float validRatioL1 = panel.getFloat("L1 valid ratio", 1, 0, 1);
            for (int i = 0; i < hiddenNodes1.length; i++) {
                Node node = hiddenNodes1[i];
                int maxEdges = (int)(node.children.length * validRatioL1);
                node.numValidEdges = maxEdges;
            }
        }
        public boolean doL1PreTraining = panel.flag("Do L1 pre-training", false); 
        public boolean preTrainingPhase = doL1PreTraining;
        // �k�Q������ HiddenCode ����Ăяo�����B
        // BUG: �k�R�ȏ�̑w������ Hidden4 �Ȃǂɂ͖��Ή��B
        public void setPreTraining(Net net, Node[] hiddenNodes2){
            if (preTrainingPhase){
                for (int i = 0; i < hiddenNodes2.length; i++) {
                    Node node = hiddenNodes2[i];
                    node.numValidEdges = 0;
                    node.inputNodeFlag = true;
                    node.winnerID = 0;
                    Lab.initVec(node.alpha, 0f);
                }
                if (panel.button("Finish L1 pre-training")){
                    preTrainingPhase = false;
                    for (int i = 0; i < hiddenNodes2.length; i++) {
                        Node node = hiddenNodes2[i];
                        Lab.initVec(node.alpha, 0.5f);
                        node.inputNodeFlag = false;
                    }
                }
            }
        }
    }

    // �R�w�a�d�r�n�l�B�w�ԑS�����o�[�W�����B
    // ���͂ɂ��Ă� n x n �̉摜�ł���Ɖ���B
    public static class Hidden3full extends HiddenForImage {
        // �Q�w��
        public int numNodes2 = panel.getInt("numNodes2", 4, 1, 30);

        public int nodeSize2 = panel.getInt("nodeSize2", 10, 2, 100);

        // �P�w�ځi���͂ɋ߂����j
        public int numNodes1 = panel.getInt("numNodes1", 8, 1, 128);

        public int nodeSize1 = panel.getInt("nodeSize1", 10, 2, 100);

        Node[] hiddenNodes2;

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            imageSize = (int)Math.sqrt(inputNodes.length);
            hiddenNodes1 = new Node[numNodes1];
            for (int i = 0; i < numNodes1; i++) {
                hiddenNodes1[i] = net.createNode("L1." + i, nodeSize1);
            }
            // ����
            for (int i = 0; i < hiddenNodes1.length; i++) {
                for (int j = 0; j < inputNodes.length; j++) {
                    // �t������
                    net.addEdge(hiddenNodes1[i], inputNodes[j]);
                }
            }

            hiddenNodes2 = new Node[numNodes2];
            for (int i = 0; i < numNodes2; i++) {
                hiddenNodes2[i] = net.createNode("L2." + i, nodeSize2);
            }
            // ����
            for (int i = 0; i < hiddenNodes2.length; i++) {
                for (int j = 0; j < hiddenNodes1.length; j++) {
                    // �t������
                    net.addEdge(hiddenNodes2[i], hiddenNodes1[j]);
                }
                for (int j = 0; j < hintNodes.length; j++) {
                    // �����̓t�������B
                    net.addEdge(hiddenNodes2[i], hintNodes[j]);
                }
            }

            icaCode.fullConnectLateralEdges(hiddenNodes1);
            icaCode.fullConnectLateralEdges(hiddenNodes2);
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(Node.append(hiddenNodes1, hiddenNodes2),
                    hintNodes);
        }

        public void updateSparseness() {
            float sparseness2 = panel.getFloat("L2 sparseness", 0f, -100, 100);
            //float sparseness1 = panel.getFloat("L1 sparseness", 0f, -10, 10);
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].sparseness = sparseness2;
            }
//            for (int i = 0; i < hiddenNodes1.length; i++) {
//                hiddenNodes1[i].sparseness = sparseness1;
//            }
            super.updateSparseness();
        }
        public void updateNumValidEdges(Net net){
            super.updateNumValidEdges(net);
            setPreTraining(net, hiddenNodes2);
        }

    }
    // �T�w�a�d�r�n�l
    // �X�p�[�X���Ȃǂ��낢�떢�Ή��B
    //  Hidden4 �̃R�[�h���R�s�[���Ĕ��C�����������B
    public static class Hidden5 extends HiddenForImage {
        public int s3 = panel.getInt("L3 map size", 1, 1, 10);
        public float l3RFsize = panel.getFloat("L3 RF size", 10, 0, 10);
        public int l3nodeSize =  panel.getInt("L3 node size", 500, 1, 1000);
        public int s2 = panel.getInt("L2 map size", 3, 1, 10);
        public float l2RFsize = panel.getFloat("L2 RF size", 2, 0, 10);
        public int l2nodeSize =  panel.getInt("L2 node size", 100, 1, 100);
        public int s1 = panel.getInt("L1 map size", 5, 1, 32);
        public float l1RFsize = panel.getFloat("L1 RF size", 6, 0, 10);
        public int l1nodeSize =  panel.getInt("L1 node size", 10, 1, 100);
        public Node[] hiddenNodes2;
        public Node[] hiddenNodes3;

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;

            hiddenNodes1 = createLayer(net, "L1", s1, l1nodeSize);
            // ���͑w�Ƃk�P�̊Ԃ͕�������
            imageSize = (int)Math.sqrt(inputNodes.length);
            Lab.assertTrue(imageSize * imageSize == inputNodes.length);
            connectLayers(net, hiddenNodes1, s1, l1RFsize, inputNodes, imageSize);

            hiddenNodes2 = createLayer(net, "L2", s2, l2nodeSize);
            connectLayers(net, hiddenNodes2, s2, l2RFsize, hiddenNodes1, s1);


            hiddenNodes3 = createLayer(net, "L3", s3, l3nodeSize);
            connectLayers(net, hiddenNodes3, s3, l3RFsize, hiddenNodes2, s2);

            // �q���g�m�[�h�Ƃk�R���t�������B
            for (int i = 0; i < hintNodes.length; i++) {
                for (int j = 0; j < hiddenNodes3.length; j++) {
                    net.addEdge(hintNodes[i], hiddenNodes3[j]);
                }
            }
            
            // ���}���B
            // TODO: �������B
            
            visualizableNodes = Node.append(Node.append(
                    Node.append(hiddenNodes1, hiddenNodes2), hiddenNodes3),
                    hintNodes);
        }
        /**
         * ���C���̃m�[�h�𐶐��B
         */
        public Node[] createLayer(Net net, String layerName, int s, int nodeSize){
            Node [] nodes = new Node[s * s];
            for (int y = 0; y < s; y++) {
                for (int x = 0; x < s; x++) {
                    nodes[y * s + x] 
                       = net.createNode(layerName+ "("+ x+ ","+ y+ ")", 
                               nodeSize);
                }
            }
            return nodes;
        }
        /**
         *  L2 ���� L1 �ւ̃G�b�W���͂�B
         */
        public void connectLayers(Net net, Node[] l2, int s2, float rf, Node[] l1, int s1){
            StringBuffer[] buf = new StringBuffer[0]; // �����p
            for (int y2 = 0; y2 < s2; y2++) {
                StringBuffer[] buf1 = new StringBuffer[s1];
                for (int i = 0; i < buf1.length; i++) {
                    buf1[i] = new StringBuffer();
                }
                for (int x2 = 0; x2 < s2; x2++) {
                    // �e�m�[�h�̒��S�̍��W�v�Z
                    float py2 = (1f / s2) * (y2 + 0.5f); 
                    float px2 = (1f / s2) * (x2 + 0.5f); 
                    for (int y1 = 0; y1 < s1; y1++) {
                        for (int x1 = 0; x1 < s1; x1++) {
                            // �q�m�[�h�̒��S�̍��W�v�Z
                            float py1 = (1f / s1) * (y1 + 0.5f); 
                            float px1 = (1f / s1) * (x1 + 0.5f);
                            float rfSize = rf * (1f / s1); 
                            //��e��̒��ɓ����Ă���ꍇ�ɃG�b�W�𒣂�B
                            if (Math.abs(py2 - py1) < (rfSize/2) &&
                                Math.abs(px2 - px1) < (rfSize/2)){
                                net.addEdge(l2[y2 * s2 + x2],
                                        l1[y1 * s1 + x1]);
                                buf1[y1].append("* ");
                            } else {
                                buf1[y1].append(". ");
                            }
                        }
                        buf1[y1].append("|");
                    }
                }
                buf = Lab.appendStringRectBelow(buf, buf1, "-");
            }
            for (int i = 0; i < buf.length; i++) {
                env.viewPanel.println("connectLayers", buf[i].toString());
            }
            env.viewPanel.println("connectLayers", "");
        }
        
        public void copyNodes(Node[] nodes1, Node[] nodes2, int fromIndex){
            for (int i = 0; i < nodes1.length; i++) {
                nodes1[i] = nodes2[fromIndex + i];
            }
        }

        public void updateSparseness() {
            // L3 Not implemented!!
            float sparseness2 = panel.getFloat("L2 sparseness", 0f, -10, 10);
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].sparseness = sparseness2;
            }
            super.updateSparseness();
        }
        public void updateNumValidEdges(Net net){
            super.updateNumValidEdges(net);
            setPreTraining(net, hiddenNodes2);
        }
    }


    // �S�w�a�d�r�n�l�B���������o�[�W�����B�e�w�͋Ǐ���e������B�I�[�o�[���b�v����B
    // �e�w�͂Q�����̃}�b�v�����Ɖ���B�w�肷��T�C�Y�͂P�ӂ̃m�[�h���B
    // ��e��̃T�C�Y�͎q�m�[�h�̃}�b�v�ɂ�����P�ӂ̃m�[�h���B
    // �k�R�̓q���g�m�[�h�B
    // ���͂ɂ��Ă� n x n �̉摜�ł���Ɖ���B
    public static class Hidden4 extends HiddenForImage {
        public int s2 = panel.getInt("L2 map size", 3, 1, 10);
        public float l2RFsize = panel.getFloat("L2 RF size", 3, 0, 10);
        public int l2nodeSize =  panel.getInt("L2 node size", 10, 1, 100);
        public int s1 = panel.getInt("L1 map size", 5, 1, 32);
        public float l1RFsize = panel.getFloat("L1 RF size", 6, 0, 10);
        public int l1nodeSize =  panel.getInt("L1 node size", 10, 1, 100);
        public Node[] hiddenNodes2;

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;

            hiddenNodes1 = createLayer(net, "L1", s1, l1nodeSize);
            // ���͑w�Ƃk�P�̊Ԃ͕�������
            imageSize = (int)Math.sqrt(inputNodes.length);
            Lab.assertTrue(imageSize * imageSize == inputNodes.length);
            connectLayers(net, hiddenNodes1, s1, l1RFsize, inputNodes, imageSize);

            hiddenNodes2 = createLayer(net, "L2", s2, l2nodeSize);
            connectLayers(net, hiddenNodes2, s2, l2RFsize, hiddenNodes1, s1);

            if (panel.flag("Connect T0", true)){
                // �q���g�m�[�h�Ƃk�Q���t�������B
                if (panel.flag("Parent T0", true)){
                    for (int i = 0; i < hintNodes.length; i++) {
                        for (int j = 0; j < hiddenNodes2.length; j++) {
                            net.addEdge(hintNodes[i], hiddenNodes2[j]);
                        }
                    }
                } else {
                    for (int i = 0; i < hintNodes.length; i++) {
                        for (int j = 0; j < hiddenNodes2.length; j++) {
                            net.addEdge(hiddenNodes2[j], hintNodes[i]);
                        }
                    }
                }
            }
            
            // ���}���B
            icaCode.connectOver��appingLateralNodes(hintNodes, hiddenNodes2);
            icaCode.connectOver��appingLateralNodes(hiddenNodes2, hiddenNodes1);
            icaCode.connectOver��appingLateralNodes(hiddenNodes1, inputNodes);
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(Node.append(hiddenNodes1, hiddenNodes2),
                    hintNodes);
        }
        /**
         * ���C���̃m�[�h�𐶐��B
         */
        public Node[] createLayer(Net net, String layerName, int s, int nodeSize){
            Node [] nodes = new Node[s * s];
            for (int y = 0; y < s; y++) {
                for (int x = 0; x < s; x++) {
                    nodes[y * s + x] 
                       = net.createNode(layerName+ "("+ x+ ","+ y+ ")", 
                               nodeSize);
                }
            }
            return nodes;
        }
        /**
         *  L2 ���� L1 �ւ̃G�b�W���͂�B
         */
        public void connectLayers(Net net, Node[] l2, int s2, float rf, Node[] l1, int s1){
            StringBuffer[] buf = new StringBuffer[0]; // �����p
            for (int y2 = 0; y2 < s2; y2++) {
                StringBuffer[] buf1 = new StringBuffer[s1];
                for (int i = 0; i < buf1.length; i++) {
                    buf1[i] = new StringBuffer();
                }
                for (int x2 = 0; x2 < s2; x2++) {
                    // �e�m�[�h�̒��S�̍��W�v�Z
                    float py2 = (1f / s2) * (y2 + 0.5f); 
                    float px2 = (1f / s2) * (x2 + 0.5f); 
                    for (int y1 = 0; y1 < s1; y1++) {
                        for (int x1 = 0; x1 < s1; x1++) {
                            // �q�m�[�h�̒��S�̍��W�v�Z
                            float py1 = (1f / s1) * (y1 + 0.5f); 
                            float px1 = (1f / s1) * (x1 + 0.5f);
                            float rfSize = rf * (1f / s1); 
                            //��e��̒��ɓ����Ă���ꍇ�ɃG�b�W�𒣂�B
                            if (Math.abs(py2 - py1) < (rfSize/2) &&
                                Math.abs(px2 - px1) < (rfSize/2)){
                                net.addEdge(l2[y2 * s2 + x2],
                                        l1[y1 * s1 + x1]);
                                buf1[y1].append("* ");
                            } else {
                                buf1[y1].append(". ");
                            }
                        }
                        buf1[y1].append("|");
                    }
                }
                buf = Lab.appendStringRectBelow(buf, buf1, "-");
            }
            for (int i = 0; i < buf.length; i++) {
                env.viewPanel.println("connectLayers", buf[i].toString());
            }
            env.viewPanel.println("connectLayers", "");
        }
        
        public void copyNodes(Node[] nodes1, Node[] nodes2, int fromIndex){
            for (int i = 0; i < nodes1.length; i++) {
                nodes1[i] = nodes2[fromIndex + i];
            }
        }

        public void updateSparseness() {
//            float sparseness2 = panel.getFloat("L2 sparseness", 0f, -10, 10);
//            for (int i = 0; i < hiddenNodes2.length; i++) {
//                hiddenNodes2[i].sparseness = sparseness2;
//            }
            if (hintNodes.length > 0){
                float activeNodes = panel.getFloat("L3 active nodes", 1, 1, 10);
//                float t = activeNodes / countNonPhiUnits(hintNodes);
//                for (int i = 0; i < hintNodes.length; i++) {
//                    hintNodes[i].winRateTarget = t;
//                }
                WinRateCode.setWinRateTargets(hintNodes, activeNodes);
            }
            float activeNodes = panel.getFloat("L2 active nodes", 10, 1, 10);
//            float t = activeNodes / countNonPhiUnits(hiddenNodes2);
//            for (int i = 0; i < hiddenNodes2.length; i++) {
//                hiddenNodes2[i].winRateTarget = t;
//            }
            WinRateCode.setWinRateTargets(hiddenNodes2, activeNodes);
            super.updateSparseness();
        }
        // �V���������y�i���e�B�ɖ��Ή��B�폜�\��B
        public void updateSparsenessOld() {
            float sparseness2 = panel.getFloat("L2 sparseness", 0f, -10, 10);
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].sparseness = sparseness2;
            }
            super.updateSparseness();
        }
        public void updateNumValidEdges(Net net){
            super.updateNumValidEdges(net);
            setPreTraining(net, hiddenNodes2);
            
            //
            int numValidEdgesL2 = panel.getInt("L2 numValidEdges", 1000, 1, 10);
            setNumValidEdges(hiddenNodes2, numValidEdgesL2);
            int numValidEdgesL3 = panel.getInt("L3 numValidEdges", 1000, 1, 10);
            setNumValidEdges(hintNodes, numValidEdgesL3);
        }
        public void prepareNormalRecog(){
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].inputNodeFlag = false;
            }
        }
        public void preparePostTransRecog(){
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].inputNodeFlag = true;
            }
            // winnerID �͓��ɐݒ肵�Ȃ��B���O�̔F�����ʂ��ϑ��l�Ƃ��Ĉ�����B
        }
    }
    
    
    // �R�w�a�d�r�n�l�B���������o�[�W�����B�i�k�P�m�[�h�͋Ǐ���e������B�j
    // ���͂ɂ��Ă� n x n �̉摜�ł���Ɖ���B
    public static class Hidden3p extends HiddenForImage {
        // �Q�w��
        public int numNodes2 = panel.getInt("numNodes2", 4, 1, 30);
        public int nodeSize2 = panel.getInt("nodeSize2", 20, 2, 100);
        public Node[][] partialL1Nodes = new Node[4][];

        // �P�w�ځi���͂ɋ߂����j
        public int numNodes1 = panel.getInt("numNodes1/4", 2, 1, 128);
        public int nodeSize1 = panel.getInt("nodeSize1", 20, 2, 100);
        public Node[] hiddenNodes2;

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            hiddenNodes1 = new Node[numNodes1 * 4];
            for (int i = 0; i < numNodes1 * 4; i++) {
                hiddenNodes1[i] = net.createNode("L1." + i, nodeSize1);
            }
            // ���͑w�Ƃk�P�̊Ԃ͕�������
            imageSize = (int)Math.sqrt(inputNodes.length);
            Lab.assertTrue(imageSize * imageSize == inputNodes.length);
            int halfSize = imageSize / 2;
            if (halfSize * 2 != imageSize){
                throw new Error("Sorry, imageSize should be even number.");
            }
            for (int i = 0; i < numNodes1; i++) {
                for (int y = 0; y < halfSize; y++) {
                    for (int x = 0; x < halfSize; x++) {
                        // ����
                        net.addEdge(hiddenNodes1[i], 
                                inputNodes[y * imageSize 
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 + i], 
                                inputNodes[y * imageSize
                                           + halfSize + x]);
                        // ����
                        net.addEdge(hiddenNodes1[numNodes1 * 2 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + x]);
                        // �E��
                        net.addEdge(hiddenNodes1[numNodes1 * 3 + i], 
                                inputNodes[(y + halfSize) * imageSize
                                           + halfSize + x]);
                        
                    }
                }
            }

            hiddenNodes2 = new Node[numNodes2];
            for (int i = 0; i < numNodes2; i++) {
                hiddenNodes2[i] = net.createNode("L2." + i, nodeSize2);
            }
            // ����
            for (int i = 0; i < hiddenNodes2.length; i++) {
                for (int j = 0; j < hiddenNodes1.length; j++) {
                    // �����̓t�������B
                    net.addEdge(hiddenNodes2[i], hiddenNodes1[j]);
                }
                for (int j = 0; j < hintNodes.length; j++) {
                    // �����̓t�������B
                    net.addEdge(hiddenNodes2[i], hintNodes[j]);
                }
            }

            
            for (int i = 0; i < 4; i++) {
                icaCode.fullConnectLateralEdges(partialL1Nodes[i]);
            }
            icaCode.fullConnectLateralEdges(hiddenNodes2);
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(Node.append(hiddenNodes1, hiddenNodes2),
                    hintNodes);
        }
        public void copyNodes(Node[] nodes1, Node[] nodes2, int fromIndex){
            for (int i = 0; i < nodes1.length; i++) {
                nodes1[i] = nodes2[fromIndex + i];
            }
        }

        // �e�X�g�p�B�������B
        // �X�p�[�X���̖ڕW�l�ɍ��킹�ăX�p�[�X���p�����^�̒l�𒲐��B
        public void adaptSparseness() {
            int activeNodes2 = panel.getInt("activeNodes L2", 4, 1, 20);
            int activeNodes1 = panel.getInt("activeNodes L1", 4, 1, 20);
            float sensitivity = panel.getFloat("sensitivity", 0.1f, 0, 1);
            adaptSparseness1(hiddenNodes1, activeNodes1, sensitivity);
            adaptSparseness1(hiddenNodes2, activeNodes2, sensitivity);
        }
        public int plotInterval = 100;
        public int plotCounter = 0;
        public void adaptSparseness1(Node[] nodes, int activeNodes,
                float sensitivity) {
            int currentActiveNodes = 0;
            for (int i = 0; i < nodes.length; i++) {
                if (nodes[i].winnerID != 0){
                    currentActiveNodes++;
                }
            }
            // ���O�� sparseness �̒l�B
            float sparseness = nodes[0].sparseness;
            // �����Ă�H�H�H
            sparseness += sensitivity * (currentActiveNodes - activeNodes);
            for (int i = 0; i < nodes.length; i++) {
                nodes[i].sparseness = sparseness;
            }
            if (plotCounter++ >= plotInterval){
                plotCounter = 0;
                env.viewPanel.plot("sparseness of "+ nodes[0].nodeName, sparseness);
            }
        }

        public void updateSparseness() {
            float sparseness2 = panel.getFloat("L2 sparseness", 0f, -10, 10);
            for (int i = 0; i < hiddenNodes2.length; i++) {
                hiddenNodes2[i].sparseness = sparseness2;
            }
            super.updateSparseness();
        }
        public void updateNumValidEdges(Net net){
            super.updateNumValidEdges(net);
            setPreTraining(net, hiddenNodes2);
        }
    }


    // �V���v���ȂQ�w�a�d�r�n�l�B
    public static class Hidden2 extends HiddenForImage {
        public int numNodes = panel.getInt("numNodes", 4, 1, 30);

        public int nodeSize = panel.getInt("nodeSize", 10, 2, 100);

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            imageSize = (int)Math.sqrt(inputNodes.length);
            hiddenNodes1 = new Node[numNodes];
            for (int i = 0; i < numNodes; i++) {
                hiddenNodes1[i] = net.createNode("H" + i, nodeSize);
            }
            // �t������
            for (int i = 0; i < hiddenNodes1.length; i++) {
                for (int j = 0; j < inputNodes.length; j++) {
                    net.addEdge(hiddenNodes1[i], inputNodes[j]);
                }
                for (int j = 0; j < hintNodes.length; j++) {
                    net.addEdge(hiddenNodes1[i], hintNodes[j]);
                }
            }
            
            icaCode.fullConnectLateralEdges(hiddenNodes1);
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(hiddenNodes1, hintNodes);
        }
    }
    // �Q�w�a�d�r�n�l�A���j�b�g�����m�[�h���ƂɎw��\�B����`�h�b�`�e�X�g�p�B
    public static class Hidden2u extends HiddenForImage {
        public int numNodes = panel.getInt("numNodes", 3, 1, 30);

        //public int nodeSize = panel.getInt("nodeSize", 10, 2, 100);

        public void addHiddenLayers(Net net, Node[] inputNodes, Node[] hintNodes) {
            this.pixelNodes = inputNodes;
            this.hintNodes = hintNodes;
            imageSize = (int)Math.sqrt(inputNodes.length);
            hiddenNodes1 = new Node[numNodes];
            for (int i = 0; i < numNodes; i++) {
                int nodeSize = panel.getInt(i+ ":nodeSize", 10, 2, 100);
                hiddenNodes1[i] = net.createNode("H" + i, nodeSize);
            }
            // �t������
            for (int i = 0; i < hiddenNodes1.length; i++) {
                for (int j = 0; j < inputNodes.length; j++) {
                    net.addEdge(hiddenNodes1[i], inputNodes[j]);
                }
//                for (int j = 0; j < hintNodes.length; j++) {
//                    net.addEdge(hiddenNodes1[i], hintNodes[j]);
//                }
            }
            
            
            icaCode.fullConnectLateralEdges(hiddenNodes1);
            icaCode.initICA(net);
            
            visualizableNodes = Node.append(hiddenNodes1, hintNodes);
        }
    }

    /**
     * �e���j�b�g�̕��ϓ��͉摜���o�́B���w�Ή��B
     */
    public static class MeanImagePainter extends Lab.Code implements
            Lab.Painter {
        // BUG: Hidden2, Hidden3p �������ނ���l���Z�b�g���Ă���B���͂P�Q���߂����B
        public int imageSize = 12; // ���߂����B

        public Node[] nodes;

        public void setNodes(Node[] nodes) {
            this.nodes = nodes;
        }

        // TODO: �c�O�Ȃ���A���܂̓X�P�[�������s���ɕύX�ł��Ȃ��B
        // �L�����o�X�T�C�Y�𓮓I�ɕς����Ȃ��̂ŁB
        int s = panel.getInt("Scale", 2, 1, 8);

        int headerHeight = 10;
        int nodePadding = 2;
        int unitPadding = 2 + 2;

        public Dimension getSize() {
            int x = (nodePadding + nodes.length * (imageSize + nodePadding))
                    * s;
            int maxNodeSize = 0;
            for (int i = 0; i < nodes.length; i++) {
                if (nodes[i].nodeSize > maxNodeSize) maxNodeSize = nodes[i].nodeSize;
            }
            int y = headerHeight + (unitPadding + maxNodeSize
                    * (imageSize + unitPadding))
                    * s;
            return new Dimension(x, y);
        }

        public void paintComponent(Graphics g, MouseEvent lastEvent) {
            boolean markWinner = panel.flag("Mark Winner", true);
            boolean paintBel = panel.flag("Paint BEL", true);
            for (int i = 0; i < nodes.length; i++) {
                int x = nodePadding + i * (imageSize + nodePadding);
                g.setColor(Color.BLACK);
                g.drawString(nodes[i].nodeName, x*s, headerHeight);
                for (int j = 0; j < nodes[i].nodeSize; j++) {
                    int y = unitPadding + j * (imageSize + unitPadding);
                    if (markWinner) {
                        if (nodes[i].winnerID == j) {
                            g.setColor(Color.RED);
                            g.drawRect(x * s - 1, headerHeight + y * s - 1, 
                                    imageSize * s + 1,
                                    imageSize * s + 1);
                        }
                    }
                    if (paintBel){
                        g.setColor(Color.BLUE);
                        // ���j�b�g�̉摜�̏�ɉ�����\���B
                        g.fillRect(x * s - 1, headerHeight + y * s - 1 - 2 * s,
                                (int)(nodes[i].bel[j] * imageSize * s), 2 * s);
                    }
                    drawImage1(g, x, y, nodes[i].meanInputs[j]);
                }
            }
        }

        public void drawImage1(Graphics g, int x, int y, float[] data) {
            if (data == null){
                g.setColor(Color.RED);
                g.drawString("null", x, y);
            } else {
                for (int row = 0; row < imageSize; row++) {
                    for (int col = 0; col < imageSize; col++) {
                        int i = row * imageSize + col;
                        g.setColor(Lab.toGrayColor(data[i]));
                        g.fillRect((x + col) * s, headerHeight + (y + row) * s, s, s);
                    }
                }
            }
        }
    }

    /**
     * �Q�l���̓m�[�h�w�̂P��̑w�̃m�[�h���\��������摜��`��B
     */
    public static class BasisImagePainter extends Lab.Code implements
            Lab.Painter {
        // BUG: HiddenForImage �������ނ���l���Z�b�g���Ă���B���͂P�Q���߂����B
        public int imageSize = 12; // ���߂����B

        public Node[] nodes;

        public boolean errorFlag = false;

        public void setNodes(Node[] nodes) {
            this.nodes = nodes;
//            for (int i = 0; i < nodes.length; i++) {
//                //checkError(nodes[i].children.length == imageSize * imageSize);
//                for (int l = 0; l < nodes[i].children.length; l++) {
//                    checkError(nodes[i].children[l].nodeSize == 2);
//                }
//            }
        }

        void checkError(boolean con) {
            //Lab.assertTrue(con);
            if (!con)
                errorFlag = true;
        }

        // TODO: �c�O�Ȃ���A���܂̓X�P�[�������s���ɕύX�ł��Ȃ��B
        // �L�����o�X�T�C�Y�𓮓I�ɕς����Ȃ��̂ŁB
        int s = panel.getInt("Scale", 2, 1, 8);

        int nodePadding = 2;

        int unitPadding = 1;

        public Dimension getSize() {
            if (errorFlag)
                return new Dimension(10, 10);
            int x = (nodePadding + nodes.length * (imageSize + nodePadding))
                    * s;
            int y = (unitPadding + nodes[0].nodeSize
                    * (imageSize + unitPadding))
                    * s;
            return new Dimension(x, y);
        }

        public boolean maskUnselected;
        public void paintComponent(Graphics g, MouseEvent lastEvent) {
            if (errorFlag)
                return;
            boolean markWinner = panel.flag("Mark Winner", true);
            maskUnselected = panel.flag("Show Selected Pixels");
            for (int i = 0; i < nodes.length; i++) {
                for (int j = 0; j < nodes[i].nodeSize; j++) {
                    int x = nodePadding + i * (imageSize + nodePadding);
                    int y = unitPadding + j * (imageSize + unitPadding);
                    if (markWinner) {
                        if (nodes[i].winnerID == j) {
                            g.setColor(Color.RED);
                            g.drawRect(x * s - 1, y * s - 1, imageSize * s + 1,
                                    imageSize * s + 1);
                        }
                    }
                    drawImage1(g, x, y, nodes[i].weights[j],
                            nodes[i]);
                }
            }
        }

        public void drawImage1(Graphics g, int x, int y, float[][] w,
                Node node) {
            for (int row = 0; row < imageSize; row++) {
                for (int col = 0; col < imageSize; col++) {
                    int i = row * imageSize + col;
                    if (maskUnselected) {
                        //if (node.validFeatureFlag[i]) {
                        if (node.validChildEdgeFlag[i]) {
                            g.setColor(Color.BLUE);
                        } else {
                            g.setColor(Color.GRAY);
                        }
                    } else {
                        g.setColor(Lab.toGrayColor(w[i][1]));
                    }
                    //                    if (maskUnselected && ! validFeatureFlag[i]){
                    //                        g.setColor(Color.BLUE);
                    //                    } else {
                    //                        g.setColor(Lab.toGrayColor(w[i][1]));
                    //                    }
                    g.fillRect((x + col) * s, (y + row) * s, s, s);
                }
            }
        }
    }

    // �p�~�\��H
    // �w�K�̏�Ԃ�]�����郂�W���[���B
    public static abstract class EvalCode extends Lab.Code {
        public int meanBin = panel.getInt("meanBin", 1000, 1, 1000);

        public int counter = 0;

        public float sum = 0;

        public void inject() {
        }

        public abstract void eval(Net net, CPTmodelCode cptModelCode,
                WinRateCode winRateCode, ICACode icaCode);

        // �w�K���ʕ]���p�B
        public static float evalLikelihood(Net net, CPTmodelCode cptModelCode,
                WinRateCode winRateCode, ICACode icaCode) {
            for (int i = 0; i < net.allNodes.length; i++) {
                Node node = net.allNodes[i];
                node.interpID = node.winnerID;
            }
            return net.calcLikelihood(net, cptModelCode, winRateCode, icaCode);
        }
    }

    public static class Eval1 extends EvalCode {
        int x = 0;
        // Start �{�^���������Ƃ��̃N���X�̃C���X�^���X����������A���̎��l�������������B
        long lastTime = System.currentTimeMillis();

        public void eval(Net net, CPTmodelCode cptModelCode, 
                WinRateCode winRateCode, ICACode icaCode) {
            counter++;
            sum += evalLikelihood(net, cptModelCode, winRateCode, icaCode);
            if (counter == meanBin) {
                long currentTime = System.currentTimeMillis();
                //env.viewPanel.println("log", ""+ x+ " elapsed time (msec): "+ (currentTime - lastTime));
                lastTime = currentTime;
                float mean = sum / meanBin;
                //System.out.println(mean);
                env.viewPanel.scatterPlot("Recog result log score", x++, mean);
                counter = 0;
                sum = 0;
            }
        }
    }

    public static abstract class NetCode extends Lab.Code {
        public void inject() {
        }

        public abstract Net createEmptyNet();
    }

    // ----------------------------------------------------------------
    public static class BMainCode1 extends Lab.MainCode {
        public NetCode netCode = panel.getCode("Net", NetCode.class);

        public InitCPTCode initCPTCode = panel.getCode("InitCPT",
                InitCPTCode.class, InitCPTCode1.class);

        public InputCode inputCode = panel.getCode("Input", InputCode.class);

//        public EncodeCode encodeCode = panel
//                .getCode("Encode", EncodeCode.class);

        public HiddenCode hiddenCode = panel
                .getCode("Hidden", HiddenCode.class);

        public CPTmodelCode cptModelCode = panel.getCode("CPTmodel",
                CPTmodelCode.class, CPTmeanOR.class);

        public RecogCode recogCode = panel.getCode("Recog", RecogCode.class,
                RecogOOBP.class);
        public RecogCode recogCode2 = panel.getCode("Recog2", RecogCode.class,
                RecogHill.class);

        public LearnCode learnCode = panel.getCode("Learn", LearnCode.class);

        public WinRateCode winRateCode = panel.getCode("WinRate",
                WinRateCode.class);

        public SelectEdgesCode selectEdgesCode = panel.getCode("SelectEdges",
                SelectEdgesCode.class);

        public BlurCode blurCode = panel.getCode("Blur", BlurCode.class);

        public ICACode icaCode = panel.getCode("ICACode", ICACode.class,
                ICAo1.class);

        public EvalCode evalCode = panel.getCode("EvalCode", EvalCode.class);

        public void main() {
            env.viewPanel.print1("Start time", ""+ new Date());

            // Dependency injection.
            netCode.inject();
            inputCode.inject();
            hiddenCode.inject(netCode, inputCode, icaCode);
            recogCode.inject(cptModelCode, winRateCode, icaCode);
            recogCode2.inject(cptModelCode, winRateCode, icaCode);
            learnCode.inject(blurCode, netCode, selectEdgesCode);
            winRateCode.inject();
            selectEdgesCode.inject();
            blurCode.inject(netCode);
            icaCode.inject(netCode);
            evalCode.inject();

            // Initialization.
            Net net = netCode.createEmptyNet();
            // �l�b�g���[�N�̍\�z�A�b�o�s�̏������A�^�X�N�̏��������s���B
            inputCode.init(net);
            Node[] inputNodes = inputCode.addInputNodes(net);
            Node[] hintNodes = inputCode.addHintNodes(net);
            hiddenCode.addHiddenLayers(net, inputNodes, hintNodes);
            Node[] allNodes = net.allNodes;
            for (int i = 0; i < allNodes.length; i++) {
                allNodes[i].makeCPTarray();
                allNodes[i].makeMessageArray();
            }
            initCPTCode.initCPT(net);
            selectEdgesCode.initChildEdges(net);
            hiddenCode.updateNumValidEdges(net);
            selectEdgesCode.selectEdges(net); // �m�[�h�P��

            lab.Lab.WTextArea cptView = null;
            
            //net.print();
            
            int c = 0;
            for (;;) {
                panel.speedControl("Main Loop", 0);
                boolean denoisingTestFlag = panel.flag("Denoising Test");
                net.analogInputFlag = panel.flag("Analog input", true);
                boolean recogDemoFlag = panel.flag("Recog demo flag");
                // �F���f�����ɂ͑��������E�����y�i���e�B�͖����B
                net.noPenaltyFlag = panel.flag("No penalty");
                
                winRateCode.winRateC = panel.getFloat("winRateC", 1, 0, 100);
                icaCode.icaC = panel.getFloat("icaC", 1, 0, 100);
                icaCode.numValidLateralEdge = icaCode.panel.getInt("numValidLateralEdge", 100, 0, 10);
                hiddenCode.updateNumValidEdges(net);
                selectEdgesCode.selectEdges(net);
                hiddenCode.updateSparseness();
                RecogCode selectedRecogCode;
                if (panel.flag("Use recog2", false)){
                    selectedRecogCode = recogCode2;
                } else {
                    selectedRecogCode = recogCode;
                }
                float[] inputData;
                if (denoisingTestFlag){
                    // ���͉摜��ό`���Ȃ��ŔF���B
                    net.translateInputFlag = false;
                    hiddenCode.prepareNormalRecog();
                    inputData = inputCode.input();
                    selectedRecogCode.calcMPE(net);
                    if (panel.flag("Paint Units", true)) {
                        hiddenCode.paintUnits();
                    }
                    panel.speedControl("Before translation", 0);
                    
                    // ���͉摜��ό`�������̂�F���B
                    net.translateInputFlag = true;
                    hiddenCode.preparePostTransRecog();
                    inputData = inputCode.input();
                    selectedRecogCode.calcMPE(net);
                    
                    // �O�̂��߂��Ƃɖ߂��Ă����B
                    net.translateInputFlag = false;
                    hiddenCode.prepareNormalRecog();
                } else {
                    // inputData ���󂯎��͉̂����̂��߁B�����͔p�~�������B
                    inputData = inputCode.input();
                    selectedRecogCode.calcMPE(net);
                }
                //System.out.println("c="+ c);
                //for (int i = 0; i < net.allNodes.length; i++) {
                //    System.out.println(net.allNodes[i].winnerID);
                //}
                if (! recogDemoFlag){
                    // �F�����ʂ̕]���B�ΐ��ޓx�̃O���t��`��B
                    evalCode.eval(net, cptModelCode, winRateCode, icaCode);
                    learnCode.learn(net);
                    winRateCode.updateWinRates(net);
                    icaCode.updateCTable(net);
                    hiddenCode.learnMeanInput(inputData); // �����p
                    inputCode.evalRecogResult(net, selectedRecogCode, 
                            cptModelCode, winRateCode, icaCode);
                }

                inputCode.paintPosterior(); // �قڕs�v�Ȃ̂Ŕp�~�������B

                // �p�~�B
                //net.copyWeightsToWeightTs();

                if (panel.flag("Pr CPT", false)) {
                    if (cptView == null){
                        cptView = new lab.Lab.WTextArea(env, "CPT");
                        cptView.setSize(30, 85);
                    }
                    // �t�H���g�T�C�Y�ݒ�͂������d���̂Œ��ӁB
                    cptView.setFontSize(panel.getInt("Font", 12, 1, 12));
                    //cptView.setText(""+ c+ net.toCompactString());
                    cptView.setText(net.cptToString());
                }
                if (panel.flag("Paint Units", true)) {
                    hiddenCode.paintUnits();
                }
                if (panel.flag("Paint L1 CPT", false)) {
                    hiddenCode.paintCPT(net);
                }
                if (panel.flag("Pr counter", true)) {
                    env.viewPanel.print1("c", "" + c);
                }
                if (panel.flag("Plot all alpha", false)) {
                    plotAllAlpha(allNodes);
                }
                if (panel.flag("Plot all winRates", false)) {
                    plotAllWinRates(allNodes);
                }
                c++;
            }
        }

        Lab.WGraph allAlphaGraph = null;

        void plotAllAlpha(Node[] nodes) {
            if (allAlphaGraph == null) {
                allAlphaGraph = new Lab.WGraph(env, "All alpha");
                allAlphaGraph.setGraphType("scatter");
                allAlphaGraph.fixX(0, 500); // ���߂���
            }
            allAlphaGraph.resetData();
            allAlphaGraph.plot(0, 0); // y���̉��[���O�ɌŒ肷�邽�߃v���b�g�B
            int x = 0;
            for (int i = 0; i < nodes.length; i++) {
                for (int j = 1; j < nodes[i].nodeSize; j++) {
                    if (nodes[i].children.length != 0) {
                        allAlphaGraph.plot(x++, nodes[i].alpha[j]);
                    }
                }
            }
        }

        Lab.WGraph allWinRatesGraph = null;

        void plotAllWinRates(Node[] nodes) {
            if (allWinRatesGraph == null) {
                allWinRatesGraph = new Lab.WGraph(env, "All winRates of non-phi units.");
                allWinRatesGraph.setGraphType("scatter");
                allWinRatesGraph.fixX(0, 500); // ���߂���
            }
            allWinRatesGraph.resetData();
            allWinRatesGraph.plot(0, 0); // y���̉��[���O�ɌŒ肷�邽�߃v���b�g�B
            int x = 0;
            for (int i = 0; i < nodes.length; i++) {
                for (int j = 1; j < nodes[i].nodeSize; j++) {
                    if (nodes[i].children.length != 0) {
                        allWinRatesGraph.plot(x++, nodes[i].winRates[j]);
                    }
                }
            }
        }
    }
}