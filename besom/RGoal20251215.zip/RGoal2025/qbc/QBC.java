/**
�� �萫�I�M�O��H

�� �p�a�b�L�q�̂c�r�k�ɂ��āB
 Java �� enum �̋@�\�� default method �̋@�\�̗������g�����߂ɁA
���s���낵�����ʁA
enum �� implement �� inner class ��g�ݍ��킹��
 ���݂̃X�^�C���ɂƂ肠�����Ȃ��Ă���B
�����Ƃ������@�����邩������Ȃ��B

*/

package qbc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lab.Lab;
import lab.Lab.LabCode;
import qbc.QBC.QBCdsl;
import qbc.QBC.QBCnet;
import qbc.QBC.QBCnetCode;
import qbc.QBN.QBNnet;
import qbc.QBN.ResultVisualizer;
import qbc.QBN.VarEnv;
import qbc.QBNlab.QBNnetCode;
import qbc.QBNlab.QBNtestMain;
import qbc.QBNlab.VisualizerCode;

public class QBC {
    public static void main(String[] args) {
        Lab.addSelectableClass(QBN.class);
        Lab.addSelectableClass(QBNlab.class);
        Lab.addSelectableClass(QBC.class);
        System.out.println(Lab.selectableClasses + "");

        LabCode labCode = new LabCode();
        labCode.main(QBCMain.class);
    }
    /**
     *  QBC ��`���x�����邽�߂̃��\�b�h���`���邽�߂�����
     * �_�~�[�̃C���^�[�t�F�[�X�B
     *  QBC ���`����N���X���� implements ���Ďg���B
     */
    public static interface QBCdsl {
        public static String __ = QBN.WildCard; // Two underscores.
        public static String O = QBN.Open;
        public static String I = QBN.Inhibit;
        public default TableNode tableNode(Object nodeName,
                List<TableRow> table){
           return new TableNode(nodeName, table);
        }
        public default List<TableRow> table(TableRow... objs){
            List<TableRow> list = Arrays.asList(objs);
            return list;
        }
        public default TableRow row(Object rowName, Object... objs){
            return new TableRow(rowName, objs);
        }
        public default Object or(Object... objs){
            return new TableElement(Arrays.asList(objs));
        }
        public default GateMatrix gateMatrix(List<Object> list1,
                List<Object> list2, List<Object> list3){
            return new GateMatrix(list1, list2, list3);
        }
        public default List<Object> list(Object... objs){
            return Arrays.asList(objs);
        }
        public default ExclusiveNode exclusiveNode(List<Object> list){
            return new ExclusiveNode(list);
        }
    }
    //public static abstract class QBCnetCode extends QBNnetCode {
    public static abstract class QBCnetCode extends Lab.Code {
        public QBNnet makeQBNnet() {
            QBCnet net = makeQBCnet();
            return QBC.qbcToQbn(net);
        }
        public abstract QBCnet makeQBCnet();
    }
    /** 
     * �e�X�g�v���O�����̃e���v���[�g�B
     */
    public static class QBCtest0 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,X1,X2,
            A,B,C,D,E,F,
            W,X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(V1,__,A),
                        row(V2,A,B)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(V1,__,__),
                        row(V2,A,__)
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(A), row(B)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(A), row(B)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                return net;
            }
        }
    }
    /** 
     * ���G�^�זE�̂悤�ȉ���������v���O�����B
     * H, V �͉������ׂ����� 0 �ƂȂ�����܂܂�Ă��܂����A����ȊO�͐����������Ă���B
     */
    public static class ComplexCell02 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            CH, CV, P1, P2, 
            H, V,
            P00on, P01on, 
            P10on, P11on,
            P00off, P01off, 
            P10off, P11off,
            P00xor, P01xor, 
            P10xor, P11xor,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                
                net.tableNodeList.add(tableNode(CH, table(
                        // Link from H to Pyx, Pyx 
                        row(P1, O,O,I,I, I,I,O,O),
                        row(P2, I,I,O,O, O,O,I,I)
                        )));
                net.tableNodeList.add(tableNode(CV, table(
                        // Link from V to Pyx, Pyx
                        row(P1, O,I,O,I, I,O,I,O),
                        row(P2, I,O,I,O, O,I,O,I)
                        )));
                net.tableNodeList.add(tableNode(H, table(
                		//row(O, __,__,__,__, __,__,__,__),
                		row(O, O,O,O,O, O,O,O,O),
                        row(I, I,I,I,I, I,I,I,I)
                        )));
                net.tableNodeList.add(tableNode(V, table(
                		//row(O, __,__,__,__, __,__,__,__),
                        row(O, O,O,O,O, O,O,O,O),
                        row(I, I,I,I,I, I,I,I,I)
                        )));
                net.tableNodeList.add(tableNode(P00xor, table(
                        row(P1, O, I), row(P2, I, O))));
                net.tableNodeList.add(tableNode(P01xor, table(
                        row(P1, O, I), row(P2, I, O))));
                net.tableNodeList.add(tableNode(P10xor, table(
                        row(P1, O, I), row(P2, I, O))));
                net.tableNodeList.add(tableNode(P11xor, table(
                        row(P1, O, I), row(P2, I, O))));
                net.tableNodeList.add(tableNode(P00on, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P01on, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P10on, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P11on, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P00off, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P01off, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P10off, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(P11off, table(row(O),row(I))));
//                net.tableNodeList.add(tableNode(P00on, table(row(I))));
//                net.tableNodeList.add(tableNode(P01on, table(row(I))));
//                net.tableNodeList.add(tableNode(P10on, table(row(I))));
//                net.tableNodeList.add(tableNode(P11on, table(row(I))));
//                net.tableNodeList.add(tableNode(P00off, table(row(I))));
//                net.tableNodeList.add(tableNode(P01off, table(row(I))));
//                net.tableNodeList.add(tableNode(P10off, table(row(I))));
//                net.tableNodeList.add(tableNode(P11off, table(row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(CH), list(H), 
                        list(P00on, P01on, P10on, P11on, P00off, P01off, P10off, P11off))
                        );
                net.gateMatrixList.add(gateMatrix(
                        list(CV), list(V), 
                        list(P00on, P01on, P10on, P11on, P00off, P01off, P10off, P11off))
                        );
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P00xor), list(P00on, P00off)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P01xor), list(P01on, P01off)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P10xor), list(P10on, P10off)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P11xor), list(P11on, P11off)));
                return net;
            }
        }
    }
    /** 
     * ���G�^�זE�̂悤�ȉ���������v���O�����B
     * �������A���̂p�a�b�̃Ӓl�̈������s���S�Ȃ̂ŏ����ρB�܂����낢��ւ�B
     */
    public static class ComplexCell01 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            CH, CV, P0, P1, P2, 
            H, V,
            B, W,
            X,
            P00on, P01on, 
            P10on, P11on,
            P00off, P01off, 
            P10off, P11off,
            P00, P01,
            P10, P11,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                
                net.tableNodeList.add(tableNode(CH, table(
                        // Link from H to Pyx, Pyx 
                        row(P0, I,I,I,I, I,I,I,I),
                        row(P1, O,O,I,I, I,I,O,O),
                        row(P2, I,I,O,O, O,O,I,I)
                        )));
                net.tableNodeList.add(tableNode(CV, table(
                        // Link from V to Pyx, Pyx
                        row(P0, I,I,I,I, I,I,I,I),
                        row(P1, O,I,O,I, I,O,I,O),
                        row(P2, I,O,I,O, O,I,O,I)
                        )));
                net.tableNodeList.add(tableNode(H, table(
                        //row(X, __,__,__,__, __,__,__,__),
                        row(O, O,O,O,O, O,O,O,O),
                        row(I, B,B,B,B, W,W,W,W)
                        )));
                net.tableNodeList.add(tableNode(V, table(
                        //row(X, __,__,__,__, __,__,__,__),
                        row(O, O,O,O,O, O,O,O,O),
                        row(I, B,B,B,B, W,W,W,W) 
                        )));
                net.tableNodeList.add(tableNode(P00, table(row(B),row(W))));
                net.tableNodeList.add(tableNode(P01, table(row(B),row(W))));
                net.tableNodeList.add(tableNode(P10, table(row(B),row(W))));
                net.tableNodeList.add(tableNode(P11, table(row(B),row(W))));
//                net.gateMatrixList.add(gateMatrix(list(),list(P00on),list(P00))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P01on),list(P01))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P10on),list(P10))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P11on),list(P11))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P00off),list(P00))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P01off),list(P01))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P10off),list(P10))); 
//                net.gateMatrixList.add(gateMatrix(list(),list(P11off),list(P11))); 
                net.gateMatrixList.add(gateMatrix(
                        list(CH), list(H), 
                        list(P00, P01, P10, P11))
                        );
                net.gateMatrixList.add(gateMatrix(
                        list(CH), list(H), 
                        list(P00, P01, P10, P11))
                        );
                net.gateMatrixList.add(gateMatrix(
                        list(CV), list(V), 
                        list(P00, P01, P10, P11))
                        );
                net.gateMatrixList.add(gateMatrix(
                        list(CV), list(V), 
                        list(P00, P01, P10, P11))
                        );
                return net;
            }
        }
    }

    /** 
     * Categorial Grammer inference rules
     * ���K�͔ŁB 
     */
    public static class CGinference2 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            S, NP, // Ground categories 
            F, // "/"
            B, // "\"
            L,R,LB,RB, // ">", "<", ">B", "<B"
            V, // void value
            IR, // Inference Rules : X, Y -> Z
            X1,X2,X3,X4,X5,X6,X7,
            Y1,Y2,Y3,Y4,Y5,Y6,Y7,
            Z1,Z2,Z3,Z4,Z5,Z6,Z7,
            V1,V2,V3, // Variables for unification.
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                List<TableRow> groundTable = table(row(S), row(NP), row(V));
                List<TableRow> slashTable = table(row(F), row(B), row(V));
                List<TableRow> groundTable2 = table(
                        row(S,S,S,S,S,S,S),
                        row(NP,NP,NP,NP,NP,NP,NP),
                        row(V,V,V,V,V,V,V));
                List<TableRow> slashTable2 = table(
                        row(F,F,F,F,F,F,F),
                        row(B,B,B,B,B,B,B),
                        row(V,V,V,V,V,V,V));
                net.tableNodeList.add(tableNode(X1, groundTable));
                net.tableNodeList.add(tableNode(X2, slashTable));
                net.tableNodeList.add(tableNode(X3, groundTable));
                net.tableNodeList.add(tableNode(Y1, groundTable));
                net.tableNodeList.add(tableNode(Y2, slashTable));
                net.tableNodeList.add(tableNode(Y3, groundTable));
                net.tableNodeList.add(tableNode(Z1, groundTable2));
                net.tableNodeList.add(tableNode(Z2, slashTable2));
                net.tableNodeList.add(tableNode(Z3, groundTable2));
                net.tableNodeList.add(tableNode(V1, groundTable2));
                net.tableNodeList.add(tableNode(IR, table(
                        // Rule > :  A/X X.. -> A..
                        row(L,
                                __,V,V,  //Z1-3
                                __,F,__, //X1-3
                                __,V,V,  //Y1-3
                                // Link from Z1-3, V1 to X1-3, Y1-3
                                O,I,I, I, //X1
                                I,I,I, I, //X2
                                I,I,I, O, //X3
                                I,I,I, O, //Y1
                                I,I,I, I, //Y2
                                I,I,I, I  //Y3
                                ),
                        // Rule < : X.. A\X -> A..
                        row(R,
                                __,V,V,
                                __,V,V,
                                __,B,__,
                                // Link from Z1-3, V1 to X1-3, Y1-3
                                I,I,I, O, //X1
                                I,I,I, I, //X2
                                I,I,I, I, //X3
                                O,I,I, I, //Y1
                                I,I,I, I, //Y2
                                I,I,I, O  //Y3
                                )
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(),
                        list(IR),
                        list(Z1,Z2,Z3, 
                             X1,X2,X3, 
                             Y1,Y2,Y3)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(IR),
                        list(Z1,Z2,Z3, V1), 
                        list(X1,X2,X3, Y1,Y2,Y3)
                        ));
                return net;
            }
        }
    }
    /** 
     * Categorial Grammer inference rules
     * �e�m�[�h�����������ĕϊ��ɔ��Ɏ��Ԃ�������B 
     */
    public static class CGinference1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            S, NP, // Ground categories 
            F, // "/"
            B, // "\"
            L,R,LB,RB, // ">", "<", ">B", "<B"
            V, // void value
            IR, // Inference Rules : X, Y -> Z
            X1,X2,X3,X4,X5,X6,X7,
            Y1,Y2,Y3,Y4,Y5,Y6,Y7,
            Z1,Z2,Z3,Z4,Z5,Z6,Z7,
            V1,V2,V3, // Variables for unification.
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                List<TableRow> groundTable = table(row(S), row(NP), row(V));
                List<TableRow> slashTable = table(row(F), row(B), row(V));
                List<TableRow> groundTable2 = table(
                        row(S,S,S,S,S,S,S,S,S,S,S,S,S,S,S),
                        row(NP,NP,NP,NP,NP,NP,NP,NP,NP,NP,NP,NP,NP,NP,NP),
                        row(V,V,V,V,V,V,V,V,V,V,V,V,V,V,V));
                List<TableRow> slashTable2 = table(
                        row(F,F,F,F,F,F,F,F,F,F,F,F,F,F,F),
                        row(B,B,B,B,B,B,B,B,B,B,B,B,B,B,B),
                        row(V,V,V,V,V,V,V,V,V,V,V,V,V,V,V));
                net.tableNodeList.add(tableNode(X1, groundTable));
                net.tableNodeList.add(tableNode(X2, slashTable));
                net.tableNodeList.add(tableNode(X3, groundTable));
                net.tableNodeList.add(tableNode(X4, slashTable));
                net.tableNodeList.add(tableNode(X5, groundTable));
                net.tableNodeList.add(tableNode(X6, slashTable));
                net.tableNodeList.add(tableNode(X7, groundTable));
                net.tableNodeList.add(tableNode(Y1, groundTable));
                net.tableNodeList.add(tableNode(Y2, slashTable));
                net.tableNodeList.add(tableNode(Y3, groundTable));
                net.tableNodeList.add(tableNode(Y4, slashTable));
                net.tableNodeList.add(tableNode(Y5, groundTable));
                net.tableNodeList.add(tableNode(Y6, slashTable));
                net.tableNodeList.add(tableNode(Y7, groundTable));
                net.tableNodeList.add(tableNode(Z1, groundTable2));
                net.tableNodeList.add(tableNode(Z2, slashTable2));
                net.tableNodeList.add(tableNode(Z3, groundTable2));
                net.tableNodeList.add(tableNode(Z4, slashTable2));
                net.tableNodeList.add(tableNode(Z5, groundTable2));
                net.tableNodeList.add(tableNode(Z6, slashTable2));
                net.tableNodeList.add(tableNode(Z7, groundTable2));
                net.tableNodeList.add(tableNode(V1, groundTable2));
                net.tableNodeList.add(tableNode(V2, slashTable2));
                net.tableNodeList.add(tableNode(V3, groundTable2));
                net.tableNodeList.add(tableNode(IR, table(
                        // Rule > :  ABC/XYZ X..YZ.. -> A..BC..
                        row(L,
                                __,V,V,__,__,V,V,       // Z1-7
                                __,__,__,F,__,__,__,    // X1-7
                                __,V,V,__,__,V,V,       // Y1-7
                                // Link from Z1-7, V1-3 to X1-7
                                O,I,I,I,I,I,I, I,I,I, //X1
                                I,I,I,O,I,I,I, I,I,I, //X2
                                I,I,I,I,O,I,I, I,I,I, //X3
                                I,I,I,I,I,I,I, I,I,I, //X4
                                I,I,I,I,I,I,I, O,I,I, //X5
                                I,I,I,I,I,I,I, I,O,I, //X6
                                I,I,I,I,I,I,I, I,I,O, //X7

                                // Link from Z1-7, V1-3 to Y1-7
                                I,I,I,I,I,I,I, O,I,I, //Y1
                                I,I,I,I,I,I,I, I,I,I, //Y2
                                I,I,I,I,I,I,I, I,I,I, //Y3
                                I,I,I,I,I,I,I, I,O,I, //Y4
                                I,I,I,I,I,I,I, I,I,O, //Y5
                                I,I,I,I,I,I,I, I,I,I, //Y6
                                I,I,I,I,I,I,I, I,I,I  //Y7
                                )
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(),
                        list(IR),
                        list(Z1,Z2,Z3,Z4,Z5,Z6,Z7,  
                                X1,X2,X3,X4,X5,X6,X7, 
                                Y1,Y2,Y3,Y4,Y5,Y6,Y7)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(IR),
                        list(Z1,Z2,Z3,Z4,Z5,Z6,Z7, V1,V2,V3), 
                        list(X1,X2,X3,X4,X5,X6,X7, Y1,Y2,Y3,Y4,Y5,Y6,Y7)
                        ));
                return net;
            }
        }
    }
    /** 
     * Unificaiton test
     *  Unify V=(a,X,X) and W=(Y,b,Z). Result: R=(a,b,b),X=Z=a,Y=b .
     *  �i������ϐ��̒l�Ƃ��Ďg���Ă��邪�A���������������ۏ؂͂Ȃ��i�͂��j�B�v���ӁB�j
     */
    public static class UnificationTest1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            V1,V2,V3,W1,W2,W3,R1,R2,R3,
            X,Y,Z,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(R1, table(
                        row(1,1,1),row(2,2,2),row(3,3,3))));
                net.tableNodeList.add(tableNode(R2, table(
                        row(1,1,1),row(2,2,2),row(3,3,3))));
                net.tableNodeList.add(tableNode(R3, table(
                        row(1,1,1),row(2,2,2),row(3,3,3))));
                net.tableNodeList.add(tableNode(V1, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(V2, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(V3, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(W1, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(W2, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(W3, table(
                        row(1),row(2),row(3))));
                net.tableNodeList.add(tableNode(X, table(
                        row(1,1,1),row(2,2,2),row(3,3,3))));
                net.tableNodeList.add(tableNode(Y, table(
                        row(1,1),row(2,2),row(3,3))));
                net.tableNodeList.add(tableNode(Z, table(
                        row(1,1),row(2,2),row(3,3))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(R1), list(V1,W1)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(R2), list(V2,W2)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(R3), list(V3,W3)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(X), list(V2,V3)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(Y), list(W1)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(Z), list(W3)
                        ));
                return net;
            }
        }
    }
    
    /**
     * �P��񂩂�[�w�i�ւ̕ϊ��B �l���������ވʒu��f�����g���ĕ\���B
     */
    public static class DeepCases1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            S,N1,N2,N3,M1,M3,W1,W2,W3,Agent, Object,
            Sactive, Spassive,
            Cat, Fish, 
            Wcat, Wfish, Weat, WisEatenBy,
            Nagent, Nobject, NactiveVerb, NpassiveVerb,
            V1,V2,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(S, table(
                        row(Sactive,Nagent,NactiveVerb,Nobject),
                        row(Spassive,Nobject,NpassiveVerb,Nagent)
                        )));
                net.tableNodeList.add(tableNode(N1, table(
                        row(Nagent,or(Wcat,Wfish), O,I),
                        row(Nobject,or(Wcat,Wfish), I,O)
                        )));
                net.tableNodeList.add(tableNode(N2, table(
                        row(NactiveVerb, Weat),
                        row(NpassiveVerb,WisEatenBy)
                        )));
                net.tableNodeList.add(tableNode(N3, table(
                        row(Nagent,or(Wcat,Wfish), O,I),
                        row(Nobject,or(Wcat,Wfish), I,O)
                        )));
                net.tableNodeList.add(tableNode(M1, table(
                        row(V1, Wcat, Cat, Cat),
                        row(V2, Wfish, Fish, Fish)
                        )));
                net.tableNodeList.add(tableNode(M3, table(
                        row(V1, Wcat, Cat, Cat),
                        row(V2, Wfish, Fish, Fish)
                        )));
                net.tableNodeList.add(tableNode(W1, table(
                        row(Wcat), row(Wfish))));
                net.tableNodeList.add(tableNode(W2, table(
                        row(Weat), row(WisEatenBy))));
                net.tableNodeList.add(tableNode(W3, table(
                        row(Wcat), row(Wfish))));
                net.tableNodeList.add(tableNode(Agent, table(
                        row(Cat),
                        row(Fish)
                        )));
                net.tableNodeList.add(tableNode(Object, table(
                        row(Cat),
                        row(Fish)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(S), list(N1,N2,N3)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N1), list(W1)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N2), list(W2)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N3), list(W3)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(M1), list(W1)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(M3), list(W3)));
                net.gateMatrixList.add(gateMatrix(
                        list(N1), list(M1), list(Agent,Object)));
                net.gateMatrixList.add(gateMatrix(
                        list(N3), list(M3), list(Agent,Object)));
                return net;
            }
        }
    }
    /**
     * �P��񂩂�[�w�i�ւ̕ϊ��B 
     */
    public static class DeepCases0 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            S,N1,N2,N3,M1,M3,W1,W2,W3,Agent, Object,
            Sactive, Spassive,
            Cat, Fish, 
            Wcat, Wfish, Weat, WisEatenBy,
            Nagent, Nobject, NactiveVerb, NpassiveVerb,
            V1,V2,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(S, table(
                        row(Sactive,Nagent,NactiveVerb,Nobject),
                        row(Spassive,Nobject,NpassiveVerb,Nagent)
                        )));
                net.tableNodeList.add(tableNode(N1, table(
                        row(Nagent,or(Wcat,Wfish), O,I),
                        row(Nobject,or(Wcat,Wfish), I,O)
                        )));
                net.tableNodeList.add(tableNode(N2, table(
                        row(NactiveVerb, Weat),
                        row(NpassiveVerb,WisEatenBy)
                        )));
                net.tableNodeList.add(tableNode(N3, table(
                        row(Nagent,or(Wcat,Wfish), O,I),
                        row(Nobject,or(Wcat,Wfish), I,O)
                        )));
                net.tableNodeList.add(tableNode(M1, table(
                        row(V1, Wcat, Cat, Cat),
                        row(V2, Wfish, Fish, Fish)
                        )));
                net.tableNodeList.add(tableNode(M3, table(
                        row(V1, Wcat, Cat, Cat),
                        row(V2, Wfish, Fish, Fish)
                        )));
                net.tableNodeList.add(tableNode(W1, table(
                        row(Wcat), row(Wfish))));
                net.tableNodeList.add(tableNode(W2, table(
                        row(Weat), row(WisEatenBy))));
                net.tableNodeList.add(tableNode(W3, table(
                        row(Wcat), row(Wfish))));
                net.tableNodeList.add(tableNode(Agent, table(
                        row(Cat),
                        row(Fish)
                        )));
                net.tableNodeList.add(tableNode(Object, table(
                        row(Cat),
                        row(Fish)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(S), list(N1,N2,N3)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N1), list(W1)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N2), list(W2)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(N3), list(W3)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(M1), list(W1)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(M3), list(W3)));
                net.gateMatrixList.add(gateMatrix(
                        list(N1), list(M1), list(Agent,Object)));
                net.gateMatrixList.add(gateMatrix(
                        list(N3), list(M3), list(Agent,Object)));
                return net;
            }
        }
    }
    public static class DupTest0 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,X1,X2,
            A,B,C,D,E,F,
            W,X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(V1,A,B),
                        row(V1,C,D)
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(A), row(B), row(C), row(D)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(A), row(B), row(C), row(D)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1), list(X1,X2)
                        ));
                return net;
            }
        }
    }
    /** 
     * ���_�K���B
     *  A and A, not A -> A  �Ȃǂ̉����o��Ƃ�����肪����B
     */
    public static class Logic0 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            V1,V2,V3,
            T,
            X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3,
            T1,T2,T3,T4,T5,
            A,B,C,
            AND,OR,NOT,THEN,
            Dummy;
            public static String N = ".".intern();
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                Object var = or(A,B,C);
                net.tableNodeList.add(tableNode(T, table(
                        // childNames: [X1, X2, X3, Y1, Y2, Y3, Z1, Z2, Z3, 
                        // V1->X1, V2->X1, V3->X1, V1->X2, V2->X2, V3->X2, V1->X3, V2->X3, V3->X3, 
                        // V1->Y1, V2->Y1, V3->Y1, V1->Y2, V2->Y2, V3->Y2, V1->Y3, V2->Y3, V3->Y3,
                        // V1->Z1, V2->Z1, V3->Z1, V1->Z2, V2->Z2, V3->Z2, V1->Z3, V2->Z3, V3->Z3]
                        row(T1, // V1, V1->V2  ==>  V2
                                var,N,N, var,THEN,var, var,N,N,
                                O,I,I, I,I,I, I,I,I, 
                                O,I,I, I,I,I, I,O,I,
                                I,O,I, I,I,I, I,I,I),
                        row(T2, // not V2, V1->V2  ==>  not V1
                                N,NOT,var, var,THEN,var, N,NOT,var,
                                I,I,I, I,I,I, I,O,I,
                                O,I,I, I,I,I, I,O,I,
                                I,I,I, I,I,I, O,I,I),
                        row(T3, // V1 and V2, not V1  ==>  V2 
                                var,AND,var, N,NOT,var, var,N,N,
                                O,I,I, I,I,I, I,O,I,
                                I,I,I, I,I,I, O,I,I,
                                I,O,I, I,I,I, I,I,I),
                        row(T4, // V1->V2, V2->V3  ==>  V1->V3
                                var,THEN,var, var,THEN,var, var,THEN,var,
                                O,I,I, I,I,I, I,O,I,
                                I,O,I, I,I,I, I,I,O,
                                O,I,I, I,I,I, I,I,O)
                        )));
                List<TableRow> vars9Table = table(
                        row(A, A,A,A, A,A,A, A,A,A),
                        row(B, B,B,B, B,B,B, B,B,B),
                        row(C, C,C,C, C,C,C, C,C,C),
                        row(N, N,N,N ,N,N,N, N,N,N));
                List<TableRow> varsTable = table(
                        row(A), row(B), row(C), row(N));
                List<TableRow> opsTable = table(
                        row(AND), row(OR), row(NOT), row(THEN), row(N));
                net.tableNodeList.add(tableNode(V1, vars9Table));
                net.tableNodeList.add(tableNode(V2, vars9Table));
                net.tableNodeList.add(tableNode(V3, vars9Table));
                net.tableNodeList.add(tableNode(X1, varsTable));
                net.tableNodeList.add(tableNode(X2, opsTable));
                net.tableNodeList.add(tableNode(X3, varsTable));
                net.tableNodeList.add(tableNode(Y1, varsTable));
                net.tableNodeList.add(tableNode(Y2, opsTable));
                net.tableNodeList.add(tableNode(Y3, varsTable));
                net.tableNodeList.add(tableNode(Z1, varsTable));
                net.tableNodeList.add(tableNode(Z2, opsTable));
                net.tableNodeList.add(tableNode(Z3, varsTable));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(T), 
                        list(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(T), list(V1,V2,V3), 
                        list(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3)
                        ));
                return net;
            }
        }
    }
    /**
     * �\���ؐ����̃e�X�g�B
     * �P�ꐔ n �ɑ΂��� O(n^4) �̃p�����^���K�v�B
     */
    public static class QBCparseTree4N extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            P15,
            P14,P25,
            P13,P24,P35,
            P12,P23,P34,P45,
            J15,
            J14,J25,
            J2,J3,J4,
            S,N1,N2,
            N11,N21,N12,N22,
            N111,N121,N211,N221,
            N112,N122,N212,N222,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(P15, table(
                        //childNames: [P12, P13, P14, P25, P35, P45]
                        row(S,N1,N1,N1,N2,N2,N2))));
                net.tableNodeList.add(tableNode(P14, table(
                        row(N1,N11,N11,N12,N12),
                        row(I,__,__,__,__))));
                net.tableNodeList.add(tableNode(P25, table(
                        row(N2,N21,N21,N22,N22),
                        row(I,__,__,__,__))));
                net.tableNodeList.add(tableNode(P13, table(
                        row(N1,N11,N12),
                        row(N2,N21,N22),
                        row(N11,N111,N112),
                        row(N12,N121,N122),
                        row(N21,N211,N212),
                        row(N22,N221,N222),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P24, table(
                        row(N1,N11,N12),
                        row(N2,N21,N22),
                        row(N11,N111,N112),
                        row(N12,N121,N122),
                        row(N21,N211,N212),
                        row(N22,N221,N222),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P35, table(
                        row(N1,N11,N12),
                        row(N2,N21,N22),
                        row(N11,N111,N112),
                        row(N12,N121,N122),
                        row(N21,N211,N212),
                        row(N22,N221,N222),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P12, table(
                        row(N1),row(N2),
                        row(N11),row(N21),row(N12),row(N22),
                        row(N111),row(N121),row(N211),row(N221),
                        row(N112),row(N122),row(N212),row(N222))));
                net.tableNodeList.add(tableNode(P23, table(
                        row(N1),row(N2),
                        row(N11),row(N21),row(N12),row(N22),
                        row(N111),row(N121),row(N211),row(N221),
                        row(N112),row(N122),row(N212),row(N222))));
                net.tableNodeList.add(tableNode(P34, table(
                        row(N1),row(N2),
                        row(N11),row(N21),row(N12),row(N22),
                        row(N111),row(N121),row(N211),row(N221),
                        row(N112),row(N122),row(N212),row(N222))));
                net.tableNodeList.add(tableNode(P45, table(
                        row(N1),row(N2),
                        row(N11),row(N21),row(N12),row(N22),
                        row(N111),row(N121),row(N211),row(N221),
                        row(N112),row(N122),row(N212),row(N222))));
                //
                net.tableNodeList.add(tableNode(J15, table(
                        //childNames: [P13, J14, P14, J25, P25, P35, P24, P15->P12, P15->P13, P15->P14, P15->P25, P15->P35, P15->P45]
                        row(J2, // ��� [1,2],[2,5]
                                I,I,I,
                                or(J3,J4),__,__,
                                __,
                                O,I,I,
                                O,I,I),
                        row(J3, // ��� [1,3],[3,5]
                                __,I,I,
                                I,I,__,
                                I,
                                I,O,I,
                                I,O,I),
                        row(J4, // ��� [1,4],[4,5]
                                __,or(J2,J3),__,
                                I,I,I,
                                __,
                                I,I,O,
                                I,I,O)
                        )));
                net.tableNodeList.add(tableNode(J14, table(
                        //childNames: [P13, P24, P14->P12, P14->P13, P14->P24, P14->P34]
                        row(J2, // ��� [1,2],[2,4]
                                I,
                                __,
                                O,I,
                                O,I),
                        row(J3, // ��� [1,3],[3,4]
                                __,
                                I,
                                I,O,
                                I,O),
                        row(I,
                                __,
                                __,
                                I,I,
                                I,I)
                        )));
                net.tableNodeList.add(tableNode(J25, table(
                        //childNames: [P24, P35, P25->P23, P25->P24, P25->P35, P25->P45]
                        row(J3, // ��� [2,3],[3,5]
                                I,
                                __,
                                O,I,
                                O,I
                                ),
                        row(J4, // ��� [2,4],[4,5]
                                __,
                                I,
                                I,O,
                                I,O),
                        row(I,
                                __,
                                __,
                                I,I,
                                I,I)
                        )));
                //
                net.gateMatrixList.add(gateMatrix(
                        list(J15), list(P15), list(P12,P13,P14)));
                net.gateMatrixList.add(gateMatrix(
                        list(J15), list(P15), list(P25,P35,P45)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(P13,J14,P14)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(J25,P25,P35)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P12,P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P24,P34)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J25), list(P25), list(P23,P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J25), list(P25), list(P35,P45)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J25), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J25), list(P35)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P13), list(P12,P23)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P24), list(P23,P34)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P35), list(P34,P45)));
                return net;
            }
        }
    }
    /**
     * �\���ؐ����̃e�X�g�B�����K���� A -> A A �̂݁B����������Ȃ̂��s���B
     */
    public static class QBCparseTree4A extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            P15,
            P14,P25,
            P13,P24,P35,
            P12,P23,P34,P45,
            J15,
            J14,J25,
            J2,J3,J4,
            A,B,C,D,E,F,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(P15, table(
                        //childNames: [P12, P13, P14, P25, P35, P45]
                        row(A,A,A,A,A,A,A))));
                net.tableNodeList.add(tableNode(P14, table(
                        row(A,A,A,A,A),
                        row(I,__,__,__,__))));
                net.tableNodeList.add(tableNode(P25, table(
                        row(A,A,A,A,A),
                        row(I,__,__,__,__))));
                net.tableNodeList.add(tableNode(P13, table(
                        row(A,A,A),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P24, table(
                        row(A,A,A),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P35, table(
                        row(A,A,A),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P12, table(
                        row(A))));
                net.tableNodeList.add(tableNode(P23, table(
                        row(A))));
                net.tableNodeList.add(tableNode(P34, table(
                        row(A))));
                net.tableNodeList.add(tableNode(P45, table(
                        row(A))));
                //
                net.tableNodeList.add(tableNode(J15, table(
                        // childNames: [P13, J14, P14, J25, P25, P35, P24, P15->P12, P15->P13, P15->P14, P15->P25, P15->P35, P15->P45]
                        row(J2, // ��� [1,2],[2,5]
                                I,I,I,
                                or(J3,J4),__,__,
                                __,
                                O,I,I,
                                O,I,I),
                        row(J3, // ��� [2,3],[3,5]
                                __,I,I,
                                I,I,__,
                                I,
                                I,O,I,
                                I,O,I),
                        row(J4, // ��� [1,4],[4,5]
                                __,or(J2,J3),__,
                                I,I,I,
                                __,
                                I,I,O,
                                I,I,O)
                        )));
                net.tableNodeList.add(tableNode(J14, table(
                        //childNames: [P13, P24, P14->P12, P14->P13, P14->P24, P14->P34]
                        row(J2, // ��� [1,2],[2,4]
                                I,
                                __,
                                O,I,
                                O,I),
                        row(J3, // ��� [1,3],[3,4]
                                __,
                                I,
                                I,O,
                                I,O),
                        row(I,
                                __,
                                __,
                                I,I,
                                I,I)
                        )));
                net.tableNodeList.add(tableNode(J25, table(
                        //childNames: [P24, P35, P25->P23, P25->P24, P25->P35, P25->P45]
                        row(J3, // ��� [2,3],[3,5]
                                I,
                                __,
                                O,I,
                                O,I
                                ),
                        row(J4, // ��� [2,4],[4,5]
                                __,
                                I,
                                I,O,
                                I,O),
                        row(I,
                                __,
                                __,
                                I,I,
                                I,I)
                        )));
                //
                net.gateMatrixList.add(gateMatrix(
                        list(J15), list(P15), list(P12,P13,P14)));
                net.gateMatrixList.add(gateMatrix(
                        list(J15), list(P15), list(P25,P35,P45)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(P13,J14,P14)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(J25,P25,P35)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J15), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P12,P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P24,P34)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J25), list(P25), list(P23,P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(J25), list(P25), list(P35,P45)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J25), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J25), list(P35)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P13), list(P12,P23)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P24), list(P23,P34)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P35), list(P34,P45)));
                return net;
            }
        }
    }
    public static class QBCparseTree3 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            P14,
            P13,P24,
            P12,P23,P34,
            J14,
            J2,J3,J4,
            A,B,C,D,E,F,G,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(P14, table(
                        row(A,B,B,C,C))));
                net.tableNodeList.add(tableNode(P13, table(
                        row(A,B,C),
                        row(B,D,E),
                        row(C,F,G),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P24, table(
                        row(A,B,C),
                        row(B,D,E),
                        row(C,F,G),
                        row(I,__,__))));
                net.tableNodeList.add(tableNode(P12, table(
                        row(A),row(B),row(C),row(D),row(E),row(F),row(G))));
                net.tableNodeList.add(tableNode(P23, table(
                        row(A),row(B),row(C),row(D),row(E),row(F),row(G))));
                net.tableNodeList.add(tableNode(P34, table(
                        row(A),row(B),row(C),row(D),row(E),row(F),row(G))));
                //
                net.tableNodeList.add(tableNode(J14, table(
                        //childNames: [P13, P24, P14->P12, P14->P13, P14->P24, P14->P34]
                        row(J2, // ��� [1,2],[2,4]
                                I,
                                __,
                                O,I,
                                O,I),
                        row(J3, // ��� [1,3],[3,4]
                                __,
                                I,
                                I,O,
                                I,O)
                        )));
                //
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P12,P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(J14), list(P14), list(P24,P34)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P13)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(J14), list(P24)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P13), list(P12,P23)));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(P24), list(P23,P34)));
                return net;
            }
        }
    }
    /**
     * ���C���h�J�[�h�̃e�X�g�B
     * ���s���ʁF
    U1, U2, X1, X2, 
    V1, V1, A, A, 
    V1, V1, B, A, 
    V1, V2, A, A, 
    V2, V1, A, B, 
    V2, V2, A, B, 
    5 solutions.
     *
     */
    public static class QBCwildCardTest1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,X1,X2,
            A,B,C,D,E,F,
            W,X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(V1,__,A),
                        row(V2,A,B)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(V1,__,__),
                        row(V2,A,__)
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(A), row(B)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(A), row(B)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                return net;
            }
        }
    }
    public static class QBCexNodetest033 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,U3,
            V1,V2,V3,
            X1,X2,X3,
            Y1,Y2,Y3,
            C0,C1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(O,O,O,O),
                        row(I,or(O,I),or(O,I),O) // or(0,X1,X2)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(O,O,O,O),
                        row(I,O,or(O,I),or(O,I)) // or(0,X2,X3)
                        )));
                net.tableNodeList.add(tableNode(V1, table(
                        row(O,O,O,O),
                        row(I,or(O,I),O,or(O,I)) // or(0,X1,X3)
                        )));
                net.tableNodeList.add(tableNode(V2, table(
                        row(O,O,O,O),
                        row(I,O,I,O) // X2
                        )));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X3, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2,X3)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(V1,V2), list(X1,X2,X3)
                        ));
                net.exclusiveNodeList.add(exclusiveNode(list(U1,U2)));
                net.exclusiveNodeList.add(exclusiveNode(list(V1,V2)));
                net.exclusiveNodeList.add(exclusiveNode(list(X1,X2,X3)));
                return net;
            }
        }
    }     
    public static class QBCexNodetest03 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,U3,
            V1,V2,V3,
            X1,X2,X3,
            Y1,Y2,Y3,
            C0,C1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(O,O,O),
                        row(I,I,O)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(O,O,O),
                        row(I,O,I)
                        )));
                net.tableNodeList.add(tableNode(V1, table(
                        row(O,O,O),
                        row(I,I,O)
                        )));
                net.tableNodeList.add(tableNode(V2, table(
                        row(O,O,O),
                        row(I,O,I)
                        )));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(V1,V2), list(X1,X2)
                        ));
                net.exclusiveNodeList.add(exclusiveNode(list(U1,U2)));
                net.exclusiveNodeList.add(exclusiveNode(list(V1,V2)));
                net.exclusiveNodeList.add(exclusiveNode(list(X1,X2)));
                return net;
            }
        }
    }        
    public static class QBCexNodetest02 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,U3,
            V1,V2,V3,
            X1,X2,X3,
            Y1,Y2,Y3,
            C0,C1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(O,O,O),
                        row(I,I,O)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(O,O,O),
                        row(I,O,I)
                        )));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                net.exclusiveNodeList.add(exclusiveNode(list(U1,U2)));
                net.exclusiveNodeList.add(exclusiveNode(list(X1,X2)));
                return net;
            }
        }
    }        
    public static class QBCexNodetest01 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,U3,
            V1,V2,V3,
            X1,X2,X3,
            Y1,Y2,Y3,
            C0,C1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X3, table(row(O),row(I))));
                net.exclusiveNodeList.add(exclusiveNode(list(X1,X2,X3)));
                return net;
            }
        }
    }        
    public static class QBCn1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U,X1,X2,
            A,B,C,D,E,F,
            W,X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U, table(
                        row(V1,or(W,X),or(A,B)),
                        row(V2,or(Y,Z),or(C,D))
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(W), row(X), row(Y), row(Z)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(A), row(B), row(C), row(D)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U), list(X1,X2)
                        ));
                return net;
            }
        }
    }        
    public static class QBCn2 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,X1,X2,
            V11, V12, V21, V22,   
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        // U1 �̒l�� Vx, X1,X2 �̒l�� Vxy 
                        row(V1,or(V11,V12),or(V11,V12)),
                        row(V2,or(V21,V22),or(V21,V22))
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        // U2 �̒l�� Vy, X1,X2 �̒l�� Vxy 
                        row(V1,or(V11,V21),or(V11,V21)),
                        row(V2,or(V12,V22),or(V12,V22))
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(V11),
                        row(V12),
                        row(V21),
                        row(V22)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(V11),
                        row(V12),
                        row(V21),
                        row(V22)
                        )));
                net.gateMatrixList.add(new GateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                
                return net;
            }
        }
    }        
    public static class QBCn3 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U1,U2,U3,X1,X2,
            V11, V12, V21, V22,   
            V1,V2,V3,V4,
            Dummy;
            // Vx,Vy,Vz ���� Vzy,Vyz ������������B
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        // U1 �̒l�� Vx, X1 �̒l�� Vxy
                        row(V1,or(V11,V12)),
                        row(V2,or(V21,V22))
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        // U2 �̒l�� Vy, X1 �̒l�� Vxy , X2 �̒l�� Vyz 
                        row(V1,or(V11,V21),or(V11,V12)),
                        row(V2,or(V12,V22),or(V21,V22))
                        )));
                net.tableNodeList.add(tableNode(U3, table(
                        // U3 �̒l�� Vz, X2 �̒l�� Vyz 
                        row(V1,or(V11,V21)),
                        row(V2,or(V12,V22))
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                        row(V11),
                        row(V12),
                        row(V21),
                        row(V22)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                        row(V11),
                        row(V12),
                        row(V21),
                        row(V22)
                        )));
                // �v���^�̃l�b�g���[�N�B
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U2,U3), list(X2)
                        ));
                
                return net;
            }
        }        
    }
    public static class QBCdslTest1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            C1,C2,U1,U2,X1,X2,
            A,B,C,
            X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(X,A,A),
                        row(Y,B,B),
                        row(Z,C,C)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(X,A,A),
                        row(Y,B,B),
                        row(Z,C,C)
                        )));
                net.tableNodeList.add(tableNode(C1, table(
                        row(V1,I,I,O,O),
                        row(V2,I,I,O,O),
                        row(V3,O,O,I,I),
                        row(V4,O,O,I,I)
                        )));
                net.tableNodeList.add(tableNode(C2, table(
                        row(V1,I,O,I,O),
                        row(V2,O,I,O,I),
                        row(V3,I,O,I,O),
                        row(V4,O,I,O,I)
                        )));
                net.tableNodeList.add(tableNode(X1, table(row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(X2, table(row(A),row(B),row(C))));
                net.gateMatrixList.add(gateMatrix(
                        list(C1,C2), list(U1,U2), list(X1,X2)
                        ));
                
                return net;
            }
        }
    }
    public static class QBCdslTest2 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            C1,C2,U1,U2,X1,X2,
            A,B,C,
            X,Y,Z,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U1, table(
                        row(X,A,A),
                        row(Y,B,B),
                        row(Z,C,C)
                        )));
                net.tableNodeList.add(tableNode(U2, table(
                        row(X,A,A),
                        row(Y,B,B),
                        row(Z,C,C)
                        )));
                net.tableNodeList.add(tableNode(X1, table(row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(X2, table(row(A),row(B),row(C))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U1,U2), list(X1,X2)
                        ));
                
                return net;
            }
        }
    }
    public static class Convolution1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            U,X1,X2,X3,
    		Vuvw,Vu0,V0u,Vv0,V0v,Vw0,V0w,
    		Vxyz,Vx0,V0x,Vy0,V0y,Vz0,V0z,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(U, table(
                		row(Vuvw,or(Vu0,V0u),or(Vv0,V0v),or(Vw0,V0w)),
                		row(Vxyz,or(Vx0,V0x),or(Vy0,V0y),or(Vz0,V0z))
                        )));
                net.tableNodeList.add(tableNode(X1, table(
                		row(Vu0),row(V0u),row(Vx0),row(V0x)
                        )));
                net.tableNodeList.add(tableNode(X2, table(
                		row(Vv0),row(V0v),row(Vy0),row(V0y)
                        )));
                net.tableNodeList.add(tableNode(X3, table(
                		row(Vw0),row(V0w),row(Vz0),row(V0z)
                        )));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(U), list(X1,X2,X3)
                        ));
                return net;
            }
        }
    }        
    public static class Occlusion1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            WhereF, WhereB, WhatF, WhatB, // font object and back object
            X0,X1,
            A,B,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(WhereF, table(
                        // WhatF->X0, WhatB->X0, WhatF->X1, WhatB->X1
                        // front object ���ʒu X0 �ɂ���Ƃ��A
                        // �ʒu X0 �� front object �̌`������A
                        // back object �̈ʒu X0 �ւ̉e���͎Ւf�����B
                        row(X0,O,I,I,O),
                        row(X1,I,O,O,I)
                        )));
                net.tableNodeList.add(tableNode(WhereB, table(
                        // WhatF->X0, WhatB->X0, WhatF->X1, WhatB->X1
                        row(X0,O,O,O,I),
                        row(X1,O,I,O,O)
                        )));
                net.tableNodeList.add(tableNode(WhatF, table(
                        row(A,A,A),
                        row(B,B,B),
                        row(O,O,O)
                        )));
                net.tableNodeList.add(tableNode(WhatB, table(
                        row(A,A,A),
                        row(B,B,B),
                        row(O,O,O)
                        )));
                net.tableNodeList.add(tableNode(X0, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(X1, table(row(A),row(B))));
                net.gateMatrixList.add(gateMatrix(
                        list(WhereF,WhereB), 
                        list(WhatF,WhatB), 
                        list(X0,X1)
                        ));
                
                return net;
            }
        }
    }
    public static class Grid3 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            Where0, Where1, What,
            V0,V1,V2,V3,V4,
            L0,L1,L2,L3,L4,L5,L6,L7,L8,
            A,B,C,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(Where1, table(
                        row(V0,I,I,I,I,I,I,O,O,O),
                        row(V1,I,I,I,O,O,O,I,I,I),
                        row(V2,O,O,O,I,I,I,I,I,I)
                        )));
                net.tableNodeList.add(tableNode(Where0, table(
                        row(V0,I,I,O,I,I,O,I,I,O),
                        row(V1,I,O,I,I,O,I,I,O,I),
                        row(V2,O,I,I,O,I,I,O,I,I)
                        )));
                net.tableNodeList.add(tableNode(What, table(
                        row(A,A,A,A,A,A,A,A,A,A),
                        row(B,B,B,B,B,B,B,B,B,B)
                        )));
                net.tableNodeList.add(tableNode(L8, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L7, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L6, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L5, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L4, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L3, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L2, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L1, table(row(A),row(B))));
                net.tableNodeList.add(tableNode(L0, table(row(A),row(B))));
                net.gateMatrixList.add(gateMatrix(
                        list(Where1,Where0), 
                        list(What), 
                        list(L8,L7,L6,L5,L4,L3,L2,L1,L0)
                        ));
                
                return net;
            }
        }
    }
    public static class Grid2 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            Where0, Where1, What,
            V0,V1,V2,V3,V4,
            L0,L1,L2,L3,L4,
            A,B,C,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(Where1, table(
                        row(V0,I,I,O,O),
                        row(V1,O,O,I,I)
                        )));
                net.tableNodeList.add(tableNode(Where0, table(
                        row(V0,I,O,I,O),
                        row(V1,O,I,O,I)
                        )));
                net.tableNodeList.add(tableNode(What, table(
                        row(A,A,A,A,A),
                        row(B,B,B,B,B),
                        row(C,C,C,C,C)
                        )));
                net.tableNodeList.add(tableNode(L3, table(
                        row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L2, table(
                        row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L1, table(
                        row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L0, table(
                        row(A),row(B),row(C))));
                net.gateMatrixList.add(gateMatrix(
                        list(Where1,Where0), list(What), list(L3,L2,L1,L0)
                        ));
                
                return net;
            }
        }
    }
    public static class Grid1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            Where, What,
            V1,V2,V3,V4,
            L1,L2,L3,L4,
            A,B,C,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(Where, table(
                        row(V1,O,I,I,I),
                        row(V2,I,O,I,I),
                        row(V3,I,I,O,I),
                        row(V4,I,I,I,O)
                        )));
                net.tableNodeList.add(tableNode(What, table(
                        row(V1,A,A,A,A),
                        row(V2,B,B,B,B),
                        row(V3,C,C,C,C)
                        )));
                net.tableNodeList.add(tableNode(L1, table(row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L2, table(row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L3, table(row(A),row(B),row(C))));
                net.tableNodeList.add(tableNode(L4, table(row(A),row(B),row(C))));
                net.gateMatrixList.add(gateMatrix(
                        list(Where), list(What), list(L1,L2,L3,L4)
                        ));
                
                return net;
            }
        }
    }
    public static class Program3 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            PC,C,
            C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,
            X0,X1,X2,X3,X4,
            V,V0,V1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(C, table(
                        row(C0,or(C4,C9),V0,O,O,I,O,O),
                        row(C1,C0,__,O,I,O,I,O),
                        row(C2,C1,__,I,O,O,O,I),
                        row(C3,C2,__,O,I,O,I,O),
                        row(C4,C3,__,O,O,I,O,O),
                        //
                        row(C5,or(C4,C9),V1,I,O,O,O,I),
                        row(C6,C5,__,O,I,O,I,O),
                        row(C7,C6,__,O,O,I,O,O),
                        row(C8,C7,__,O,I,O,I,O),
                        row(C9,C8,__,I,O,O,O,I)
                        )));
                net.tableNodeList.add(tableNode(PC, table(
                        row(C0),
                        row(C1),
                        row(C2),
                        row(C3),
                        row(C4),
                        row(C5),
                        row(C6),
                        row(C7),
                        row(C8),
                        row(C9)
                        )));
                net.tableNodeList.add(tableNode(V, table(
                        row(V0),
                        row(V1)
                        )));
                net.tableNodeList.add(tableNode(X0, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X3, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X4, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(C), list(PC,V,X0,X1,X2,X3,X4)
                        ));
                
                return net;
            }
        }
    }
    public static class Program2 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            PC,C,
            C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,
            X0,X1,X2,X3,X4,
            V,V0,V1,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                // �e�m�[�h�̒l�ŏ�������
                net.tableNodeList.add(tableNode(PC, table(
                        // Table of row(previous-value, possible-next-value)
                        row(C0,C1),
                        row(C1,C2),
                        row(C2,C3),
                        row(C3,C4),
                        row(C4,or(C0,C5)),
                        row(C5,C6),
                        row(C6,C7),
                        row(C7,C8),
                        row(C8,C9),
                        row(C9,or(C0,C5))
                        )));
                // ���܂����������ۂ��Ȃ��B���̃��f���͎��s�B
                net.tableNodeList.add(tableNode(V, table(
                        row(V0,or(C0,C1,C2,C3,C4)),
                        row(V1,or(C5,C6,C7,C8,C9))
                        )));
                net.tableNodeList.add(tableNode(C, table(
                        row(C0,O,O,I,O,O),
                        row(C1,O,I,O,I,O),
                        row(C2,I,O,O,O,I),
                        row(C3,O,I,O,I,O),
                        row(C4,O,O,I,O,O),
                        //
                        row(C5,I,O,O,O,I),
                        row(C6,O,I,O,I,O),
                        row(C7,O,O,I,O,O),
                        row(C8,O,I,O,I,O),
                        row(C9,I,O,O,O,I)
                        )));
                net.tableNodeList.add(tableNode(X0, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X3, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X4, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(PC,V), list(C)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(C), list(X0,X1,X2,X3,X4)
                        ));
                
                return net;
            }
        }
    }
    public static class Program1 extends QBCnetCode {
        public QBCnet makeQBCnet(){
            return MakeNet.Dummy.makeNet();
        }
        public static enum MakeNet implements QBCdsl {
            PC,C,
            C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,
            X0,X1,X2,X3,X4,
            V1,V2,V3,V4,
            Dummy;
            public QBCnet makeNet(){
                QBCnet net = new QBCnet();
                net.tableNodeList.add(tableNode(PC, table(
                        // Table of row(previous-value, next-value)
                        row(C0,C1),
                        row(C1,C2),
                        row(C2,C3),
                        row(C3,C4),
                        row(C4,C0)
                        )));
                net.tableNodeList.add(tableNode(C, table(
                        row(C0,O,O,I,O,O),
                        row(C1,O,I,O,I,O),
                        row(C2,I,O,O,O,I),
                        row(C3,O,I,O,I,O),
                        row(C4,O,O,I,O,O)
                        )));
                net.tableNodeList.add(tableNode(X0, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X1, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X2, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X3, table(row(O),row(I))));
                net.tableNodeList.add(tableNode(X4, table(row(O),row(I))));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(PC), list(C)
                        ));
                net.gateMatrixList.add(gateMatrix(
                        list(), list(C), list(X0,X1,X2,X3,X4)
                        ));
                
                return net;
            }
        }
    }
    public static class QBCnet {
        public List<TableNode> tableNodeList = new ArrayList<>();
        public List<GateMatrix> gateMatrixList = new ArrayList<>();
        public List<ExclusiveNode> exclusiveNodeList = new ArrayList<>();
        public String toString(){
            return "QBCnet:"+ Lab.lineSeparator+
                    tableNodeList.toString()+
                    gateMatrixList.toString()+
                    exclusiveNodeList.toString();
        }
    }
    public static class TableNode {
        public Object nodeName;
        //public List<List<Object>> table;
        public List<TableRow> table;
        public TableNode(Object nodeName, List<TableRow> table) {
            this.nodeName = nodeName;
            this.table = table;
        }
        
        public List<TableNode> parents = new ArrayList<>();
        public List<Object> childNames = new ArrayList<>();
        public List<Object> values = new ArrayList<>();
        public List<Object> usedValues = new ArrayList<>();
        public List<GateNode> parentGateNodes = new ArrayList<>();
        public List<List<Object>> cpt = new ArrayList<>();
        
        public String toString() {
            StringBuffer buf = new StringBuffer();
            buf.append("TableNode nodeName: "+ nodeName);
            buf.append(Lab.lineSeparator);
            buf.append("table = {"+ Lab.lineSeparator);
            table.forEach(row -> {
                buf.append("  ");
                buf.append(row.rowName+ ": ");
                row.elements.forEach(element -> buf.append(element + ", "));
                buf.append(Lab.lineSeparator);
            });
            buf.append("}");
            buf.append(Lab.lineSeparator);
            buf.append("parent names : "+ listOfTableNodeToString(parents));
            buf.append(Lab.lineSeparator);
            buf.append("childNames: "+ childNames);
            buf.append(Lab.lineSeparator);
            buf.append("values: "+ values);
            buf.append(Lab.lineSeparator);
            buf.append("parentGateNodes's names: ");
            parentGateNodes.forEach(g -> {
                buf.append(g.nodeName+ ", ");
            });
            buf.append(Lab.lineSeparator);
            buf.append("cpt: "+ cpt);
            buf.append(Lab.lineSeparator);
            buf.append(Lab.lineSeparator);
            return buf.toString();
        }
        public static String listOfTableNodeToString(List<TableNode> list){
        	if (list == null) return "null";
        	String ret = "";
        	for (TableNode tableNode : list){
        		ret += tableNode.nodeName+ ", ";
        	}
        	return ret;
        }
    }
    public static class TableRow {
        public Object rowName;
        public List<Object> elements = new ArrayList<>();
        public TableRow(Object rowName, Object[] elements) {
            this.rowName = rowName;
            this.elements = Arrays.asList(elements);
        }
        public String toString(){
            return "row("+ rowName+ ", "+ elements;
        }
    }
    public static class TableElement {
        public List<Object> elements;
        public TableElement(List<Object> elements) {
            this.elements = elements;
        }
        public String toString() {
            StringBuffer buf = new StringBuffer();
            buf.append("or(");
            elements.forEach(e -> buf.append(e+ ","));
            buf.append(")");
            return buf.toString();
        }
    }
    public static class GateMatrix {
        public List<Object> controlNodes;
        public List<Object> parentNodes;
        public List<Object> childNodes;
            GateMatrix(List<Object> controlNodes,
                    List<Object> parentNodes,
                    List<Object> childNodes) {
            this.controlNodes = controlNodes;
            this.parentNodes = parentNodes;
            this.childNodes = childNodes;
        }
        // �Ⴆ�ΐe�� U1,U2 �A�q�� X1,X2 �̏ꍇ�A
        // U1->X1,U2->X1,U1->X2,U2->X2 �Ƃ������Ԃ� GateNode ��ێ��B 
        public List<GateNode> gateNodes = new ArrayList<>();
        public String toString(){
            return "GateMatrix "+ Lab.lineSeparator+
                    "controlNodes: "+ controlNodes+ Lab.lineSeparator+
                    "parentNodes: "+ parentNodes+ Lab.lineSeparator+
                    "childNodes"+ childNodes+ Lab.lineSeparator+
                    Lab.lineSeparator;
        }
    }
    public static class GateNode {
        public Object nodeName;
        public List<Object> controlNodeNames = new ArrayList<>();
        public TableNode parent;
        public List<List<Object>> cpt = new ArrayList<>();
        
        public String toString(){
            return "GateNode nodeName: "+ nodeName+ Lab.lineSeparator+ 
                    "controlNodeNames: "+ 
            		controlNodeNames+ Lab.lineSeparator+
                    "parent: "+ 
            		(parent == null ? "null" : parent.nodeName)+ Lab.lineSeparator+
                    "cpt: "+ cpt+ Lab.lineSeparator+
                    Lab.lineSeparator;
        }
            
        // myValue �𐶐�������e�m�[�h�̒l�̌��W�������B
        public List<Object> valueGenerator(Object myValue, TableNode controlNode){
            Set<Object> paValSet = new HashSet<>();
            int indexAtParent = controlNode.childNames.indexOf(nodeName);
            int paValId = 0;
            for (TableRow row : controlNode.table){
                if (tableElementMatch(myValue, row.elements.get(indexAtParent))){
                    // ���� row �ɑΉ�����e�m�[�h�̒l�� Set �ɒǉ��B
                    Object paVal = controlNode.values.get(paValId) ;
                    paValSet.add(paVal);
                }
                paValId++;
            }
            // Set �� List �ɕϊ����� return �B
            List<Object> ret = new ArrayList<>();
            paValSet.forEach(val -> ret.add(val));
            return ret;
        }
    }
    public static class ExclusiveNode {
        public String nodeName;
        public List<Object> parentNodes;
        public List<List<Object>> cpt = new ArrayList<>();
        ExclusiveNode(List<Object> parentNodes) {
            this.parentNodes = parentNodes;
            StringBuffer buf = new StringBuffer();;
            parentNodes.forEach(parentName -> buf.append(parentName));
            nodeName = buf.toString().intern();
        }
        public String toString(){
            return "ExclusiveNode "+ Lab.lineSeparator+
                    "parentNodes: "+ parentNodes+ Lab.lineSeparator+
                    Lab.lineSeparator;
        }
    }

    /**
     * �E�������̒��ӁF Object ���m�� == �ł͂Ȃ� equals �Ŕ�r���邱�ƁB
     */
    public static QBNnet qbcToQbn(QBCnet qbcNet){
        List<TableNode> tableNodeList = qbcNet.tableNodeList;
        List<GateMatrix> gateMatrixList = qbcNet.gateMatrixList;
        // �����̃A�E�g���C���i�\��j�F
        //   TableNode ���ƂɁA�Q�[�g�𖳎������ꍇ�̐e�m�[�h���X�g�����B
        //   �Q�[�g�͖������� tableNode �̂b�o�s���\�z�B
        //   �Q�[�g�̂b�o�s���\�z�B
        //   QBN �\�z�p�̃f�[�^�𐶐��B
        
        // TableNode �𖼑O�Ō����ł��� Map ������Ă����B
        Map<Object,TableNode> tableNodeMap = new HashMap<>();
        tableNodeList.forEach(node -> {
            // ���O�̏d���`�F�b�N
            if (tableNodeMap.get(node.nodeName) != null){
                throw new Error("duplicate table node name: "+ node.nodeName);
            }
            tableNodeMap.put(node.nodeName, node);
        });
        
        // �Q�[�g�m�[�h�����B
        List<GateNode> allGateNodes = new ArrayList<>();
        gateMatrixList.forEach(gm -> {
            // �e�m�[�h m �A�q�m�[�h n �ɑ΂��� m x n �̃Q�[�g�����B
            gm.childNodes.forEach(childName -> {
                TableNode childNode = tableNodeMap.get(childName);
                if (childNode == null){
                    throw new Error("childName "+ childName+ 
                            " not found.");
                }
                gm.parentNodes.forEach(parentName -> {
                    GateNode g = new GateNode();
                    TableNode parentNode = tableNodeMap.get(parentName);
                    if (parentName == null){
                        throw new Error("parentName "+ parentName+ 
                                " not found.");
                    }
                    g.nodeName = parentName + "->"+ childName;
                    g.controlNodeNames = new ArrayList<>(gm.controlNodes);
                    g.parent = parentNode;
                    gm.gateNodes.add(g);
                    allGateNodes.add(g);
                    childNode.parentGateNodes.add(g);
                });
            });
        });
        
        //   TableNode ���ƂɁA�Q�[�g�𖳎������ꍇ�̐e�m�[�h���X�g�ƁA
        // �Q�[�g���܂߂��q�m�[�h���X�g�ɒl��ǉ�����B
        gateMatrixList.forEach(gm -> {
            gm.parentNodes.forEach(parentName -> {
                TableNode parentNode = tableNodeMap.get(parentName);
                if (parentName == null){
                    throw new Error("parentName "+ parentName+ 
                            " not found.");
                }
                gm.childNodes.forEach(childName -> {
                    TableNode childNode = tableNodeMap.get(childName);
                    if (childNode == null){
                        throw new Error("childName "+ childName+ 
                                " not found.");
                    }
                    parentNode.childNames.add(childName);
                });
            });
            gm.childNodes.forEach(childName -> {
                TableNode childNode = tableNodeMap.get(childName);
                if (childNode == null){
                    throw new Error("childName "+ childName+ 
                            " not found.");
                }
                gm.parentNodes.forEach(parentName -> {
                    TableNode parentNode = tableNodeMap.get(parentName);
                    if (parentNode == null){
                        throw new Error("parentName "+ parentName+ 
                                " not found.");
                    }
                    childNode.parents.add(parentNode);
                });
            });
        });
        
        // ����m�[�h�̎q�m�[�h���X�g�ɂ̓Q�[�g���܂߂�B
        gateMatrixList.forEach(gm -> {
            gm.controlNodes.forEach(controlNodeName -> {
                TableNode controlNode = tableNodeMap.get(controlNodeName);
                if (controlNode == null){
                    throw new Error("controlNodeName "+ controlNodeName+ 
                            " not found.");
                }
                System.out.println("****:"+ gm.gateNodes.size());
                gm.gateNodes.forEach(g -> controlNode.childNames.add(g.nodeName));
            }); 
         });
        if (true){
            System.out.println("-----------------------------");
        	System.out.println(tableNodeList);
            System.out.println(allGateNodes);
        }
        // �e�[�u���T�C�Y�̐������̃`�F�b�N�B
        // TODO: row �̒l�̏d����`�`�F�b�N�B
        tableNodeList.forEach(tableNode -> {
            int size = tableNode.childNames.size();
            tableNode.table.forEach(row -> {
                if (row.elements.size() != size){
                    throw new Error(tableNode.nodeName+ ": row length is "+ 
                            row.elements.size()+ 
                            " but "+ size+
                            " is expected : "+ row);
                }
            });
        });

        // �e TableNode ����蓾��l��ݒ�B 
        tableNodeMap.forEach((nodeName, tableNode) -> {
            tableNode.table.forEach(row -> {
                // row(rowName, ...) �̍ŏ��̗v�f���W�߂�B
                tableNode.values.add(row.rowName);
            });
        });
        
        //  TableNode �̐e�Ŏg���Ă���l���W�߂�B�L�q�~�X�`�F�b�N�̂��߁B
        // XXX: ���C���h�J�[�h "__" �̈����́H
        tableNodeMap.forEach((nodeName, tableNode) -> {
            // �e�m�[�h�̃e�[�u�����玩������肤��l���W�߂�B
            Set<Object> myValuesSet = new HashSet<>(); 
            tableNode.parents.forEach(parentNode -> {
                // �������e���猩�ĉ��Ԗڂ̎q���Ȃ̂����ׂ�B
                int indexAtParent = parentNode.childNames.indexOf(nodeName);
                if (indexAtParent < 0){
                    throw new Error("nodeName "+ nodeName+ " not found in "+ 
                            parentNode.childNames+ " of "+ tableNode);
                }
                parentNode.table.stream()
                    .map(row -> row.elements.get(indexAtParent))
                    .forEach(element -> { 
                        if (element instanceof TableElement){
                            ((TableElement)element).elements.forEach(e ->
                                    myValuesSet.add(e));
                        } else {
                            myValuesSet.add(element);
                        }
                    });
            });
            // tableNode.values �ɒl��ݒ�B
            myValuesSet.forEach(val -> tableNode.usedValues.add(val));
        });
        // TODO: �e�Ŏg���Ă���l���q�Œ�`����Ă��邩���`�F�b�N�B

        if (true){
            System.out.println("before makeCpt -----------------------------");
            System.out.println(tableNodeList);
            System.out.println(allGateNodes);
        }

        // TableNode �� CPT �����B
        tableNodeMap.forEach((nodeName, tableNode) -> {
            tableNode.values.forEach(myValue -> {
                List<Set<Object>> paValSetList = new ArrayList<>();
                tableNode.parents.forEach(parentNode ->{
                    // myValue �𐶐�������e�m�[�h�̒l�̌��W�����A�e�m�[�h���Ƃɍ��B
                    Set<Object> paValSet = new HashSet<>();
                    int indexAtParent = parentNode.childNames.indexOf(nodeName);
                    int paValId = 0;
                    for (TableRow row : parentNode.table){
                        if (tableElementMatch(myValue, row.elements.get(indexAtParent))){
                            // ���� row �ɑΉ�����e�m�[�h�̒l�� Set �ɒǉ��B
                            Object paVal = parentNode.values.get(paValId) ;
                            paValSet.add(paVal);
                        }
                        paValId++;
                    }
                    // �ł��� Set �� List �ɒǉ��B
                    paValSetList.add(paValSet);
                });
                // Set �� List �ɕϊ��B
                List<List<Object>> paValListList = new ArrayList<>();
                paValSetList.forEach(set -> {
                    List<Object> list = new ArrayList<>();
                    set.forEach(val -> list.add(val));
                    // �e�m�[�h�̒l�̌��ɂ̓Ӓl���ǉ����Ă����B
                    // �e�m�[�h���Ӓl�ɂȂ肦�Ȃ����Ƃ����邩������Ȃ����A�p�a�m�̐��_���ʂɉe���͂Ȃ��B
                    list.add(QBN.Phi);
                    paValListList.add(list);
                });
                //System.out.println(nodeName+ ", "+ myValue+ ", paValListList="+ paValListList);
                
                // �e�m�[�h�̒l�̌��̂��ׂĂ̑g�ݍ��킹���b�o�s�ɒǉ�����B
                List<List<Object>> cpt0 = new ArrayList<>();
                List<Object> cp0 = new ArrayList<>();
                cp0.add(myValue);
                cpt0.add(cp0);
                tableNode.cpt.addAll(makeCpt(cpt0, paValListList, 0));
                // �e�����ׂăӒl�̏ꍇ�͏��O�B
                // �e�m�[�h���P�ł����鎞�́A�Ō�̗v�f���I�[���Ӓl�ɂȂ��Ă���͂��Ȃ̂ŁA
                //������폜����B
                //System.out.println("last CPT: "+ tableNode.cpt.get(tableNode.cpt.size()-1));
                if (tableNode.parents.size() >= 1){
                    tableNode.cpt.remove(tableNode.cpt.size()-1);
                }
                
            });
            // �u�e�m�[�h���I�[���Ӓl�̂Ƃ��������Ӓl�v�Ƃ����b�o��ǉ��B
            // �e�m�[�h���Ӓl�ɂȂ肦�Ȃ����Ƃ����邩������Ȃ����A�p�a�m�̐��_���ʂɉe���͂Ȃ��B
            List<Object> allPhi = new ArrayList<>();
            allPhi.add(QBN.Phi); // �����̒l
            tableNode.parents.forEach(p -> allPhi.add(QBN.Phi)); // �e�̒l
            tableNode.cpt.add(allPhi);
        });

        // �Q�[�g�m�[�h�̂b�o�s�����B
        allGateNodes.forEach(gateNode -> {
            
            // �e�m�[�h�̒l�̌��̂��ׂĂ̑g�ݍ��킹���b�o�s�ɒǉ�����B
            // �Ⴆ�ΐ���m�[�h���Q�̏ꍇ�A�b�o�s�͂����Ȃ�B
            // {��,closer,__,__}{��,__,closer,__}{X,opener,opener,X}
            
            //  �����̒l���ӂɂȂ�ꍇ�̂b�o�s�B {��,closer,__,__}{��,__,closer,__}
            for (int i = 0; i < gateNode.controlNodeNames.size(); i++){
                TableNode controlNode = tableNodeMap.get(gateNode.controlNodeNames.get(i));
                List<Object> closer = gateNode.valueGenerator(QBN.Inhibit, controlNode);

                List<Object> firstList = new ArrayList<>();
                firstList.add(QBN.Phi);
                List<List<Object>> cpt = new ArrayList<>();
                cpt.add(firstList);
                for (int j = 0; j < gateNode.controlNodeNames.size(); j++){
                    //cp.add(i == j ? QBN.Close : QBN.WildCard);
                    if (i == j){
                        cpt = listCombination(cpt, closer);
                    } else {
                        List<Object> wildCardList = new ArrayList<>();
                        wildCardList.add(QBN.WildCard);
                        cpt = listCombination(cpt, wildCardList);
                    }
                }
                List<Object> lastList = new ArrayList<>();
                lastList.add(QBN.WildCard);
                cpt = listCombination(cpt, lastList);
                gateNode.cpt.addAll(cpt);
            }
            // {X,opener,opener,X}
            gateNode.parent.values.forEach(v -> {
                List<Object> firstList = new ArrayList<>();
                firstList.add(v);
                List<List<Object>> cpt = new ArrayList<>();
                cpt.add(firstList);
                for (int i = 0; i < gateNode.controlNodeNames.size(); i++){
                    TableNode controlNode = tableNodeMap.get(gateNode.controlNodeNames.get(i));
                    List<Object> openers = gateNode.valueGenerator(QBN.Open, controlNode);
                    cpt = listCombination(cpt, openers);
                }
                List<Object> lastList = new ArrayList<>();
                lastList.add(v);
                cpt = listCombination(cpt, lastList);
                gateNode.cpt.addAll(cpt);
            });
        });
        
        // ExclusiveNode �� CPT �����B
        // �e�m�[�h���R�Ȃ� {{O,__,__,__},{I,O,O,O},{I,I,O,O},{I,O,I,O},{I,O,O,I}}
        // BUG: �{���� O �ɂȂ�ꍇ�� 2^n - n - 1 �����Ɨ񋓂��Ȃ��Ƃ����Ȃ����A
        //  ���܂̂Ƃ���  {O,__,__,__} �ő�p�B
        //   �e�X�g�������̂� ExclusiveNode �̒l�� I �̂Ƃ��̐U�镑�������Ȃ̂ł��̂܂ܕ��u�B
        qbcNet.exclusiveNodeList.forEach(node -> {
            
            System.err.println("Warning: ExclusiveNode is not fully implemented.");
            
            List<Object> others = new ArrayList<>();
            others.add(QBN.Open);
            for (int i = 0; i < node.parentNodes.size(); i++){
                others.add(QBN.WildCard);
            }
            node.cpt.add(others);
            List<Object> allZero = new ArrayList<>();
            allZero.add(QBN.Inhibit);
            for (int i = 0; i < node.parentNodes.size(); i++){
                allZero.add(QBN.Open);
            }
            node.cpt.add(allZero);
            for (int i = 0; i < node.parentNodes.size(); i++){
                List<Object> cp = new ArrayList<>();
                cp.add(QBN.Inhibit); // 1
                for (int j = 0; j < node.parentNodes.size(); j++){
                    if (i == j){
                        cp.add(QBN.Inhibit); // 1
                    } else {
                        cp.add(QBN.Open); // 0
                    }
                }
                node.cpt.add(cp);
            }
        });
        
        if (true){
            System.out.println("------------------------------------");
            System.out.println("Translated intermediate data:");
            System.out.println("tableNodeMap:");
            System.out.println(tableNodeMap);
            System.out.println("gateNodes:");
            System.out.println(allGateNodes);
        }
        
        // QBN �̃R���X�g���N�^�ɓn����`���ɕϊ��B
        List<Object[][]> nodeDataList = new ArrayList<>();
        tableNodeMap.forEach((name,tableNode) -> {
            List<Object> nodeNames = new ArrayList<>();
            nodeNames.add(tableNode.nodeName);
            tableNode.parentGateNodes.forEach(g -> {
                nodeNames.add(g.nodeName);
            });
            nodeDataList.add(makeNodeData(nodeNames, tableNode.cpt));
        });
        allGateNodes.forEach(gateNode -> {
            List<Object> nodeNames = new ArrayList<>();
            nodeNames.add(gateNode.nodeName);
            gateNode.controlNodeNames.forEach(name -> {
                nodeNames.add(name);
            });
            nodeNames.add(gateNode.parent.nodeName);
            nodeDataList.add(makeNodeData(nodeNames, gateNode.cpt));
        });
        qbcNet.exclusiveNodeList.forEach(node -> {
            List<Object> nodeNames = new ArrayList<>();
            nodeNames.add(node.nodeName);
            node.parentNodes.forEach(parentName -> {
                TableNode parent = tableNodeMap.get(parentName);
                nodeNames.add(parent.nodeName);
            });
            nodeDataList.add(makeNodeData(nodeNames, node.cpt));
            
        });
        Object[][][] netData = nodeDataList.toArray(new Object[0][][]);
        return new QBNnet(netData);
    }
    public static boolean tableElementMatch(Object childVal, Object element){
        if (element.equals(QBN.WildCard)){
            return true;
        } if (element instanceof TableElement) {
            return ((TableElement)element).elements.stream()
                .anyMatch(e -> e.equals(childVal));
        } else {
            return childVal.equals(element);
        }
    }
    // Returns list of combination of 
    //                listlist1
    //            and paValListList(index)
    //            and paValListList(index + 1)
    //            and ...
    public static List<List<Object>> makeCpt(List<List<Object>> listlist1,
            List<List<Object>> paValListList, int index) {
        if (paValListList.size() == index) return listlist1;
        List<List<Object>> listlist2 = new ArrayList<>();
        listlist1.forEach(list -> {
            paValListList.get(index).forEach(obj -> {
                List<Object> newList = new ArrayList<>(list); // ���X�g�̃R�s�[
                newList.add(obj);
                listlist2.add(newList);
            });
        });
        return makeCpt(listlist2, paValListList, index + 1);
    }
    // List<List<Object>> cpt �� Object[][] �ɕϊ��B
    public static Object[][] makeNodeData(List<Object> nodeNames,
            List<List<Object>> cpt){
        List<Object[]> list = new ArrayList<>();
        // �ŏ��� nodeName �̃��X�g�� list �ɒǉ��B
        list.add(nodeNames.toArray(new Object[0]));
        // CPT �̊e�v�f���I�u�W�F�N�g�z��ɕϊ����� list �ɒǉ��B
        cpt.forEach(cp -> {
            list.add(cp.toArray(new Object[0]));
        });
        // List ��z��ɕϊ����ĕԂ��B
        return list.toArray(new Object[0][]);
    }
    // listlist1 �̂��ׂĂ̗v�f�� list2 �̂��ׂĂ̗v�f��g�ݍ��킹�����̂�Ԃ��B
    public static List<List<Object>> listCombination(List<List<Object>> listlist1,
            List<Object> list2) {
        List<List<Object>> ret = new ArrayList<>();
        listlist1.forEach(list1 -> {
            list2.forEach(obj -> {
                List<Object> newList = new ArrayList<>(list1); // ���X�g�̃R�s�[
                newList.add(obj);
                ret.add(newList);
            });
        });
        return ret;
    } 

    //--------------------------------------------------
    // TODO: ���������B�Ăяo���C���^�[�t�F�[�X���l���Ȃ��ƁB
    public static class QBCMain extends Lab.MainCode {
        public QBCnetCode netCode = panel.getCode("netCode", QBCnetCode.class);
        public QBCVisualizerCode visualizerCode = panel.getCode("visualizer", QBCVisualizerCode.class);  
        public void main() {
            QBCnet qbcNet = netCode.makeQBCnet();
            visualizerCode.qbcNet = qbcNet;
            visualizerCode.init();
            QBNnet net = qbcToQbn(qbcNet);
            System.out.println("net:");
            System.out.println(net.toString());
            if (panel.flag("Sort nodes", true)){
                net.sortAndInfer(visualizerCode, panel.flag("bottomUp", false));
            } else {
                net.infer(visualizerCode);
            }
            visualizerCode.finish();
        }
    }
    //public static abstract class QBCVisualizerCode extends VisualizerCode {
    public abstract static class QBCVisualizerCode extends Lab.Code implements ResultVisualizer {
        public QBCnet qbcNet;
        public abstract void init();
        public abstract void finish();
    }
    // ���̒l�̑g���b�r�u�`���Ńe�L�X�g�o�́B
    public static class QBCVisualizeCSV1 extends QBCVisualizerCode {
        public int counter = 0;
        public List<Object> varList = new ArrayList<>();
        public Lab.WTextArea textArea;
        public void init(){
            textArea = new Lab.WTextArea(env, "Solutions");
            qbcNet.exclusiveNodeList.forEach(exNode -> {
                varList.add(exNode.nodeName);
            });
            qbcNet.tableNodeList.forEach(tableNode -> {
                varList.add(tableNode.nodeName);
            });
              
            varList.forEach(var -> {
                textArea.print(var+ ", ");
            });
            textArea.println("");
        }
        public void call(QBNnet net, VarEnv varEnv) {
            counter++;
            varList.forEach(var -> {
                textArea.print(varEnv.findVal(var)+ ", ");
            });
            textArea.println("");
        }
        public void finish(){
            textArea.println(counter+ " solutions.");
        }
    }
}
