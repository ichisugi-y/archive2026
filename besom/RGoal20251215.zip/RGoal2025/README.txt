	RGoal 2025 : Hierarchical Reinforcement Learning with Unlimited Recursive Subroutine Calls
					Author Yuuji Ichisugi	2025-12

This program aims to reproduce the experiments described in RGoal papers and help other researchers better understand the architecture.
Unfortunately, we do not provide detailed documentation for this program.

=============================================================

Java source:
	lab\Lab.java		Immediate Mode GUI library
	tmm1\*.java		RGoal sample implementations
	compress\Compress.java	An experimental table compression algorithm
	qbc\*.java		Quasi Bayesian Network test programs

=============================================================

How to run a newest sample implementation on Windows:
	> javac -J-Dfile.encoding=SJIS tmm1\TMM3v13.java
	> java tmm1.TMM3v13

To run a non-default test program, push "Stop" button, select "Main" menu and push "Start" button.

=============================================================

Papers of RGoal 2025 (In Japanese):
https://doi.org/10.11517/jsaisigtwo.2023.AGI-025_08
https://doi.org/10.11517/jsaisigtwo.2023.agi-026_50

Paper of RGoal 2019:
Ichisugi Y., Takahashi N., Nakada H., Sano T.,
Hierarchical Reinforcement Learning with Unlimited Recursive Subroutine Calls. In Artificial Neural Networks and Machine Learning - ICANN 2019: Deep Learning, Lecture Notes in Computer Science, vol 11728, pp. 103--114, Springer, Cham, 2019.
https://doi.org/10.1007/978-3-030-30484-3_9

=============================================================

This program is distributed under the MIT license. See License-of-RGoal.txt .
This work was supported by JSPS KAKENHI Grant Number JP18K11488, JP22K12188 .
The file Lab.java is a part of BESOM-lab Ver.3 distributed under the 3-clause BSD license. See License-of-lab.txt .

