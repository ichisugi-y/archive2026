// $B$3$N%b%8%e!<%k$O%i%$%V%i%jCf$K$b$"$k$N$G!"K\Mh$ODj5A$9$kI,MW$O$J$$!#(B
// $B$7$+$7!"$3$N%F%9%H%W%m%0%i%`$NCJ3,$G$O%i%$%V%i%j$O$^$@$J$$$N$G!"(B
//$B$3$3$GDj5A$9$kI,MW$,$"$k!#(B
module mj.lang.ss
{
  define class SS extends mjc.SS {
    static SS instance;
    void setInstance(mjc.SS x){ instance = (SS)x; }
    void main(String[] args){
      System.out.println("*** ss:SS:main");
      System.out.println("this.equals(null)="+ this.equals(null));
      System.out.println("this.equals(this)="+ this.equals(this));
    }
    void _init_SS(){
      System.out.println("*** ss:SS:_init_SS");
    }
  }
} 


// $B:9J,DI2C$N%F%9%H(B
{
  module m1 {

    define class A  {
      // PseudoConstructor plug-in $B$,$J$$$N$G!"(B _call_init_A $B$rD>@\Dj5A$9$k!#(B
      define A _call_init_A() {
	_init_A();
	return this;
      }
      define void _init_A(){
	this(1);
	System.out.println("###_init_A()");
      }
      define void _init_A(int x){
	System.out.println("###_init_A("+ x+ ")");
      }
      define void a()  { System.out.println("m1:A:a()"); }
    }

    define class SubA extends A {
      define SubA _call_init_SubA() {
	_init_SubA();
	return this;
      }
      define void _init_SubA(){
	super();
	System.out.println("###_init_SubA()");
      }
      void a() { original(); System.out.println("+ m1:SubA:a()"); }
      define void b() { System.out.println("m1:SubA:b()"); }
    }

    class SS {
      void main(String[] args){


	System.out.println("***begin m1:SS:main");
	original(args);
	A a = new A();
	SubA suba = new SubA();
	this.testA(a, suba);
	System.out.println("***end m1:SS:main");
      }
      define void testA(A a, SubA suba){
	System.out.println("***begin m1:SS:testA");
	a.a();
	suba.a(); suba.b();
	A aa = suba; aa.a();
	System.out.println("***end m1:SS:testA");
      }
    }
  }


  // A, SubA, B, SubB $B$N$=$l$>$l$N%a%=%C%I$r3HD%!#(B
  module m2 extends m1 {

    class A {
      void a() { original(); System.out.println("+ m2:A:a()"); }
      define void m2a() { System.out.println("m2:A:m2a()"); }
    }

    class SubA {
      void a() { original(); System.out.println("+ m2:SubA:a()"); }
      void m2a() { original(); System.out.println("+ m2:SubA:m2a()"); }
    }

    class SS {
      void main(String[] args){
	System.out.println("***begin m2:SS:main");
	original(args);
	System.out.println("***end m2:SS:main");
      }
      void testA(A a, SubA suba){
	System.out.println("***begin m2:SS:testA");
	original(a, suba);
	a.m2a();
	suba.m2a();
	System.out.println("***end m2:SS:testA");
      }
    }
  }

  module m3 extends m1 {
    class A {
      void a() { original(); System.out.println("+ m3:A:a()"); }
      define void m3a(){ System.out.println("m3:A:m3a()"); } 
    }
    class SubA {
      void a() { original(); System.out.println("+ m3:SubA:a()"); }
      //
      void m3a(){ original(); System.out.println("+ m3:SubA:m3a()"); } 
    }
    class SS {
      void main(String[] args){
	System.out.println("***begin m3:SS:main");
	original(args);
	System.out.println("***end m3:SS:main");
      }
      void testA(A a, SubA suba){
	System.out.println("***begin m3:SS:testA");
	original(a, suba);
	a.m3a();
	suba.m3a();
	System.out.println("***end m3:SS:testA");
      }
    }
  }
}


// FQN $B$*$h$S(B interface $B$N%F%9%H(B
{
  module merge0 {
    define class C {
      define C _call_init_C() { return this; }
    }
    define class CC implements I1 {
      define CC _call_init_CC() { return this; }
    }
    define interface I1 { }
    define interface I2 { }
  }

  module merge1 extends merge0 {
    class C {
      define int foo(){ return 100; }
      int x = 1000;
    }
    class CC { int i11() { return 11; } }
    interface I1 { define int i11(); }
    interface I2 { define int i12(); }
  }

  module merge2 extends merge0 {
    class C {
      define int foo(){ return 200; }
      int x = 2000;
    }
    class CC { int i21() { return 21; } }
    interface I1 { define int i21(); }
    interface I2 { define int i22(); }
  }

  module merge extends merge1, merge2 {
    class C {
      int FQN[merge1::foo](){ return original() + 10000; }
      int FQN[merge2::foo](){ return original() + 20000; }
    }
    class CC implements I2 {
      int i12() { return 12; }
      int i22() { return 22; }
    }
    class SS {
      void main(String[] args){
	original(args);
	System.out.println("=========");

	C c = new C();
	//System.out.println(c.foo());    // ambiguous error
	System.out.println(c.FQN[merge1::foo]());
	System.out.println(c.FQN[merge2::foo]());
	//System.out.println(c.x);    // ambiguous error
	System.out.println(c.FQN[merge1::x]);
	System.out.println(c.FQN[merge2::x]);


	CC cc = new CC();
	System.out.println(cc.i11());
	System.out.println(cc.i12());
	System.out.println(cc.i21());
	System.out.println(cc.i22());
      }
    }
  }
}


// anonymousClass $B$N%F%9%H(B
module anonymousClass 
imports jp.go.etl.epp.util.* 
{
  define class C {
    define C _call_init_C() { return this; }
    int x = 111;
    define int foo() { return 333; }
  }

  class SS {
    int x = 222;
    define int foo() { return 444; }

    void main(String[] args){
      original(args);
      System.out.println("=========");
      
      {
	int x = -222;
	System.out.println(x);
      }

      final C c = new C();
      System.out.println(x);
      System.out.println(c.x);
      System.out.println(foo());
      System.out.println(c.foo());
      
      final SS outer = this;
      ArrayGenerator gen = new ArrayGenerator(){
	public Object[] generate(int size){
	  ArrayGenerator ag = this;
	  System.out.println(ag);
	  // System.out.println(x);  // error
	  System.out.println(foo());
	  System.out.println(outer.x);
	  System.out.println(c.x);
	  System.out.println(outer.foo());
	  System.out.println(c.foo());
	  return new String[size];
	}
	int foo(){ return 555; }
      };
      String[] a = (String[])gen.generate(2);
      System.out.println(a.length);

      {
	Vec<String> vec = {};
	vec.push("abc");
	vec.push("def");
	foreach (String s in vec){
	  System.out.println(s);
	}
      }

    }
  }
}


// $BD9$$%b%8%e!<%kL>$N%F%9%H(B
{
  module very.longlong.module.name {
    class SS {
      void main(String[] args){
	original(args);
	System.out.println("=========");
	System.out.println("very.longlong.module.name!!");
      }
    }
  }

  module very.longlong.another.module.name
    extends very.longlong.module.name {
    class SS {
      void main(String[] args){
	original(args);
	System.out.println("=========");
	System.out.println("very.longlong.another.module.name!!");
      }
    }
  }
}

module protectedTest
{
  define class C extends mjc.Test1 {
    define C _call_init_C() { return this; }
    define void foo() {
      this.protectedMethod();
      this.protectedFinalMethod();
      this.protectedStaticMethod();
      //C.publicStaticMethod();  // Error, MJC bug.
      //C.protectedStaticMethod();  // Error, MJC bug.
      //mjc.Test1.protectedStaticMethod();// jikes Error, See JLS .
      System.out.println(publicField);
      System.out.println(protectedField);
      System.out.println(protectedStaticField);
      System.out.println(this.protectedStaticField);
      //System.out.println(C.publicStaticField);  // Error, MJC bug.
      //System.out.println(C.protectedStaticField);  // Error, MJC bug.
      //System.out.println(mjc.Test1.protectedStaticField);// jikes caution, See JLS .
    }
  }
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("=========");
      new C().foo();
    }
  }
}

module staticTest1 {
  class SS {
    static int x1 = 1;
    static {
      System.out.println("static initializer !!111");
      System.out.println(""+ SS.x1+ SS.x2); // -> "10"
    }
    static int x2 = 2;
    define static void foo(){ System.out.println("static method foo."); }
  }
  define class C {
    define static void foo(){ System.out.println("static method C#foo."); }
  }
}
module staticTest
extends staticTest1
{
  class SS {
    static int x3 = 3;
    static {
      System.out.println("static initializer !!222");
      System.out.println(""+ SS.x1+ SS.x2+ SS.x3+ SS.x4); // -> "1230"
      SS.bar();
      // bar();  -> error (MJ1.0 bug)
    }
    static int x4 = 4;
    void main(String[] args){
      original(args);
      System.out.println("=========");
      SS.foo(); 
      SS.bar();
      C.foo();
      // SS.FQN[staticTest1::foo]();  // Currently not supported.
      mjc.Test1.publicStaticMethod();
      System.out.println(mjc.Test1.publicStaticField);
    }
    define static void bar(){ System.out.println("static method bar."); }
  }
}

module ssTest {
  define class C {
    define C _call_init_C() { return this; }
    define void foo(){ System.out.println(222); }
    define void bar(){
      foo();
      SS.instance.foo();
    }
    
  }
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("=========");
      C x = new C();
      x.bar();
    }
    define void foo(){ System.out.println(111); }
  }
}

module macroTest1 {
  defmacro ExtendSS(message){
    class SS {
      void main(String[] args){
	original(args);
	System.out.println("=========");
	System.out.println(message);
      }
    }
  }
  defmacro CLASSES_A_B(){
    define class A {}
    define class B {}
  }
  defmacro CONCAT_TEST(prefix){
    define class CONCAT_ID(CAPITALIZE_ID(prefix), _C){
      String s1;
      define CONCAT_ID(CAPITALIZE_ID(prefix), _C)
	CONCAT_ID(_call_init_,
		  CONCAT_ID(CAPITALIZE_ID(prefix), _C))(String s1){
	this.CONCAT_ID(_init_,
		       CONCAT_ID(CAPITALIZE_ID(prefix), _C))(s1);
	return this;
      }
      define void
	CONCAT_ID(_init_,
		  CONCAT_ID(CAPITALIZE_ID(prefix), _C))(String s1){
	this.s1 = s1;
      }
      define String CONCAT_ID(prefix, _m)(String s2){
	return s1+ s2;
      }
    }
  }
  defmacro SWAP(type, v1, v2){
    type tmp = v1;
    v1 = v2;
    v2 = tmp;
  }
  defmacro FOREACH(var, array, block){
    for (int i = 0; i < array.length; i++){
      int var = array[i];
      block;
    }
  }
  usemacro CONCAT_TEST(pre);
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("=========");
      int x = 12, y = 34;
      usemacro SWAP(int, x, y);
      System.out.println("x = "+ x+ ", y = "+ y);
      Pre_C c = new Pre_C("a");
      System.out.println(c.pre_m("b")); // -> "ab"

      int[] a = {1,2,3};
      int sum = 0;
      usemacro FOREACH(elem, a){
	sum += elem;
      }
      System.out.println(sum); // -> 6
    }
  }
}

module macroTest2 
extends macroTest1 
{
  usemacro ExtendSS("macroTest2");
  usemacro CLASSES_A_B();
  define class C {
    define void foo(){
      A a = null;
      B b = null;
    }
  }
}

module all
extends m2
extends m3
extends merge
extends anonymousClass 
extends very.longlong.another.module.name
extends protectedTest
extends staticTest
extends ssTest
extends macroTest2
{}
