/*

 Usage:
	% mjc complements.java; mj test



$B"!Jd40%b%8%e!<%k8!:w%k!<%A%s%F%9%H%W%m%0%i%`(B

$B!&$^$:(B CLASSPATH $B$r%9%-%c%s$7!"Jd40%b%8%e!<%kL>$N%j%9%H$r:n$k!#(B
 Zip $B$N>l9g$O!"A4%(%s%H%j$r%9%-%c%s$9$k!#(B
 $B%G%#%l%/%H%j$N>l9g$O!"(B COMPLEMENTARY_PACKAGE_PREFIX $B$ND>2<$N$_$r%9%-%c%s!#(B
$B!J(B40msec $B$G=*N;!#!K(B

$B!&3FJd40%b%8%e!<%k$N(B MJComplementaryModuleDescripor $B$r(B load $B$7!"(B
$BJd40%b%8%e!<%k%G!<%?%Y!<%9(B(complerTable, compleeTable)$B$r:n$k!#(B

$B!&%b%8%e!<%k$r(B load $B$9$k$?$S$K!"$=$N%b%8%e!<%k$K4XO"$9$kJd40%b%8%e!<%k$,(B
$BB8:_$9$k$+$rD4$Y!"Jd40$9$Y$-$J$i$P!"Jd40%b%8%e!<%k$r(B load $B$9$k!#(B
$B$5$i$KJd40%b%8%e!<%k$r(B load $B$9$Y$-$+$I$&$+$O:F5"E*$K%A%'%C%/$5$l$k!#(B


*/

module test
imports java.util.*
imports java.util.zip.*
imports java.io.*
imports java.lang.reflect.*
{
  class SS {
    void main(String[] args){
      mjc.MJClassFileReader classFileReader = new mjc.MJClassFileReader();
      Object[] classPathDirs = classFileReader.classPathDirs;

      // CLASSPATH $B$r%9%-%c%s$7!"(B $BJd40%b%8%e!<%k%G!<%?%Y!<%9$r:n$k!#(B
      time("Scan CLASSPATH");
      Vec<String> complName = {};
      foreach (Object classPathElem in classPathDirs){
	System.out.println("-------------:"+ classPathElem);
	if (classPathElem instanceof ZipFile) {
	  // in case of archive file
	  ZipFile zf = (ZipFile)classPathElem;
	  // Even on windows, use '/' .
	  String complPrefix = mjc.MJC.COMPLEMENTARY_PACKAGE_PREFIX+ '/';
	  for (Enumeration e = zf.entries(); e.hasMoreElements();){
	    ZipEntry entry = (ZipEntry)e.nextElement();
	    //System.out.println(entry.getName());
	    if (entry.getName().startsWith(complPrefix)
		&& entry.getName()
		.endsWith(File.separator+
			  "MJComplementaryModuleDescripor.class")){
	      // ".class" $B$r$O$.<h$C$F%/%i%9L>$K$9$k!#(B
	      String path = entry.getName();
	      complName.push(path.substring(0, path.length() - 6)
			     .replace('/', '.'));
	    }
	  }
	} else if (classPathElem instanceof String) {
	  File dir = new File((String)classPathElem);
	  if (dir.exists()) {
	    String[] list = dir.list(); // $B$H$j$"$($:%U%#%k%?$J$7!#(B
	    foreach (String f in list){
	      if (f.equals(mjc.MJC.COMPLEMENTARY_PACKAGE_PREFIX)){
		getComplNamesRecursively(dir+ File.separator+ f,
					 f,
					 complName);
	      }
	    }
	  }
	} else {
	  throw fatal("");
	}
      }
      time("End scanning CLASSPATH.");

      {
	foreach (String name in complName){
	  System.out.println(name);
	}
	time("End printing all complNames.");
      }

      // load $B$5$l$?(B MJComplementaryModuleDescripor $B$N%/%i%9$N%F!<%V%k!#(B
      Table<String, Class> loadedDesc = {};

      foreach (String name in complName){
	try {
	  // JavaVM $B$K%/%i%9$r(B load $B$5$;$k!#(B
	  // CLASSPATH $B$+$i$NC5:w$O!"(B JavaVM $B$,9T$&!#(B
	  // $BF1$8L>A0$N(B complName $B$,=EJ#$7$FB8:_$9$k2DG=@-$,$"$k$,!"(B
	  // forName $B$OM%@hEY$N9b$$(B CLASSPATH $B$N%(%s%H%j$+$i(B load $B$5$l$k!#(B
	  Class c = Class.forName(name);
	  loadedDesc.put(name, c);
	} catch (Throwable e){
	  e.printStackTrace(System.err);
	  throw fatal(""+ e);
	}
      }
      time("End loading classes.");

      // $BJd40%b%8%e!<%k$H!"$=$l$,Jd40$9$k%b%8%e!<%k$N%j%9%H$N%F!<%V%k!#(B
      Table<String, Vec<String> > complerTable = {};
      // $BJd40$5$l$k%b%8%e!<%k$H!"$=$l$rJd40$9$kJd40%b%8%e!<%k$N%j%9%H$N%F!<%V%k!#(B
      Table<String, Vec<String> > compleeTable = {};
      foreach (Class c in loadedDesc.valueIter()){
	String moduleName;
	String[] complees;
	try {
	  Field f1 = c.getField("moduleName");
	  moduleName = (String)f1.get(null);
	  Field f2 = c.getField("complements");
	  complees= (String[])f2.get(null);
	} catch (Throwable e){
	  e.printStackTrace(System.err);
	  throw fatal(""+ e);
	}
	complerTable.put(moduleName, new Vec<String>(complees));
	foreach (String s in complees){
	  Vec<String> complers = compleeTable.get(s)
	    ifNull {
	      complers = new Vec<String>();
	      compleeTable.put(s, complers);
	    };
	  complers.push(moduleName);
	}
      }
      complerTable.print("complerTable");
      compleeTable.print("compleeTable");

      // load $B$N%F%9%H!#(B
      MJModuleManager manager = new MJModuleManager(complerTable,
						    compleeTable);
      manager.loadModule("testComple.m1");
      manager.loadModule("testComple.m2");
      manager.loadModule("testComple.m3");
    }
  
    /** */
    define void getComplNamesRecursively(String path,
					 String className,
					 Vec<String> complName){
      File f = new File(path);
      if (f.isDirectory()){
	String[] list = f.list();
	foreach (String s in list){
	  getComplNamesRecursively(path+ File.separator+ s,
				   className+ "."+ s,
				   complName);
	}
      } else {
	System.out.println("path:"+ path);
	System.out.println("className:"+ className);
	// $B%U%!%$%k!#(B
	if (path.endsWith(File.separator+
			  "MJComplementaryModuleDescripor.class")){
	  // ".class" $B$r$O$.<h$C$F%/%i%9L>$K$9$k!#(B
	  complName.push(className.substring(0, className.length() - 6));
	}
      }
    }

    //--------------------------------------------------

    long lastTime = 0;
    /** $B:G8e$K$3$N%a%=%C%I$r8F$s$G$+$i7P2a$7$?;~4V!J%_%j%;%+%s%I!K$rI=<(!#(B */
    define void time(String str){
      long currentTime = System.currentTimeMillis();
      System.err.println(str+ " : "+ (currentTime - lastTime));
      lastTime = currentTime;
    }

    /** fatal error */
    define Error fatal(String msg) { return new Error(msg); }
  }

  /** module manager */
  define class MJModuleManager {
    Table<String, Vec<String> > complerTable = {};
    Table<String, Vec<String> > compleeTable = {};
    Table<String, String> moduleTable = {};

    /** $B=i4|2=(B */
    define MJModuleManager(Table<String, Vec<String> > complerTable,
			   Table<String, Vec<String> > compleeTable
			   ){
      this.complerTable = complerTable;
      this.compleeTable = compleeTable;
    }

    /** $B%b%8%e!<%k$r#1$D2>A[E*$K(B load $B$9$k!#:F5"E*$K8F$S=P$5$l$k$3$H$b$"$k!#(B */
    define void loadModule(String name){
      if (moduleTable.containsKey(name)) return;

      System.out.println("load "+ name);
      moduleTable.put(name, name);

      Vec<String> complerVec = compleeTable.get(name)
	ifNull {
	  // $B$3$N%b%8%e!<%k$rJd40$9$k%b%8%e!<%k$O$J$$$N$G!"(B return $B$9$k!#(B
	  return;
	};
      // $B8uJd$H$J$k3FJd40%b%8%e!<%k$r!"(B load $B$9$Y$-$+$I$&$+$r8!::$9$k!#(B
      foreach (String compler in complerVec){
	// $BJd40BP>]$N%b%8%e!<%k$,$9$Y$F(B load $B$:$_$J$i$P!"(B
	// $BJd40%b%8%e!<%k$r(B load $B$9$k!#(B

	// $B$^$:!"$3$NJd40%b%8%e!<%k$NJd40BP>]%b%8%e!<%k$rF@$k!#(B
	Vec<String> compleeVec = complerTable.get(compler)
	  ifNull { throw SS.instance.fatal(""+ compler); };
      tryNext:
	{
	  foreach (String complee in compleeVec){
	    if (! moduleTable.containsKey(complee)){
	      // $BJd40BP>]$,(B load $B$5$l$F$$$J$$!"$H$$$&$3$H$O!"(B
	      // $B$3$NJd40%b%8%e!<%k$O(B load $B$9$kI,MW$,$J$$!#(B
	      break tryNext;
	    }
	  }
	  // $B$3$NJd40%b%8%e!<%k$r(B load $B$9$Y$-$J$N$G(B load $B$9$k!#(B
	  this.loadModule(compler);
	}
      }
    }
  }
}

module testComple.m1 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m1");
    }
  }
}

module testComple.m2 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m2");
    }
  }
}

module testComple.m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m3");
    }
  }
}


module testComple.m1m2 complements testComple.m1,  testComple.m2 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m1m2");
    }
  }
}


module testComple.m2m3 complements testComple.m2,  testComple.m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m2m3");
    }
  }
}


module testComple.m1m2m2m3 complements testComple.m1m2,  testComple.m2m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("testComple.m1m2m2m3");
    }
  }
}

