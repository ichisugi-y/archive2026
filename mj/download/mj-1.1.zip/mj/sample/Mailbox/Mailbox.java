/*
Usage:

	% mjc Mailbox.java
	% mjball all
	% mj all
	Hello.
	%

$BCm(B:  mailbox $B$O!"F|K\8l$G8@$&%]%9%H$N$3$H!#!J1Q$G$O(B postbox $B!#!K(B


 */


//--------------------------------------------------
// External interface definitions.


module envelope.className
{
  /**	Envelope class. */
  define class Envelope {
    define Envelope(){}
  }
}


module mailbox.className
{
  /**	Mailbox class. */
  define class Mailbox {
    define Mailbox(){}
  }
}


module mailbox.forUser
extends mailbox.className
uses envelope.className
{
  class Mailbox {
    /**		Put an envelope in the mailbox . */
    define abstract void put(Envelope e);
  }
}


module mailbox.forPostOffice
extends mailbox.className
uses envelope.className
{
  class Mailbox {
    /**		Get envelopes from the mailbox */
    define abstract Envelope[] get();
  }
}


module envelope.forPostOffice
extends envelope.className
uses user
{
  class Envelope {
    /**		Get the destination of the envelope. */
    define abstract User destination();
  }
}


module envelope.forUser
extends envelope.className
uses user
{
  class Envelope {
    /**		Initialize.  Specify the destination. */
    define abstract Envelope init(User destination);

    /**		Put contents to the envelope and seal it. */
    define abstract void seal(String s);

    /**		Unseal the envelope and get the contents. */
    define abstract String unseal();
  }
}

// An instance of mailbox shared by post office and users.
module aMailbox
uses mailbox.className
{
  class Mailbox {
    static Mailbox aMailbox = new Mailbox();
  }
}

//--------------------------------------------------

module mailbox.implementation
extends mailbox.forPostOffice, mailbox.forUser
imports java.util.*
{
  class Mailbox {
    Vector envelopes = new Vector();

    void put(Envelope e) {
      envelopes.addElement(e);
    }

    Envelope[] get() {
      Envelope[] ret = new Envelope[envelopes.size()];
      envelopes.copyInto(ret);
      return ret;
    }
  }
}

//--------------------------------------------------

module envelope.implementation
extends envelope.forUser, envelope.forPostOffice
{
  class Envelope {
    User destination;
    String contents;

    Envelope init(User destination0) {
      destination = destination0;
      return this;
    }

    User destination() {
      return destination;
    }

    void seal(String s) {
      contents = s;
    }

    String unseal() {
      return contents;
    }
  }
}

//--------------------------------------------------
// User

module user
uses aMailbox, envelope.forUser, mailbox.forUser
{
  /**	User class. */
  define class User {
    define User(){}
    /**		Write a letter to another user. */
    define void writeALetterTo(User destination){
      Envelope envelope = new Envelope().init(destination);
      envelope.seal("Hello.");
      Mailbox.aMailbox.put(envelope);
    }
    /**		Receive and read the letter delivered by the post office. */
    define void receiveALetter(Envelope envelope){
      System.out.println(envelope.unseal());
    }
  }
}

//--------------------------------------------------
// Post office

module postOffice
uses aMailbox, mailbox.forPostOffice, envelope.forPostOffice, user
{
  /**	PostOffice class. */
  define class PostOffice {
    define PostOffice(){}
    /**		Deriver all envelopes to their destinations. */
    define void deliver(){
      Envelope[] envelopes = Mailbox.aMailbox.get();
      for (int i = 0; i < envelopes.length; i++){
	User destination = envelopes[i].destination();
	destination.receiveALetter(envelopes[i]);
      }
    }
  }
}

//--------------------------------------------------

module test
uses user, postOffice
{
  class SS {
    void main(String[] args){
      PostOffice postOffice = new PostOffice();
      User user1 = new User();
      User user2 = new User();
      user1.writeALetterTo(user2);
      postOffice.deliver();
    }
  }
}
