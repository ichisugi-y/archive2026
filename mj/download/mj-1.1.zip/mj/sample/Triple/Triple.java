/*
 Usage:
	% mjc Triple.java
	% mj test


 $B#3<!853HD%2DG=%7%9%F%`$NNc!#(B

 A#m(B, C) $B$H$$$&%a%=%C%I$N(B triple dispatch $B!#(B

 $B%/%i%9(B A, B, C $B$N%5%V%/%i%9$N?t$r(B l, m, n $B8D$H$9$k$H!"(B
 l$B!&(Bm + l$B!&(Bm$B!&(Bn $B8D$NJd40%b%8%e!<%k$,I,MW!#(B

 */

module f {

  define abstract class A {
    define A(){}
    define abstract void m(B b, C c);
  }

  define abstract class B {
    define B(){}
  }
  define abstract class C {
    define C(){}
  }
}


module a1 extends f {
  define class A1 extends A {
    define A1(){}
    void m(B b, C c){
      b.m_A1(this, c);
    }
  }
  class B {
    define abstract void m_A1(A1 a, C c);
  }
}

module a2 extends f {
  define class A2 extends A {
    define A2(){}
    void m(B b, C c){
      b.m_A2(this, c);
    }
  }
  class B {
    define abstract void m_A2(A2 a, C c);
  }
}

module b1 extends f {
  define class B1 extends B {
    define B1(){}
  }
}

module c1 extends f {
  define class C1 extends C {
    define C1(){}
  }
}

module b2 extends f {
  define class B2 extends B {
    define B2(){}
  }
}

module c2 extends f {
  define class C2 extends C {
    define C2(){}
  }
}


module a1_b1 complements a1, b1 {
  class B1 {
    void m_A1(A1 a, C c){
      c.m_A1_B1(a, this);
    }
  }
  class C {
    define abstract void m_A1_B1(A1 a, B1 b);
  }
}

module a1_b2 complements a1, b2 {
  class B2 {
    void m_A1(A1 a, C c){
      c.m_A1_B2(a, this);
    }
  }
  class C {
    define abstract void m_A1_B2(A1 a, B2 b);
  }
}

module a2_b1 complements a2, b1 {
  class B1 {
    void m_A2(A2 a, C c){
      c.m_A2_B1(a, this);
    }
  }
  class C {
    define abstract void m_A2_B1(A2 a, B1 b);
  }
}

module a2_b2 complements a2, b2 {
  class B2 {
    void m_A2(A2 a, C c){
      c.m_A2_B2(a, this);
    }
  }
  class C {
    define abstract void m_A2_B2(A2 a, B2 b);
  }
}



module a1_b1_c1 complements a1_b1, c1 {
  class C1 {
    void m_A1_B1(A1 a, B1 b){
      System.out.println("A1#(B1,C1) invoked");
    }
  }
}

module a2_b1_c1 complements a2_b1, c1 {
  class C1 {
    void m_A2_B1(A2 a, B1 b){
      System.out.println("A2#(B1,C1) invoked");
    }
  }
}

module a1_b2_c1 complements a1_b2, c1 {
  class C1 {
    void m_A1_B2(A1 a, B2 b){
      System.out.println("A1#(B2,C1) invoked");
    }
  }
}

module a2_b2_c1 complements a2_b2, c1 {
  class C1 {
    void m_A2_B2(A2 a, B2 b){
      System.out.println("A2#(B2,C1) invoked");
    }
  }
}

module a1_b1_c2 complements a1_b1, c2 {
  class C2 {
    void m_A1_B1(A1 a, B1 b){
      System.out.println("A1#(B1,C2) invoked");
    }
  }
}

module a2_b1_c2 complements a2_b1, c2 {
  class C2 {
    void m_A2_B1(A2 a, B1 b){
      System.out.println("A2#(B1,C2) invoked");
    }
  }
}

module a1_b2_c2 complements a1_b2, c2 {
  class C2 {
    void m_A1_B2(A1 a, B2 b){
      System.out.println("A1#(B2,C2) invoked");
    }
  }
}

module a2_b2_c2 complements a2_b2, c2 {
  class C2 {
    void m_A2_B2(A2 a, B2 b){
      System.out.println("A2#(B2,C2) invoked");
    }
  }
}




//--------------------------------------------------
module test extends a1, a2, b1, b2, c1, c2  {
  class SS {
    void main(String[] args){
      original(args);
      new A1().m(new B1(), new C1());
      new A1().m(new B2(), new C1());
      new A2().m(new B2(), new C2());
    }
  }
}
