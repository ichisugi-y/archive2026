/*

	Usage:
		% mjc sort1.java; mj sort

 monotonic $B$J(B linearization $B$N%F%9%H%W%m%0%i%`!#(B
 uses $B@k8@L$BP1~HG!#(B
 */

module sort {

  define class Module {
    define Module(){}

    int name;
    Vec<int> superModules;	// $B<+J,$O4^$^$J$$!#=gITF1!#=EJ#2D!#(B
    Vec<int> linearizedModules;	// currently not used.

    int TRAVERSING = -998;
    int NOT_DETERMINED = -999;
    int level = FQN[sort::NOT_DETERMINED];

    Vec<Vec<Module> > levelVec = null;

    String toString(){ return "m"+ name; }
  }

  class SS {
    Table<int, Module> moduleManager;
    define void resetModuleManager(){
      moduleManager = new Table<int, Module>();
    }

    void main(String[] args){
      // $B!V!V(BsuperModules $B$NG[Ns!W$NG[Ns!W(B
      // $B$,#1$D$N%0%i%U$rI=$9%F%9%H%G!<%?$G!"(B dataList $B$O$=$NG[Ns!#(B
      // level 0:       m0
      // level 1:   m1  m2  m3
      // level 2:   m4  m5  m6
      // level 3:       m7
      int[][][] dataList =
      {
	// data[0]
	{ {} //0, not referred
	  {}, //1
	  {}, //2
	  {}, //3
	  {3}, //4
	  {1}, //5
	  {2}, //6
	  {4,5,6}, //7
	},
	// data[1]
	{ {}, //0, not referred
	  {}, //1
	  {}, //2
	  {}, //3
	  {2}, //4
	  {2,3}, //5
	  {1}, //6
	  {4,5,6}, //7
	},
	// data[2]
	{ {}, //0
	  {0}, //1
	  {0}, //2
	  {0}, //3
	  {3}, //4
	  {3}, //5
	  {3}, //6
	  {3,4,5,6}, //7
	},
	// data[3]
	{ {}, //0
	  {0}, //1
	  {0}, //2
	  {0}, //3
	  {3}, //4
	  {2}, //5
	  {1}, //6
	  {6}, //7
	},
	// data[4]
	{ {}, //0
	  {0}, //1
	  {0}, //2
	  {0}, //3
	  {2}, //4
	  {1}, //5
	  {2}, //6
	  {2,4,5,6}, //7
	},
	// data[5]
	{ {}, //0
	  {0}, //1
	  {0}, //2
	  {0}, //3
	  {1}, //4
	  {2}, //5
	  {3}, //6
	  {1,2,3,5}, //7
	},
      };
      foreach (int[][] data in dataList){
	test1(data);
      }
    }

    define void test1(int[][] data){
      resetModuleManager();
      foreach (int index, int[] supers in data){
	Module module = new Module();
	module.name = index;
	module.superModules = new Vec<int>(supers);
	moduleManager.put(index, module);
      }

#+debug
      {
	// $B;n$7$K(B m7 $B$+$i$d$C$F$_$k!#(B
	Module m = moduleManager.get(7)
	  ifNotFound { throw fatal(""+ 7); };
	decideLevelVec(m);
      }

      // $B$=$l$>$l$N(B module $B$r(B sort $B$7$F!"7k2L$r=PNO$9$k!#(B
      foreach (int name in data.length){
	Module m = moduleManager.get(name)
	  ifNull { throw fatal(""+ name); };

	decideLevelVec(m);
	// Collection plug-in $B$N%P%0$rHr$1$k$?$a!"(B
	//m.levelVec $B$r$+$C$3$G0O$`I,MW$"$j!#(B
	(m.levelVec).print("levelVec of "+ m.name+ " :");
      }
    }

    define void decideLevelVec(Module module){
      if (module.level >= 0){
	// Level is already detemined. Do nothing.
	return;
      } else if (module.level == module.TRAVERSING){
	throw new Error("Cycle: "+ module.name);
      } else {
	Vec<Vec<Module> > levelVec = {};
	foreach (int name in module.superModules){
	  Module s = moduleManager.get(name)
	    ifNull {
	      throw fatal("getModule:"+ name);
	    };
	  // $B:F5"8F$S=P$7(B
	  decideLevelVec(s);
	  // $B$3$3$G!"3F(B level $B$N(B merge $B$r9T$&!#(B
	  mergeLevelVec(levelVec, s.levelVec);
	}
	Vec<Module> lastLevel = {module}; // $B<+J,<+?H(B
	levelVec.push(lastLevel);
	module.levelVec = levelVec;
	module.level = (module.levelVec).size();
      
      }
    }

    define void mergeLevelVec(Vec<Vec<Module> > sublevelVec,
			      Vec<Vec<Module> > superlevelVec){
      foreach (int index, Vec<Module> superVec in superlevelVec){
	if (index >= sublevelVec.size()){
	  sublevelVec.push(new Vec<Module>());
	}
	Vec<Module> subVec = sublevelVec.get(index);
	// merge $B$9$k!#(B
	Vec<Module> r = new Vec<Module>();
	int i1 = 0, i2 = 0, ir = 0;
	while (i1 < subVec.size() && i2 < superVec.size()){
	  Module m1 = subVec.get(i1);
	  Module m2 = superVec.get(i2);
	  if (m1.name == m2.name){
	    r.push(m1);
	    i1++;
	    i2++;
	  } else if (m1.name < m2.name){
	    // $B>.$5$$L>A0$rM%@h!#(B
	    r.push(m1);
	    i1++;
	  } else {
	    r.push(m2);
	    i2++;
	  }
	}
	while (i1 < subVec.size()){
	  r.push(subVec.get(i1));
	  i1++;
	}
	while (i2 < superVec.size()){
	  r.push(superVec.get(i2));
	  i2++;
	}
	sublevelVec.put(index, r);
      }
    }

    define Error fatal(String msg) { return new Error(msg); }
  }
}
