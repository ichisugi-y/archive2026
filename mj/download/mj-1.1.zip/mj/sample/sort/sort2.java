/*

	Usage:
		% mjc sort2.java; mj sort

 monotonic $B$J(B linearization $B$N%F%9%H%W%m%0%i%`!#(B
 uses $B@k8@BP1~HG!#(B

 */

module sort {

  define class Module {
    define Module(){}
    int name;
    Vec<int> extendingModules;	// $B<+J,$O4^$^$J$$!#=gITF1!#=EJ#2D!#(B
    Vec<int> usingModules;	// extendingModules $B$r4^$^$J$/$F$b$h$$!#(B
    Vec<int> linearizedModules;	// currently not used.

    int TRAVERSING = -998;
    int NOT_DETERMINED = -999;
    int level = FQN[sort::NOT_DETERMINED];

    Vec<Vec<Module> > levelVec = null;

    String toString(){ return "m"+ name; }
  }

  class SS {
    Table<int, Module> moduleManager;
    /** moduleManager $B$NCf?H$r6u$K%j%;%C%H$9$k!#(B */
    define void resetModuleManager(){
      moduleManager = new Table<int, Module>();
    }

    void main(String[] args){
      // $B!V!V!V(BextendingModules $B$NG[Ns!W$H!V(BusingModules $B$NG[Ns!W!W$NG[Ns!W(B
      // $B$,#1$D$N%0%i%U$rI=$9%F%9%H%G!<%?$G!"(B dataList $B$O$=$NG[Ns!#(B
      // level 0:       m0
      // level 1:   m1  m2  m3
      // level 2:   m4  m5  m6
      // level 3:       m7
      int[][][][] dataList =
      {
	// data[0]
	{ {{}, {}}, //0, not referred
	  {{}, {}}, //1
	  {{}, {0}}, //2
	  {{}, {}}, //3
	  {{3}, {}}, //4
	  {{1}, {}}, //5
	  {{2}, {}}, //6
	  {{4,5,6}, {}}, //7
	},
	// data[1]
	{ {{}, {}}, //0, not referred
	  {{}, {}}, //1
	  {{}, {}}, //2
	  {{}, {}}, //3
	  {{2}, {0}}, //4
	  {{2,3}, {}}, //5
	  {{1}, {}}, //6
	  {{4,5,6}, {}}, //7
	},
	// data[2]
	{ {{}, {1,2,7,3}}, //0
	  {{0}, {}}, //1
	  {{0}, {}}, //2
	  {{0}, {}}, //3
	  {{3}, {}}, //4
	  {{3}, {}}, //5
	  {{3}, {}}, //6
	  {{3,4,5,6}, {}}, //7
	},
	// data[3]
	{ {{}, {}}, //0
	  {{0}, {5,0,4}}, //1
	  {{0}, {}}, //2
	  {{0}, {}}, //3
	  {{3}, {}}, //4
	  {{2}, {}}, //5
	  {{1}, {}}, //6
	  {{6}, {}}, //7
	},
	// data[4]
	{ {{}, {}}, //0
	  {{0}, {}}, //1
	  {{0}, {}}, //2
	  {{0}, {}}, //3
	  {{2}, {}}, //4
	  {{1}, {}}, //5
	  {{2}, {}}, //6
	  {{2,4,5,6}, {3}}, //7
	},
	// data[5]
	{ {{}, {}}, //0
	  {{0}, {}}, //1
	  {{0}, {4,6}}, //2
	  {{0}, {}}, //3
	  {{1}, {}}, //4
	  {{2}, {}}, //5
	  {{3}, {}}, //6
	  {{1,2,3,5}, {}}, //7
	},
      };
      foreach (int index, int[][][] data in dataList){
	System.err.println("-----------------");
	System.err.println("data["+ index+ "]");
	test1(data);
      }
    }

    /** $BM?$($i$l$?%F%9%H%G!<%?$r(B linearize $B$9$k!#(B */
    define void test1(int[][][] data){
      resetModuleManager();
      foreach (int index, int[][] pair in data){
	Module module = new Module();
	module.name = index;
	module.extendingModules = new Vec<int>(pair[0]);
	Vec<int> usingModules = new Vec<int>(pair[1]);
	foreach (int name in module.extendingModules){
	  usingModules.push(name);
	}
	module.usingModules = usingModules;
	moduleManager.put(index, module);
      }

#+debug
      {
	// $B;n$7$K(B m7 $B$+$i$d$C$F$_$k!#(B
	Module m = moduleManager.get(7)
	  ifNull { throw fatal(""+ 7); };
	linearize(m);
      }

      // $B$=$l$>$l$N(B module $B$r(B sort $B$7$F!"7k2L$r=PNO$9$k!#(B
      foreach (int name in data.length){
	Module m = moduleManager.get(name)
	  ifNull { throw fatal(""+ name); };

	linearize(m);
	m.levelVec.print("levelVec of "+ m.name+ " :");
      }
    }

    /** linearize $B$7$F(B levelVec $B$r5a$a$k!#(B */
    define void linearize(Module module){
      Table<int, Module> allModules = {};
      decideAllModules(module, allModules);
      foreach (Module m in allModules.valueIter()){
	decideLevel(m);
      }
      module.levelVec = makeLevelVec(allModules);
    }

    /**  uses $B4X78$N(B transitive closure $B$r5a$a$k!#(B*/
    define void decideAllModules(Module module, Table<int, Module> allModules){
      if (allModules.containsKey(module.name)) return;
      allModules.put(module.name, module);
      foreach (int name in module.usingModules){
	Module m = moduleManager.get(name)
	  ifNull {
	    throw fatal("getModule:"+ name);
	  };
	decideAllModules(m, allModules);
      }
    }

    /** module $B$N(B level $B$r7hDj$9$k!#(B */
    define void decideLevel(Module module){
      if (module.level >= 0){
	// Level has already detemined. Do nothing.
	return;
      } else if (module.level == module.TRAVERSING){
	throw new Error("Cycle: "+ module.name);
      } else {
	module.level = module.TRAVERSING;
	int level = -1;
	foreach (int name in module.extendingModules){
	  Module s = moduleManager.get(name)
	    ifNull {
	      throw fatal("getModule:"+ name);
	    };
	  // $B:F5"8F$S=P$7(B
	  decideLevel(s);
	  if (s.level > level) level = s.level;
	}
	module.level = level + 1;
      }
    }

    /**  levelVec $B$r:n$k!#(B */
    define Vec<Vec<Module> > makeLevelVec(Table<int, Module> allModules){
      Vec<Vec<Module> > levelVec = {};
      foreach (Module m1 in allModules.valueIter()){
	if (m1.level < 0) throw fatal(""+ m1+ ":"+ m1.level);
	foreach (int i in m1.level + 1 - levelVec.size()){
	  levelVec.push(new Vec<Module>());
	}
	Vec<Module> vec = levelVec.get(m1.level);
	// $BA^F~!#$?$@$7F10l$JL>A0$N>l9g$OA^F~$7$J$$!#(B
      done:{
	  foreach (int index, Module m2 in vec){
	    if (m1.name == m2.name) break done;
	    if (m1.name < m2.name){
	      // .....m.........
	      //      ^ index   ^ p = vec.size()
	      int p = vec.size();
	      vec.push(null);
	      while (index < p){
		vec.put(p, vec.get(p - 1));
		p--;
	      }
	      vec.put(index, m1);
	      break done;
	    }
	  }
	  vec.push(m1);
	}
      }
      return levelVec;
    }

    /** fatal error */
    define Error fatal(String msg) { return new Error(msg); }
  }
}
