/*

 Usage:
	% mjc Draw.java
	% mj -s box -s clear -s dragPoint -s pressPoint -s mirror -s dup draw 

	All modules except for "draw" are optional.
	For example, try this:

	% mj -s clear -s pressPoint -s mirror draw 

 */


//  A framework of drawing tool.
//  Method "drawLine" is invoked if mouse is dragged.
//  A line is drawn from the start point to the end point
// if method "drawLine" is called.
module draw
imports java.applet.*
imports java.awt.*
imports java.awt.event.*
{
  class SS {
    void main(String[] args){
      original(args);
      final Frame f = new Frame();
      Applet a = new Draw();
      f.add(a, "Center");
      a.init();
      f.setSize(180,250);
      f.show();
      f.addWindowListener(new WindowAdapter(){
	public void windowClosing(WindowEvent e){
	  System.err.println("Closed!!");
	  f.dispose();
	  System.exit(0);
	}
      });
    }
  }

  /** A framework of draw applet. */
  define class Draw extends Applet
    implements MouseListener, MouseMotionListener {

    define Draw(){}

    int lastX = 0, lastY = 0;

    void init(){
      this.addMouseListener(this);
      this.addMouseMotionListener(this);
    }

    /** Draw line. */
    define void drawLine(int x1, int y1, int x2, int y2){
      Graphics g = this.getGraphics();
      g.drawLine(x1, y1, x2, y2);
    }

    void mousePressed(MouseEvent e){ }
    void mouseDragged(MouseEvent e){
      this.drawLine(lastX, lastY, e.getX(), e.getY());
    }
    void mouseReleased(MouseEvent e) {}
    void mouseClicked(MouseEvent e) {}
    void mouseEntered(MouseEvent e) {}
    void mouseExited(MouseEvent e) {}
    void mouseMoved(MouseEvent e) {}
  }
}


//  A box is drawn from the start point to the end point
//  if method "drawLine" is called.
module box
extends draw
{
  class Draw {
    void drawLine(int x1, int y1, int x2, int y2){
      original(x1, y1, x2, y2);
      Graphics g = this.getGraphics();
      if (x2 - x1 < 0){
	int tmp = x1;
	x1 = x2;
	x2 = tmp;
      }
      if (y2 - y1 < 0){
	int tmp = y1;
	y1 = y2;
	y2 = tmp;
      }
      g.drawRect(x1, y1, x2 - x1, y2 - y1);
    }
  }
}



//  Clear botton is displayed.
module clear
extends draw
{
  class Draw {
    void init(){
      original();

      Button b = new Button("Clear");
      final Draw outer = this;
      b.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent e){
	  System.err.println("Clear button is pressed !");
	  Graphics g = outer.getGraphics();
	  g.clearRect(0, 0, 1000, 1000);
	}});
      this.add(b);
    }
  }
}



//  The start point is updated if mouse is dragged.
module dragPoint
extends draw
{
  class Draw {
    void mouseDragged(MouseEvent e){
      original(e);
      Graphics g = this.getGraphics();
      lastX = e.getX(); lastY = e.getY();
    }
  }
}



//  The start point is updated if mouse botton is pressed.
module pressPoint
extends draw
{
  class Draw {
    void mousePressed(MouseEvent e){
      original(e);
      Graphics g = this.getGraphics();
      lastX = e.getX(); lastY = e.getY();
    }
  }
}



//  Method "drawLine" draws mirrored line.
module mirror
extends draw
{
  class Draw {
    void drawLine(int x1, int y1, int x2, int y2){
      original(x1, y1, x2, y2);
      original(y1, x1, y2, x2);
    }
  }
}



//  Method "drawLine" draws dupplicated line.
module dup
extends draw
{
  class Draw {
    void drawLine(int x1, int y1, int x2, int y2){
      original(x1, y1, x2, y2);
      original(x1 + 5, y1, x2 + 5, y2);
    }
  }
}
