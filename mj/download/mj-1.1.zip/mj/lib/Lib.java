/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

module mj.lang.ss
{
  define class SS extends mjc.SS {
    static SS instance;
    void setInstance(mjc.SS x){ instance = (SS)x; }

    void _init_SS(){}
    void main(String[] args){}
  }
} 

module test.defmacroTest {
  defmacro ExtendSS(message){
    class SS {
      void main(String[] args){
	original(args);
	System.out.println("=========");
	System.out.println(message);
      }
    }
  }
  defmacro CLASSES_A_B(){
    define class A {}
    define class B {}
  }
  defmacro CONCAT_TEST(prefix){
    define class CONCAT_ID(CAPITALIZE_ID(prefix), _C){
      String s1;
      define CONCAT_ID(CAPITALIZE_ID(prefix), _C)
	CONCAT_ID(_call_init_,
		  CONCAT_ID(CAPITALIZE_ID(prefix), _C))(String s1){
	this.CONCAT_ID(_init_,
		       CONCAT_ID(CAPITALIZE_ID(prefix), _C))(s1);
	return this;
      }
      define void
	CONCAT_ID(_init_,
		  CONCAT_ID(CAPITALIZE_ID(prefix), _C))(String s1){
	this.s1 = s1;
      }
      define String CONCAT_ID(prefix, _m)(String s2){
	return s1+ s2;
      }
    }
  }
  defmacro SWAP(type, v1, v2){
    type tmp = v1;
    v1 = v2;
    v2 = tmp;
  }
}
