/*

 Programs appeared in the MJ 1.0 tutorial.

 */


//--------------------------------------------------

module t.m1 {
  define class C {
    define C(){}
    define void m(){ System.out.println("m1:C#m()"); }
  }
  define class SubC extends C {
    define SubC(){}
    void m(){ original(); System.out.println("+ m1:SubC#m()"); }
  }
  class SS {
    void main(String[] args){
      System.out.println("----- invoke C#m();");
      C c = new C();
      c.m();
      System.out.println("----- invoke SubC#m();");
      SubC subc = new SubC();
      subc.m();
    }
  }
}

module t.m2 extends t.m1 {
  class C {
    void m(){ original(); System.out.println("+ m2:C#m()"); }
  }
  class SubC {
    void m(){ original(); System.out.println("+ m2:SubC#m()"); }
  }
}

module t.m3 extends t.m1 {
  class C {
    void m(){ original(); System.out.println("+ m3:C#m()"); }
  }
  class SubC {
    void m(){ original(); System.out.println("+ m3:SubC#m()"); }
  }
}

module t.m4 extends t.m2, t.m3 {
  class C {
    void m(){ original(); System.out.println("+ m4:C#m()"); }
  }
  class SubC {
    void m(){ original(); System.out.println("+ m4:SubC#m()"); }
  }
}

//--------------------------------------------------

module t.hello {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("Hello.");
    }
  }
}
module t.world extends t.hello {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("World.");
    }
  }
}

//--------------------------------------------------
// Method invocation of class SS

module t.ss.method {
  class SS {
    define int foo(){ return 123; }
    void main(String[] args){
      original(args);
      A a = new A();
      System.out.println(a.bar());  // 1230
    }
  }
  define class A {
    define A(){}
    define int bar(){
      return SS.instance.foo() * 10;
    }
  }
}

//--------------------------------------------------
// Constructors
// (Monolithic version of class Point)

module t.point.m {
  define class Point {
    int x;
    int y;
    define Point(int x, int y){
      this.x = x; this.y = y;
    }
    define void move(int dx, int dy){ x += dx; y += dy; }
    define int getX(){ return x; }
    define int getY(){ return y; }
  }
  class SS {
    void main(String[] args){
      original(args);
      Point p = new Point(10, 10);
      p.move(1, 2);
      System.out.println(p.getX());  // 11
      System.out.println(p.getY());  // 12
    }
  }
}

//--------------------------------------------------
// abstract class, abstract method

module t.abst.m1 {
  define abstract class C {
    define C(){}
    define abstract int foo();
  }
  define class SubC extends C {
    define SubC(){}
    define abstract int bar();
  }
  class SS {
    void main(String[] args){
      original(args);
      SubC c = new SubC();
      System.out.println(c.foo());
      System.out.println(c.bar());
    }
  }
}
module t.abst.m2 extends t.abst.m1 {
  class SubC {
    int foo(){ return 111; }
    int bar(){ return 222; }
  }
}

//--------------------------------------------------
// interface

module t.color {
  define interface Color {
    int RED = 0xff0000;
    int GREEN = 0x00ff00;
    int BLUE = 0x0000ff;
    define int getRGBCode();
  }
  define class ColorImplementation implements Color {
    define ColorImplementation(){}
    int code = 0x000001;
    int getRGBCode(){ return code; }
  }
  class SS {
    void main(String[] args){
      original(args);
      Color c = new ColorImplementation();
      System.out.println(c.getRGBCode()); // 1
      System.out.println(Color.BLUE);     // 255
    }
  }
}



//--------------------------------------------------
// Specification module and implementation module.

module t.point {
  define class Point {
    define abstract Point(int x, int y);
    define abstract void move(int dx, int dy);
    define abstract int getX();
    define abstract int getY();
  }
}
module t.point.implementation extends t.point {
  class Point {
    int x;
    int y;
    Point(int x, int y){
      this.x = x; this.y = y;
    }
    void move(int dx, int dy){ x += dx; y += dy; }
    int getX(){ return x; }
    int getY(){ return y; }
  }
}
module t.point.test extends t.point {
  class SS {
    void main(String[] args){
      original(args);
      Point p = new Point(10, 10);
      p.move(1, 2);
      System.out.println(p.getX());  // 11
      System.out.println(p.getY());  // 12
    }
  }
}


//--------------------------------------------------
// Nested name spaces.

module t.nest.interface_A_B {
  define class A { }
  define class B {
    define abstract B();
    define abstract int getX();
  }
}
module t.nest.implementation_A_B extends t.nest.interface_A_B {
  class A {
    static int x = 123;
  }
  class B {
    B(){}
    int getX(){ return A.x; }
  }
}
module t.nest.test extends t.nest.interface_A_B {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println(new B().getX());	// 123
    }
  }
}


//--------------------------------------------------
// "imports" declarations.

module t.javalib.m1
imports java.io.*
imports java.util.Vector
{
}
module t.javalib.m2 extends t.javalib.m1 {
  class SS {
    void main(String[] args){
      original(args);
      File f = new File("f");
      Vector v = new Vector();
    }
  }
}

//--------------------------------------------------

module t.sharpPlus.m1 {
  class SS {
    void main(String[] args){
      original(args);
#+comment
      System.out.println("aaa");
      //#+comment
      {
	System.out.println("bbb");
      }
      System.out.println("ccc");
    }
  }
}
#+comment
{
  module t.sharpPlus.m1{
#+comment
    class C { }
  }
#+comment
  module t.sharpPlus.m2{
  }
}


//--------------------------------------------------

module t.uses.a uses t.uses.b {
  define class A {
    define A(){}
    define B getB(){ return new B(); }
  }
}
module t.uses.b uses t.uses.a {
  define class B {
    define B(){}
    define A getA(){ return new A(); }
  }
}


//--------------------------------------------------
// Dynamic loading of classes.

module t.forName {
  define class A {
    static int x = 123;
  }
  class SS {
    void main(String[] args){
      original(args);
      try {
	Class c = Class.forName("t.forName.A");
	A a = (A)c.newInstance();
	System.out.println(a.x); // 123
      } catch (Throwable e){
	e.printStackTrace(System.err);
	System.err.println(e.getMessage());
	throw new Error();
      }
    }
  }
}


//--------------------------------------------------
// FQN

module t.fqn.m1 {
  define class A {
    define A(){}
  }
}
module t.fqn.m2 extends t.fqn.m1 {
  class A {
    define int m(){ return 2; }
  }
}
module t.fqn.m3 extends t.fqn.m1 {
  class A {
    define int m(){ return 3; }
  }
}
module t.fqn.m4 extends t.fqn.m2, t.fqn.m3 {
  class A {
    int FQN[t.fqn.m2::m](){ return original() * 10; }
    int FQN[t.fqn.m3::m](){ return original() * 100; }
  }
  class SS {
    void main(String[] args){
      original(args);
      A a = new A();
      //System.out.println(a.m()); // error
      System.out.println(a.FQN[t.fqn.m2::m]());  // 20
      System.out.println(a.FQN[t.fqn.m3::m]());  // 300
    }
  }
}


//--------------------------------------------------
// Complementary module.

module t.compl.orig {
  define abstract class S { }
  define class A extends S { }
}
module t.compl.sub extends t.compl.orig {
  define class B extends S { }
}
module t.compl.abst extends t.compl.orig {
  class S {
    define abstract int m();
  }
  class A {
    int m(){ return 1; }
  }
}
module t.compl.compl_sub_abst complements t.compl.sub, t.compl.abst {
  class B {
    int m(){ return 2; }
  }
}


//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------
//
// The rest of this line is not appeared in the tutorial.



//--------------------------------------------------
// Another example of complementary modules.
// Try "mj -s t.compl.m1 -s t.compl.m2 t.compl.m3" . 

module t.compl.m1 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m1");
    }
  }
}

module t.compl.m2 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m2");
    }
  }
}

module t.compl.m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m3");
    }
  }
}


module t.compl.m1m2 complements t.compl.m1, t.compl.m2 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m1m2");
    }
  }
}


module t.compl.m2m3 complements t.compl.m2, t.compl.m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m2m3");
    }
  }
}


module t.compl.m1m2m2m3 complements t.compl.m1m2, t.compl.m2m3 {
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("t.compl.m1m2m2m3");
    }
  }
}



//--------------------------------------------------
// Test program of arguments.
// Try "mj t.args 1 2 3" .

module t.args {
  class SS {
    void main(String[] args){
      original(args);
      Vec<String> vec = new Vec<String>(args);
      vec.print("args:");
    }
  }
}

//--------------------------------------------------
// An example of printFunction customization.

module t.collection.printFunction
imports jp.go.etl.epp.util.*
imports java.io.*
{
  define class Foo {
    String name;
    define Foo(String name){
      this.name = name;
    }
  }
  define class FooPrintFunctionDecorator extends PrintFunction {

    PrintFunction next;

    define FooPrintFunctionDecorator(PrintFunction next){
      this.next = next;
    }
    
    void call(PrintWriter out, String indent, Object x){
      if (x instanceof Foo){
	out.print(indent);
	out.print("Foo(");
	PrintFunction.printFunction.call(out, "", ((Foo)x).name);
	out.print(")");
      } else {
	next.call(out, indent, x);
      }
    }
  }
  class SS {
    SS(){
      original();
      PrintFunction.printFunction
	= new FooPrintFunctionDecorator(PrintFunction.printFunction);
    }
    void main(String[] args){
      original(args);
      // test
      Vec<String> stringVec = { "aaa", "bbb" };
      Vec<Foo> fooVec= { new Foo("aaa"), new Foo("bbb") };
      stringVec.print("stringVec:");
      fooVec.print("fooVec:");
    }
  }
}


//--------------------------------------------------
// Assert statement example.

module t.assert {
  class SS {
    void main(String[] args){
      int x = 0;
      assert(x == 0);
      System.out.println("assert test.");
      assert(x != 0); // fail
    }
  }
}

//--------------------------------------------------
//  usemacro test.  test.defmacroTest is defined at Lib.java
module test.usemacroTest extends test.defmacroTest {

  usemacro CONCAT_TEST(pre);
  class SS {
    void main(String[] args){
      original(args);
      System.out.println("=========");
      int x = 12, y = 34;
      usemacro SWAP(int, x, y);
      System.out.println("x = "+ x+ ", y = "+ y);
      Pre_C c = new Pre_C("a");
      System.out.println(c.pre_m("b")); // -> "ab"
    }
  }

  usemacro CLASSES_A_B();
  define class C {
    define void foo(){
      A a = null;
      B b = null;
    }
  }
}
