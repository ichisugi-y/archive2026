/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */


/*

 macro plug-in


*/


#epp jp.go.etl.epp.EppLibLevel0
#epp jp.go.etl.epp.Collection

package mjc;
import mjc.*;

SystemMixin MJMacro {
  class Epp {
    //--------------------------------------------------
    // Syntax extension

    extend Tree identifier(){
      if (lookahead() == :CONCAT_ID) {
	matchAny();
	match(:"(");
	Tree id1 = identifier();
	match(:",");
	Tree id2 = identifier();	
	match(:")");
	return new Tree(:CONCAT_ID, id1, id2);

      } else if (lookahead() == :CAPITALIZE_ID) {
	matchAny();
	match(:"(");
	Tree id1 = identifier();
	match(:")");
	return new Tree(:CAPITALIZE_ID, id1);

      } else {
	return original();
      }
    }

    extend Tree statementTop() {
      Token token = lookahead();
      if (token == :usemacro) {
	matchAny();
	Tree name = identifier();
	Tree argumentList = argumentList();
	if (lookahead() == :"{"){
	  return new Tree(:usemacroWithBlock, name, argumentList, block());
	} else {
	  match(:";");
	  return new Tree(:usemacro, name, argumentList);
	}

      } else if (token == :class || token == :interface
		 || token == :define){
	return mjTypeDeclarationAfterMJMarks(mjMarks());

      } else {
	return original();
      }
    }

    /* not used
    extend Tree mjClassBodyDeclaration(){
      if (lookahead() == :PARSE_AS_CONSTRUCTOR){
	matchAny();
	return mjConstructorDeclaration(mjMarks(), modifiers());
      } else {
	return original();
      }
    }
    */

    extend Tree convertExpressionToType(Tree exp){
      Symbol tag = exp.tag();
      if (tag == :CONCAT_ID
	  || tag == :CAPITALIZE_ID){
	Tree newTree = new Tree(:name, exp);
	return TypeChecker.remakeTree(newTree, exp);

      } else {
	return original(exp);
      }
    }

    extend Tree mjTypeDeclarationTop() {
      if (lookahead() == :usemacro) {
	matchAny();
	Tree name = identifier();
	Tree argumentList = argumentList();
	match(:";");
	return new Tree(:usemacro, name, argumentList);
      } else if (lookahead() == :defmacro) {
	matchAny();
	Tree name = identifier();
	Tree argumentList = argumentList();
	Tree block = block();
	return new Tree(:defmacro, name, argumentList, block);
      } else {
	return original();
      }
    }
    
    //--------------------------------------------------
    // moduleSig

    extend Tree normalizeMJTypeDeclaration(Tree tree){
      if (tree.tag() == :defmacro || tree.tag() == :usemacro){
	return tree;
      } else {
	return original(tree);
      }
    }

    //--------------------------------------------------
    extend void initMacroTable () {
      original();
      defineMacro(:usemacroWithBlock,
			new UsemacroWithBlockMacro());
    }

    extend void initTypeCheckerTable () {
      original();

      defineTypeChecker(:defmacro,	new DefmacroTypeChecker());
      defineTypeChecker(:usemacro,	new UsemacroTypeChecker());
    }

  }
}

class DefmacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    return `(emptyTypeDeclaration);
  }
}

class UsemacroWithBlockMacro extends Macro {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    return `(usemacro ,(args[0]) (argumentList ,@(args[1].args()) ,(args[2])));
  }
}

class UsemacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    MJModuleInfo module = (MJModuleInfo)Dynamic.get(:currentModule);
    Symbol macroName = tree.args()[0].idName();
    Tree defmacro = module.macroTable.get(macroName)
      ifNull {
	throw errorAt(tree, "Undefined macro: "+ macroName);
      };
    return MJModuleInfo.macroExpand(tree, defmacro);
  }
}
