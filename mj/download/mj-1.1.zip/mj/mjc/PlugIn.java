/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */


#epp jp.go.etl.epp.EppLibLevel0

package mjc;
import java.util.*;
import java.io.*;

BeforeLoadingPlugIn{
  requirePlugIn("jp.go.etl.epp.SharpPlus.PlugIn");
  requirePlugIn("mjc.Syntax");
  requirePlugIn("mjc.TypeCheck");
  requirePlugIn("mjc.Trans");
  requirePlugIn("mjc.FileSig");
  requirePlugIn("mjc.MJMacro");
}

SystemMixin MJC {
  class Epp {
    //--------------------------------------------------

    // $B$3$N%a%=%C%I$O!"(B global EPP $B$KBP$7$F$O8F$P$l$J$$$N$GCm0U!#(B
    // $BBe$o$j$K(B initGlobalProcessor $B$r;H$&$3$H!#(B
    extend void initializationPass() {
      original();
      // $B%(%i!<%a%C%;!<%8$r=P$9$H$-$K;H$&!#(B
      Dynamic.bind(:processingModuleName, null);
      Dynamic.bind(:macroExpandingTree, null);
    }

    extend void initGlobalProcessor() {
      original();
      // $B%(%i!<%a%C%;!<%8$r=P$9$H$-$K;H$&!#(B
      Dynamic.bind(:processingModuleName, null);
      Dynamic.bind(:macroExpandingTree, null);

      // linkModeFlag $B$J$I$r@_Dj$9$k!#(B
#+old
      MJLinker.checkLinkerOption();

      MJC.checkNoFQNFlag();
    }

    //--------------------------------------------------
    // $B$3$N%a%=%C%I$O!"(B EPP main routine $B$+$i8F$P$l$k!#(B
    // MJ $B$G$OITMW$J$N$G!"6u$N(B FileSignature $B$rJV$9!#(B
    // $B$=$N$+$o$j!"(B mjInitialization $B$NCf$G(B normalizeMJCompilationUnit $B$r(B
    //$B8F$s$G$$$k!#(B

    redefine Tree normalizeCompilationUnit(Tree tree){
      return `(fileSignature
	       (packageDeclaration)
	       (importDeclarations)
	       (typeDeclarations));
    }

    //--------------------------------------------------
    // module $B>pJs$rBg0hE*$K=8$a$k!#(B
    extend void globalProcessAfterMacroExpansionPass() {
      original();
      if (Opts.nocatch){
	mjInitialization();
      } else {
	try {
	  mjInitialization();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught by globalProcessAfterMacroExpansionPass().");
	}
      }
      Epp.checkErrorCounter();
    }

    define implement void mjInitialization(){
      // treeToMJMethod $B$G!"7?L>$r7?$KJQ49$9$k$H$-$K;H$o$l$k!#(B
      Dynamic.bind(:typeNameCheckerTable, new Hashtable());
      initTypeNameCheckerTable();

      MJModuleTable mjModuleTable = new MJModuleTable();
      MJModuleTable.instance = mjModuleTable;

      for (int i = 0; i < (self!allFileInfo).length; i++){
	DVenv env = (self!allFileInfo)[i].getDVenv();
	EppInputStream eppInputStream =
	  (EppInputStream)env.get(:eppInputStream);
	Tree fileSignature
	  = normalizeMJCompilationUnit((self!allFileInfo)[i].getTree());

	if (Opts.printFileSignature || Opts.printTree) {
	  Opts.out.println("normalized MJCompilationUnit:");
	  fileSignature.print();
	}

	String inputFileName = (self!allFileInfo)[i].getInputFileName();
	mjModuleTable.addModulesFromFileSignature(inputFileName,
						  eppInputStream,
						  fileSignature);
      }

      mjModuleTable.initAllModules();
    }

    //--------------------------------------------------

    extend void initEmitterTable() {
      original();
      // $B=PNO%3!<%I$r>/$7$G$b8+$d$9$/$9$k$?$a!"7;Do%-%c%9%H$O$3$l$r;H$&!#(B
      // $B!J(B mjCast $B$O!"K\Ev$O(B Translator $B$G=hM}$9$Y$-Cf4V%N!<%I!#!K(B
      defineEmitter(:mjCast, new MJCastEmitter());
      redefineEmitter(:expressionStatement,
		      new MJExpressionStatementEmitter());
    }


    //--------------------------------------------------
    // $BBg0hE*$KJQ49!"$=$N$^$^JQ498e$N3F%/%i%9$r=PNO!#(B
    // $B!J(Bepp $B<+BN$O(B -no-code-emitting $B%*%W%7%g%s$rIU$1$F8F$S=P$9!#!K(B
    extend void globalProcessAfterTypeCheckingPass() {
      original();

      if (MJLinker.linkModeFlag){
	// $B7?%A%'%C%/$N4D6-@_Dj$,=*$o$C$?8e!"%j%s%/!#(B
	new MJLinker().doLink();
      } else {
	if (Opts.log) Opts.out.println("Translation and Emitting pass of MJ.");

	MJTranslator translator = new MJTranslator();
	translator.checkTranslationOption();
	for (int i = 0; i < (self!allFileInfo).length; i++){
	  translator
	    .translateMJCompilationUnit((self!allFileInfo)[i].getInputFileName(),
					(self!allFileInfo)[i].getTree());
	}
	translator.outputAllModuleNames();
      }
    }
  }
}
  
// $B%M%9%H$7$?(B mjCast $B$O#1$D$@$1;D$9$h$&$K:GE,2=$9$k!#(B
class MJCastEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    checkArgsLength(tree, 2);
    // ((%)(Object)(%))
    Tree[] args = tree.args();
    emitString(out, "((");
    emitTree(out, args[0]);
    emitString(out, ")(Object)(");
    emitTree(out, removeRedundantCasts(args[1]));
    emitString(out, "))");
  }
  Tree removeRedundantCasts(Tree tree){
    Symbol tag = tree.tag();
    if (tag == :mjCast || tag == :cast){
      return removeRedundantCasts(tree.args()[1]);
    } else {
      return tree;
    }
  }
}

  
class MJExpressionStatementEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    checkArgsLength(tree, 1);
    Tree exp = removeIllegalStatementExpression(tree.args()[0]);
    emitTree(out, exp);
    if (exp.tag() != :block){
      out.write(';');
    }
  }

  // In order to make deveropping plug-in easy,
  // the emitter removes cast which causes Java compiler error.
  //     (T)exp;   ->   exp;
  Tree removeIllegalStatementExpression(Tree tree){
    Symbol tag = tree.tag();
    // $B<!$N#19T$r=$@5$7$?$@$1!#$"$H$O%*%j%8%J%k$HF1$8!#(B
    if (tag == :cast || tag == :mjCast){
      return removeIllegalStatementExpression(tree.args()[1]);
    } else {
      return tree;
    }
  }
}




//--------------------------------------------------

// Utilities.
public class MJC {

  public static String MJ_PACKAGE = "mjc"; // "jp.go.etl.mjc"

  public static final String COMPLEMENTARY_PACKAGE_PREFIX = "MJcomplementary";

  public static final Symbol JAVA_MODULE_NAME = :"java";

#+old
  public static Error error(String msg){
    Symbol processingModuleName = (Symbol)Dynamic.get(:processingModuleName);
    if (processingModuleName != null){
      msg = "In module \""+ processingModuleName+ "\" : "+ msg;
    }
    Dynamic.setInt(:errorCounter,
		   Dynamic.getInt(:errorCounter) + 1);
    return new MJUserError("MJ: "+ msg);
  }
#+old
  public static Error errorAt(Tree tree, String msg){
    String str = "";
    if (tree != null){
      str = str+ (String)Dynamic.get(:inputFileName)+ ":"+
	tree.lineNumber()+ ": ";
      if (Opts.log) {
	Opts.out.println("Type-checking tree: "+ tree);
	Opts.out.println("tree.beginningPoint =  "+ tree.beginningPoint());
	Opts.out.println("tree.endPoint "+ tree.endPoint());
      }
    }
    Dynamic.setInt(:errorCounter,
		   Dynamic.getInt(:errorCounter) + 1);
    return new MJUserError(str+ "MJ: "+ msg);
  }

  public static Error fatal(String msg){
    if (msg == null) msg = "null";
    Symbol processingModuleName;
    try {
      processingModuleName = (Symbol)Dynamic.get(:processingModuleName);
    } catch (UnboundDynamicVariableAccessException e){
      processingModuleName = null;
    }
    if (processingModuleName != null){
      msg = "In module \""+ processingModuleName+ "\" : "+ msg;
    }
    try {
      Obj epp = (Obj)Dynamic.get(:epp);
      epp!printErrorMessage(msg);
    } catch (Throwable e){
      Opts.out.println("Error has caught during printErrorMessage("+
		       Tree.quoteStringContents(msg)+
		       ") called by MJC.fatal. ");
    }
    return new Error("MJC: FATAL ERROR : "+ msg);
  }

  // (name (id a) (id b) (id c)) -> (id a_b_c)
  public static Tree nameToId(Tree tree){
    if (tree.tag() != :name) throw Epp.fatal("");
    StringBuffer buf = new StringBuffer();
    Tree[] elems = tree.args();
    buf.append(elems[0].idName().toString());
    for (int i = 1; i < elems.length; i++){
      buf.append('_');
      buf.append(elems[i].idName().toString());
    }
    return new Identifier(Symbol.intern(buf.toString()));
  }

  public static boolean noFQNFlag = false;
  public static void checkNoFQNFlag(){
    String prop = System.getProperty("mjc.noFQN");
    noFQNFlag = (prop != null) && (prop.length() != 0);
  }
  // a.b::c -> (id a_b_c), java::foo -> (id foo)
  public static Tree fullNameToId(Symbol moduleName, Symbol simpleName){
    if (moduleName == MJC.JAVA_MODULE_NAME){
      return new Identifier(simpleName);
    } else if (noFQNFlag){
      return new Identifier(simpleName);
    } else {
      return new Identifier(Symbol.intern(moduleName.
					  toString().replace('.','_')+
					  "_"+ simpleName));
    }
  }
  //     a.b.c, d.e.f -> a.b.c._Delta_d_e_f
  // or  a.b.c, d_e_f -> a.b.c._Delta_d_e_f
  public static Symbol makeDeltaLiName(Symbol moduleName, Symbol fullName){
    Symbol name = Symbol.intern((moduleName == :"" ? "" : moduleName+ ".")+
				fullName.toString().replace('.','_'));
    return addPrefixToFullName(name, "_Delta_");
  }
  //     a.b.c, d.e.f -> a.b.c._Dummy_d_e_f
  public static Symbol makeDummyClassName(Symbol moduleName, Symbol fullName){
    Symbol name = Symbol.intern((moduleName == :"" ? "" : moduleName+ ".")+
				fullName.toString().replace('.','_'));
    return addPrefixToFullName(name, "_Dummy_");
  }
  // a.b.c.A -> a.b.c._G_A
  public static Symbol makeGeneratorClassName(Symbol fullName){
    return addPrefixToFullName(fullName, "_G_");
  }
  // a.b.c, d.e.f -> a.b.c._Delta_d_e_f
  public static Symbol makeJavaDeltaLiName(Symbol moduleName,
					   Symbol classFullName){
    return makeDeltaLiName(moduleName, classFullName);
  }
  public static Symbol addPrefixToFullName(Symbol fullName, String prefix){
    String str = fullName.toString();
    int lastDot = str.lastIndexOf('.');
    // lastDot $B$,(B -1 $B$N$H$-$bF0$/!#(B
    String newStr =
      str.substring(0, lastDot + 1)+
      prefix+
      str.substring(lastDot + 1);
    return Symbol.intern(newStr);
  }

  
  //--------------------------------------------------
  
  // $B>-MhE*$K$O(B modifier $B$O8+$:$K!"K\BN$,(B ";" $B$+$I$&$+$GH=CG$7$?$$!#(B
  //$B!J(B normalizeMJMethod $B$NJ}$G$bBP=h$,I,MW!#!K(B
  public static boolean isAbstractMethod(Tree modifiers){
    return hasModifier(:abstract, modifiers);
  }

#+old
  // Currently not used.
  public static boolean isPublicMethod(Tree modifiers){
    boolean pub = hasModifier(:public, modifiers);
    boolean pro = hasModifier(:protected, modifiers);
    if (pub && pro){
      throw MJC.errorAt(modifiers,
			"MJ: Both public and protected were specified.");
    }
    if ((! pub) && (! pro)){
      throw MJC.errorAt(modifiers,
			"MJ: Neither public nor protected were specified.");
    }
    return pub;
  }

  public static boolean hasModifier(Symbol modifier, Tree modifiers){
    return hasModifier(modifier, modifiers.args());
  }
  public static boolean hasModifier(Symbol modifier, Tree[] modifiers){
    for (int i = 0; i < modifiers.length; i++){
      if (modifiers[i].idName() == modifier) return true;
    }
    return false;
  }

  //--------------------------------------------------
  // mjInfo $B4X78(B

  public static boolean isDefinition(Tree mjInfo){
    if (mjInfo.tag() == :mjInfo) {
      foreach (Tree info in mjInfo.args()){
	if (info.tag() == :id && info.idName() == :isDefinition){
	  return true;
	}
      }
      return false;
    } else if (mjInfo.tag() == :mjMarks) {
      return (mjInfo.args().length > 0);
    } else {
      throw MJC.fatal(""+ mjInfo);
    }
  }

  //--------------------------------------------------
  // FQN $B4X78(B

  public static Symbol mjNameToSimpleName(Tree mjName){
    if (mjName.tag() == :id){
      return mjName.idName();
    } else if (mjName.tag() == :mjFQN){
      Tree[] args = mjName.args();
      return args[args.length - 1].idName();
    } else {
      throw MJC.fatal("mjNameToSimpleName:"+ mjName);
    }
  }
 
  public static Symbol mjFQNToModuleName(Tree mjName){
    if (mjName.tag() == :mjFQN){
      StringBuffer buf = new StringBuffer();
      Tree[] ids = mjName.args();
      buf.append(ids[0].idName().toString());
      for (int i = 1; i < ids.length - 1; i++){
	buf.append("."+ ids[i].idName());
      }
      return Symbol.intern(buf.toString());
    } else {
      throw MJC.fatal("mjFQNToModuleName:"+ mjName);
    }
  }

  // For generating error messages.
  public static String mjNameToString(Tree mjName){
    if (mjName.tag() == :mjFQN){
      StringBuffer buf = new StringBuffer();
      Tree[] ids = mjName.args();
      buf.append("FQN["+ ids[0].idName().toString());
      for (int i = 1; i < ids.length - 1; i++){
	buf.append("."+ ids[i].idName());
      }
      buf.append("::"+ ids[ids.length - 1]+ "]");
      return buf.toString();
    } else if (mjName.tag() == :id){
      return mjName.idName().toString();
    } else {
      throw MJC.fatal("mjNameToString:"+ mjName);
    }
  }
 
  public static Tree mjNameToName(Tree mjName){
    if (mjName.tag() == :id){
      return `(name ,mjName);
    } else if (mjName.tag() == :mjFQN){
      return `(name ,@(mjName.args()));
    } else {
      throw MJC.fatal("mjNameToName:"+ mjName);
    }
  }



  public static MJMethodInfo findMethodInfo(Type typeOfThis,
					    Tree mjName, Tree argumentList){
    Obj epp = (Obj)Dynamic.get(:epp);

    Tree[] pdecls = argumentList.args();

    Symbol simpleName = MJC.mjNameToSimpleName(mjName);
    Symbol moduleName;
    if (mjName.tag() == :id){
      moduleName = null;
    } else if (mjName.tag() == :mjFQN){
      moduleName = MJC.mjFQNToModuleName(mjName);
    } else {
      throw MJC.fatal(""+ mjName);
    }

    Vec<MJMethodInfo> vec
      = ((MJClassType)typeOfThis).mjClassInfo()
      .getOverloadedMJMethods(simpleName)
      ifNull{
	throw MJC.fatal(""+ typeOfThis+ ":"+ mjName);
      };

    Vec<MJMethodInfo> foundMethodVec = {};

    foreach (MJMethodInfo m in vec){
      Type[] mparams = m.getParameterTypes();
    notMatch:{
	if (mparams.length != pdecls.length) {
	  break notMatch;
	}
	for (int j = 0; j < pdecls.length; j++){
	  Type declType = getPdeclVarType(pdecls[j].args()[1].type(),
					  pdecls[j].args()[2]);
	  if (! epp!equals(declType, mparams[j])){
	    // Try next me
	    break notMatch;
	  }
	}
	// match.
	if (m.moduleName == null){ throw MJC.fatal(""+ m); }
	if (moduleName == null){
	  foundMethodVec.push(m);
	} else {
	  if (moduleName == m.moduleName){
	    foundMethodVec.push(m);
	  }
	}
      }
    }

    if (foundMethodVec.size() == 0){
      throw MJC.fatal("findMethodInfo: No MethodInfo found:"+ mjName);
    } else if (foundMethodVec.size() == 1){
      return foundMethodVec.get(0);
    } else {
      StringBuffer buf = new StringBuffer();
      buf.append("findMethodInfo: More than one MethodInfo found."+
		 Opts.lineSeparator);
      foreach (MJMethodInfo m in foundMethodVec){
	buf.append("  "+ m.fullName+ Opts.lineSeparator);
      }
      throw MJC.fatal(buf.toString());
    }
  }

  // String s[][] -> array of array of String
  public static Type getPdeclVarType(Type type, Tree var){
    if (var.tag() == :id){
      return type;
    } else if (var.tag() == :arrayVar){
      return getPdeclVarType(new ArrayType(type), var.args()[0]);
    } else {
      throw MJC.fatal(""+ var);
    }
  }

  //--------------------------------------------------
  
}

public class MJUserError extends EppUserError {
  public MJUserError(String s){ super(s); }
}



//--------------------------------------------------
/*
 MJC $B5/F0%W%m%0%i%`!#(B

 */

public class MJCStartup extends Epp {
    
  public static void main(String[] argv){
    new MJCStartup().eppMain(argv);
  }
  public void eppMain(String[] args){
    MJLinker.linkModeFlag = false;

    Vec<String> eppOption={};
    {
      String targetClasspath = System.getProperty("mjc.targetClasspath");
      if (targetClasspath != null){
	eppOption.push("-target-classpath");
	eppOption.push(targetClasspath);
      }
    }
    foreach (String s in args){
      eppOption.push(s);
    }
#+debug
    {
      Opts.out.println("eppOptions:");
      foreach (String s in eppOption){
	Opts.out.println("  "+ Tree.quoteStringContents(s));
      }
    }
    super.eppMain(eppOption.toArray());
  }
}

//--------------------------------------------------
/*
 MJ $B5/F0%W%m%0%i%`!#(B

 $BBh0l0z?t$,(B eppArgs, $BBhFs0z?t$,(B selected $B!#$N$3$j$O(B ss main $B$N0z?t!#(B
 dump mode $B$K$7$?$$>l9g$O!"(B -E-Dmj.dump=true $B$,0z?t$KF~$C$F$$$l$P$h$$!#(B

 */

public class MJ extends Epp {
    
  public static void main(String[] argv){
    new MJ().eppMain(argv);
  }

  public void eppMain(String[] args){
    if (args.length < 2) {
      throw new Error("MJ: Usage: mjc.MJ eppArgs selectedModules [mainArgs]");
    }

    String[] mainArgs = new String[args.length - 2];
    for (int i = 0; i < mainArgs.length; i++){
      mainArgs[i] = args[i + 2];
    }
    MJLinker.mjMainArgs = mainArgs;
    MJLinker.linkModeFlag = true;
    MJLinker.selectedModules = args[1];

    Vec<String> eppOption = MJLinker.parseProperty(args[0]);

    {
      String[] eppArgs = {
	"-global",
	"-type-check",
	"-no-code-emitting",
	"-plug-in",
	"mjc",
	"-plug-in",
	"jp.go.etl.epp.Collection",
      };
      foreach (String s in eppArgs){
	eppOption.push(s);
      }
    }

#+debug
    {
      // $B$^$@(B Opts.* $B$NCM$O@_Dj$5$l$F$$$J$$$N$GCm0U!#(B
      Opts.out.println("eppOptions:");
      foreach (String s in eppOption){
	Opts.out.println("  "+ Tree.quoteStringContents(s));
      }
    }
    super.eppMain(eppOption.toArray());
  }

#+old
  public void eppMain(String[] args){
    // $BEO$5$l$?(B argv $B$O$=$N$^$^(B ss void main(String[]) $B$N0z?t$K$9$k!#(B

    MJLinker.mjMainArgs = args;

    Vec<String> eppOption
      = MJLinker.parseProperty(System.getProperty("mj.eppOption"));

    // -Dmj.selected $B$O!"(B java $B$N0z?t$G;XDj$5$l$k$b$N$H$9$k!#(B
    // dump mode $B$K$7$?$$>l9g$O!"(B -Dmj.dump=true $B$b(B java $B$G;XDj!#(B
    {
      String[] eppArgs = {
	"-global",
	"-type-check",
	"-no-code-emitting",
	"-plug-in",
	"mjc",
	"-plug-in",
	"jp.go.etl.epp.Collection",
      };
      foreach (String s in eppArgs){
	eppOption.push(s);
      }
    }

#+debug
    {
      // $B$^$@(B Opts.* $B$NCM$O@_Dj$5$l$F$$$J$$$N$GCm0U!#(B
      Opts.out.println("eppOptions:");
      foreach (String s in eppOption){
	Opts.out.println("  "+ Tree.quoteStringContents(s));
      }
    }
    super.eppMain(eppOption.toArray());
  }

  public void checkEppoutDirectory(){
    // Do nothing.
  }
}




//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------
// Java class $B7Q>5$N%F%9%HMQ!#(B

public class Test1 {
  public int publicField = 1;
  protected int protectedField = 2;
  int defaultField = 3;
  private int privateField = 4;

  public void publicMethod() {}
  protected final void protectedFinalMethod() {}
  protected void protectedMethod() {}
  void defaultMethod() {}
  private void privateMethod() {}

  static public int publicStaticField = 5;
  static protected int protectedStaticField = 6;
  static int defaultStaticField = 7;
  static private int privateStaticField = 8;

  static public void publicStaticMethod() {}
  static protected void protectedStaticMethod() {}
  static void defaultStaticMethod() {}
  static private void privateStaticMethod() {}
}

public interface Test2 {
  int interfaceField = 222;
  int interfaceMethod();
}

public interface Test3 {
  int interfaceField = 333;
  int interfaceMethod();
}

abstract public class Test4 {
  public abstract int nonAbstractMethod(int x);
  public abstract int abstractMethod(int x);
}
