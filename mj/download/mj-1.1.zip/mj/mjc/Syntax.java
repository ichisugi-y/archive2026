/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0

/*

AST format 
----------
MJCompilationUnit
	(mjCompilationUnit MJModule*)

MJModule
	(mjModule 
		MJMarks
		Name
		(mjModuleHeaderDeclarations MJModuleHeaderDeclaration*) 
		(mjTypeDeclarations MJTypeDeclaration*))

MJModuleHeaderDeclaration
	(complementingModules Name*)
	(extendingModules Name*)
	(usingModules Name*)
	(importingPackages NameOrNameAsterisc*)

NameOrNameAsterisc
	Name
	(nameAsterisc Name)

MJTypeDeclaration
	(mjClass
		MJMarks
		(modifiers Modifier*)
		MJClassKeyword
		MJName
		(extends Name*)
		(implements Name*)
		(classBody ClassBodyDeclaration*))
	(emptyTypeDeclaration)

MJClassKeyword
	class
	interface

ClassBodyDeclaration
	<original alternatives>
	MJField
	MJMethod
	MJConstructor

MJField
	VariableDeclaration
	// FQN is not allowed.
	// Currently MJMarks is ignored.

MJMethod
	(mjMethod 
		MJMarks
		(modifiers Modifier*)
		Type
		MJName
		(formalParameters FormalParameter*)
		(throws Name*)
		MethodBody)

MJConstructor
	(mjConstructor ...<same as mjMethod>...)

MJMarks
	(mjMarks)
	(mjMarks (id define))

Expression
	<original alternatives>
	(field1MJName MJFQN)
	(fieldExpMJName Expression MJFQN)
	(fieldLongMJName Name MJFQN)
	(invoke1MJName MJFQN argumentList)
	(invokeExpMJName Expression MJFQN argumentList)
	(invokeStaticMJName TypeName MJFQN argumentList)
	(original ArgumentList)

Type
	<original alternatives>
	MJFQN

MJName
	Identifier
	MJFQN

MJFQN
	(mjFQN Identifier Identifier*)



Intermidiate Nodes
------------------
Expression
	<original alternatives>
	(mjJavaFieldExp Expression
		(id declaringModule) (id classFullName) (id fieldSimpleName))
	(mjJavaProtectedFieldExp Expression
		(id declaringModule) (id classFullName) (id fieldSimpleName))
	(mjFieldExp Expression
		(id declaringModule) (id classFullName) (id fieldFullName))
	(mjJavaFieldStatic
		(id declaringModule) (id classFullName) (id fieldSimpleName))
	(mjFieldStatic
		(id declaringModule) (id classFullName) (id fieldFullName))
	(mjJavaInterfaceInvokeExp Expression
		(id classFullName) (id methodSimpleName)
		ArgumentList)
	(mjJavaProtectedInvokeExp Expression
		(id declaringModule) (id classFullName) (id methodSimpleName) 
		ArgumentList)
	(mjJavaInvokeExp Expression
		(id declaringModule) (id classFullName) (id methodSimpleName) 
		ArgumentList)
	(mjInvokeExp Expression
		(id declaringModule) (id classFullName) (id methodFullName) 
		ArgumentList)
	(mjInvokeStatic TypeName
		(id declaringModule) (id classFullName) (id methodFullName) 
		ArgumentList)
	(mjNew Name ArgumentList)
	(mjThis Name)
	(mjCast Type Expression)



FileSignature
-------------
MJFileSignature
	(mjFileSignature MJModuleSig*)

MJModuleSig
	(moduleSig
		MJInfo
		Name
		(mjModuleHeaderDeclarations MJModuleHeaderDeclaration*) 
		(mjTypeDeclarations MJClassSig*))

MJClassSig
	(mjClass MJInfo ...)

MJConstructorSig
	(mjConstructor MJInfo ...)

MJMethodSig
	(mjMethod MJInfo ...)

MJInfo
	(mjInfo MJInfoElem*)

MJInfoElem
	(id isDefinition)
	(id containsOriginal)



 */

package mjc;

import jp.go.etl.epp.SharpPlus.*;


defineNonTerminal(mjFQN, mjFQNOtherwise());

defineNonTerminal(mjModuleName, name()); // $B9THV9f>pJs$r$D$1$k$?$a!#(B

defineNonTerminal(mjTypeDeclaration, mjTypeDeclarationOtherwise());

defineNonTerminal(mjClassBodyDeclaration,
		  mjClassBodyDeclarationAfterMJMarks(mjMarks()));



SystemMixin Syntax {
  class Epp {

    //--------------------------------------------------
    // Parser extension

    define implement Tree mjFQNOtherwise(){
      match(:FQN);
      match(:"[");
      TreeVec tvec = new TreeVec();
      tvec.add(identifier());
      while (lookahead() == :".") {
	matchAny();
	tvec.add(identifier());
      }
      match(:"::");
      tvec.add(identifier());
      match(:"]");
      return new Tree(:mjFQN, tvec);
    }

    define implement Tree mjName(){
      if (lookahead() == :FQN){
	return mjFQN();
      } else {
	return identifier();
      }
    }

    define implement Tree mjMarks(){
      Token token = lookahead();
      if (token == :define){
	matchAny();
	return new Tree(:mjMarks, new Identifier((Symbol)token));
      } else {
	return new Tree(:mjMarks);
      }
    }
    
    extend Tree instanceCreation() {
      int p = inputPointer();
      match(:new);
      if (lookahead() == :FQN){
	// The function type() should not be called at here.
	// Consider the following case:
	//	new a[10][]
	Tree name = mjFQN();
	if (lookahead() == :"(") {
	  Tree args = argumentList();
	  if (lookahead() == :"{") {
	    return new Tree(:anonymousClass, name, args, classBody());
	  } else {
	    return new Tree(:new, name, args);
	  }
	} else if (lookahead() == :"[") {
	  return arrayCreation(name);
	} else {
	  throw error(""+ lookahead()+
		      " appeared after \"new Name\".");
	}
      } else {
	backtrack(p);
	return original();
      }
    }

    //--------------------------------------------------
    // Expressions

    extend Tree primaryTop() {
      if (lookahead() == :original) {
	matchAny();
	return new Tree(:original, argumentList());
      } else if (lookahead() == :FQN) {
	Tree fqn = mjFQN();
	if (lookahead() == :"("){
	  return `(invoke1MJName ,fqn ,(argumentList()));
	} else {
	  return `(field1MJName ,fqn);
	}
      } else {
	return original();
      }
    }

    extend Tree convertExpressionToType(Tree exp){
      Symbol tag = exp.tag();
      if (tag == :field1MJName){
	return exp.args()[0];
      } else {
	return original(exp);
      }
    }

    extend Tree primaryLeft(Tree tree) {
      if (lookahead() == :".") {
	int p = inputPointer();
	matchAny();
	if (lookahead() == :FQN){
	  Tree fqn = mjFQN();
	  if (lookahead() == :"("){
	    Tree args = argumentList();
	    return new Tree(:invokeExpMJName, tree, fqn, args);
	  } else {
	    return new Tree(:fieldExpMJName, tree, fqn);
	  }
	} else {
	  backtrack(p);
	  return original(tree);
	}
      } else {
	return original(tree);
      }
    }

    // This method is called in the following situations:
    //		a.b.c.new T...
    //		a.b.c.class
    //		a(args, ...)
    //		a
    //		a.b.c.x(args, ...)
    //		a.b.c.x
    // AND      a.b.c.FQN[...](args, ...)
    extend Tree primaryOtherwise() {
      int p = inputPointer();
      TreeVec tvec = new TreeVec();
      tvec.add(identifier());
      while (lookahead() == :"."){
	matchAny();
	if (lookahead() == :FQN){
	  Tree fqn = mjFQN();
	  if (lookahead() == :"("){
	    // MJ static method $B$OB8:_$7$J$$$H2>Dj!#(B
	    // a.b.c.FQN[...](...) $B$N(B a.b.c $B$O(B expression $B!#(B
	    return `(invokeExpMJName ,(makeInvokeExpFQNTarget(tvec))
		     ,fqn ,(argumentList()));
	  } else {
	    return `(fieldLongMJName (name ,@tvec) ,fqn);
	    //old return `(fieldExpMJName ,(makeInvokeExpFQNTarget(tvec)) ,fqn);
	  }
	}
	tvec.add(identifier());
      }
      backtrack(p);
      return original();
    }
    define Tree makeInvokeExpFQNTarget(TreeVec tvec){
      Tree[] args = tvec.toArray();
      if (args.length < 1){
	throw Epp.fatal("");
      } else if (args.length == 1){
	return args[0];
      } else {
	TreeVec butlast = new TreeVec();
	for (int i = 0; i < args.length - 1; i++){
	  butlast.add(args[i]);
	}
	return `(fieldLong (name ,butlast) ,(args[args.length - 1]));
      }
    }

    
    //--------------------------------------------------
    // mjClassBody

    define Tree mjClassBodyDeclarationAfterMJMarks(Tree mjMarks){
      return mjClassBodyDeclarationAfterModifiers(mjMarks, modifiers());
    }

    define Tree mjClassBodyDeclarationAfterModifiers(Tree mjMarks,
						     Tree modifiers){
      if (lookahead() == :class || lookahead() == :interface
	  || lookahead() == :delta){
	// An inner class at the ClassBody.
	throw error("MJ: Member class is not supported.");
      } else {
	int p = inputPointer();
	Token firstToken = matchAny();

	// NOTE: The following is not a constructor.
	// class Foo { Foo m(){...} }
	boolean isConstructor 
	  = (firstToken == Dynamic.get(:currentClassName) &&
	     lookahead() == :"(");

	backtrack(p);
	if (isConstructor){
	  return mjConstructorDeclaration(mjMarks, modifiers);
	} else {
	  return mjMethodOrFieldDeclaration(mjMarks, modifiers);
	}
      }
    }

    define Tree mjConstructorDeclaration(Tree mjMarks, Tree modifiers) {
      Tree result = new Tree(:name, new Identifier(:void)); // dummy value
      Tree name = identifier();
      match(:"(");
      Tree args = formalParameterList();
      match(:")");
      Tree thrs = throws();
      Tree body;
      if (lookahead() == :";"){
	// body is emptyStatement.
	body = statement();
      } else {
	body = block();
      }
      return new Tree(:mjConstructor,
		      mjMarks,
		      modifiers, result, name, args, thrs, body);
    }
    
    define Tree mjMethodOrFieldDeclaration(Tree mjMarks, Tree modifiers) {
      Tree result = type();
      int p = inputPointer();
      mjName();
      boolean isMethod = (lookahead() == :"(");
      backtrack(p);
      if (isMethod) {
	return mjMethodDeclaration(mjMarks, modifiers, result);
      } else {
	return mjFieldDeclaration(mjMarks, modifiers, result);
      }
    }
    
    define Tree mjMethodDeclaration(Tree mjMarks,
				    Tree modifiers, Tree result) {
      Tree name = mjName();
      match(:"(");
      Tree args = formalParameterList();
      match(:")");
      while(true) {
	if (lookahead() == :"[") {
	  matchAny();
	  match(:"]");
	  result = new Tree(:arrayOf, result);
	} else {
	  break;
	}
      }
      Tree thrs = throws();
      Tree body;
      if (lookahead() == :";"){
	// body is emptyStatement.
	body = statement();
      } else {
	body = block();
      }
      return new Tree(:mjMethod,
		      mjMarks,
		      modifiers, result, name, args, thrs, body);
    }

    define Tree mjFieldDeclaration(Tree mjMarks,
				   Tree modifiers, Tree type) {
      Tree decls = variableDeclarators();
      match(:";");
      //return new Tree(:mjField, mjMarks, modifiers, type, decls);
      return new Tree(:decl, modifiers, type, decls);
    }

    extend Tree mjClassBodyDeclarationTop(){
      if (lookahead() == :"#+" || lookahead() == :"#-"){
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  mjClassBodyDeclaration();
	  return new Tree(:emptyClassBodyDeclaration);
	} else  {
	  return mjClassBodyDeclaration();
	}
      } else if (lookahead() == :static) {
	int p = inputPointer();
	matchAny();
	boolean isStaticInitializer = (lookahead() == :"{");
	backtrack(p);
	if (isStaticInitializer) {
	  return staticInitializer();
	} else {
	  return original();
	}
      } else if (lookahead() == :";") {
	matchAny();
	// emptyClassBodyDeclaration seems to become valid since JLS2.0 .
	return new Tree(:emptyClassBodyDeclaration);
      } else {
	return original();
      }
    }

    define implement Tree mjClassBody() {
      match(:"{");
      if (Opts.nocatch){
	return mjClassBodyRest();
      } else {
	try {
	  return mjClassBodyRest();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught during parsing a ClassBody. Skipping until the end of the MJClassBody.");
	  int level = 1;
	  while (level > 0){
	    Token token = matchAny();
	    if (token == :"{") {
	      level++;
	    } else if (token == :"}"){
	      level--;
	    } else if (token.isLiteralToken() &&
		       token.literalTag() == :eof){
	      throw error("Unexpected EOF.");
	    }
	  }
	  return new Tree(:errorInClassBody);
	}
      }
    }

    define implement Tree mjClassBodyRest() {
      TreeVec tvec = new TreeVec();
      while (lookahead() != :"}") {
	tvec.add(mjClassBodyDeclaration());
      }
      match(:"}");
      return new Tree(:classBody, tvec.toArray());
    }
    
    extend void initMacroTable() {
      original();
      java.util.Hashtable macroTable
	= (java.util.Hashtable)Dynamic.get(:macroTable);
      defineMacro(:mjClassBody, (Macro)macroTable.get(:classBody));
    }


    //--------------------------------------------------
    // Module definition

    extend Tree mjTypeDeclarationTop() {
      if (lookahead() == :"#+" || lookahead() == :"#-"){
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  mjTypeDeclaration();
	  return new Tree(:emptyTypeDeclaration);
	} else  {
	  return mjTypeDeclaration();
	}
      } else if (lookahead() == :";") {
	matchAny();
	return new Tree(:emptyTypeDeclaration);
      } else {
	return original();
      }
    }

    define implement Tree mjTypeDeclarationOtherwise(){
      return mjTypeDeclarationAfterMJMarks(mjMarks());
    }

    define implement Tree mjTypeDeclarationAfterMJMarks(Tree mjMarks){
      return mjTypeDeclarationAfterModifiers(mjMarks, modifiers());
    }

    define implement Tree mjTypeDeclarationAfterModifiers(Tree mjMarks,
							  Tree modifiers){
      if (lookahead() == :delta){
	throw error("MJ: delta is obsolete keyword.");
      }

      if (lookahead() == :class || lookahead() == :interface){
	return mjClassDeclaration(mjMarks, modifiers);
      } else {
	throw error("MJ: mjTypeDeclaration is expected here.");
      }
    }
    
    define implement Tree mjClassDeclaration(Tree mjMarks, Tree modifiers){

      if (lookahead() != :class && lookahead() != :interface){
	throw error("Keyword \"class\" or \"interface\" is required here.");
      }
      Tree keyword = identifier();
      Tree name = mjName();
      Tree extds = extends();
      Tree implmnts = implements();
      Tree classBody;

      Symbol simpleName;
      if (name.tag() == :id){
	simpleName = name.idName();
      } else if (name.tag() == :mjFQN){
	Tree[] fqnArgs = name.args();
	simpleName = fqnArgs[fqnArgs.length - 1].idName();
      } else {
	//throw Epp.fatal("");
	// :CONCAT_ID
	simpleName = null;
      }

      Dynamic.bind(:currentClassName, simpleName);
      try {
	classBody = mjClassBody();
	return new Tree(:mjClass,
			mjMarks,
			modifiers, keyword, name, extds, implmnts,
			classBody);
      } finally {
	Dynamic.unbind();
      }
    }

    define Tree mjModuleHeaderDeclaration(){
      Token token = lookahead();
      if (token == :extends){
	matchAny();
	TreeVec tvec = new TreeVec();
	tvec.add(mjModuleName());
	while(lookahead() == :",") {
	  matchAny();
	  tvec.add(mjModuleName());
	}
	return new Tree(:extendingModules, tvec);
      } else if (token == :uses){
	matchAny();
	TreeVec tvec = new TreeVec();
	tvec.add(mjModuleName());
	while(lookahead() == :",") {
	  matchAny();
	  tvec.add(mjModuleName());
	}
	return new Tree(:usingModules, tvec);
      } else if (token == :complements){
	matchAny();
	TreeVec tvec = new TreeVec();
	tvec.add(mjModuleName());
	while(lookahead() == :",") {
	  matchAny();
	  tvec.add(mjModuleName());
	}
	return new Tree(:complementingModules, tvec);
      } else if (token == :import){
	throw error("MJ: Use \"imports\" instead of \"import\" .");
      } else if (token == :imports){
	matchAny();
	TreeVec tvec = new TreeVec();
	tvec.add(nameOrNameAsterisc());
	while(lookahead() == :",") {
	  matchAny();
	  tvec.add(nameOrNameAsterisc());
	}
	return new Tree(:importingPackages, tvec);
      } else {
	throw error("MJ: extends, uses, complements or imports "+
		    "is expected.");
      }
    }

    define Tree nameOrNameAsterisc(){
      Tree name = name();
      if (lookahead() == :".*") {
	matchAny();
	return new Tree(:nameAsterisc, name);
      } else {
	return name;
      }
    }

    define void mjTypeDeclarations(TreeVec decls){
      match(:"{");
      while(lookahead() != :"}") {
	if (lookahead() == :"{"){
	  mjTypeDeclarations(decls);
	} else {
	  decls.add(mjTypeDeclaration());
	}
      }
      match(:"}");
    }

    define void mjModule(TreeVec tvec){
      if (lookahead() == :";"){
	matchAny();
	// Do nothing
      } else if (lookahead() == :"{"){
	matchAny();
	while (lookahead() != :"}"){
	  mjModule(tvec);
	}
	match(:"}");
      } else if (lookahead() == :"#+" || lookahead() == :"#-"){
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  TreeVec tvec2 = new TreeVec();
	  mjModule(tvec2);
	  // Ignore the tvec2.
	} else {
	  mjModule(tvec);
	}
      } else {
	Tree mjMarks = mjMarks();
	match(:module);
	Tree name = mjModuleName();
	TreeVec headers = new TreeVec();
	while(lookahead() != :"{") {
	  Tree t = mjModuleHeaderDeclaration();
	  headers.add(t);
	}

	TreeVec decls = new TreeVec();
	mjTypeDeclarations(decls);

	tvec.add(new Tree(:mjModule,
			  mjMarks,
			  name,
			  new Tree(:mjModuleHeaderDeclarations, headers),
			  new Tree(:mjTypeDeclarations, decls)
			  ));

      }
    }

    // $B%(%i!<%j%+%P%j$r$b$&>/$7:Y$+$/$9$k!)(B
    define Tree mjCompilationUnit(){
      TreeVec tvec = new TreeVec();
      while(true) {
	if (lookahead().isLiteralToken() &&
	    lookahead().literalTag() == :eof){
	  break;
	} else {
	  mjModule(tvec);
	}
      }
      return new Tree(:mjCompilationUnit, tvec);
    }

    default Tree start() {
      return mjCompilationUnit();
    }

  }      
}
