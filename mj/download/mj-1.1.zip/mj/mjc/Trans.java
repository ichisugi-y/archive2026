/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0


package mjc;
import java.util.*;
import java.io.*;


SystemMixin Trans {
  class Epp {

    // initializationPass() $B$O(B global EPP $B$KBP$7$F$O8F$P$l$J$$$N$G!"(B
    // $B$3$3$G(B translatorTable $B$rL@<(E*$K=i4|2=$9$kI,MW$,$"$k!#(B
    extend void initGlobalProcessor() {
      original();
      Dynamic.bind(:translatorTable, new Hashtable());
      Dynamic.bind(:translatingTree, null);
      initTranslatorTable();
    }

    extend void initTranslatorTable () {
      original();
      defineTranslator(:mjJavaFieldExp,    new MJJavaFieldExpTranslator());
      defineTranslator(:mjJavaProtectedFieldExp,
		       new MJJavaFieldProtectedExpTranslator());
      defineTranslator(:mjFieldExp,    new MJFieldExpTranslator());
      defineTranslator(:mjJavaFieldStatic,new MJJavaFieldStaticTranslator());
      defineTranslator(:mjFieldStatic,    new MJFieldStaticTranslator());
      defineTranslator(:mjJavaInterfaceInvokeExp,
		       new MJJavaInterfaceInvokeExpTranslator());
      defineTranslator(:mjJavaInvokeExp,   new MJJavaInvokeExpTranslator());
      defineTranslator(:mjJavaProtectedInvokeExp,
		       new MJJavaProtectedInvokeExpTranslator());
      defineTranslator(:mjInvokeExp,   new MJInvokeExpTranslator());
      defineTranslator(:mjInvokeStatic,new MJInvokeStaticTranslator());

      defineTranslator(:fieldExpMJName,new MJFatalErrorTranslator());
      defineTranslator(:invokeExpMJName,new MJFatalErrorTranslator());
      defineTranslator(:original,      new MJOriginalTranslator());
      defineTranslator(:mjNew,         new MJNewTranslator());
      defineTranslator(:mjCast,                new DefaultTranslator());
      defineTranslator(:mjThis,                new MJThisTranslator());
      defineTranslator(:mjMarks,            new MJFatalErrorTranslator());
      defineTranslator(:mjField,               new MJFatalErrorTranslator());

      /*
      defineTranslator(:mjMethod,
			new MJConstructorAndMethodTranslator());
      defineTranslator(:mjConstructor,
			new MJConstructorAndMethodTranslator());
      defineTranslator(:mjClass,               new MJClassTranslator());
      defineTranslator(:mjTypeDeclarations,new VoidTranslator());
      //defineTranslator(:mjModuleHeaderDeclarations,new Void1Translator());
      defineTranslator(:mjModule,	new MJModuleTranslator());
      defineTranslator(:mjCompilationUnit,new DefaultTranslator());
      */

      extendTranslator(:name, new MJNameDecorator());

      // anonymous class $B$r%5%]!<%H$9$k$H$-$O!"$3$l$O$O$:$9!#(B
      //extendTranslator(:method, new MJFatalErrorTranslator());

      // $BG0$N$?$a!"$"$V$J$=$&$J$N$r%A%'%C%/!#(B
      extendTranslator(:class, new MJFatalErrorTranslator());
    }
  }
}



public class MJJavaInterfaceInvokeExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaInterfaceInvokeExp) throw MJC.fatal(""+ tree);
    // (mjJavaInterfaceInvokeExp Expression (id classFullName)
    //     (id methodSimpleName) ArgumentList)
    // $B!V(B classFullName $B$H$$$&(B Java interface $B$GDj5A$5$l!"(B
    //  MJ interface $B$,7Q>5$7$?!"(B  methodSimpleName $B$H$$$&%a%=%C%I$N8F$S=P$7!W(B
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol classFullName = args[1].idName();
    Tree methodSimpleName = args[2];
    Tree argumentList = args[3];
    return `(invokeExp
	     (mjCast
	      ,(new Identifier(classFullName))
	      ,(translateTree(exp)))
	     ,methodSimpleName
	     ,(translateTree(argumentList)));
  }
}

public class MJJavaInvokeExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaInvokeExp) throw MJC.fatal(""+ tree);
    // (mjJavaInvokeExp Expression (id declaringModule) (id classFullName)
    //     (id methodSimpleName) ArgumentList)
    // $B!V(BdeclaringModule $B$K$F(B MJ class $B$K7Q>5$5$l$?!"(B classFullName $B$H$$$&(B
    //   Java class $B$GDj5A$5$l$?!"(B methodSimpleName $B$H$$$&%a%=%C%I$N8F$S=P$7!W(B
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree methodSimpleName = args[3];
    Tree argumentList = args[4];

    Tree javaDeltaLiName =
      `(name ,(new Identifier(MJC.makeJavaDeltaLiName(declaringModule,
						      classFullName))));
    return `(invokeExp
	     (mjCast
	      ,javaDeltaLiName
	      ,(translateTree(exp)))
	     ,methodSimpleName
	     ,(translateTree(argumentList)));
  }
}

public class MJJavaProtectedInvokeExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaProtectedInvokeExp) throw MJC.fatal(""+ tree);
    // (mjJavaProtectedInvokeExp
    //      Expression (id declaringModule) (id classFullName)
    //     (id methodSimpleName) ArgumentList)
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree methodSimpleName = args[3];
    Tree argumentList = args[4];

    // Li $B$K$*$1$k(B this $B$N7?L>$r:n$j!"$=$l$K%-%c%9%H!#(B
    Symbol moduleName
      = ((MJModuleInfo)Dynamic.get(:currentModule)).moduleName;
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(moduleName,
						  typeOfThis.classInfo()
						  .getName()))));
    return `(invokeExp
	     (mjCast
	      ,deltaLiName
	      ,(translateTree(exp)))
	     ,methodSimpleName
	     ,(translateTree(argumentList)));
  }
}

public class MJInvokeExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjInvokeExp) throw MJC.fatal(""+ tree);
    // (mjInvokeExp Expression (id declaringModule) (id classFullName)
    //     (id methodFullName) ArgumentList)
    // $B!V(BdeclaringModule $B$K$FDj5A$5$l$?!"(B classFullName $B$r%?!<%2%C%H$H$9$k!"(B
    //   methodFullName $B$H$$$&L>A0$N%a%=%C%I$N8F$S=P$7!W(B
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree methodFullName = args[3];
    Tree argumentList = args[4];

    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(declaringModule,
						  classFullName))));
    return `(invokeExp
	     (mjCast
	      ,deltaLiName
	      ,(translateTree(exp)))
	     ,methodFullName
	     ,(translateTree(argumentList)));
  }
}


public class MJInvokeStaticTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjInvokeStatic) throw MJC.fatal(""+ tree);
    // (mjInvokeStatic TypeName (id declaringModule) (id classFullName)
    //     (id methodFullName) ArgumentList)
    // $B!V(BdeclaringModule $B$K$FDj5A$5$l$?!"(B classFullName $B$r%?!<%2%C%H$H$9$k!"(B
    //   methodFullName $B$H$$$&L>A0$N%a%=%C%I$N8F$S=P$7!W(B
    Tree[] args = tree.args();
    Tree typeName = args[0];  // Not used.
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree methodFullName = args[3];
    Tree argumentList = args[4];

    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(declaringModule,
						  classFullName))));
    return `(invokeStatic
	     ,deltaLiName
	     ,methodFullName
	     ,(translateTree(argumentList)));
  }
}

public class MJJavaFieldExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaFieldExp) throw MJC.fatal(""+ tree);
    // (mjJavaFieldExp Expression (id declaringModule) 
    //		(id classFullName) (id fieldSimpleName))
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree fieldSimpleName = args[3];

    Tree javaDeltaLiName =
      `(name ,(new Identifier(MJC.makeJavaDeltaLiName(declaringModule,
						      classFullName))));
    return `(fieldExp
	     (mjCast
	      ,javaDeltaLiName
	      ,(translateTree(exp)))
	     ,fieldSimpleName);
  }
}

public class MJJavaFieldProtectedExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaProtectedFieldExp) throw MJC.fatal(""+ tree);
    // (mjJavaProtectedFieldExp Expression (id declaringModule) 
    //		(id classFullName) (id fieldSimpleName))
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree fieldSimpleName = args[3];

    // Li $B$K$*$1$k(B this $B$N7?L>$r:n$k!#(B
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    Symbol moduleName
      = ((MJModuleInfo)Dynamic.get(:currentModule)).moduleName;
    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(moduleName,
						  typeOfThis.classInfo()
						  .getName()))));
    return `(fieldExp
	     (mjCast
	      ,deltaLiName
	      ,(translateTree(exp)))
	     ,fieldSimpleName);
  }
}

public class MJFieldExpTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjFieldExp) throw MJC.fatal(""+ tree);
    // (mjFieldExp Expression (id declaringModule) 
    //		(id classFullName) (id fieldFullName))
    Tree[] args = tree.args();
    Tree exp = args[0];
    Symbol declaringModule = args[1].idName();
    Symbol classFullName = args[2].idName();
    Tree fieldFullName = args[3];

    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(declaringModule,
						  classFullName))));
    return `(fieldExp
	     (mjCast
	      ,deltaLiName
	      ,(translateTree(exp)))
	     ,fieldFullName);
  }
}


public class MJJavaFieldStaticTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjJavaFieldStatic) throw MJC.fatal(""+ tree);
    // (mjJavaFieldStatic (id declaringModule) 
    //		(id classFullName) (id fieldSimpleName))
    Tree[] args = tree.args();
    Symbol declaringModule = args[0].idName();
    Symbol classFullName = args[1].idName();
    Tree fieldSimpleName = args[2];

#+old
    Tree javaDeltaLiName =
      `(name ,(new Identifier(MJC.makeJavaDeltaLiName(declaringModule,
						      classFullName))));
    return `(fieldStatic
	     //old ,javaDeltaLiName
	     ,(new Identifier(classFullName))
	     ,fieldSimpleName);
  }
}

public class MJFieldStaticTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjFieldStatic) throw MJC.fatal(""+ tree);
    // (mjFieldStatic (id declaringModule) 
    //		(id classFullName) (id fieldFullName))
    Tree[] args = tree.args();
    Symbol declaringModule = args[0].idName();
    Symbol classFullName = args[1].idName();
    Tree fieldFullName = args[2];

    Tree deltaLiName =
      `(name ,(new Identifier(MJC.makeDeltaLiName(declaringModule,
						  classFullName))));
    return `(fieldStatic
	     ,deltaLiName
	     ,fieldFullName);
  }
}


public class MJNewTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :mjNew) throw MJC.fatal(""+ tree);
    // (new Type ArgumentList)
    Tree[] args = tree.args();
    if (args[0].tag() != :name) throw MJC.fatal(""+ tree);
    Type type = args[0].type();
    if (type.tag() != :MJclass) throw MJC.fatal(""+ type);

    Symbol classFullName = ((MJClassType)type).mjClassInfo().getName();
    Symbol generatorClassName = MJC.makeGeneratorClassName(classFullName);
    return `(mjCast
	     ,(translateTree(args[0]))
	     (new (name ,(new Identifier(generatorClassName)))
	      ,(translateTree(args[1]))));
  }
}

public class MJThisTranslator extends Translator {
  public Tree call(Tree tree){
    Tree[] args = tree.args();
    return `(mjCast ,(translateTree(args[0])) (this));
  }
}

public class MJOriginalTranslator extends Translator {
  public Tree call(Tree tree){
    if (tree.tag() != :original) throw MJC.fatal("");
    // (original ArgumentList)
    MJMethodInfo mjMethodInfo
      = (MJMethodInfo)Dynamic.get(:currentMJMethodInfo);
    Tree methodFullName = MJC.fullNameToId(mjMethodInfo.moduleName,
					   mjMethodInfo.getName());

#+comment
    if (MJC.hasModifier(:static,
			`(modifiers ,@(mjMethodInfo.getModifiers())))){
      Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
      Symbol fullName = typeOfThis.classInfo().getName();
      Symbol dummyClassName = MJC.makeDummyClassName(:"", fullName);
      return `(invokeStatic
	       ,(new Identifier(dummyClassName))
	       ,methodFullName
	       ,(translateTree(tree.args()[0])));
    } else {
      return `(invokeSuper ,methodFullName
	       ,(translateTree(tree.args()[0])));
    }

    return `(invokeSuper ,methodFullName
	     ,(translateTree(tree.args()[0])));
  }
}

public class MJNameDecorator extends Translator {
  public Tree call(Tree tree){
    Tree[] args = tree.args();
    if (tree.tag() != :name) throw MJC.fatal("");
    // $B7?L>$O40A48BDjL>$KJQ49!#(B
    if (args.length == 1){
      Type type = tree.type();
      if (type.tag() == :class || type.tag() == :MJclass){
	Tree newTree
	  =  Tree.stringToNameTree(type.classInfo().getName().toString());
	// $B7?$rJ]B8$9$k!#(B addDummyMethod $B$G;2>H$5$l$k$N$G!#(B
	return tree.modifyArgs(newTree.args());
      } else {
	return tree;
      } 
    } else {
      return tree;
    }
  }
}

public class MJFatalErrorTranslator extends Translator {
  public Tree call(Tree tree){
      throw MJC.fatal(""+ tree);
  }
}


//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------


public class MJTranslator {

  // Global epp $B$N%$%s%9%?%s%9!#$"$A$3$A$+$i;H$o$l$k$N$G!"(B
  // $B%$%s%9%?%s%9JQ?t$K$7$F$*$/!#(B
  Obj epp = (Obj)Dynamic.get(:epp);

  //--------------------------------------------------
  // translationPass (LsLo $BJQ49%Q%9(B)$B$r8F$V!#(B

  public Tree translateTree(Tree tree){
    return Translator.translateTree(tree);
  }

  //--------------------------------------------------

  // $B%a%=%C%I$NL>A0$r!"40A48BDjL>$N(B prefix $B$D$-$NL>A0$KJQ99$9$k!#(B
  // $B$=$N$?$a$K!"(B :typeOfThis $B$+$i!"<+J,<+?H$N(B MJMethodInfo $B$r8!:w$7!"(B
  // $B$=$3$+$i40A48BDjL>$rF@$k!#(B
  public Tree translateMethod(Tree tree){
    if (tree.tag() != :mjMethod) throw MJC.fatal("");
    Tree[] args = tree.args();
    Tree modifiers = args[1];
    Tree retType = args[2];
    Tree mjName = args[3];
    Tree params = args[4];
    Tree thrs = args[5];
    Tree body = args[6];

    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);

    MJMethodInfo mjMethodInfo = MJC.findMethodInfo(typeOfThis,
						   mjName,
						   params);
    Tree methodFullName = MJC.fullNameToId(mjMethodInfo.moduleName,
					   mjMethodInfo.getName());

    Tree newBody;
    if (MJC.hasModifier(:abstract, modifiers)
	&& (! typeOfThis.classInfo().isInterface())){
      newBody = `(block ,(abstractErrorTree()));
    } else {
      // mjMethodInfo $B$O(B original $B8F$S=P$7$NJQ49$G;H$o$l$k!#(B
      Dynamic.bind(:currentMJMethodInfo, mjMethodInfo);
      try {
	newBody = translateTree(body);
      } finally {
	Dynamic.unbind();
      }
    }
    // throws $B$H$+%Q%i%a!<%?$N7?L>$b40A48BDjL>$K$9$k!#(B
    return `(method ,(beNonAbstract(bePublic(modifiers)))
	     ,(translateTree(retType))
	     ,methodFullName
	     ,(translateTree(params))
	     ,(translateTree(thrs))
	     ,newBody);
  }

  //--------------------------------------------------

  // field $B$NL>A0$r40A48BDjL>(B prefix $B$D$-$NL>A0$KJQ49!#(B
  public Tree translateField(Tree tree){
    if (tree.tag() != :decl) throw MJC.fatal("");
    Tree[] args = tree.args();
    Tree modifiers = args[0];
    Tree type = args[1];
    Tree[] vardecls = args[2].args();

    TreeVec tvec = new TreeVec();
    for (int i = 0; i < vardecls.length; i++){
      Symbol declTag = vardecls[i].tag();
      if (declTag == :id || declTag == :arrayVar){
	tvec.add(translateVardeclId(vardecls[i]));

      } else if (declTag == :varInit){
	Tree[] declArgs = vardecls[i].args();
	Tree[] newArgs = { translateVardeclId(declArgs[0]),
			   translateTree(declArgs[1]) };
	tvec.add(vardecls[i].modifyArgs(newArgs));

      } else {
	throw MJC.fatal(""+ vardecls[i]);
      }
    }
    Tree newVardecls = args[2].modifyArgs(tvec.toArray());

    // $B7?L>$b40A48BDjL>$K$9$k!#(B
    return `(decl ,(bePublic(modifiers))
	     ,(translateTree(type))
	     ,newVardecls);
  }

  public Tree translateVardeclId(Tree tree){
    Symbol tag = tree.tag();

    if (tag == :id){
      Symbol simpleName = tree.idName();
      Type typeOfThis = (Type)Dynamic.get(:typeOfThis);

      Vec<MJFieldInfo> vec
	= ((MJClassType)typeOfThis).mjClassInfo().getMJFields(simpleName)
	ifNull {
	  throw MJC.fatal(""+ simpleName);
	};
      Symbol moduleName
	= ((MJModuleInfo)Dynamic.get(:currentModule)).moduleName;
      MJFieldInfo mjFieldInfo;
    found: {
	foreach (MJFieldInfo f in vec){
	  if (f.moduleName == moduleName) {
	    mjFieldInfo = f;
	    break found;
	  }
	}
	throw MJC.fatal(""+ simpleName+ ":"+ vec);
      }

      return MJC.fullNameToId(mjFieldInfo.moduleName,
			      mjFieldInfo.getName());

    } else if (tag == :arrayVar){
      Tree[] newArgs = { translateVardeclId(tree.args()[0]) };
      return tree.modifyArgs(newArgs);

    } else {
      throw MJC.fatal(""+ tree);
    }      
  }

  


  //--------------------------------------------------

  public Tree bePublic(Tree modifiers){
    Tree[] args = modifiers.args();
    TreeVec tvec = new TreeVec();
    for (int i = 0; i < args.length; i++){
      Symbol modifier = args[i].idName();
      if (modifier == :public ||
	  modifier == :protected || modifier == :private){
	// Do nothing.
      } else {
	tvec.add(args[i]);
      }
    }
    tvec.add(new Identifier(:public));
    return `(modifiers ,@tvec);
  }

  public Tree beNonAbstract(Tree modifiers){
    Tree[] args = modifiers.args();
    TreeVec tvec = new TreeVec();
    for (int i = 0; i < args.length; i++){
      Symbol modifier = args[i].idName();
      if (modifier != :abstract){
	tvec.add(args[i]);
      }
    }
    return `(modifiers ,@tvec);
  }

  public Tree translateMember(Tree tree){
    Symbol tag = tree.tag();
    if (tag == :mjConstructor){
      throw MJC.fatal("constructor is not supported.");
    } else if (tag == :mjMethod){
      return translateMethod(tree);
    } else if (tag == :decl){
      return translateField(tree);
    } else if (tag == :emptyClassBodyDeclaration){
      return translateTree(tree);
    } else if (tag == :staticInitializer){
      return translateTree(tree);
    } else {
      throw MJC.fatal("Not supported. :"+ tag);
    }
  }

  // Collection plug-in $B$N$?$a$K(B :afterCurrentClassBodyDeclaration$B$r=hM}!#(B
  public Tree translateClassBody(Tree tree){
    if (tree.tag() != :classBody) throw MJC.fatal("");
    Tree[] args = tree.args();
    TreeVec tvec = new TreeVec();
    Dynamic.bind(:beginningOfClassBody, new TreeVec());
    Dynamic.bind(:beforeCurrentClassBodyDeclaration, null);
    Dynamic.bind(:afterCurrentClassBodyDeclaration, null);
    try{
      for (int i = 0; i < args.length; i++){
	Dynamic.set(:beforeCurrentClassBodyDeclaration, new TreeVec());
	Dynamic.set(:afterCurrentClassBodyDeclaration, new TreeVec());

        Tree earg = translateMember(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentClassBodyDeclaration));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentClassBodyDeclaration));
      }
      TreeVec beginning = (TreeVec)Dynamic.get(:beginningOfClassBody);
      beginning.addA(tvec);
      return tree.modifyArgs(beginning.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  //--------------------------------------------------

  // class, delta $B$NDj5A$r!"(B Li $B$KJQ49!#7k2L$O(B tvec $B$K$$$l$k!#(B
  // $B!J#1$D$N(B mj class $B$OJ#?t$N(B Li class $B$KJQ49$5$lF@$k$N$GCm0U!#!K(B
  public void translateDecls(Tree tree, TreeVec tvec){
    Symbol tag = tree.tag();
    if (tag == :mjClass){
      Tree[] args = tree.args();
      Tree mjMarks = args[0];
      Tree classKeyword = args[2];
      Tree mjName = args[3];
      Tree extds = args[4];
      Tree impls = args[5];
      Tree body = args[6];

      boolean isDefinition = (mjMarks.args().length > 0);

      Tree superTree;
      {
	MJClassType type = (MJClassType)tree.type();
	MJClassInfo classInfo = type.mjClassInfo();
	Type superclassType = classInfo.getSuperclass();
	if (superclassType == null){
	  // interface $B$N>l9g!#(B
	  superTree = `(extends);

	} else if (superclassType.tag() == :class){
	  Symbol moduleName
	    = ((MJModuleInfo)Dynamic.get(:currentModule)).moduleName;
	  Symbol classFullName = superclassType.classInfo().getName();
	  Symbol superName = MJC.makeJavaDeltaLiName(moduleName,
						     classFullName);
	  superTree = `(extends (name ,(new Identifier(superName))));

	} else if (superclassType.tag() == :MJclass){
	  superTree = translateTree(extds);

	} else {
	  throw MJC.fatal(""+ superclassType);
	}
      }

      if (isDefinition){
	// javac $B$rDL$9$?$a!"(B class $B$N>l9g$O(B abstract $B$K$7$F$*$/!#(B
	// verifier $B$rDL$9$?$a!"%j%s%/;~$K(B class $B$r$9$Y$F(B non-abstract $B$K$9$k!#(B
	//$B!J(B abstract method $B$,;D$C$F$$$F$b!"(B verifier $B$ODL$k!#(B
	//  $B$?$@$7$=$N(B abstract method $B$r8F$s$@;~E@$G%(%i!<$K$J$k!#!K(B
	tvec.add(`(class
		   ,(classKeyword.idName() == :interface ?
		     `(modifiers (id public)) :
		     `(modifiers (id public) (id abstract)))
		   ,classKeyword
		   ,(new Identifier(MJC.mjNameToSimpleName(mjName)))
		   ,superTree
		   (implements)// $B6u$K$7$F$*$/!#(B
		   //old ,(translateTree(impls))
		   (classBody)));
      } else {
	// classSig $B$r:n$k$H$-$K%A%'%C%/:Q$N$O$:!#(B
	if (classKeyword.idName() == :class &&
	    extds.args().length != 0) throw MJC.fatal(""+ tree);
      }

      Type typeOfThis = tree.type();
      if (classKeyword.idName() == :class){
	translateDelta(tree, typeOfThis, tvec);
      } else if (classKeyword.idName() == :interface){
	translateDeltaInterface(tree, typeOfThis, tvec);
      } else {
	throw MJC.fatal(""+ tree);
      }

      /*old
    } else if (tag == :block){
      // TypeDeclarations enclosed by block.
      foreach (Tree t in tree.args()){
	translateDecls(t, tvec);
      }
      */

    } else if (tag == :emptyTypeDeclaration){
      // Do nothing.

    } else {
      throw MJC.fatal("translateDecls:"+ tree);
    }
  }


  public void translateDelta(Tree tree, Type typeOfThis, TreeVec tvec){
    if (! (tree.tag() == :mjClass)) throw MJC.fatal(""+ tree);
    Tree[] args = tree.args();
    Tree mjName = args[3];
    Tree extds = args[4];
    Tree impls = args[5];
    Tree classBody = args[6];

    Symbol fullName = typeOfThis.classInfo().getName();
    Symbol dummyClassName = MJC.makeDummyClassName(:"", fullName);

    MJClassInfo mjClassInfo = ((MJClassType)typeOfThis).mjClassInfo();
      
    Tree deltaTree;
    // Delta class $B$NDI2C!#(B
    {
      Symbol deltaLiName = MJC.makeDeltaLiName(:"", fullName);
      Dynamic.bind(:typeOfThis, typeOfThis);
      try{
	// $B$3$NCM$O!"(B dummy super class $B$r:n$k$H$-$K$b;H$&!#(B
	deltaTree = `(class (modifiers (id public) (id abstract))
		      (id class) ,(new Identifier(deltaLiName))
		      (extends (name ,(new Identifier(dummyClassName))))
		      (implements)
		      ,(translateClassBody(classBody)));
	tvec.add(deltaTree);
      } finally {
	Dynamic.unbind();
      }      
    }

    // dummy super class $B$NDI2C!#(B
    {
      Tree[] deltaMembers = deltaTree.args()[5].args();
      TreeVec dummyMembers = new TreeVec();
      for (int i = 0; i < deltaMembers.length; i++){
	if (deltaMembers[i].tag() == :method){
	  addDummyMethod(deltaMembers[i], dummyMembers);
	} else {
	  // Currently, do nothing.
	}
      }


      {
	Symbol moduleName
	  = ((MJModuleInfo)Dynamic.get(:currentModule)).moduleName;
	foreach (Vec<MJMethodInfo> vec in mjClassInfo.methodTable.valueIter()){
	  foreach (MJMethodInfo m in vec){
	    // $B$3$N%/%i%9$,%-%c%9%H@h$H$J$k$h$&$J(B abstract $B%a%=%C%I$KBP$7!"(B
	    // abstractError $B%a%=%C%I$rDI2C$9$k!#(B
	    if (MJC.hasModifier(:abstract, `(modifiers ,@(m.getModifiers())))
		&&
		m.declaringModule == moduleName){
	      // cast $B@h$N%a%=%C%I$,B8:_$7$J$$$H(B javac $B$N%(%i!<$K$J$k$N$G!#(B
	      addAbstractErrorMethod(m, dummyMembers);
	    }
	  }
	}
      }

      Type superclassType = mjClassInfo.getSuperclass();

      // protected member $B$K%"%/%;%9$G$-$k$h$&$K!"(B
      // super class $B$r@_Dj!#(B
      Tree superTreeOfDummy;
      if (superclassType.tag() == :class){
	Symbol moduleName = ((MJClassType)typeOfThis).mjClassInfo().moduleName;
	Symbol superName = MJC.makeJavaDeltaLiName(moduleName,
						   superclassType.classInfo()
						   .getName());
	superTreeOfDummy = `(name ,(new Identifier(superName)));
      } else if (superclassType.tag() == :MJclass){
	superTreeOfDummy = superclassType.toTree();
      } else {
	throw MJC.fatal(""+ superclassType);
      }

      tvec.add(`(class (modifiers (id public) (id abstract))
		 (id class) ,(new Identifier(dummyClassName))
		 //old (extends ,(superclassType.toTree()))
		 (extends ,superTreeOfDummy)
		 (implements)
		 //old ,(translateTree(impls))
		 (classBody ,@(dummyMembers))));
    }
  }

  public void addAbstractErrorMethod(MJMethodInfo m, TreeVec tvec){
    Tree methodFullName = MJC.fullNameToId(m.moduleName,
					   m.getName());
    int i = 0;
    TreeVec vars = new TreeVec();
    TreeVec params = new TreeVec();
    foreach (Type pType in m.getParameterTypes()){
      Tree var = new Identifier(Symbol.intern("p"+ i++));
      vars.add(var);
      params.add(`(pdecl (modifiers) ,(pType.toTree()) ,var));
    }
    TreeVec thrs = new TreeVec();
    foreach (Type t in m.getExceptionTypes()){
      thrs.add(t.toTree());
    }

    tvec.add(`(method
	       (modifiers (id public))
	       ,(m.getReturnType().toTree())
	       ,methodFullName
	       (formalParameters ,@params)
	       (throws ,@thrs)
	       (block ,(abstractErrorTree()))
	       ));
  }

  public void translateDeltaInterface(Tree tree,
				      Type typeOfThis,
				      TreeVec tvec){
    if (! (tree.tag() == :mjClass)) throw MJC.fatal(""+ tree);
    Tree[] args = tree.args();
    Tree mjName = args[3];
    Tree extds = args[4];
    Tree impls = args[5];
    Tree classBody = args[6];

    Symbol fullName = typeOfThis.classInfo().getName();
      
    Tree deltaTree;
    // Delta class $B$NDI2C!#(B
    {
      Symbol deltaLiName = MJC.makeDeltaLiName(:"", fullName);
      Dynamic.bind(:typeOfThis, typeOfThis);
      try{
	deltaTree = `(class (modifiers (id public))
		      (id interface)
		      ,(new Identifier(deltaLiName))
		      ,(translateTree(extds))
		      ,(translateTree(impls))
		      ,(translateClassBody(classBody)));
	tvec.add(deltaTree);
      } finally {
	Dynamic.unbind();
      }      
    }
  }

  // $B%a%=%C%I$N(B tree $B$r8+$F!"(B dummy method $B$,I,MW$J$i:n$C$F(B tvec $B$KDI2C!#(B
  public void addDummyMethod(Tree tree, TreeVec tvec){
    if (containInvokeSuper(tree)){
      // throws $B@k8@$O$I$&$9$k!)$D$1$F$*$$$F$b$+$^$o$J$$!)(B
      Tree[] args = tree.args();
      Tree modifiers = args[0];
      Tree retType = args[1];
      Tree name = args[2];
      Tree params = args[3];
      Tree thrs = args[4];
      tvec.add(`(method ,modifiers
		 ,(translateTree(retType))
		 ,name
		 ,(translateTree(params))
		 ,(translateTree(thrs))
		 (block ,(returnCode(retType.type())))));
    } else {
      // Do nothing.
    }
  }

  public boolean containInvokeSuper(Tree tree){
    if (tree.tag() == :invokeSuper){
      return true;
    } else {
      Tree[] args = tree.args();
      for (int i = 0; i < args.length; i++){
	if (containInvokeSuper(args[i])){
	  return true;
	}
      }
    }
    return false;
  }

  public Tree returnCode(Type type){
    Symbol tag = type.tag();
    if (tag == :void){
      return `(return);
    } else if (tag == :double || tag == :float || tag == :long
	       || tag == :int || tag == :char || tag == :short
	       || tag == :byte){
      return `(returnWithExp (literalTree int "0"));
    } else if (tag == :boolean){
      return `(returnWithExp (id false));
    } else if (tag == :class || tag == :MJclass || tag == :arrayOf){
      return  `(returnWithExp (id null));
    } else {
      throw MJC.fatal("returnCode:"+ type);
    }
  }

  //--------------------------------------------------

  // _G_A $B$H$$$&%@%_!<$N%/%i%9$rDI2C!#(B
  void addGeneratorClass(Tree tree, TreeVec tvec){
    if (tree.tag() == :mjClass){
      if (MJC.isDefinition(tree.args()[0])){
	Symbol simpleClassName = MJC.mjNameToSimpleName(tree.args()[3]);
	Symbol generatorClassName
	  = MJC.makeGeneratorClassName(simpleClassName);
	tvec.add(`(class (modifiers (id public))
		   (id class) ,(new Identifier(generatorClassName))
		   (extends) (implements)
		   (classBody)));
      }
    }
  }

  //--------------------------------------------------

  void addJavaClassDelta(Tree[] decls, TreeVec tvec){

    // $B#1%b%8%e!<%kFb$G!"=EJ#$7$FF1$8L>A0$N(B java class delta $B$,(B
    //$B:n$i$l$J$$$h$&$K$9$k!#(B
    // key = class full name, value = dummy
    Table<Symbol, Symbol> javaClassDeltas = {};

    foreach (Tree tree in decls){
      // interface $B$N>l9g$O!)(B
      if (tree.tag() == :mjClass
	  && MJC.isDefinition(tree.args()[0])){
	Symbol classKeyword = tree.args()[2].idName();
	if (classKeyword == :class) {
	  // $B%N!<%I$+$i!"$3$N%/%i%9$N(B MJClassInfo $B$r<h$j=P$7!"(B
	  //super $B$r<h$j=P$9!#(B
	  MJClassType type = (MJClassType)tree.type();
	  MJClassInfo classInfo = type.mjClassInfo();
	  Type superclassType = classInfo.getSuperclass();
	  if (superclassType.tag() == :class){
	    Symbol classFullName = superclassType.classInfo().getName();
	    Symbol javaDeltaLiName
	      = MJC.makeJavaDeltaLiName(:"", classFullName);

	    Symbol javaClassDelta = javaClassDeltas.get(javaDeltaLiName)
	      ifNull {
	      // $BF1$8L>A0$G0JA0!"DI2C$5$l$F$$$J$$$N$G!"DI2C$9$k!#(B

	      // abstract member $B$NDI2C$OITMW$+$b!#(B
	      // $B!J$?$@$7$=$N$+$o$j!"(B (id abstract) $B$,I,MW!#!K(B
	      tvec.add(`(class (modifiers (id abstract) (id public))
			 (id class) ,(new Identifier(javaDeltaLiName))
			 (extends ,(superclassType.toTree())) (implements)
			 (classBody
			  //old ,@(makeJavaClassDeltaMembers(superclassType))
			  )));
	      javaClassDeltas.put(javaDeltaLiName, :dummu);
	    };
	  } else if (superclassType.tag() == :MJclass){
	    // Do nothing.
	  } else {
	    throw MJC.fatal(""+ superclassType);
	  }
	} else if (classKeyword == :interface) {
	  // Do nothing.
	} else {
	  throw MJC.fatal(""+ classKeyword);
	}
      }
    }
  }

  // protected member $B$K%"%/%;%9$G$-$k$h$&$K$J$C$?$7!"(B
  // abstractError $B$NDI2C$bITMW$K$J$C$?$O$:$J$N$G!"%3%a%s%H%"%&%H!#(B
  #+old
  // Java class $B$N(B protected class $B$r!"(B public $B$K(B override $B$7$J$*$9!#(B
  public TreeVec makeJavaClassDeltaMembers(Type classType){
    TreeVec tvec = new TreeVec();
    foreach (MethodInfo m in classType.classInfo().getMethods()){

      Tree modifiers = `(modifiers ,@(m.getModifiers()));

      // abstractError() $B$rDI2C$7$J$/$F$b!"(B abstract method $B$N$^$^$G$b(B
      //$BF0$/$h$&$K$J$C$?$H;W$&!#$G$b!"(B protected $B$J(B abstract method $B$r(B
      // public $B$K$9$k!"$H$$$&=hM}$O!"$I$N$_$AI,MW!#(B
      if (MJC.hasModifier(:abstract, modifiers) ||
	  (MJC.hasModifier(:protected, modifiers)
	   // protected final $B$O7Q>5$7$J$$!#(B
	   && ! MJC.hasModifier(:final, modifiers))){
	Tree name = new Identifier(m.getName());
	int i = 0;
	TreeVec vars = new TreeVec();
	TreeVec params = new TreeVec();
	foreach (Type pType in m.getParameterTypes()){
	  Tree var = new Identifier(Symbol.intern("p"+ i++));
	  vars.add(var);
	  params.add(`(pdecl (modifiers) ,(pType.toTree()) ,var));
	}
	TreeVec thrs = new TreeVec();
	foreach (Type t in m.getExceptionTypes()){
	  thrs.add(t.toTree());
	}
	Tree body;
	if (MJC.hasModifier(:abstract, modifiers)){
	  body = abstractErrorTree();
	} else if (MJC.hasModifier(:protected, modifiers)){
	  Tree invokeSuper = `(invokeSuper ,name (argumentList ,@vars));
	  body = (m.getReturnType().tag() == :void) ?
	    `(expressionStatement ,invokeSuper) :
	    `(returnWithExp ,invokeSuper);
	} else {
	  throw MJC.fatal(""+ modifiers);
	}

	tvec.add(`(method
		   (modifiers (id public))
		   ,(m.getReturnType().toTree())
		   ,name
		   (formalParameters ,@params)
		   (throws ,@thrs)
		   (block ,body)
		   ));
      }
    }
    return tvec;
  }

  public Tree abstractErrorTree(){
    return `(throw
	     (invokeLong (name (id mjc) (id Start))
	      (id abstractError)
	      (argumentList)));
  }

  //--------------------------------------------------

  public Tree makeMJModuleLoader(MJModuleInfo module){
    // $B#S<0$NJ8;zNs$K$7$F!"%/%i%9Dj5A$KKd$a9~$`!#(B
    Tree moduleNameTree = Tree.stringToNameTree(module.moduleName.toString());
    Tree mjPackageName = Tree.stringToNameTree(MJC.MJ_PACKAGE);

    if (Opts.printTree) {
      Opts.out.println("makeMJModuleLoader:");
      module.toTree().print();
    }

    String moduleSig = Tree.quoteStringContents(module.toTree().toString());
    return `(class (modifiers (id public)) (id class) (id MJModuleLoader)
	     (extends (name ,@(mjPackageName.args()) (id MJModuleLoader)))
	     (implements)
	     (classBody
	      (method (modifiers (id public)) (name (id String))
	       (id getModuleSig) (formalParameters) (throws)
	       (block
		(returnWithExp
		 ,(splitVeryLongStringLiteral(moduleSig)))))));
  }

  // In order to avoid the bug of javac 1.3.0 and jikes 1.13,
  //  very long string literal should be split.
  public Tree splitVeryLongStringLiteral(String str){
    // Each string constant should be encoded into UTF8
    //whose size is less than 65536.
    int max = 4096;		// I do not know if this size is small enough.
    if (str.length() < max){
      return new LiteralTree(:string, str);

    } else {
      // To avoid splitting of "\\t" into "\\" and "t" .
      if (str.charAt(max - 1) == '\\') max++;

      // The long string is translated into "str".concat("str".concat(...)) .
      // Actually, I should use StringBuffer.
      return `(invokeExp
	       ,(new LiteralTree(:string, str.substring(0, max)))
	       (id concat)
	       (argumentList
		,(splitVeryLongStringLiteral(str.substring(max)))));
    }
  }

  public Tree makeMJComplementaryModuleDescripor(MJModuleInfo module){
    String packageName = MJC.COMPLEMENTARY_PACKAGE_PREFIX+
      "."+ module.moduleName;
    Tree mjPackageName = Tree.stringToNameTree(MJC.MJ_PACKAGE);
    TreeVec tvec = new TreeVec();
    foreach (Symbol name in module.complementingModules){
      tvec.add(new LiteralTree(:string, name.toString()));
    }
    return `(compilationUnit
	     (packageDeclaration ,(Tree.stringToNameTree(packageName)))
	     (importDeclarations)
	     (typeDeclarations
	      (class (modifiers (id public)) (id class)
	       (id MJComplementaryModuleDescripor)
	       (extends (name ,@(mjPackageName.args())
			 (id MJComplementaryModuleDescripor)))
	       (implements)
	       (classBody
		(decl (modifiers (id public) (id static) (id final))
		 (name (id String))
		 (vardecls
		  (varInit
		   (id moduleName)
		   ,(new LiteralTree(:string, module.moduleName.toString()))
		   )))
		(decl (modifiers (id public) (id static) (id final))
		 (arrayOf (name (id String)))
		 (vardecls
		  (varInit
		   (id complements)
		   (arrayInitializer ,tvec))))))
	      ));
  }
  
  // module $B$r(B pacakge $B$KJQ49(B
  public Tree translateModule(Tree tree, TreeVec complementaryDescs){
    if (tree.tag() != :mjModule) throw MJC.fatal(""+ tree);
    Tree[] args = tree.args();
    Tree moduleName = args[1];
    // import $B$K$D$$$F$O!"$9$Y$F40A48BDjL>$KJQ49:Q$H$9$k!#(B
    Tree[] decls = flattenDecls(args[3].args());
    TreeVec tvec = new TreeVec();

    MJModuleInfo module
      = MJModuleTable.instance.get(Symbol.intern(moduleName.nameToString()));

    clearModuleDirectory(module);

    // MJComplementaryModuleDescripor $B$rI,MW$J$i$P@8@.!#(B
    if (module.complementingModules.size() > 0){
      complementaryDescs.add(makeMJComplementaryModuleDescripor(module));
    }

    // Used by translateVardeclId .
    // abstract method $B$N=hM}$r$9$k$H$-$K$b;H$&!#(B
    Dynamic.bind(:currentModule, module);
    try {
      addJavaClassDelta(decls, tvec);
      foreach (Tree decl in decls){
	translateDecls(decl, tvec);
	addGeneratorClass(decl, tvec);
      }
    } finally {
      Dynamic.unbind();
    }

    allModuleNames.push(module.moduleName);

    // $B!JG0$N$?$a!K:G8e$K(B MJModuleLoader $B$rDI2C!#(B
    tvec.add(makeMJModuleLoader(module));
    
    return `(compilationUnit
	     (packageDeclaration ,moduleName)
	     (importDeclarations)
	     (typeDeclarations ,tvec));
  }

  public Tree[] flattenDecls(Tree[] decls){
    TreeVec tvec = new TreeVec();
    foreach (Tree decl in decls){
      flattenDecls1(decl, tvec);
    }
    return tvec.toArray();
  }
  public void flattenDecls1(Tree tree, TreeVec tvec){
    if (tree.tag() == :block){
      foreach (Tree t in tree.args()){
	flattenDecls1(t, tvec);
      }
    } else {
      tvec.add(tree);
    }
  }

  //--------------------------------------------------
  // $B=PNO$9$k%G%#%l%/%H%j$K0JA0$N(B *.java $B$,;D$C$F$$$k$H!"(B
  //$B%3%s%Q%$%k%(%i!<$N860x$K$J$k$N$G!"A]=|$9$k!#(B
  public void clearModuleDirectory(MJModuleInfo module){
    clearPackageDirectory(module.moduleName.toString());
    clearPackageDirectory(MJC.COMPLEMENTARY_PACKAGE_PREFIX+
			  "."+ module.moduleName);
  }
  public void clearPackageDirectory(String packageName){
    File dir = new File("eppout"+ File.separatorChar+
			packageName.replace('.', File.separatorChar));
    //System.err.println(dir+ ":"+ dir.exists());
    if (! dir.exists()) return;
    if (! dir.isDirectory()){
      throw Epp.error("MJ: File "+ dir+ " already exists. Please remove it.");
    }
    // sub directory $B$OJ]B8$9$k!#(B *.java $B$H(B *.class $B$@$1A]=|!#(B
    String[] list = dir.list(new JavaFilenameFilter());
    foreach (String f in list){
      String path = dir.toString()+ File.separatorChar+ f;
      if (! Epp.isGeneratedFile(path)){
	throw Epp.error("MJ: File "+ path+ " is not a generated file. "+
			" mjc did not remove it.");
      }
      if (Opts.log) Opts.out.println("delete "+ path);
      new File(path).delete();
    }
  }

  //--------------------------------------------------

  public void emitAllFiles(Tree tree){
    Tree[] args = tree.args();
    Tree packageDecl = args[0];
    Tree[] packageElem = packageDecl.args()[0].args();
    Tree imports = args[1];
    Tree[] typeDecls = args[2].args();

    if (imports.args().length != 0) throw MJC.fatal(""+ tree);

    String packageDirName = "eppout";
    for (int i = 0; i < packageElem.length; i++){
      packageDirName = packageDirName+ File.separator+ packageElem[i].idName();
    }

    // $B$9$Y$F(B public class $B$H2>Dj!#(B
    for (int i = 0; i < typeDecls.length; i++){
      Symbol tag = typeDecls[i].tag();
      if (tag == :emptyTypeDeclaration){
	;			// Do nothing;

      } else if (tag == :class || tag == :interface){
	Symbol className = typeDecls[i].args()[2].idName();
	String outputFileName = packageDirName+
	  File.separator+ className+ ".java";
	Tree outputTree = `(compilationUnit
			    ,packageDecl
			    (importDeclarations)
			    (typeDeclarations ,(typeDecls[i])));

	//Opts.out.println("outputFileName:"+ outputFileName);
	epp!emit1(outputFileName, outputTree);

      } else {
	throw MJC.fatal("Unknown type declaration node:"+ tree);
      }
    }

  }

  // inputFileName $B$O%(%i!<%a%C%;!<%8;H$($k$h$&$K(B bind $B$9$k!#(B
  public void translateMJCompilationUnit(String inputFileName, Tree tree){

    // PlugIn.java $B$G%A%'%C%/$7$F$$$k!#(B
    //old checkTranslationOption();

    Tree[] args = tree.args();
    TreeVec complementaryDescs = new TreeVec();

    // emitterTable $B$r=i4|2=!#(B
    Dynamic.bind(:emitterTable, new Hashtable());
    epp!initEmitterTable();

    // for debug
    if (emitToSingleFile){
      Opts.newlineForReadability = true;	// $BFI$_$d$9$/!#(B
      TreeVec tvec = new TreeVec();
      for (int i = 0; i < args.length; i++){
	Tree aLiTree = translateModule(args[i], complementaryDescs);
	if (Opts.printTree) {
	  Opts.out.println();
	  Opts.out.println("Translated Li Tree:");
	  aLiTree.print(Opts.out);
	}
	tvec.add(aLiTree);
      }
      epp!emit1("eppout"+ File.separator+ inputFileName,
		// $BL5M}LpM}#1$D$N(B tree $B$K$7$F0l5$$K=PNO!#(B
		`(typeDeclarations ,tvec));
    } else {
      for (int i = 0; i < args.length; i++){
	Tree aLiTree = translateModule(args[i], complementaryDescs);
	if (Opts.printTree) {
	  Opts.out.println();
	  Opts.out.println("Translated Li Tree:");
	  aLiTree.print(Opts.out);
	}
	emitAllFiles(aLiTree);
      }
      foreach (Tree aLiTree in complementaryDescs.toArray()){
	emitAllFiles(aLiTree);
      }
    }
  }

  // mjc $B$N0z?t$K;XDj$5$l$?(B *.java $B$K4^$^$l$kA4$F$N%b%8%e!<%kL>$r(B
  //$B%U%!%$%k$K=PNO!#(B -Dmj.all=fileName $B$G;XDj!#;XDj$,$J$1$l$P=PNO$7$J$$!#(B
  public Vec<Symbol> allModuleNames = {};
  public void outputAllModuleNames(){
    PrintWriter out;
    try {
      String fileName = System.getProperty("mj.all");
      if (fileName == null) return;
      out = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));
      foreach (Symbol name in allModuleNames){
	out.println(name.toString());
      }
      out.close();
    } catch (IOException e){
      throw Epp.error("MJ:"+ e.getMessage());
    }
  }

  //  $B%G%P%C%0Cf$O(B true $B$K$9$k$H!"FI$_$d$9$$7A<0$G#1$D$N%U%!%$%k$K=PNO$5$l$k!#(B
  // $B$?$@$7!"=PNO7k2L$O(B javac $B$9$k$3$H$O$G$-$J$$!#(B
  //  $B$3$NJQ?t$O!"(B translateMJCompilationUnit $B$+$i$N$_;2>H$5$l$k!#(B
  public static boolean emitToSingleFile = false;

  public void checkTranslationOption(){
    String prop = System.getProperty("mj.emitToSingleFile");
    if (prop == null || prop.equals("false")){
      emitToSingleFile = false;
    } else if (prop.equals("true")){
      emitToSingleFile = true;
    } else {
      throw Epp.error("MJ: Illgal property value : "+
		      "mj.emitToSingleFile="+ prop);
    }
  }
}

public class JavaFilenameFilter implements FilenameFilter {
  public boolean accept(File dir, String name){
    return name.endsWith(".java") || name.endsWith(".class");
  }
}

