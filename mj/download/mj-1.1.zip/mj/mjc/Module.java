/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0


package mjc;
import java.util.*;


public class MJModuleTable {

  // Singleton object.
  // mjInitialization() $B$H$$$&%a%=%C%I$G=i4|2=$5$l$k!#(B
  public static MJModuleTable instance;

  public Table<Symbol, MJModuleInfo> mjModuleInfoTable = {};

  // $B!V%=!<%9$"$j%b%8%e!<%k!W$N(B Vec $B!#(B
  // $B%(%i!<%a%C%;!<%8$r%=!<%9%3!<%I$N=g$K=P$9$?$a$K!"(B
  //$B$3$N=g=x$K$7$?$,$C$F!"%b%8%e!<%k$N=i4|2=$r9T$&!#(B
  // $B=i4|2=$,=*$o$C$?$i!";H$o$l$k$3$H$O$J$$!#(B
  public Vec<MJModuleInfo> modulesWithSrc = {};

  // $B!V%=!<%9$J$7%b%8%e!<%k!W!#(B initPhase1 $B$K$*$$$F!"(B
  // class file $B$+$i(B on demand $B$G(B load $B$5$l$k!#(B
  public Vec<MJModuleInfo> modulesWithoutSrc = {};

  // Global epp $B$N%$%s%9%?%s%9!#$"$A$3$A$+$i;H$o$l$k$N$G!"(B
  // $B%$%s%9%?%s%9JQ?t$K$7$F$*$/!#(B
  Obj epp = (Obj)Dynamic.get(:epp);

  //--------------------------------------------------

  // CLASSPATH $B$NCf$+$i(B forName $B$G$=$N%b%8%e!<%k$r(B load $B$7$F%F!<%V%k$KEPO?!#(B
  // Phase1 $B$K$*$$$F!"(B extends $B$J$I$G;XDj$5$l$?(B module $B$,(B
  //$BB8:_$9$k$+$I$&$+$rAa$$CJ3,$G%A%'%C%/$9$k$?$a$N%a%=%C%I!#(B
  public NullOr<MJModuleInfo> loadAndAddModule(Symbol moduleName) {
    MJModuleInfo ret = mjModuleInfoTable.get(moduleName)
      ifNull {

	if (Opts.log) Opts.out.println("Start loadAndAddModule:"+ moduleName);

	String moduleSig;
	if (MJLinker.linkModeFlag){
	  // Find the MJModuleLoader from CLASSPATH.
	  // Define the found class at the current ClassLoader.
	  MJModuleLoader m;
	  try {
	    m = (MJModuleLoader)Class.forName(moduleName+
					      ".MJModuleLoader").newInstance();
	  } catch (ClassNotFoundException e){
	    //old throw NotFound.instance;
	    return null;
	  } catch (Exception e){
	    throw MJC.fatal("loadAndAddModule:"+ e+ ":"+ e.getMessage());
	  }
	  moduleSig = m.getModuleSig();

	} else {
	  // Find the MJModuleLoader from target classpath.
	  try {
	    Class c = TargetClassLoader.instance
	      .loadClass(moduleName+ ".MJModuleLoader", true);
	    Object obj = c.newInstance();
	    java.lang.reflect.Method m = c.getMethod("getModuleSig",
						     new Class[]{});
	    moduleSig = (String)m.invoke(obj, new Object[]{});

	  } catch (ClassNotFoundException e){
	    return null;
	  } catch (Exception e){
	    throw MJC.fatal("getModuleSig:"+ e+ ":"+ e.getMessage());
	  }
	}

	Tree moduleTree;
	Dynamic.bindInt(:lineNumberOfThisNode, -1);
	Dynamic.bindInt(:beginningPointOfThisNode, -1);
	Dynamic.bindInt(:endPointOfThisNode, -1);
	try {
	  moduleTree = Tree.readTree(moduleSig);
	} finally {
	  Dynamic.unbindInt();
	  Dynamic.unbindInt();
	  Dynamic.unbindInt();
	}
	MJModuleInfo module = MJModuleInfo.treeToMJModuleInfo(moduleTree);
	// load $B$5$l$?$i$9$0$K=i4|2=!#(B
	//initPhase2, initPhase4 $B$O!"%=!<%9$"$j!"%=!<%9$J$74^$a$F9T$o$l$k!#(B
	mjModuleInfoTable.put(moduleName, module);
	modulesWithoutSrc.push(module);

	module.initPhase1();
	if (Opts.log) Opts.out.println("End loadAndAddModule:"+ moduleName);
	return module;
      };
    return ret;
  }

  public MJModuleInfo get(Symbol moduleName) {
    MJModuleInfo ret = mjModuleInfoTable.get(moduleName)
      ifNull {
	throw MJC.fatal("MJModuleTable#get:"+ moduleName);
      };
    return ret;
  }

  //--------------------------------------------------
  // addModulesFromFileSignature $B$H(B initAllModules $B$O!"(B
  //globalProcessAfterMacroExpansionPass() $B$+$i8F$P$l$k!#(B

  // $B$^$:!"(B moduleTable $B$K!"%=!<%9%U%!%$%kCf$N$9$Y$F$N(B module $B$rEPO?!#(B
  public void addModulesFromFileSignature(String inputFileName,
					  EppInputStream eppInputStream,
					  Tree tree){
    if (tree.tag() != :mjFileSignature) throw Epp.fatal(""+ tree);
    foreach (Tree moduleSig in tree.args()) {
      if (moduleSig.tag() != :moduleSig) throw Epp.fatal(""+ tree);
      Tree moduleNameTree = moduleSig.args()[1];
      Symbol moduleName = Symbol.intern(moduleNameTree.nameToString());

      MJModuleInfo m = mjModuleInfoTable.get(moduleName)
	ifNull { m = null; };
      if (m != null) {
	Dynamic.bind(:inputFileName, inputFileName);
	Dynamic.bind(:eppInputStream, eppInputStream);
	try {
	  throw epp!errorAt(moduleNameTree, "MJ: Module "+ moduleName+
			    " already defined at the other place.");
	} finally {
	  Dynamic.unbind();
	  Dynamic.unbind();
	}
      }

      MJModuleInfo module = new MJModuleInfo(inputFileName,
					     eppInputStream,
					     moduleSig);
      mjModuleInfoTable.put(moduleName, module);
      modulesWithSrc.push(module);
    }
  }

  // MJLinker $B$,(B bottom module $B$N(B moduleSig $B$r:n$C$F!"(B
  // $B$3$N%a%=%C%I$r8F$S=P$9!#(B
  // $B%(%i!<$,@dBP$K5/$-$J$$$h$&$K!"$9$Y$F$N(B super module $B$,B8:_$9$k$3$H$r(B
  //$B8F$S=P$7B&$G3NG'$7$F$+$i$3$N%a%=%C%I$r8F$S=P$5$J$1$l$P$J$i$J$$!#(B
  public void addHandMadeModule(Symbol moduleName, Tree moduleTree){
    MJModuleInfo module = MJModuleInfo.treeToMJModuleInfo(moduleTree);
    mjModuleInfoTable.put(moduleName, module);
    modulesWithoutSrc.push(module);
    module.initPhase1();
  }

  // moduleTable $B$K(B module $B$,$9$Y$F$=$m$C$?$i!"$=$l$r;H$C$F=i4|@_Dj$r$9$k!#(B
  public void initAllModules(){

    // $B!V%=!<%9$"$j%b%8%e!<%k!W$KBP$7!"(B initPhase1 $B$r<B9T!#(B
    // $B!V%=!<%9$J$7%b%8%e!<%k!W$O!"I,MW$K1~$8$F(B loadAndAddModule $B$G(B
    //$B%/%i%9%U%!%$%k$+$iFI$_9~$^$l!"$=$3$G(B initPhase1 $B$5$l$k!#(B
    foreach (MJModuleInfo module in modulesWithSrc){
      // $B$?$a$7$K%(%i!<%j%+%P%j$rF~$l$F$_$k!#(B
      // EppTypeError $B$b5/$-$k$+$bCN$l$J$$!#(B
      if (Opts.nocatch){
	module.initPhase1();
      } else {
	try {
	  module.initPhase1();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught by initPhase1 :"+
					 e.getMessage());
	}
      }
    }
    Epp.checkErrorCounter();

    foreach (MJModuleInfo module in modulesWithSrc){
      // $B$3$3$G$b(B loop $B8!=P$N%(%i!<$,5/$-$k$O$:!#(B
      module.initPhase2();
    }
    foreach (MJModuleInfo module in modulesWithoutSrc){
      module.initPhase2();
    }
    Epp.checkErrorCounter();

    foreach (MJModuleInfo module in modulesWithSrc){
      module.initPhase3();
    }
    foreach (MJModuleInfo module in modulesWithoutSrc){
      module.initPhase3();
    }
    Epp.checkErrorCounter();

    foreach (MJModuleInfo module in modulesWithSrc){
      if (Opts.nocatch){
	module.initPhase4();
      } else {
	try {
	  module.initPhase4();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught by initPhase4 :"+
					 e.getMessage());
	}
      }
    }
    foreach (MJModuleInfo module in modulesWithoutSrc){
      module.initPhase4();
    }
    Epp.checkErrorCounter();
  }
}



public class TargetClassLoader extends ClassLoader{
  public static TargetClassLoader instance
    = new TargetClassLoader();
  public Hashtable classCache = new Hashtable();
  public synchronized Class loadClass(String name, boolean resolve)
    throws ClassNotFoundException {
    if (Opts.log){
      Opts.out.println("TargetClassLoader : name = "+ name+ ", resolve = "+ resolve);
    }
    Class c = (Class)classCache.get(name);
    if (c == null){
      if (name.startsWith("java.")){
	// Only java.lang.Object and String are required to be loaded.
	try {
	  c = findSystemClass(name);
	} catch (ClassNotFoundException e){
	  throw MJC.fatal(e.getMessage());
	}
      } else {
	java.io.InputStream in
	  = JavaClassAPIClassFileReader.instance.findClassFile(name);

	if (in == null) throw new ClassNotFoundException(name);

	// Read the classfile into buf.
	byte[] buf = new byte[50000];
	int size = 0;
	try {
	  while(true){
	    int ret = in.read(buf, size, buf.length - size);
	    if (ret == -1) break;
	    size = size + ret;
	    if (size > buf.length / 2){
	      byte[] newBuf = new byte[buf.length * 2];
	      for (int i = 0; i < size; i++){
		newBuf[i] = buf[i];
	      }
	      buf = newBuf;
	    }
	  }
	  in.close();
	} catch (java.io.IOException e) {
	  throw MJC.fatal(e.getMessage());
	}
	c = defineClass(null, buf, 0, size);
      }
      classCache.put(name, c);
    }

    if (Opts.log) Opts.out.println("TargetClassLoader : found "+ c.getName());

    if (resolve) resolveClass(c);
    return c;
  }
}


//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------
// MJModuleInfo


public class MJModuleInfo {
  public Symbol moduleName;
  public Vec<Symbol> complementingModules;	// Vec of module names.
  public Vec<Symbol> extendingModules;		// Vec of module names.
  public Vec<Symbol> usingModules;		// Vec of module names.
  public Table<Symbol, MJClassData> mjClassDataTable = {};

  public Vec<MJClassType> definedMJClassType;
  public Vec<Tree> declaredImports;
  public Vec<Tree> definedMacros = {}; // Macros defined at this module.
  public Table<Symbol, Tree> macroTable = {}; // All available macros.

  //old public Vec<MJModuleInfo> linearizedExtendingModules;
  public Vec<MJModuleInfo> linearizedUsingModules;
  Obj epp = (Obj)Dynamic.get(:epp);

  public String inputFileName;
  public EppInputStream eppInputStream;
  public Tree moduleSig;
  public Vec<Tree> macroExpandedTypeDecls;

  // Table of class simple name to Vec of class full name .
  Table<Symbol, Vec<Symbol> > usingTypeNameTable = {};
  GlobalTypeNameTable globalTypeNameTable;

  // Table of class full name to MJClassType .
  Table<Symbol, MJClassType> mjClassTypeTable = {};

  public MJModuleInfo(String inputFileName,
			EppInputStream eppInputStream,
			Tree moduleSig){
    this.inputFileName = inputFileName;
    this.eppInputStream = eppInputStream;
    this.moduleSig = moduleSig;
  }

  //--------------------------------------------------
  //--------------------------------------------------
  //--------------------------------------------------
  // initialization

  public void initPhase1(){
    Dynamic.bind(:inputFileName, inputFileName);
    Dynamic.bind(:eppInputStream, eppInputStream);
    try {
      if (moduleSig.tag() != :moduleSig) throw MJC.fatal("");
      Tree[] args = moduleSig.args();
      this.moduleName = Symbol.intern(args[1].nameToString());
      Tree[] headers = args[2].args();
      Tree[] typeDecls = args[3].args();

      if (moduleName == MJC.JAVA_MODULE_NAME){
	throw epp!errorAt(args[1], "MJ: The module name \""+ moduleName+
			  "\" can not be used.");
      }

      complementingModules = new Vec<Symbol>();
      extendingModules = new Vec<Symbol>();
      usingModules = new Vec<Symbol>();
      declaredImports = new Vec<Tree>();

      foreach (Tree header in headers){
	Symbol tag = header.tag();
	if (tag == :extendingModules ||
	    tag == :usingModules ||
	    tag == :complementingModules){
	  foreach (Tree name in header.args()){
	    Symbol mName = Symbol.intern(name.nameToString());
	    MJModuleInfo info = MJModuleTable.instance.loadAndAddModule(mName)
	      ifNull {
		throw epp!errorAt(name, "MJ: Module "+ mName+ " not found.");
	      };
	    if (tag == :complementingModules){
	      complementingModules.push(mName);
	      extendingModules.push(mName);
	      usingModules.push(mName);

	    } else if (tag == :extendingModules){
	      extendingModules.push(mName);
	      usingModules.push(mName);

	    } else if (tag == :usingModules) {
	      usingModules.push(mName);

	    } else {
	      throw MJC.fatal(""+ tag);
	    }
	  }

	} else if (tag == :importingPackages){
	  declaredImports.push(header);

	} else {
	  throw MJC.fatal(""+ header);
	}
      }
      {
	foreach (Tree typeDecl in typeDecls){
	  if (typeDecl.tag() == :defmacro) {
	    definedMacros.push(typeDecl);
	  }
	}
      }
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  public void initPhase2(){
    Dynamic.bind(:inputFileName, inputFileName);
    Dynamic.bind(:eppInputStream, eppInputStream);
    try {
      // $B%b%8%e!<%k$N%0%i%U9=B$$O(B initPhase1 $B$G3NDj$7$?$N$G!"$=$l$rMQ$$$F(B
      // extendingModules $B$H(B usingModules $B$r(B linearize $B!#(B
      linearizeUsingModules();

      // macroTable $B$N@_Dj!#(B
      foreach (MJModuleInfo module in linearizedUsingModules){
	foreach (Tree macro in module.definedMacros){
	  macroTable.put(macro.args()[0].idName(), macro);
	}
      }

      // typeDecls $B$r%^%/%mE83+!#(B
      macroExpandedTypeDecls = new Vec<Tree>();
      macroExpandTypeDecls(moduleSig.args()[3].args(),
			   macroExpandedTypeDecls);
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  public void initPhase3(){
    // $BE,59%^%/%mE83+$7$J$,$i$3$N%b%8%e!<%k$,Dj5A$9$k7?L>$N%F!<%V%k$r:n@.!#(B
    Dynamic.bind(:inputFileName, inputFileName);
    Dynamic.bind(:eppInputStream, eppInputStream);
    try {
      {
	Table<Symbol, Symbol> types = {};
	foreach (Tree typeDecl in macroExpandedTypeDecls){
	  if (typeDecl.tag() == :mjClass) {

	    Tree mjInfo = typeDecl.args()[0];

	    if (MJC.isDefinition(mjInfo)){
	      // $B=EJ#Dj5A%A%'%C%/(B
	      // $B!J(Bdelta $B$,=EJ#$7$FDj5A$5$l$F$$$k>l9g$O$I$3$G%A%'%C%/$9$k!)!K(B
	      Symbol simpleName = MJC.mjNameToSimpleName(typeDecl.args()[3]);
	      if (! types.containsKey(simpleName)){
		types.put(simpleName, simpleName);
		continue;
	      }
	      throw epp!errorAt(typeDecl, "MJ: Type "+ simpleName+
				" already defined at the same module.");
	    }
	  } else if (typeDecl.tag() == :emptyTypeDeclaration) {
	    // Do nothing.
	  } else {
	    throw MJC.fatal(""+ typeDecl);
	  }
	}
	definedMJClassType = new Vec<MJClassType>();
	foreach (Symbol simpleName in types.keyIter()){
	  Symbol fullName = Symbol.intern(moduleName+ "."+ simpleName);
	  definedMJClassType.push(new MJClassType(fullName,
						  simpleName,
						  moduleName,
						  this));
	}
      }
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  public void macroExpandTypeDecls(Tree[] typeDecls, Vec<Tree> vec){
    foreach (Tree tree in typeDecls){
      macroExpandTypeDecl(tree, vec);
    }
  }
  public void macroExpandTypeDecl(Tree tree, Vec<Tree> vec){
    Symbol tag = tree.tag();
    if (tag == :block){
      macroExpandTypeDecls(tree.args(), vec);

    } else if (tag == :usemacro){
      //
      Symbol macroName = tree.args()[0].idName();
      Tree defmacro = macroTable.get(macroName)
	ifNull {
	  throw epp!errorAt(tree, "Undefined macro: "+ macroName);
	};
      macroExpandTypeDecl(macroExpand(tree, defmacro), vec);

    } else if (tag == :mjClass){
      vec.push(epp!normalizeMJClass(tree));

    } else if (tag == :defmacro || tag == :emptyTypeDeclaration){
      // Do nothing.
    } else {
      throw MJC.fatal(""+ tree);
    }
  }
  // $B$H$j$"$($:$3$3$GE83+=hM}$r<BAu!#(B
  public static Tree macroExpand(Tree usemacro, Tree defmacro){
    Tree[] fparams = defmacro.args()[1].args();
    Tree[] aparams = usemacro.args()[1].args();
    if (fparams.length != aparams.length){
      Obj epp = (Obj)Dynamic.get(:epp);
      throw epp!errorAt(usemacro, "Illegal number of macro arguments.");
    }
    Table<Symbol, Tree> paramTable = {};
    foreach (int index, Tree fparam in fparams){
      paramTable.put(fparam.idName(), aparams[index]);
    }
    return macroExpandTree(defmacro.args()[2], paramTable, usemacro);
  }
  public static Tree macroExpandTree(Tree tree,
				     Table<Symbol, Tree> paramTable,
				     Tree oldTree){
    Symbol tag = tree.tag();
    Tree[] args = tree.args();
    if (tag == :id){
      Tree ret = paramTable.get(tree.idName())
	ifNull { ret = tree; };
      return ret;

    } else if (tag == :CONCAT_ID){
      // $B:81&$r%^%/%mE83+$7$F!"7k9g!#(B
      Tree id1 = macroExpandTree(args[0], paramTable, oldTree);
      Tree id2 = macroExpandTree(args[1], paramTable, oldTree);
      if (id1.tag() != :id || id2.tag() != :id){
	Obj epp = (Obj)Dynamic.get(:epp);
	throw epp!errorAt(tree, "CONCAT_ID: Not identifier: "+ id1+ id2);
      }
      // $B;DG0$J$,$i0LCV>pJs$rF~$l$i$l$J$$!#(B
      return new Identifier(Symbol.intern(""+ id1.idName()+ id2.idName()));

    } else if (tag == :CAPITALIZE_ID){
      Tree id = macroExpandTree(args[0], paramTable, oldTree);
      if (id.tag() != :id){
	Obj epp = (Obj)Dynamic.get(:epp);
	throw epp!errorAt(tree, "CAPITALIZE_ID: Not identifier: "+ id);
      }
      String s = id.idName().toString();
      if (s.length() == 0) return tree;
      return new Identifier(Symbol.intern(Character.toUpperCase(s.charAt(0))+
					  s.substring(1)));
      

    } else if (tag == :literalTree){
      return tree;
    } else {
      Tree[] newArgs = new Tree[args.length];
      foreach (int index, Tree t in args){
	newArgs[index] = macroExpandTree(t, paramTable, oldTree);
      }
      return TypeChecker.remakeTree(new Tree(tag, newArgs), oldTree);
    }
  }

  public void initPhase4(){
    Dynamic.bind(:inputFileName, inputFileName);
    Dynamic.bind(:eppInputStream, eppInputStream);
    try {
      // linearizeUsingModules $B$r;H$C$F!"(B globalTypeNameTable $B$r@_Dj!#(B
      Vec<Tree> allImports = {};
      // linearizeUsingModules $B$K$O!"<+J,<+?H$bF~$C$F$$$k$b$N$H$9$k!#(B
      foreach (MJModuleInfo module in linearizedUsingModules){
	foreach (Tree importingPackages in module.declaredImports){
	  foreach (Tree name in importingPackages.args()){
	    if (name.tag() == :name){
	      allImports.push(`(importSingle ,name));
	    } else if (name.tag() == :nameAsterisc) {
	      allImports.push(`(importOnDemand ,(name.args()[0])));
	    } else {
	      throw MJC.fatal(""+ moduleSig);
	    }
	  }
	}
      }
      globalTypeNameTable
	= new GlobalTypeNameTable(`(fileSignature
				    (packageDeclaration
				     (name (id _dummy_pacakge_name)))
				    (importDeclarations
				     ,(allImports.toArray()))
				    (typeDeclarations)));


      // $B$3$N%b%8%e!<%k$+$i8+$($kA4$F$N(B MJClassType $B$r!"(B
      //  mjClassTypeTable $B$H!"(B usingTypeNameTable $B$KEPO?!#(B
      foreach (MJModuleInfo module in linearizedUsingModules){
	foreach (MJClassType t in module.definedMJClassType){
	  mjClassTypeTable.put(t.getName(), t);

	  Vec<Symbol> fullNames = usingTypeNameTable.get(t.getSimpleName())
	    ifNull{
	      fullNames = new Vec<Symbol>();
	      usingTypeNameTable.put(t.getSimpleName(), fullNames);
	    };
	  fullNames.push(t.getName());
	}
      }

      // $B$3$l$GL>A04D6-$,40@.$7$?$N$G!"$=$N4D6-$N85$G!"(B
      // $B$3$N%b%8%e!<%k$,Dj5A$9$k%/%i%9$N(B MJClassData $B$r:n$C$F%F!<%V%k$KEPO?!#(B
      Dynamic.bind(:currentModule, this);
      try {
	initMJClassDataTable();
      } finally {
	Dynamic.unbind();
      }
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  //--------------------------------------------------
  // monotonic linearization

  public final int TRAVERSING = -998;
  public final int NOT_DETERMINED = -999;
  public int level = NOT_DETERMINED;

  public void linearizeUsingModules(){
    Table<Symbol, MJModuleInfo> allModules = {};
    decideAllModules(this, allModules);
    foreach (MJModuleInfo m in allModules.valueIter()){
      decideLevel(m);
    }
    Vec<Vec<MJModuleInfo> > levelVec = makeLevelVec(allModules);

    Vec<MJModuleInfo> linearizedModules = {};
    foreach (Vec<MJModuleInfo> vec in levelVec){
      foreach (MJModuleInfo m in vec){
	linearizedModules.push(m);
      }
    }
    linearizedUsingModules = linearizedModules;
    if (Opts.log){
      Opts.out.println("linearizedUsingModules for "+ moduleName+ " :");
      foreach (MJModuleInfo m in linearizedUsingModules){
	Opts.out.println("  "+ m.moduleName);
      }
    }
  }

  //  uses $B4X78$N(B transitive closure $B$r5a$a$k!#(B
  public void decideAllModules(MJModuleInfo module,
			       Table<Symbol, MJModuleInfo> allModules){
    if (allModules.containsKey(module.moduleName)) return;
    allModules.put(module.moduleName, module);
    foreach (Symbol name in module.usingModules){
      MJModuleInfo m = MJModuleTable.instance.get(name);
      decideAllModules(m, allModules);
    }
  }

  // module $B$N(B level $B$r7hDj$9$k!#(B
  public void decideLevel(MJModuleInfo module){
    if (module.level >= 0){
      // Level has already detemined. Do nothing.
      return;
    } else if (module.level == module.TRAVERSING){
      throw new Error("Cycle: "+ module.moduleName);
    } else {
      module.level = module.TRAVERSING;
      int level = -1;
      foreach (Symbol name in module.extendingModules){
	MJModuleInfo s = MJModuleTable.instance.get(name);
	// $B:F5"8F$S=P$7(B
	decideLevel(s);
	if (s.level > level) level = s.level;
      }
      module.level = level + 1;
    }
  }

  //  levelVec $B$r:n$k!#(B
  public Vec<Vec<MJModuleInfo> >
    makeLevelVec(Table<Symbol, MJModuleInfo> allModules){
    Vec<Vec<MJModuleInfo> > levelVec = {};
    foreach (MJModuleInfo m1 in allModules.valueIter()){
      if (m1.level < 0) throw MJC.fatal(""+ m1.moduleName+
					    ":"+ m1.level);
      foreach (int i in m1.level + 1 - levelVec.size()){
	levelVec.push(new Vec<MJModuleInfo>());
      }
      Vec<MJModuleInfo> vec = levelVec.get(m1.level);
      // vec $B$KA^F~!#$?$@$7F10l$JL>A0$N>l9g$OA^F~$7$J$$!#(B
    done:{
	foreach (int index, MJModuleInfo m2 in vec){
	  if (m1.moduleName == m2.moduleName) break done;
	  if (m1.moduleName.toString().compareTo(m2.moduleName.toString())
	      < 0){
	    // .....m.........
	    //      ^ index   ^ p = vec.size()
	    int p = vec.size();
	    vec.push(null);
	    while (index < p){
	      vec.put(p, vec.get(p - 1));
	      p--;
	    }
	    vec.put(index, m1);
	    break done;
	  }
	}
	vec.push(m1);
      }
    }
    return levelVec;
  }



  //--------------------------------------------------

  public void initMJClassDataTable(){
    if (moduleSig.tag() != :moduleSig) throw MJC.fatal("");
    foreach (Tree typeDecl in macroExpandedTypeDecls){
      if (typeDecl.tag() == :mjClass){
	Tree mjName = typeDecl.args()[3];
	Tree name = MJC.mjNameToName(mjName);
	// ambiguous $B$J>l9g$O!"(B getType $B$NCf$G%(%i!<$K$J$k!#(B
	try {
	  Type mjClassType = getType(name)
	    ifNull{
	      if (! MJC.isDefinition(typeDecl.args()[0])){
		throw epp!errorAt(mjName,
				  "MJ: No class definition of "+
				  name.nameToString()+ " found.  "+
				  "Probably, missing \"define\" for it, "+
				  "missing \"extends\" declaration or "+
				  "misspelling.");
	      } else {
		throw MJC.fatal(""+ mjName);
	      }
	    };
	  if (mjClassType.tag() != :MJclass){
	    throw MJC.fatal(""+ mjClassType);
	  }
	  Symbol fullName = ((MJClassType)mjClassType).getName();
	  mjClassDataTable.put(fullName,
			       epp!treeToMJClassData(typeDecl,
						     (MJClassType)mjClassType,
						     moduleName));
	} catch (EppTypeError e){
	  throw epp!errorAt(mjName, e.getMessage());
	}
      }
    }
  }

  // $B$3$N%b%8%e!<%k$,;}$C$F$$$k(B MJClassData $B$r<h$j=P$9!#(B
  public NullOr<MJClassData> getMJClassData(Symbol fullName) {
    return mjClassDataTable.get(fullName);
  }


  //--------------------------------------------------
  //--------------------------------------------------
  //--------------------------------------------------

  /*
    $B!&8!:w$N7k2L8uJd$,J#?t$"$l$P!"(Bambiguous error $B$H$9$k!#(B
    $B!&<BAu$r4JC1$K$9$k$?$a$K!"(B ambiguous error $B$N%A%'%C%/$O0J2<$N$h$&$K9T$&!#(B
    $B$^$:!"C1=cL>$N>l9g!#(B
    $B$^$:(B Ls $B$NCf$+$i$=$N7?L>$r$5$,$7!"J#?t$"$l$P(B ambiguous error $B!#(B
    $B<!$K!"(B Lj $B$NCf$+$i$=$N7?L>$rC5$7!J(BimportOnDemand $B$N=hM}!K!"(B
    $BJ#?t$"$l$P(B ambiguous error $B!#(B
    $B:G8e$K!"(B Ls $B$H(B Lj $B$NN>J}$G8+$D$+$C$?$J$i$P(B ambiguous error $B!#(B
    $B$I$A$i$+#1J}$J$i$P!"$=$l$rJV$9!#(B
    $B!&40A48BDjL>$N>l9g$O!"(B
    ClassTypeTable $B$+$i(B get $B$7$FJV$9!#(B
    NotFound $B$N=hM}$O(B MJClassTypeTable $B$,9T$&$O$:!#(B
    $B!&(B ambiguous error $B$,5/$-$?>l9g$O!"(B
    $B%(%i!<%a%C%;!<%8$,$A$g$C$H$o$+$j$K$/$$$,!"(B
    throw EppTypeError $B$r;H$&$3$H$K$9$k!#(B
    */
  // key = Symbol (simple name of the ClassType or MJClassType), val = Type
  Table<Symbol, Type> typeCache = {};

  // $B$3$N%a%=%C%I$O!"(B MJTypeNameTable $B$+$i$N$_8F$P$l$k!#(B
  public NullOr<Type> getType(Tree name) {
    Symbol fullName;
    if (name.args().length == 1){
      Symbol simpleName = name.args()[0].idName();

      // $B$^$:(B Ls $B$+$iC5$9!#(B
      Symbol mjFullName;
      Vec<Symbol> fullNames = usingTypeNameTable.get(simpleName)
	ifNull { fullNames = null; };
      if (fullNames == null){
	mjFullName = null;
      } else {
	if (fullNames.size() == 0){
	  throw MJC.fatal(""+ name+ ":"+ usingTypeNameTable);
	} else if (fullNames.size() == 1){
	  mjFullName = fullNames.get(0);
	} else {
	  StringBuffer buf = new StringBuffer();
	  buf.append("MJ: Ambiguous class name \""+ simpleName+
		     "\" is used at module "+ moduleName+
		     Opts.lineSeparator);
	  foreach (Symbol s in fullNames){
	    buf.append("    "+ s+ Opts.lineSeparator);
	  }
	  throw new EppTypeError(buf.toString());
	}
      }

      // $B<!$K(B globalTypeNameTable $B$+$i$bC5$9!#(B
      Type javaType = globalTypeNameTable.get(name)
	ifNotFound { javaType = null; };
      

      // $BN>J}$G8+$D$+$C$?$i!"(B ambiguous error $B!#$A$g$&$I#1$D$J$i!"$=$l!#(B
      if (mjFullName != null){
	if (javaType != null){
	  StringBuffer buf = new StringBuffer();
	  buf.append("MJ: Ambiguous class name \""+ simpleName+
		     "\" is used at module "+ moduleName+
		     Opts.lineSeparator);
	  buf.append("  "+ mjFullName+ Opts.lineSeparator);
	  buf.append("  "+ javaType+ Opts.lineSeparator);
	  throw new EppTypeError(buf.toString());
	} else {
	  fullName = mjFullName;
	}
      } else {
	if (javaType != null){
	  // Return the type. It may be an Lj ClassType or a primitive type.
	  return javaType;
	} else {
	  //old throw NotFound.instance;
	  return null;
	}
      }

    } else {
      fullName = Symbol.intern(name.nameToString());
    }

    // Ls $B%/%i%9$N>l9g$O!"(B classTypeTable $B$+$i<h$j=P$9!#(B
    // $B$=$N%/%i%9$,B8:_$7$J$$>l9g$O(B NotFound $B$r(B throw $B$7$F$/$l$k!#(B
    ClassTypeTable classTypeTable
      = (ClassTypeTable)Dynamic.get(:classTypeTable);
    Type type = classTypeTable.get(fullName)
      ifNotFound { return null; };
    return type;
  }


  //--------------------------------------------------
  
  // $B$3$N%a%=%C%I$O(B MJClassTypeTable $B$+$i$N$_8F$S=P$5$l$k!#(B
  public NullOr<MJClassType> getMJClassType(Symbol fullName) {
    return mjClassTypeTable.get(fullName);
  }

  //--------------------------------------------------

  // key = class full name, val = MJClassInfo .
  Table<Symbol, MJClassInfo> mjClassInfoTable = {};

  // key = class full name, val = :initializing or initialized (or :error?)
  Table<Symbol, Symbol> mjClassInfoInitializingState = {};
  

  // $B$3$N%a%=%C%I$O!"(B MJClassType $B$+$i$N$_8F$S=P$5$l$k!#(B
  // lazy $B$K(B  MJClassInfo $B$r:n$k!#(B
  public MJClassInfo getMJClassInfo(Symbol fullName) {
    MJClassInfo mjClassInfo = mjClassInfoTable.get(fullName)
      ifNull {
	Symbol state = mjClassInfoInitializingState.get(fullName)
	ifNull {

	  if (Opts.log){
	    Opts.out.println("Start initializing MJClassInfo of "+
			     fullName+ " at "+ moduleName+ " .");
	  }

	  // Start initialization.
	  mjClassInfoInitializingState.put(fullName, :initializing);

	  Vec<MJClassData> linearizedMJClassData = {};
	  foreach (MJModuleInfo module in linearizedUsingModules){
	    MJClassData data = module.getMJClassData(fullName)
	      ifNull{
		data = null;
	      };
	    if (data != null){
	      linearizedMJClassData.push(data);
	    }
	  }

	  try {
	    mjClassInfo = composeClassOrInterface(linearizedMJClassData);
	  } catch (MJConstraintError e){
	    throw
	    new EppTypeError("MJ: In "+
			     fullName+ " at module "+ moduleName+
			     " : "+
			     e.getMessage());
	  }
	  mjClassInfoTable.put(fullName, mjClassInfo);
	  mjClassInfoInitializingState.put(fullName, :initialized);

	  if (Opts.log){
	    Opts.out.println("End initializing MJClassInfo of "+
			     fullName+ " at "+ moduleName+ " .");
	    Opts.out.println(mjClassInfo.toString());
	  }

	  return mjClassInfo;
	};
	if (state == :initializing){
	  throw new EppTypeError("MJ: Type dependency loop is detected: "+
				 fullName);
	} else {
	  throw MJC.fatal(""+ state);
	}
      };
    return mjClassInfo;
  }

  public MJClassInfo composeClassOrInterface(Vec<MJClassData>
					     linearizedMJClassData){
    MJClassData firstClassData = linearizedMJClassData.get(0);
    if (firstClassData.classKeyword == :class){
      return composeClass(linearizedMJClassData);
    } if (firstClassData.classKeyword == :interface){
      return composeInterface(linearizedMJClassData);
    } else {
      throw MJC.fatal(""+ firstClassData.classKeyword);
    }
  }


  public MJClassInfo composeClass(Vec<MJClassData> linearizedMJClassData){
    classExtensionConstraints(linearizedMJClassData);
    MJClassData firstClassData = linearizedMJClassData.get(0);
    Type superclassType = firstClassData.superclassType;

    // key = full name of interface, value = Type
    Table<Symbol, Type> interfaceTable = {};
    Table<Symbol,Vec<MJFieldInfo> > fieldTable = {};
    Table<Symbol,Vec<MJMethodInfo> > methodTable = {};

    foreach (MJClassData mjClassData in linearizedMJClassData){
      inheritInterfaces(mjClassData, interfaceTable);
    }
    Vec<Type> directSuperInterfaceVec = {};
    foreach (Type t in interfaceTable.valueIter()){
      directSuperInterfaceVec.push(t);
    }

    if (superclassType.tag() == :class){
      inheritFromJavaClass(firstClassData.moduleName,
			   superclassType,
			   interfaceTable,
			   fieldTable,
			   methodTable);
    } else if (superclassType.tag() == :MJclass){
      inheritFromMJClass(superclassType,
			 interfaceTable,
			 fieldTable,
			 methodTable);
    } else {
      throw MJC.fatal("");
    }

    // interfaceVec $B$O!"(B direct super interfaces $B$H!"(B
    // direct super class $B$+$i7Q>5$9$k(B interface $B$r$9$Y$F9g$o$;$?$b$N!#(B
    Vec<Type> interfaceVec = {};
    foreach (Type t in interfaceTable.valueIter()){
      interfaceVec.push(t);
    }

    // $B$9$Y$F$N(B direct super interface $B$+$i!"%a%s%P$r7Q>5$9$k!#(B
    // $B!J=EJ#$,$"$C$F$b#1$D$K$^$H$a$k!#!K(B
    // $B$?$@$7!"(B method $B$K$D$$$F$O!"(B MJMethodInfo $B$N(B declaringModule $B$,(B
    //$BI,$:!V<+J,!W$K$J$k$h$&$K9)IW$9$k!#(B
    Table<Symbol,Vec<MJMethodInfo> > abstractMethodTable = {};
    foreach (Type type in directSuperInterfaceVec){
      if (type.tag() == :class){
	inheritFromJavaInterface(firstClassData.moduleName,
				 type,
				 fieldTable,
				 abstractMethodTable);
      } else if (type.tag() == :MJclass){
	inheritFromMJInterface(type,
			       fieldTable,
			       abstractMethodTable);
      } else {
	throw MJC.fatal("");
      }
    }

    // interface $B$r(B implements $B$9$k$H$$$&$3$H$O!"(B
    // $B!V$=$N(B interface $B$N(B member $B$r!"<+J,$,(B abstract method $B$H$7$F(B
    //$BDj5A$9$k$3$H$G$"$k!W!"$H2r<a$7$F=hM}$9$k!#(B
    // $B!J<+J,$,$=$N%a%=%C%I$r!V<BAu!W$7$F$$$k>l9g$O!"(B
    //   $B<!$N(B inheritMJMethodInfo $B$N=hM}$G(B override $B$5$l$k!#!K(B
    addAbstractMethodTable(firstClassData.classType,
			   abstractMethodTable, methodTable);

    foreach (MJClassData mjClassData in linearizedMJClassData){
      inheritMJFieldInfo(mjClassData, fieldTable);
    }
    foreach (MJClassData mjClassData in linearizedMJClassData){
      inheritMJMethodInfo(mjClassData, methodTable);
    }

    //old MJClassData lastClassData
    //  = linearizedMJClassData.get(linearizedMJClassData.size() - 1);
    return new MJClassInfo(firstClassData.fullName,
			   firstClassData.simpleName,
			   firstClassData.moduleName,
			   firstClassData.modifiers,
			   (firstClassData.classKeyword == :interface),
			   firstClassData.superclassType,
			   interfaceVec.toArray(),
			   new MJMethodInfo[]{}, // mjConstructors
			   fieldTable,
			   methodTable);
  }

  public void addAbstractMethodTable(Type classType,
				     Table<Symbol,Vec<MJMethodInfo> >
				     abstractMethodTable,
				     Table<Symbol,Vec<MJMethodInfo> >
				     methodTable){
    foreach (Vec<MJMethodInfo> vec in abstractMethodTable.valueIter()){
      foreach (MJMethodInfo m0 in vec){
	// $B%-%c%9%H@h$N$_$A$,$&(B MJMethodInfo $B$r:n$C$F!"(B methodTable $B$KDI2C!#(B
	MJMethodInfo abstractMethod
	  = new MJMethodInfo(moduleName, //$B%-%c%9%H@h!#(B
			     classType,	// $B$3$l$b%-%c%9%H@h$H$7$F;H$o$l$k!#(B
			     m0.mjInfo,	// isDefinition $B$J$O$:!#(B
			     m0.getModifiers(),	// abstract $B$J$O$:!#(B
			     m0.getReturnType(),
			     m0.getName(),
			     m0.fullName,
			     m0.moduleName,
			     m0.getParameterTypes(),
			     m0.getExceptionTypes());
	addOneMJMethodInfo(abstractMethod, methodTable);
      }
    }
  }

  public void inheritFromJavaClass(Symbol moduleName,
				   Type superclassType,
				   Table<Symbol, Type> interfaceTable,
				   Table<Symbol,Vec<MJFieldInfo> > fieldTable,
				   Table<Symbol,Vec<MJMethodInfo> > methodTable){
    ClassInfo classInfo = superclassType.classInfo();

    foreach (Type t in classInfo.getInterfaces()){
      // $B$3$3$G=EJ#$,8+$D$+$k$+$b$7$l$J$$$,!"#1$D$@$17Q>5!#(B
      interfaceTable.put(t.classInfo().getName(), t);
    }

    Hashtable javaFieldTable = classInfo.getFieldTable();
    for (Enumeration e = javaFieldTable.keys(); e.hasMoreElements();){
      Symbol key = (Symbol)e.nextElement();
      FieldInfo fieldInfo = (FieldInfo)javaFieldTable.get(key);
      if (! fieldInfo.isAmbiguousField()){
	Tree[] modifiers = fieldInfo.getModifiers();
	// public field $B$H(B protected field $B$N$_7Q>5(B
	if (MJC.hasModifier(:public, modifiers)
	    || MJC.hasModifier(:protected, modifiers)
	    ){
	  Vec<MJFieldInfo> newVec = {};
	  newVec.push(new MJJavaFieldInfo(superclassType,
					  fieldInfo,
					  moduleName
					  ));
	  fieldTable.put(key, newVec);
	}
      }
    }

    Hashtable javaMethodTable = classInfo.getMethodTable();
    for (Enumeration e = javaMethodTable.keys(); e.hasMoreElements();){
      Symbol key = (Symbol)e.nextElement();
      MethodInfo[] methods = (MethodInfo[])javaMethodTable.get(key);
      Vec<MJMethodInfo> newVec = {};
      foreach (MethodInfo m in methods){
	Tree[] modifiers = m.getModifiers();
	// public/protected method $B$N$_7Q>5(B
	if (MJC.hasModifier(:public, modifiers)
	    || MJC.hasModifier(:protected, modifiers)){
	  newVec.push(new MJJavaMethodInfo(superclassType, m,
					   moduleName
					   ));
	}
      }
      if (newVec.size() > 0){
	methodTable.put(key, newVec);
      }
    }
  }

  public void inheritFromMJClass(Type superclassType,
				 Table<Symbol, Type> interfaceTable,
				 Table<Symbol,Vec<MJFieldInfo> > fieldTable,
				 Table<Symbol,Vec<MJMethodInfo> > methodTable){

    MJClassInfo mjClassInfo = ((MJClassType)superclassType).mjClassInfo();
   
    foreach (Type t in mjClassInfo.getInterfaces()){
      Symbol fullName = t.classInfo().getName();
      Type x = interfaceTable.get(fullName) ifNull{ x = null; };
      if (x == null){
	interfaceTable.put(fullName, t);
      } else {
	interfaceTable.print();
	throw MJC.fatal(""+ fullName);
      }
    }

    // Deep copy the fieldTable of mjClassInfo.
    foreach (Symbol key, Vec<MJFieldInfo> vec in mjClassInfo.fieldTable){
      Vec<MJFieldInfo> newVec = {};
      foreach (MJFieldInfo f in vec){ newVec.push(f); }
      fieldTable.put(key, newVec);
    }

    // Deep copy the methodTable of mjClassInfo.
    foreach (Symbol key,Vec<MJMethodInfo> vec in mjClassInfo.methodTable){
      Vec<MJMethodInfo> newVec = {};
      foreach (MJMethodInfo m in vec){ newVec.push(m); }
      methodTable.put(key, newVec);
    }
  }


  public void classExtensionConstraints(Vec<MJClassData>
					linearizedMJClassData){
    // $BD9$5$,#10J>e$+!)(B
    if (linearizedMJClassData.size() < 1) {
      throw MJC.fatal(""+ linearizedMJClassData);
    }
    // $B:G=i$,(B isDefinition $B$G$=$l0J9_$,(B ! isDefinition $B$+!)(B
    // delta $B$,(B super $B$rDj5A$7$F$$$J$$$+!)(B
    //$B!JG0$N$?$a!)(B fullName $B$,0c$C$F$$$J$$$+!)!K(B
    // $B$b$7%(%i!<$,8+$D$+$C$?$i!"(B MJConstraintError $B$r(B throw $B$9$k!#(B
    // $B!J(B delta list $B$r(B message $B$KF~$l$F!"$o$+$j$d$9$$%(%i!<%a%C%;!<%8$K!#!K(B
    // $B$G!"$A$c$s$H$I$3$+$G(B catch $B$7$F!"E,@Z$J%(%i!<%a%C%;!<%8$r=P$9!#(B

    // interface $B$H(B class $B$,$^$6$C$F$$$J$$$+!)(B
    Symbol classKeyword = linearizedMJClassData.get(0).classKeyword;
    foreach (MJClassData data in linearizedMJClassData){
      if (data.classKeyword != classKeyword){
	 throw new MJConstraintError("The "+ classKeyword+ " "+
				     linearizedMJClassData.get(0).fullName+
				     " is extended as "+ data.classKeyword+
				     " in "+ data.moduleName+ " .");
      }
    }

    // fullName $B$,(B null $B$@$C$?$i!"$3$3$GCM$r(B set $B$9$k!#(B
    foreach (int index, MJClassData mjClassData in linearizedMJClassData){
      if (index != 0 && mjClassData.fullName == null){
	// $BK\Ev$O$$$m$$$m%(%i!<%A%'%C%/$r$9$k!#(B
	MJClassData prev = linearizedMJClassData.get(index - 1);
	mjClassData.fullName = prev.fullName;
	mjClassData.moduleName = prev.moduleName;
      }
    }
  }

  //--------------------------------------------------
  // Inheritance of class members.


  public void inheritInterfaces(MJClassData mjClassData,
				Table<Symbol, Type> interfaceTable){
    foreach (Type t in mjClassData.interfaceTypes){
      Symbol fullName = t.classInfo().getName();
      Type x = interfaceTable.get(fullName) ifNull{ x = null; };
      if (x == null){
	interfaceTable.put(fullName, t);
      } else {
	// Do nothing.
	//throw MJConstraintError("interface "+ fullName + " is repeatedly implemented .");
      }
    }
  }

  // hide $B$O5v$5$J$$!#F1$8L>A0$GDj5A$9$k$3$H$O5v$9!#(B
  public void inheritMJFieldInfo(MJClassData mjClassData,
				 Table<Symbol,Vec<MJFieldInfo> > fieldTable
				 ){
    // $B<+J,$,Dj5A$9$k(B MJFieldInfo $B$rDI2C!#(B
    foreach (Symbol name, MJFieldInfo f in mjClassData.fieldTable){
      Vec<MJFieldInfo> vec = fieldTable.get(name)
	ifNull{
	  vec = new Vec<MJFieldInfo>();
	  fieldTable.put(name, vec);
	};
      vec.push(f);
    }
  }

  public void inheritMJMethodInfo(MJClassData mjClassData,
				  Table<Symbol,Vec<MJMethodInfo> > methodTable
				  ){
    // $B<+J,$,Dj5A$9$k(B MJMethodInfo $B$rDI2C!#(B
    foreach (Vec<MJMethodInfo> vec0 in mjClassData.methodTable.valueIter()){
      foreach (MJMethodInfo m0 in vec0){
	addOneMJMethodInfo(m0, methodTable);
      }
    }
  }

  public void addOneMJMethodInfo(MJMethodInfo m0,
				 Table<Symbol,Vec<MJMethodInfo> > methodTable){
    Symbol simpleName = m0.getName();
    Vec<MJMethodInfo> vec1 = methodTable.get(simpleName)
      ifNull{
	vec1 = new Vec<MJMethodInfo>();
	methodTable.put(simpleName, vec1);
      };
    Vec<int> overrideCandidates = {};
    foreach (int index1, MJMethodInfo m1 in vec1){
      if (epp!doesOverride(m0, m1)){
	if (m1.moduleName == null){ throw MJC.fatal(""+ m1); }
	if (m0.moduleName == null) {
	  overrideCandidates.push(index1);
	} else {
	  if (m0.moduleName == m1.moduleName){
	    overrideCandidates.push(index1);
	  }
	}
      }
    }
    if (overrideCandidates.size() > 1) {
      if (m0.moduleName != null){ throw MJC.fatal(""+ m0); }
      // ambiguous error 
      // $B!J(Bm0 $B$N(B fullName $B$,(B null $B$G!"(B overrideCandidates $B$,J#?t$"$k>l9g!#!K(B
      StringBuffer buf = new StringBuffer();
      buf.append("Ambiguos method name. "+
		 "Can not determine the method to be overridden. :"+
		 Opts.lineSeparator);
      foreach (int index in overrideCandidates){
	MJMethodInfo m1 = vec1.get(index);
	buf.append("    "+ m1.fullName+ Opts.lineSeparator);
      }
      throw new MJConstraintError(buf.toString(), m0);

    } else if (overrideCandidates.size() == 1){
      int index1 = overrideCandidates.get(0);
      MJMethodInfo m1 = vec1.get(index1);
      checkMethodOverridingConstraints(m0, m1);
      // vec1 $B$NMWAG(B m1 $B$r!"(B override $B$7$?%a%=%C%I(B m0 $B$GCV$-49$($k!#(B
      vec1.put(index1, m0);

      if (m0.isDefinition){

	// $B$H$j$"$($:!"Dj5A$:$_(B Java method $B$r(B subclass $B$G(B implements
	// $B$9$k$N$O6X;_!"$H$9$k!#(B
#+comment
	{
	  // Java method $B$K4X$7$F$O!"(B isDefinition $B$,(B isDefinition $B$r(B
	  // override $B$7$F$b$+$^$o$J$$$b$N$H$9$k!#(B
	  // $B$9$G$K(B super $B$K$*$$$FDj5A$:$_$N%a%=%C%I$r4^$`%$%s%?!<%U%'!<%9$r!"(B
	  // subclass $B$G(B implemens $B@k8@$9$k$H$-$K5/$-$k!#(B
	  if (m0.moduleName != MJC.JAVA_MODULE_NAME){
	    throw new MJConstraintError("Definition-method overrides another method. : "+ m0.getName(),
					m0);
	  }
	}

	throw new MJConstraintError("Definition-method overrides another method. : "+ m0.getName(),
				    m0);
      }
    } else {
      // $B$I$N(B method $B$b(B override $B$7$F$$$J$$$J$i!"?7$7$$%a%=%C%I!#(B

      // $B$3$3$G!"(B moduleName $B$,<+J,$G$"$k$3$H$r3NG'$7$J$$$H$@$a!#!JJ]N1!#!K(B

      if (! m0.isDefinition){
	throw new MJConstraintError("Definition-method does not have \"define\" . : "+ m0.getName(),
				    m0);
      }
      vec1.push(m0);
      //
    }
  }

  // Check if m0 correctly overrides m1.
  public void checkMethodOverridingConstraints(MJMethodInfo m0,
					       MJMethodInfo m1){

    if (Opts.log){
      Opts.out.println("\t"+
		       m0.getDeclaringClass()+ "#"+
		       m0.moduleName+ "::"+ m0.getName()+
		       " at "+ m0.declaringModule
		       );
      Opts.out.println("\t\t overrides "+
		       m1.getDeclaringClass()+ "#"+
		       m1.moduleName+ "::"+ m1.getName()+
		       " at "+ m1.declaringModule+
		       " .");
    }

    // Not implemented.
    if (m0.fullName == null){
      // $B$$$^$O$3$3$G(B fullName $B$N@_Dj$r9T$C$F$$$k$,!"(B
      // $BK\Ev$O!"7?%A%'%C%/%Q%9$ND>A0$K(B fullName $B$N@_Dj$r9T$C$F$*$+$J$1$l$P(B
      // $B$J$i$J$$!#(B
      m0.fullName = m1.fullName;
      m0.moduleName = m1.moduleName;
    } else {
      if (m0.fullName != m1.fullName){

#+debug
	System.err.println("checkMethodOverridingConstraints:"+
			   "m0.fullName="+ m0.fullName+
			   ":m1.fullName="+ m1.fullName);

	//throw Epp.error("checkMethodOverridingConstraints: "+
	//		m0+ " overrites "+ m1);
	// throw new MJConstraintError(m0);
      }
    }
  }

  //--------------------------------------------------


  public MJClassInfo composeInterface(Vec<MJClassData> linearizedMJClassData){
    classExtensionConstraints(linearizedMJClassData);
    MJClassData firstClassData = linearizedMJClassData.get(0);

    // key = full name of interface, value = Type
    Table<Symbol,Vec<MJFieldInfo> > fieldTable = {};
    Table<Symbol,Vec<MJMethodInfo> > methodTable = {};

    // $B$^$:!"$9$Y$F$N(B delta $B$G@k8@$5$l$?(B direct super interface $B$r(B merge $B$9$k!#(B
    Table<Symbol, Type> interfaceTable = {};
    foreach (MJClassData mjClassData in linearizedMJClassData){
      foreach (Type t in mjClassData.interfaceTypes){
	// $B=EJ#$O5v$9!#(B
	interfaceTable.put(t.classInfo().getName(), t);
      }
    }
    Vec<Type> interfaceVec = {};
    foreach (Type t in interfaceTable.valueIter()){
      interfaceVec.push(t);
    }

    // $B$9$Y$F$N(B direct super interface $B$+$i!"%a%s%P$r7Q>5$9$k!#(B
    foreach (Type type in interfaceVec){
      if (type.tag() == :class){
	inheritFromJavaInterface(firstClassData.moduleName,
				 type,
				 fieldTable,
				 methodTable);
      } else if (type.tag() == :MJclass){
	inheritFromMJInterface(type,
			       fieldTable,
			       methodTable);
      } else {
	throw MJC.fatal("");
      }
    }

    // $B:G8e$K3F(B delta $B$,<+J,$GDj5A$7$F$$$k%a%s%P$rDI2C!#(B
    // $B$9$Y$F$,!V(B abstract $B$+$D(B definition $B!W$G$"$k$O$:!#(B
    foreach (MJClassData mjClassData in linearizedMJClassData){
      inheritMJFieldInfoFromInterface(mjClassData, fieldTable);
    }
    foreach (MJClassData mjClassData in linearizedMJClassData){
      inheritMJMethodInfoFromInterface(mjClassData, methodTable);
    }

    //old MJClassData lastClassData
    //  = linearizedMJClassData.get(linearizedMJClassData.size() - 1);
    return new MJClassInfo(firstClassData.fullName,
			   firstClassData.simpleName,
			   firstClassData.moduleName,
			   firstClassData.modifiers,
			   (firstClassData.classKeyword == :interface),
			   firstClassData.superclassType,
			   interfaceVec.toArray(),
			   new MJMethodInfo[]{}, // mjConstructors
			   fieldTable,
			   methodTable);
  }

  public void inheritFromJavaInterface(Symbol moduleName,
				       Type superclassType,	// interface
				       Table<Symbol,Vec<MJFieldInfo> >
				       fieldTable,
				       Table<Symbol,Vec<MJMethodInfo> >
				       methodTable){
    ClassInfo classInfo = superclassType.classInfo();

    Hashtable javaFieldTable = classInfo.getFieldTable();
    for (Enumeration e = javaFieldTable.keys(); e.hasMoreElements();){
      Symbol key = (Symbol)e.nextElement();
      FieldInfo fieldInfo = (FieldInfo)javaFieldTable.get(key);
      // $B!JJ#?t$N(B super interface $B$+$iF1$8(B field $B$r7Q>5$9$k>l9g!"(B
      //   $B<B$OF10l5/8;$N(B field $B$G$"$C$F$b!"(B
      //   $B0[$J$k(B MJJavaMethodInfo $B$GI=8=$5$l$k!#(B
      //   $B$7$+$7(B mergeMJMethodInfo $B$G7k6I#1$D$,;D$5$l$k!#!K(B
      MJFieldInfo f0 = new MJJavaFieldInfo(superclassType,
					   fieldInfo,
					   moduleName
					   );
      mergeMJFieldInfo(f0, fieldTable);
    }


    Hashtable javaMethodTable = classInfo.getMethodTable();
    for (Enumeration e = javaMethodTable.keys(); e.hasMoreElements();){
      Symbol key = (Symbol)e.nextElement();
      MethodInfo[] methods = (MethodInfo[])javaMethodTable.get(key);
      foreach (MethodInfo m in methods){
	//Opts.out.println("mmm:"+ m.getName()+ ":"+ m.getDeclaringClass());
	// $B$3$3$G$O(B java.lang.Object $B$+$i$N%a%=%C%I$O7Q>5$7$J$$$3$H$K$9$k!#(B
	if (m.getDeclaringClass().classInfo().getName()
	    != :"java.lang.Object"){
	  MJMethodInfo m0
	    = new MJJavaMethodInfo(superclassType, m,
				   moduleName
				   );
	  mergeMJMethodInfo(m0, methodTable);
	}
      }
    }
  }

  public void inheritFromMJInterface(Type superclassType,	// interface
				     Table<Symbol,Vec<MJFieldInfo> >
				     fieldTable,
				     Table<Symbol,Vec<MJMethodInfo> >
				     methodTable){

    MJClassInfo mjClassInfo = ((MJClassType)superclassType).mjClassInfo();

    foreach (Symbol key, Vec<MJFieldInfo> vec in mjClassInfo.fieldTable){
      foreach (MJFieldInfo f0 in vec){
	mergeMJFieldInfo(f0, fieldTable);
      }
    }

    foreach (Symbol key,Vec<MJMethodInfo> vec in mjClassInfo.methodTable){
      foreach (MJMethodInfo m0 in vec){
	mergeMJMethodInfo(m0, methodTable);
      }
    }
  }

  public void inheritMJFieldInfoFromInterface(MJClassData mjClassData,
					      Table<Symbol,Vec<MJFieldInfo> >
					      fieldTable
					      ){
    foreach (MJFieldInfo f0 in mjClassData.fieldTable.valueIter()){
      mergeMJFieldInfo(f0, fieldTable);
    }
  }

  public void inheritMJMethodInfoFromInterface(MJClassData mjClassData,
					       Table<Symbol,Vec<MJMethodInfo> >
					       methodTable
					       ){
    foreach (Vec<MJMethodInfo> vec in mjClassData.methodTable.valueIter()){
      foreach (MJMethodInfo m0 in vec){
	mergeMJMethodInfo(m0, methodTable);
      }
    }
  }

  public void mergeMJFieldInfo(MJFieldInfo f0,
			       Table<Symbol,Vec<MJFieldInfo> > fieldTable){
    Symbol fullName0 = f0.fullName;
    Vec<MJFieldInfo> vec = fieldTable.get(fullName0)
      ifNull {
	vec = new Vec<MJFieldInfo>();
	fieldTable.put(f0.getName(), vec);
      };
    // $B4{B8$N(B f $B$HF10l$+$I$&$+!">WFM$7$F$$$J$$$+$I$&$+!#(B
    foreach (MJFieldInfo f1 in vec){
      if (fullName0 == f1.fullName){
	// $B!JK\Ev$O!"(B ambiguousFieldInfo $B$N=hM}$r$9$Y$-!#!K(B
	// $B$b$H$b$H$"$C$?#1$D$r;D$7$F(B return $B$9$k!#(B
	return;
      }
    }
    // $BF1$8(B fullName $B$r;}$D$b$N$,8+$D$+$i$J$+$C$?!#DI2C$9$k!#(B
    vec.push(f0);
  }

  // $B$A$J$_$K!"$9$Y$F$N(B m0 $B$O(B abstract method $B!#(B
  public void mergeMJMethodInfo(MJMethodInfo m0,
				Table<Symbol,Vec<MJMethodInfo> > methodTable){
    Symbol fullName0 = m0.fullName;
    Vec<MJMethodInfo> vec = methodTable.get(m0.getName())
      ifNull {
	vec = new Vec<MJMethodInfo>();
	methodTable.put(m0.getName(), vec);
      };

    if (Opts.log){
      Opts.out.println("mergeMJMethodInfo: "+
		       m0.getDeclaringClass()+ "#"+
		       m0.moduleName+ "::"+ m0.getName()+
		       " declared at "+ m0.declaringModule
		       );
    }

    // $B4{B8$N(B m $B$HF10l$+$I$&$+!">WFM$7$F$$$J$$$+$I$&$+!#(B
    foreach (MJMethodInfo m1 in vec){
      if (epp!doesOverride(m0, m1) &&
	  fullName0 == m1.fullName){
	// $B!J$?$V$s!KF10l5/8;$J$N$G!"$b$H$b$H$"$C$?#1$D$r;D$7$F(B return $B$9$k!#(B
	return;
      }
    }
    // $BF1$8(B signature $B$r;}$D$b$N$,8+$D$+$i$J$+$C$?!#DI2C$9$k!#(B

    if (Opts.log){
      Opts.out.println("\t This MJMethodInfo is pushed to methodTable.");
    }

    vec.push(m0);
  }


  //--------------------------------------------------
  //--------------------------------------------------
  //--------------------------------------------------

  // moduleSig $B$H!J$[$\!KEy2A$J>pJs$r(B tree $B$K$9$k!#(B
  // $B!J$?$@$7L>A0$O$9$Y$F40A48BDjL>$K$J$k!#!K(B
  public Tree toTree(){
    Tree mjName = Tree.stringToNameTree(moduleName.toString());

    TreeVec headers = new TreeVec();
    TreeVec cmpls = new TreeVec();
    foreach (Symbol name in complementingModules){
      cmpls.add(Tree.stringToNameTree(name.toString()));
    }
    headers.add(`(complementingModules ,@cmpls));
    TreeVec extds = new TreeVec();
    foreach (Symbol name in extendingModules){
      extds.add(Tree.stringToNameTree(name.toString()));
    }
    headers.add(`(extendingModules ,@extds));
    TreeVec uses = new TreeVec();
    foreach (Symbol name in usingModules){
      uses.add(Tree.stringToNameTree(name.toString()));
    }
    headers.add(`(usingModules ,@uses));
    foreach (Tree t in declaredImports){
      headers.add(t);
    }

    TreeVec decls = new TreeVec();
    foreach (MJClassData mjClassData in mjClassDataTable.valueIter()){
      decls.add(mjClassData.toTree());
    }
    foreach (Tree defmacro in definedMacros){
      decls.add(defmacro);
    }

    return `(moduleSig
	     (mjInfo)		// $B$H$j$"$($:!"$b$H$N%3%a%s%H$OJ]B8$7$J$$!#(B
	     ,mjName
	     (mjModuleHeaderDeclarations ,@headers)
	     (mjTypeDeclarations ,@decls));
  }

  //  loadAndAddModule $B$H(B addHandMadeModule $B$+$i8F$P$l$k!#(B
  public static MJModuleInfo treeToMJModuleInfo(Tree tree) {
    if (Opts.printTree){
      Opts.out.println("treeToMJModuleInfo: "+ tree);
    }
    MJModuleInfo module = new MJModuleInfo(null, null, tree);
    return module;
  }
}


// $B$I$3$+$G(B catch $B$7$F!"(B method list $B$r=PNO$9$k!#(B
// $B$=$N:]!"(B m $B$N0LCV$bI=<($9$k!#(B
public class MJConstraintError extends Error {
  String message;
  MJMethodInfo mjModuleInfo;
  public MJConstraintError(String message){
    super(message);
    mjModuleInfo = null;
  }
  public MJConstraintError(String message, MJMethodInfo m){
    super(message);
    this.mjModuleInfo = m;
  }
}
