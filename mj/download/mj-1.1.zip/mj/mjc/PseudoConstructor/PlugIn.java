/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */


/*

 PseudoConstructor plug-in

*/


#epp jp.go.etl.epp.EppLibLevel0
#epp jp.go.etl.epp.Collection

package mjc.PseudoConstructor;
import mjc.*;

BeforeLoadingPlugIn{
  requirePlugIn("mjc.PlugIn");
}

SystemMixin PlugIn {
  class Epp {
    extend void afterMacroExpansionPass(){
      original();
      self!tree = new TransPseudoConstructor().transTree(self!tree);
    }
  }
}


public class TransPseudoConstructor {
  Obj epp = (Obj)Dynamic.get(:epp);

  // mjCompilationUnit $B$N2<$r:F5"E*$K=hM}!#(B
  public Tree transTree(Tree tree){
    if (tree.tag() == :mjClass) {
      return transMJClass(tree);
    }  else {
      TreeVec tvec = new TreeVec();
      foreach (Tree t in tree.args()){
	tvec.add(transTree(t));
      }
      return tree.modifyArgs(tvec.toArray());
    }
  }

  // $B%/%i%9L>$rF0E*JQ?t$K@_Dj!#(B classBody $B0U30$O$=$N$^$^!#(B
  public Tree transMJClass(Tree tree){
    if (tree.tag() != :mjClass) throw MJC.fatal("");
    Tree mjName = tree.args()[3];
    Dynamic.bind(:currentClassName, mjName);
    try {
      TreeVec tvec = new TreeVec();
      foreach (Tree t in tree.args()){
	if (t.tag() == :classBody){
	  tvec.add(transClassBody(t));
	} else {
	  tvec.add(t);
	}
      }
      return tree.modifyArgs(tvec.toArray());
    } finally {
      Dynamic.unbind();
    }
  }

  // constructor $B0U30$O$=$N$^$^!#(B
  public Tree transClassBody(Tree tree){
    if (tree.tag() != :classBody) throw MJC.fatal("");
    Tree[] args = tree.args();
    TreeVec tvec = new TreeVec();
    foreach (Tree t in tree.args()){
      Symbol tag = t.tag();
      if (tag == :mjConstructor){
	transMJConstructor(t, tvec);
      } else {
	tvec.add(t);
      }
    }
    return tree.modifyArgs(tvec.toArray());
  }

  // $B%3%s%9%H%i%/%?$r%a%=%C%I(B _call_init_C, _init_C $B$KJQ49!#(B
  public void transMJConstructor(Tree tree, TreeVec tvec){
    if (tree.tag() != :mjConstructor) throw MJC.fatal("");
    Tree[] args = tree.args();
    Tree mjMarks = args[0];
    Tree currentClassName = (Tree)Dynamic.get(:currentClassName);
    Symbol classSimpleName = MJC.mjNameToSimpleName(currentClassName);
    Tree initializerName
      = (new Identifier(Symbol.intern("_init_"+ classSimpleName)));
    if (mjMarks.args().length != 0){
      Tree callerName
	= (new Identifier(Symbol.intern("_call_init_"+ classSimpleName)));

      TreeVec vars = new TreeVec();
      foreach (Tree pdecl in args[4].args()){
	vars.add(pdecl.args()[2]);
      }

      tvec.add(
	       `(mjMethod
		 (mjMarks (id define))
		 (modifiers)
		 (name ,(new Identifier(classSimpleName)))
		 ,callerName
		 ,(args[4])
		 (throws)
		 (block
		  (expressionStatement
		   (invoke1 ,initializerName (argumentList ,vars)))
		  (returnWithExp (this))))
	       );
    }
    Tree newTree = `(mjMethod
		     ,(args[0])
		     ,(args[1])
		     (name
		      (id void))
		     ,initializerName
		     ,(args[4])
		     ,(args[5])
		     ,(transMethodBody(args[6]))
		     );
    tvec.add(TypeChecker.remakeTree(newTree, tree));
  }

  // $B@hF,$r8+$F!"!V0EL[$N%3%s%9%H%i%/%?8F$S=P$7!W$rDI2C!#(B
  public Tree transMethodBody(Tree tree){
    if (tree.tag() == :emptyStatement) return tree;
    if (tree.tag() != :block) throw MJC.fatal("");
    Tree[] args = tree.args();
    if (args.length == 0 || args[0].tag() != :expressionStatement){
      return tree;
    } else {
      Symbol tag = args[0].args()[0].tag();
      if (tag == :invokeThisConstructor
	  || tag == :invokeSuperConstructor
	  || tag == :original) {
	return tree;
      } else {
	Tree invokeSuper
	  = TypeChecker.remakeTree(`(invokeSuperConstructor (argumentList)),
	  tree);
	Tree newTree = `(block (expressionStatement ,invokeSuper) ,@args);
	return TypeChecker.remakeTree(newTree, tree);
      }
    }
  }
}
