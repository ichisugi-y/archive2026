
module pConstTest1
{
  define class C {
    define C(){
      System.out.println("C()");
    }
    define C(int x){
      this();
      System.out.println("C("+ x+ ")");
    }
  }
  class SS {
    void main(String[] args){
      original(args);
      C x;
      System.out.println("==="); x = new C();
      System.out.println("==="); x = new C(234);
    }
  }
}
module pConstTest2 extends pConstTest1
{
  class C {
    C(){
      original();
      System.out.println("+C()");
    }
    C(int x){
      original(x);
      System.out.println("+C("+ x+ ")");
    }
  }
  define class D extends C {
    define D(){
      super(999);
      System.out.println("D()");
    }
    define D(int x){
      this();
      System.out.println("D("+ x+ ")");
    }
    define D(int x, int y){
      System.out.println("D("+ x+ ", "+ y+ ")");
    }
  }
  class SS {
    void main(String[] args){
      original(args);
      D x;
      System.out.println("==="); x = new D();
      System.out.println("==="); x = new D(123);
      System.out.println("==="); x = new D(123, 456);
    }
  }
}
module pConstTest3 extends pConstTest2
{
  class D {
    define abstract D(String s);
  }
  class SS {
    void main(String[] args){
      original(args);
      D x;
      System.out.println("==="); x = new D("aaa");
    }
  }
}
module pConstTest4 extends pConstTest3
{
  class D {
    D(String s){
      System.out.println("D(\""+ s+ "\")");
    }
  }
}
