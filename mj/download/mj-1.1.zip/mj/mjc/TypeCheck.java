/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0


package mjc;
import java.util.*;

SystemMixin TypeCheck {
  class Epp {


    //--------------------------------------------------
    // $B7?%A%'%C%/(B

    extend TypeNameTable generateTypeNameTable(){
      // $BK\Mh$O!"%U%!%$%kFb$N7?L>$NL>A04D6-!#(B
      // MJ $B$G$O%b%8%e!<%k$4$H$K@_Dj$9$k$N$G!"$3$3$G$O(B null $B$rJV$7$F$*$/!#(B
      return null;
    }
    
    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :MJclass){
	if (t2.tag() == :MJclass){
	  //old return t1.classInfo().getName() == t2.classInfo().getName();
	  return ((MJClassType)t1).fullName == ((MJClassType)t2).getName();
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    extend boolean isSuperType(Type t1, Type t2){
      // TypeSyste.java $B$+$i%3%T!<!#(B
      if (t1.tag() == :MJclass || t1.tag() == :class){
	if (t2.tag() == :MJclass || t2.tag() == :class){
	  // Shortcut.
	  if (t1.classInfo().getName() == t2.classInfo().getName()) {
	    return true;
	  }
	  ClassInfo info1 = t1.classInfo();
	  ClassInfo info2 = t2.classInfo();
	  if (info1.isInterface()){
	    // info2 may be class or interface.
	    return doesImplement(info1, info2);
	  } else if (info2.isInterface()){
	    // info1 is class, info2 is interface.
	    return info1.getName() == :"java.lang.Object";
	  } else {
	    // Both info1 and info2 are classes.
	    return isAncestor(info1, info2);
	  }
	} else if (t2.tag() == :arrayOf){
	  // "array" extends Object implements Cloneable
	  ClassInfo info1 = t1.classInfo();
	  ClassTypeTable classTypeTable
	    = (ClassTypeTable)Dynamic.get(:classTypeTable);
	  ClassInfo arrayClassInfo = classTypeTable.getArrayClassInfo();
	  if (info1.isInterface()){
	    return doesImplement(info1, arrayClassInfo);
	  } else {
	    // Both info1 and info2 are classes.
	    return isAncestor(info1, arrayClassInfo);
	  }
	} else {
	  // If t1 is a reference type and t2 is a primitive type,
	  //return true iff t2 is a null type.
	  return t2.tag() == :null;
	}
      } else {
	return original(t1, t2);
      }
    }


    // MJ $B$N7?(B M $B$r!"(B M $B$N(B super type S $B$KJQ49$9$k%3!<%I$rA^F~!#(B
    // $B%;%^%s%F%#%C%/%9>e$OITMW$@$,!"(B Li $B$KJQ49$9$k$H$-$K$3$N>pJs$,I,MW$K$J$k!#(B
    extend Tree coerce(Type type, Tree tree){
      Tree newTree = original(type, tree);
      if (equals(type, tree.type())){
	return newTree;
      } else if (type.tag() == :MJclass || tree.type().tag() == :MJclass){
	// $B$I$A$i$+$,(B (MJ class $B$+(B Java class) $B$G$J$$>l9g$O!"(B
	// $B$3$N$^$^(B return $B$9$k!#(B
	// $B!J$?$V$s(B tree.type() $B$,(B <null> $B$N>l9g$7$+$J$$!#!K(B
	if (! ((type.tag() == :MJclass || type.tag() == :class)
	       &&
	       (tree.type().tag() == :MJclass || tree.type().tag() == :class)
	       )){
	  return newTree;
	}
	// $B$I$A$i$+$,(B MJClass $B$G!"$J$*$+$D!"$I$A$i$+$,(B interface $B$J$i$P!"(B
	// $B%-%c%9%H$,I,MW$J>l9g$,$"$k!#(B
	// $B!J$5$i$K%-%c%9%H$r>J$1$k>l9g$b$"$k$+$b$7$l$J$$$,!"(B
	//   $B8zN($K$O$"$^$j1F6A$7$J$$$+$bCN$l$J$$!#!J!)!K!K(B
	ClassInfo classInfo1 = type.classInfo();
	ClassInfo classInfo2 = tree.type().classInfo();
	if (classInfo1.isInterface() ||
	    classInfo2.isInterface()){
	  return TypeChecker.typeCheckTree(`(mjCast ,(type.toTree())
					     ,newTree));
	} else {
	  return newTree;
	}
      } else {
	return newTree;
      }
    }



    // MJ class $B$KBP$7$F(B field access, method invocation $B$,$G$-$k$h$&$K$9$k!#(B
    extend ClassInfo getTargetClassInfo(Type targetType){
      if (targetType.tag() == :MJclass){
	return targetType.classInfo();
      } else {
	return original(targetType);
      }
    }

    //--------------------------------------------------
    // $B%U%#!<%k%I!&%a%=%C%I$NA*Br!#(B FQN $B$KBP1~!#(B
    define implement MJFieldInfo selectMJField(Type targetType,
					       Tree fieldName){
      MJClassInfo targetMJClassInfo = getTargetMJClassInfo(targetType);
      Symbol simpleName = MJC.mjNameToSimpleName(fieldName);

      Vec<MJFieldInfo> selectedFields
	= targetMJClassInfo.getMJFields(simpleName)
	ifNull {
	  throw new EppTypeError("MJ: Field \""+ simpleName+
				 "\" is not defined at "+
				 targetMJClassInfo.getName()+ " .");
	};
      if (fieldName.tag() == :id){
	if (selectedFields.size() == 1){
	  return selectedFields.get(0);
	} else if (selectedFields.size() > 1){
	  StringBuffer buf = new StringBuffer();
	  buf.append("MJ: Ambiguous field name \""+ simpleName+ "\" of "+
		     targetType+ " :"+ Opts.lineSeparator);
	  foreach (MJFieldInfo f in selectedFields){
	    buf.append("    "+ f.fullName+ Opts.lineSeparator);
	  }
	  throw new EppTypeError(buf.toString());
	} else {
	  throw MJC.fatal(""+ selectedFields);
	}

      } else {
	// FQN
	Symbol moduleName = MJC.mjFQNToModuleName(fieldName);
	foreach (MJFieldInfo f in selectedFields){
	  if (f.moduleName == moduleName) return f;
	}
	throw new EppTypeError("MJ: No field "+ MJC.mjNameToString(fieldName)+
			       " found in "+ targetType);
      }
    }	

    define implement MJClassInfo getTargetMJClassInfo(Type targetType){
      if (targetType.tag() == :MJclass){
	return ((MJClassType)targetType).mjClassInfo();
      } else {
	throw new EppTypeError("The type can not be used as a MJ class : "+
			       targetType);
      }
    }

    // $B7?%A%'%C%/$9$k$^$($N(B argumentList $B$rEO$9!#(B
    // $B7k2L$O!"7?%A%'%C%/$H(B coerce $B$:$_$N(B argumentList $B!#(B
    define implement Object[] typeCheckAndSelectMJMethod(Type targetType,
							 Tree methodName,
							 Tree argumentList
							 ){
      MJClassInfo targetMJClassInfo = getTargetMJClassInfo(targetType);
      Symbol simpleName = MJC.mjNameToSimpleName(methodName);

      Vec<MJMethodInfo> candidates
	= targetMJClassInfo.getOverloadedMJMethods(simpleName)
	ifNull {
	  throw new EppTypeError("MJ: Method \""+ simpleName+
				 "\" is not defined at "+
				 targetType+ " .");
	};
      Tree newArgumentList = TypeChecker.typeCheckTree(argumentList);

      MJMethodInfo selectedMJMethod
	= selectMostSpecificMJMethod(methodName,
				     candidates,
				     targetType,
				     newArgumentList);
      return new Object[]{ selectedMJMethod,
			   coerceArgumentList(newArgumentList, selectedMJMethod)
			   };
    }


    define implement MJMethodInfo selectMostSpecificMJMethod(Tree methodName,
							     Vec<MJMethodInfo>
							     methods,
							     Type targetType,
							     Tree argumentList){
      
      //  $B$^$:!"<B0z?t$KE,9g$9$k(B method $B$K8uJd$r9J$k!#(B
      Vec<MJMethodInfo> confirmingMethods = {};
      foreach (MJMethodInfo m in methods){
	if (confirmArgs(m, argumentList)){
	  confirmingMethods.push(m);
	}
      }
      
      if (confirmingMethods.size() == 0){
	throw new EppTypeError("MJ: No method matching "+
			       MJC.mjNameToSimpleName(methodName)+
			       argumentListToSignatureString(argumentList)+
			       " found in "+ targetType+ " .");
      }
      
      // $B#1$D$E$D!"!V$=$N%a%=%C%I$,!"B>$N$9$Y$F$N8uJd$h$j$b(B specific $B$+!W$r(B
      // $BD4$Y$k!#(B
      Vec<MJMethodInfo> selectedMethods = {};
      foreach (int i, MJMethodInfo mi in confirmingMethods){
      checkNextCandidate:
	{
	  foreach (int j, MJMethodInfo mj in confirmingMethods){
	    if (i != j && ! moreSpecificMethod(mi, mj)){
	      break checkNextCandidate;
	    }
	  }
	  // The most specific method is found.
	  selectedMethods.push(mi);
	}
      }

      if (selectedMethods.size() == 0){
	String msg = "MJ: Reference to "+
	  MJC.mjNameToSimpleName(methodName)+ " is ambiguous. ";
	foreach (MJMethodInfo m in confirmingMethods){
	  msg += m.fullName+ "(";
	  Type[] types = m.getParameterTypes();
	  if (types.length > 0){
	    msg += types[0];
	    for (int j = 1; j < types.length; j++){
	      msg += ", "+ types[j];
	    }
	  }
	  msg += ") ";
	}
	msg += "in "+ targetType+ " .";
	throw new EppTypeError(msg);
      }


      if (methodName.tag() == :id){
	if (selectedMethods.size() == 1){
	  return selectedMethods.get(0);
	} else if (selectedMethods.size() > 1){
	  StringBuffer buf = new StringBuffer();
	  buf.append("MJ: Reference to "+ methodName.idName()+
		     argumentListToSignatureString(argumentList)+
		     " of "+
		     targetType+ " is ambiguous. :"+ Opts.lineSeparator);
	  foreach (MJMethodInfo m in selectedMethods){
	    buf.append("    "+ m.fullName+ Opts.lineSeparator);
	  }
	  throw new EppTypeError(buf.toString());
	} else {
	  throw MJC.fatal(""+ selectedMethods);
	}

      } else {
	// FQN
	Symbol moduleName = MJC.mjFQNToModuleName(methodName);
	foreach (MJMethodInfo m in selectedMethods){
	  if (m.moduleName == moduleName) return m;
	}
	throw new EppTypeError("MJ: No method matching "+
			       MJC.mjNameToString(methodName)+
			       argumentListToSignatureString(argumentList)+
			       " found in "+ targetType);
      }
    }


    // $B%m!<%+%kJQ?t4D6-$@$1$G$J$/!"(B typeOfThis $B$b8+$k$h$&$K:FDj5A!#(B
    redefine Tree resolveAmbiguousName1(Tree tree){
      // args.length == 1
      Tree[] args = tree.args();
      VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
      if (varEnv != null){
	try {
	  VarInfo info = varEnv.lookup(args[0].idName());
	  // If NotFound is not thrown, it is a local variable or
	  //a method parameter or a class field.
	  // Anyway, it is an expression. Returns (id xxx).
	  return TypeChecker.typeCheckTree(args[0]);
	} catch (NotFound e){
	  // Do nothing. Go to next step.
	}
      }

      // $B$3$3$rDI2C!#(B
    fieldNotFound:
      {
	Type typeOfThis;
	try {
	  typeOfThis = (Type)Dynamic.get(:typeOfThis);
	} catch (UnboundDynamicVariableAccessException e){
	  // treeToMJClassData $B$+$i8F$P$l$?>l9g!#(B
	  // $B$=$N>l9g$O!"(B typeOfThis $B$O(B bind $B$5$l$F$$$J$$$O$:!#(B
	  break fieldNotFound;
	}
	if (typeOfThis.tag() == :MJclass) {
	  // anonymous class $B$N>l9g$O(B typeOfThis $B$O(B ClassType $B!#(B
	  // $B$=$&$G$J$$>l9g$O!"(B field $B$r(B typeOfThis $B$+$i8!:w!#(B
	  MJClassInfo mjClassInfo = ((MJClassType)typeOfThis).mjClassInfo();
	  Vec<MJFieldInfo> selectedFields
	    = mjClassInfo.getMJFields(args[0].idName())
	    ifNull {
	      break fieldNotFound;
	    };
	  // field $B$,8+$D$+$C$?>l9g!#(B
	  return TypeChecker.typeCheckTree(args[0]);
	}
      }

      TypeNameTable typeNameTable
	= (TypeNameTable)Dynamic.get(:typeNameTable);
      try {
	Type t = typeNameTable.get(tree);
	// It is type name. Returns (name ...) .
	return tree.modifyTypeAndArgs(t, args);
      } catch (NotFound e){
	// Do nothing. Go to next step.
      }
      // Returns null which indicates the name might be PackageName .
      return null;
    }


    //--------------------------------------------------
    // TypeChecker $B$N3HD%(B
    extend void initTypeCheckerTable () {
      original();

      //old extendTypeChecker(:fieldLong,	new MJFieldLongDecorator());
      extendTypeChecker(:fieldExp,	new MJFieldExpDecorator());
      extendTypeChecker(:fieldStatic,	new MJFieldStaticDecorator());
      //extendTypeChecker(:fieldSuper,	new MJUserErrorTypeChecker());
      extendTypeChecker(:invoke1,	new MJInvoke1Decorator());
      //old extendTypeChecker(:invokeLong,	new MJInvokeLongDecorator());
      extendTypeChecker(:invokeExp,	new MJInvokeExpDecorator());
      extendTypeChecker(:invokeStatic,new MJInvokeStaticDecorator());
      extendTypeChecker(:invokeSuper,	new MJUserErrorTypeChecker());
      defineTypeChecker(:mjFieldExp,	new MJFieldExpTypeChecker());
      defineTypeChecker(:mjJavaFieldExp,new MJJavaFieldExpTypeChecker());
      defineTypeChecker(:mjJavaProtectedFieldExp,
			new MJJavaProtectedFieldExpTypeChecker());
      defineTypeChecker(:mjFieldStatic,new MJFieldStaticTypeChecker());
      defineTypeChecker(:mjInvokeExp,	new MJInvokeExpTypeChecker());
      defineTypeChecker(:mjJavaInvokeExp,new MJJavaInvokeExpTypeChecker());
      defineTypeChecker(:mjJavaProtectedInvokeExp,
			new MJJavaProtectedInvokeExpTypeChecker());
      defineTypeChecker(:mjInvokeStatic,new MJInvokeStaticTypeChecker());
      defineTypeChecker(:field1MJName,	new MJField1MJNameTypeChecker());
      defineTypeChecker(:fieldLongMJName,new MJFieldLongMJNameTypeChecker());
      defineTypeChecker(:fieldExpMJName,new MJFieldExpMJNameTypeChecker());
      defineTypeChecker(:fieldStaticMJName,
			new MJFieldStaticMJNameTypeChecker());
      defineTypeChecker(:invoke1MJName,new MJInvoke1MJNameTypeChecker());
      defineTypeChecker(:invokeExpMJName,new MJInvokeExpMJNameTypeChecker());
      defineTypeChecker(:invokeStaticMJName,new MJInvokeStaticMJNameTypeChecker());

      defineTypeChecker(:original,	new MJOriginalTypeChecker());

      extendTypeChecker(:new,		new MJNewDecorator());
      defineTypeChecker(:mjNew,		new MJNewTypeChecker());
      extendTypeChecker(:newEnclosingInstance, new MJUserErrorTypeChecker());
      extendTypeChecker(:anonymousClass,new MJAnonymousClassDecorator());
      extendTypeChecker(:classLiteral,	new MJClassLiteralTypeChecker());
      //extendTypeChecker(:anonymousClass,	new MJUserErrorTypeChecker());

      extendTypeChecker(:id,		new VariableDecorator());
      extendTypeChecker(:this,		new MJThisDecorator());
      defineTypeChecker(:mjCast,		new MJCastTypeChecker());
      defineTypeChecker(:mjThis,		new MJThisTypeChecker());

      extendTypeChecker(:invokeSuperConstructor,
			new MJInvokeSuperConstructorDecorator());
      extendTypeChecker(:invokeThisConstructor,
			new MJInvokeThisConstructorDecorator());

      defineTypeChecker(:mjMarks,		new Void1TypeChecker());
      defineTypeChecker(:mjField,		new MJFatalErrorTypeChecker());
      defineTypeChecker(:mjMethod,
			new MJConstructorAndMethodTypeChecker());
      defineTypeChecker(:mjConstructor,
			new MJConstructorAndMethodTypeChecker());
      extendTypeChecker(:constructor,		new MJFatalErrorTypeChecker());

      // anonymousClass $B$NCf$G=P$F$/$k!#(B
      //extendTypeChecker(:method,	new MJFatalErrorTypeChecker());

      extendTypeChecker(:instanceInitializer,	new MJUserErrorTypeChecker());

      //old extendTypeChecker(:staticInitializer,	new MJUserErrorTypeChecker());

      extendTypeChecker(:class,			new MJFatalErrorTypeChecker());
      defineTypeChecker(:mjClass,		new MJClassTypeChecker());
      
      extendTypeChecker(:importDeclarations,	new MJFatalErrorTypeChecker());
      extendTypeChecker(:packageDeclaration,	new MJFatalErrorTypeChecker());
      extendTypeChecker(:typeDeclarations,	new MJFatalErrorTypeChecker());
      extendTypeChecker(:compilationUnit,	new MJFatalErrorTypeChecker());

      defineTypeChecker(:mjTypeDeclarations,new VoidTypeChecker());
      //defineTypeChecker(:mjModuleHeaderDeclarations,new Void1TypeChecker());
      defineTypeChecker(:mjModule,new MJModuleTypeChecker());
      defineTypeChecker(:mjCompilationUnit,new VoidTypeChecker());

    }

    extend void initTypeNameCheckerTable() {
      original();

      defineTypeNameChecker(:mjFQN,	new MJFQNTypeNameChecker());
    }

  }      
}

//--------------------------------------------------

// MJ $B$NCj>]9=J8LZ$K4^$^$l$F$$$k$O$:$N$J$$%N!<%I(B
class MJFatalErrorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("Illegal AST node: "+ tree);
  }
}
// MJ $B$G$O%5%]!<%H$5$l$F$$$J$$%N!<%I!#(B
class MJUserErrorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Obj epp = (Obj)Dynamic.get(:epp);
    throw epp!errorAt(tree, "MJ: This language construct is not supported. : "+
		      tree.tag());
  }
}

//--------------------------------------------------

class MJFQNTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    // $B7?L>$H$7$F(B FQN(a.b::C) $B$H=q$$$?>l9g$O!"C1$K(B a.b.C $B$H=q$$$?$N$HF1$8!#(B
    Tree newTree = `(name ,@(tree.args()));
    return TypeChecker.remakeTree(newTree, tree);
  }
}


class MJInvoke1Decorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    // foo() -> this.foo()
    Tree newTree = `(invokeExp (this)
		     ,(args[0]) ,(args[1]));
    return remakeTree(newTree, tree);
  }
}
#+old
class MJInvoke1Decorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    // foo() -> ((mj.lang.ss.SS)(mjc.SS.instance)).foo()
    Tree newTree =  `(invokeExp
		      (cast (name (id mj) (id lang) (id ss) (id SS))
		       (fieldStatic (name (id mjc) (id SS)) (id instance)))
		      ,(args[0]) ,(args[1]));
    return remakeTree(newTree, tree);
  }
}


class MJFieldExpDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    Tree name = args[1];	// (id simpleName)
    if (targetType.tag() == :MJclass){
      Tree newTree = `(fieldExpMJName ,exp ,name);
      return remakeTree(newTree, tree);
    } else {
      Tree[] newArgs = { exp, name };
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

class MJFieldStaticDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree targetTree = typeNameCheckTree(args[0]);
    Type targetType = targetTree.type();
    Tree name = args[1];	// (id simpleName)
    // ClassName.this $B$H$$$&9=J8$O$H$j$"$($:L5;k!#(B
    if (targetType.tag() == :MJclass){
      Tree newTree = `(fieldStaticMJName ,targetTree ,name);
      return remakeTree(newTree, tree);
    } else {
      Tree[] newArgs = { targetTree, name };
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

#+old
class MJFieldLongDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    // (invokeLong Name Identifier)
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree[] ids = args[0].args();
    Symbol firstName = ids[0].idName();
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass){
      // anonymousClass $B$NFbIt$N>l9g!#(B
      return orig.call(tree);
    }
    MJClassInfo mjClassInfo = ((MJClassType)typeOfThis).mjClassInfo();
    Vec<MJFieldInfo> selectedFields = mjClassInfo.getMJFields(firstName)
      ifNull {
	return orig.call(tree);
      };
    // fieldExp $B$KJQ49!#(B remakeTree $B$9$k!#7?%A%'%C%/$O$7$J$$!#(B
    Tree newTree = `(fieldExp ,(MJInvokeLongDecorator
				.makeFieldExp(ids, ids.length - 1, tree))
		     ,(tree.args()[1]));
    return remakeTree(newTree, tree);
  }
}

#+old
class MJInvokeLongDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    // (invokeLong Name Identifier ArgumentList)
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree[] ids = args[0].args();
    Symbol firstName = ids[0].idName();
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass){
      // anonymousClass $B$NFbIt$N>l9g!#(B
      return orig.call(tree);
    }
    MJClassInfo mjClassInfo = ((MJClassType)typeOfThis).mjClassInfo();
    Vec<MJFieldInfo> selectedFields = mjClassInfo.getMJFields(firstName)
      ifNull {
	return orig.call(tree);
      };
    // invokeExp $B$KJQ49!#(B remakeTree $B$9$k!#7?%A%'%C%/$O$7$J$$!#(B
    Tree newTree = `(invokeExp ,(makeFieldExp(ids, ids.length - 1, tree))
		     ,(tree.args()[1]) ,(tree.args()[2]));
    return remakeTree(newTree, tree);
  }
  public static Tree makeFieldExp(Tree[] ids, int index, Tree tree){
    if (index == 0){
      return ids[index];
    } else {
      Tree newTree = `(fieldExp ,(makeFieldExp(ids, index - 1, tree))
		       ,(ids[index]));
      return remakeTree(newTree, tree);
    }
  }
}

class MJInvokeExpDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    Tree methodName = args[1];	// (id simpleName)
    Tree methodArgs = args[2];
    if (targetType.tag() == :MJclass){
      Tree newTree = `(invokeExpMJName ,exp ,methodName ,methodArgs);
      return remakeTree(newTree, tree);
    } else {
      Tree[] newArgs = { exp, methodName, methodArgs };
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}


// MJ $B<+BN$NE83+$K$OITMW$@$,!"(B
// $BB>$N(B plug-in $B$,E83+8e$N(B tree $B$H$7$F:n$k>l9g$,$"$jF@$k!*(B
class MJFieldExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJFieldStaticTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJInvokeExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJJavaFieldExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJJavaProtectedFieldExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJJavaInvokeExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJJavaProtectedInvokeExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}
class MJInvokeStaticTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("TypeChecker not implemented : "+ tree);
  }
}


class MJInvokeStaticDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree typeName = typeCheckTree(args[0]);
    Type targetType = typeName.type();
    Tree methodName = args[1];	// (id simpleName)
    Tree methodArgs = args[2];
    if (targetType.tag() == :MJclass){
      Tree newTree = `(invokeStaticMJName ,typeName ,methodName ,methodArgs);
      return remakeTree(newTree, tree);
    } else {
      Tree[] newArgs = { typeName, methodName, methodArgs };
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

class MJField1MJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree newTree = `(fieldExpMJName (this) ,(tree.args()[0]));
    return remakeTree(newTree, tree);
  }
}

class MJFieldLongMJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree resolved = resolveAmbiguousName(args[0]);
    if (resolved == null){
      throw error("Undefined variable or type name: "+ args[0].nameToString());
    } else if (resolved.tag() == :name
	       || resolved.tag() == :innerClassExp
	       || resolved.tag() == :innerClassStatic
	       ){
      //`(fieldStaticMJName ,resolved ,(args[1]))
      return remakeTree(:fieldStaticMJName,
			new Tree[]{ resolved, args[1] },
			args);

      //} else if (resolved.tag() == :id || resolved.tag() == :fieldExp
      //  || resolved.tag() == :fieldStatic) {
    } else {
      //`(fieldExpMJName ,resolved ,(args[1]))
      return remakeTree(:fieldExpMJName,
			new Tree[]{ resolved, args[1] },
			args);
    }
  }
}

class MJFieldExpMJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    Obj epp = (Obj)Dynamic.get(:epp);
    MJFieldInfo mjFieldInfo;
    try {
      mjFieldInfo = epp!selectMJField(targetType, args[1]);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }

    Type definer = mjFieldInfo.getDeclaringClass();

    if (definer.tag() == :class) {
      Symbol classFullName = ((ClassType)definer).classInfo().getName();
      Tree newTree;
      if (MJC.hasModifier(:protected, mjFieldInfo.getModifiers())){
	// $B%"%/%;%98"$,$"$k$+$I$&$+$N%A%'%C%/$O>JN,!#(B
	//$B!J$J$$>l9g$O:G0-!"<B9T;~$K(B ClassCastException $B$K$J$k!)!K(B
	newTree = `(mjJavaProtectedFieldExp
		    ,exp
		    ,(new Identifier(mjFieldInfo.declaringModule))
		    ,(new Identifier(classFullName))
		    ,(new Identifier(mjFieldInfo.getName())));
      } else {
	newTree = `(mjJavaFieldExp
		    ,exp
		    ,(new Identifier(mjFieldInfo.declaringModule))
		    ,(new Identifier(classFullName))
		    ,(new Identifier(mjFieldInfo.getName())));
      }
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(mjFieldInfo.getType(),
				       newTree.args());
      
    } else if (definer.tag() == :MJclass) {
      Symbol classFullName = ((MJClassType)definer).mjClassInfo().getName();
      Tree newTree = `(mjFieldExp
		       ,exp
		       ,(new Identifier(mjFieldInfo.moduleName))
		       ,(new Identifier(classFullName))
		       ,(MJC.fullNameToId(mjFieldInfo.moduleName,
					  mjFieldInfo.getName())));
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(mjFieldInfo.getType(),
				       newTree.args());
    } else {
      throw MJC.fatal(""+ tree+ definer);
    }

  }
}

class MJFieldStaticMJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree targetTree = typeNameCheckTree(args[0]);
    Type targetType = targetTree.type();
    Obj epp = (Obj)Dynamic.get(:epp);
    MJFieldInfo mjFieldInfo;
    try {
      mjFieldInfo = epp!selectMJField(targetType, args[1]);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }

    Type definer = mjFieldInfo.getDeclaringClass();

    if (definer.tag() == :class) {
      // protected static field $B$X$N%"%/%;%9$O$"$-$i$a$k!#(B
      Symbol classFullName = ((ClassType)definer).classInfo().getName();
      Tree newTree = `(mjJavaFieldStatic
		       ,(new Identifier(mjFieldInfo.declaringModule))
		       ,(new Identifier(classFullName))
		       ,(new Identifier(mjFieldInfo.getName())));
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(mjFieldInfo.getType(),
				       newTree.args());
      
    } else if (definer.tag() == :MJclass) {
      Symbol classFullName = ((MJClassType)definer).mjClassInfo().getName();
      Tree newTree = `(mjFieldStatic
		       ,(new Identifier(mjFieldInfo.moduleName))
		       ,(new Identifier(classFullName))
		       ,(MJC.fullNameToId(mjFieldInfo.moduleName,
					  mjFieldInfo.getName())));
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(mjFieldInfo.getType(),
				       newTree.args());
    } else {
      throw MJC.fatal(""+ tree+ definer);
    }

  }
}

class MJInvoke1MJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    // foo() -> this.foo()
    Tree newTree =  `(invokeExpMJName (this)
		      ,(args[0]) ,(args[1]));
    return remakeTree(newTree, tree);
  }
}
#+old
class MJInvoke1MJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    // foo() -> ((mj.lang.ss.SS)(mjc.SS.instance)).foo()
    Tree newTree =  `(invokeExpMJName
		      (cast (name (id mj) (id lang) (id ss) (id SS))
		       (fieldStatic (name (id mjc) (id SS)) (id instance)))
		      ,(args[0]) ,(args[1]));
    return remakeTree(newTree, tree);
  }
}

class MJInvokeExpMJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    Tree methodName = args[1];	// MJName
    Tree methodArgs = args[2];
    Object[] pair;
    try {
      Obj epp = (Obj)Dynamic.get(:epp);
      pair = epp!typeCheckAndSelectMJMethod(targetType,
					    methodName,
					    methodArgs);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MJMethodInfo selectedMethod = (MJMethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];

    Type definer = selectedMethod.getDeclaringClass();

    if (definer.tag() == :class) {
      ClassInfo classInfo = ((ClassType)definer).classInfo();
      Symbol classFullName = classInfo.getName();
      if (classInfo.isInterface()){
	// MJ interface $B$,(B Java interface $B$+$i7Q>5$7$?(B Java method $B!#(B
	Tree newTree = `(mjJavaInterfaceInvokeExp
			 ,exp
			 ,(new Identifier(classFullName))
			 ,(new Identifier(selectedMethod.getName()))
			 ,newMethodArgs);
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
					 newTree.args());
      } else {
	//  Java method $B!J(BJava class/interface $B$,Dj5A$7$?(B method $B!K!#(B
	Tree newTree;
	if (MJC.hasModifier(:protected, selectedMethod.getModifiers())){
	  // $B%"%/%;%98"$,$"$k$+$I$&$+$N%A%'%C%/$O>JN,!#(B
	  //$B!J$J$$>l9g$O:G0-!"<B9T;~$K(B ClassCastException $B$K$J$k!)!K(B
	  newTree = `(mjJavaProtectedInvokeExp
		      ,exp
		      ,(new Identifier(selectedMethod.declaringModule))
		      ,(new Identifier(classFullName))
		      ,(new Identifier(selectedMethod.getName()))
		      ,newMethodArgs);
	} else {
	  newTree = `(mjJavaInvokeExp
		      ,exp
		      ,(new Identifier(selectedMethod.declaringModule))
		      ,(new Identifier(classFullName))
		      ,(new Identifier(selectedMethod.getName()))
		      ,newMethodArgs);
	}
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
					 newTree.args());
      }

    } else if (definer.tag() == :MJclass) {
      // MJ method $B!J(BMJ class/interface $B$,Dj5A$7$?(B method $B!K!#(B
      // Java interface $B$r(B MJ class $B$G<BAu$7$?>l9g$b$3$3!#(B
      Symbol classFullName
	= ((MJClassType)definer).mjClassInfo().getName();
      Tree newTree = `(mjInvokeExp
		       ,exp
		       ,(new Identifier(selectedMethod.declaringModule))
		       ,(new Identifier(classFullName))
		       ,(MJC.fullNameToId(selectedMethod.moduleName,
					  selectedMethod.getName()))
		       ,newMethodArgs);
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				       newTree.args());
    } else {
      throw MJC.fatal(""+ tree+ definer);
    }
  }
}


class MJInvokeStaticMJNameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree typeName = typeCheckTree(args[0]);
    Type targetType = typeName.type();
    Tree methodName = args[1];	// MJName
    Tree methodArgs = args[2];
    Object[] pair;
    try {
      Obj epp = (Obj)Dynamic.get(:epp);
      pair = epp!typeCheckAndSelectMJMethod(targetType,
					    methodName,
					    methodArgs);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MJMethodInfo selectedMethod = (MJMethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];

    // Check if it is a static method.
    {
      if (! MJC.hasModifier(:static,
			    `(modifiers ,@(selectedMethod.getModifiers())))){
	throw errorAt(tree, "The method "+ MJC.mjNameToString(methodName)+
		      " is not a static method.");
      }
    }

    Type definer = selectedMethod.getDeclaringClass();

    if (definer.tag() == :class) {
#+comment
      {
      ClassInfo classInfo = ((ClassType)definer).classInfo();
      Symbol classFullName = classInfo.getName();
      if (classInfo.isInterface()){
	// MJ interface $B$,(B Java interface $B$+$i7Q>5$7$?(B Java method $B!#(B
	Tree newTree = `(mjJavaInterfaceInvokeStatic
			 ,exp
			 ,(new Identifier(classFullName))
			 ,(new Identifier(selectedMethod.getName()))
			 ,newMethodArgs);
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
					 newTree.args());
      } else {
	//  Java method $B!J(BJava class/interface $B$,Dj5A$7$?(B method $B!K!#(B
	Tree newTree;
	if (MJC.hasModifier(:protected, selectedMethod.getModifiers())){
	  // $B%"%/%;%98"$,$"$k$+$I$&$+$N%A%'%C%/$O>JN,!#(B
	  //$B!J$J$$>l9g$O:G0-!"<B9T;~$K(B ClassCastException $B$K$J$k!)!K(B
	  newTree = `(mjJavaProtectedInvokeStatic
		      ,exp
		      ,(new Identifier(selectedMethod.declaringModule))
		      ,(new Identifier(classFullName))
		      ,(new Identifier(selectedMethod.getName()))
		      ,newMethodArgs);
	} else {
	  newTree = `(mjJavaInvokeStatic
		      ,exp
		      ,(new Identifier(selectedMethod.declaringModule))
		      ,(new Identifier(classFullName))
		      ,(new Identifier(selectedMethod.getName()))
		      ,newMethodArgs);
	}
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
					 newTree.args());
      }
      }

      throw errorAt(tree, "MJ: Inherited static method invocation is not fully supported by current MJ.");

    } else if (definer.tag() == :MJclass) {
      // MJ static method $B!J(BMJ class $B$,Dj5A$7$?(B static method $B!K!#(B
      Symbol classFullName
	= ((MJClassType)definer).mjClassInfo().getName();
      Tree newTree = `(mjInvokeStatic
		       ,typeName
		       ,(new Identifier(selectedMethod.declaringModule))
		       ,(new Identifier(classFullName))
		       ,(MJC.fullNameToId(selectedMethod.moduleName,
					  selectedMethod.getName()))
		       ,newMethodArgs);
      newTree = remakeTree(newTree, tree);
      return newTree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				       newTree.args());
    } else {
      throw MJC.fatal(""+ tree+ definer);
    }
  }
}



class MJOriginalTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree argumentList = typeCheckTree(args[0]);
    Tree[] aparams = argumentList.args();

    MJMethodInfo mjMethodInfo
      = (MJMethodInfo)Dynamic.get(:currentMethod);
    // $B0z?t$r7?%A%'%C%/!#(B
    Type[] fparams = mjMethodInfo.getParameterTypes();
    // $B%Q%i%a%?$N?t$@$1$O$3$3$G%A%'%C%/!#(B
    if (aparams.length != fparams.length){
      throw errorAt(tree, "MJ: The original method requires "+ fparams.length+
		    " parameters but "+ aparams.length+
		    " were supplied.");
    }
    // $B%Q%i%a%?$N7?$,4V0c$C$F$$$k>l9g$O!"$3$NCf$G%(%i!<$K$J$k!#(B
    Obj epp = (Obj)Dynamic.get(:epp);
    Tree newArgumentList = epp!coerceArgumentList(argumentList,
						  mjMethodInfo);
    mjMethodInfo.containsOriginal = true;
    Tree[] newArgs = { newArgumentList };
    return tree.modifyTypeAndArgs(mjMethodInfo.getReturnType(),
				  newArgs);
  }
}


class MJNewDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree[] newArgs = { typeTree,
		       typeCheckTree(args[1])};
    if (typeTree.type().tag() == :MJclass){
      // new C(...) -> new C()._call_init_C(...)
      Symbol classSimpleName = ((MJClassType)typeTree.type()).getSimpleName();
      Tree initializerName = (new Identifier(Symbol.intern("_call_init_"+
							   classSimpleName)));
      Tree newTree = `(invokeExp
		       (mjNew ,(newArgs[0]) (argumentList))
		       ,initializerName
		       ,(newArgs[1]));

      //old Tree newTree = `(mjNew ,@newArgs);

      return remakeTree(newTree, tree);
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

// $B$d$k$3$H$O(B NewTypeChecker $B$HF1$8!#(B
// Translator $B$NJ}$,0c$&!#!J(B B $B$N7?$K%-%c%9%H$9$k!#!K(B
// Actually, I should call selectMostSpecificMethod
//and coerceArgumentList.
class MJNewTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree[] newArgs = { typeNameCheckTree(args[0]),
		       typeCheckTree(args[1])};
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}


class MJAnonymousClassDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    //(anonymousClass Name ArgumentList (classBody ClassBodyDeclaration*))
    Tree newName	= TypeNameChecker.typeNameCheckTree(tree.args()[0]);
    Tree newArgumentList = typeCheckTree(tree.args()[1]);
    Tree classBody	= tree.args()[2];
    if (newName.type().tag() == :MJclass){
      throw errorAt(newName, "MJ does not support creating anonymous class"+
		    " of MJ class : "+ newName.type().classInfo().getName());
    } else {
      Tree[] newArgs = { newName, newArgumentList, classBody };
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

class MJClassLiteralTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw MJC.fatal("Type checking of class literal is not implemented.");
  }
}


class VariableDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass) {
      // anonymous class $B$N>l9g!#(B
      return orig.call(tree);
    }

    // field $B$r(B typeOfThis $B$+$i8!:w!#(B
    MJClassInfo mjClassInfo = ((MJClassType)typeOfThis).mjClassInfo();
    Vec<MJFieldInfo> selectedFields
      = mjClassInfo.getMJFields(tree.idName())
	ifNull {
	  selectedFields = null;
	};

    // $B%m!<%+%kJQ?t$O!"(B varEnv $B$+$i8!:w!#(B
    VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
    Type t = varEnv.lookup(tree.idName()).type()
      ifNotFound{ t = null; };

    if (selectedFields != null && t != null){
#+old
      throw error("MJ: Ambiguous variable name \""+ tree.idName()+ "\" . "+
		  " Please rename the local variable name or the field name.");

      // Local variable can shadow fields.
      return tree.modifyTypeAndArgs(t, tree.args());
      

    } else if (selectedFields != null){
      Tree newTree = `(fieldExp (this) ,tree);
      return remakeTree(newTree, tree);
    } else if (t != null){
      return tree.modifyTypeAndArgs(t, tree.args());
    } else {
      throw error("Undefined variable: "+ tree.idName());
    }
  }
}

class MJCastTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // (mjCast Type Expression)
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree exp = typeCheckTree(args[1]);
    return tree.modifyTypeAndArgs(typeTree.type(),
				  new Tree[]{ typeTree, exp });
  }
}

class MJThisDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 0);
    // $B$3$NCf4V%N!<%I$O!"(B coerce $B$G$N%-%c%9%H=hM}$H$OJL$NM}M3$GI,MW!#(B
    // Ls $B$G$O(B this $B$N7?$O(B B $B$G$"$C$F$b!"(B Li $B$G$O(B _Delta_B $B$J$N$G!"(B
    //$B%-%c%9%H$9$k%3!<%I$rA^F~$9$kI,MW$,$"$k!#$=$3$GCf4V%N!<%I$rF3F~!#(B
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass) {
      return orig.call(tree);
    }
    Tree newTree = `(mjThis ,(((MJClassType)typeOfThis).toTree()));
    return remakeTree(newTree, tree);
  }
}

class MJThisTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree typeTree = typeNameCheckTree(tree.args()[0]);
    Tree[] newArgs = { typeTree };
    return tree.modifyTypeAndArgs(typeTree.type(), newArgs);
  }
}

class MJInvokeSuperConstructorDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    // super(...) -> _init_S(...)
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass){
      // anonymousClass $B$NFbIt$N>l9g!#(B
      return orig.call(tree);
    } else {
      Tree argumentList = tree.args()[0];
      Type superclassType = typeOfThis.classInfo().getSuperclass();
      if (superclassType.tag() != :MJclass){
	if (argumentList.args().length == 0){
	  return `(emptyStatement);
	} else {
	  throw errorAt(tree,
			"MJ: Invocation of super constructor defined at "+
			"the Java language is not supported.");
	}
      } else {
	Symbol classSimpleName = ((MJClassType)superclassType).getSimpleName();
	Tree initializerName
	  = (new Identifier(Symbol.intern("_init_"+ classSimpleName)));
	Tree newTree = `(invoke1 ,initializerName ,argumentList);
	return TypeChecker.remakeTree(newTree, tree);
      }
    }
  }
}

class MJInvokeThisConstructorDecorator extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    // this(...) -> _init_C(...)
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :MJclass){
      // anonymousClass $B$NFbIt$N>l9g!#(B
      return orig.call(tree);
    } else {
      Symbol classSimpleName = ((MJClassType)typeOfThis).getSimpleName();
      Tree initializerName
	= (new Identifier(Symbol.intern("_init_"+ classSimpleName)));
      Tree newTree = `(invoke1 ,initializerName ,(tree.args()[0]));
      return TypeChecker.remakeTree(newTree, tree);
    }
  }
}



class MJConstructorAndMethodTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    if (! (tree.tag() == :mjConstructor || tree.tag() == :mjMethod)){
      throw Epp.fatal(""+ tree);
    }
    if (tree.tag() == :mjConstructor){
      throw errorAt(tree, "MJ: Constructor definition is not supported.");
    }
    checkArgsLength(tree, 7);
    Tree[] args = tree.args();
    Tree retType = typeNameCheckTree(args[2]);
    Tree mjName = args[3];
    Tree formalParameters = args[4];
    Tree[] params = formalParameters.args();
    Tree body = args[6];

    VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
    Tree[] newParams = new Tree[params.length];
    for (int i = 0; i < params.length; i++){
      // (pdecl (modifiers Modifier*) Type Identifier)
      Tree[] pargs = params[i].args();

      Tree paramTypeTree = typeNameCheckTree(pargs[1]);
      Tree[] declaredVars = new Tree[1];
      Tree newVarId = checkVariableDeclaratorId(paramTypeTree.type(),
						pargs[2],
						declaredVars);
      Tree var = declaredVars[0];
      varEnv =  new VarEnv(var.idName(),
			   new VarInfo(pargs[0].args(),
				       var.type()),
			   varEnv);
      Tree[] newPargs = { pargs[0], paramTypeTree, newVarId };
      newParams[i] = params[i].modifyTypeAndArgs(Type.Tvoid, newPargs);
    }
    Tree newFormalParameters
      = formalParameters.modifyTypeAndArgs(Type.Tvoid, newParams);
    
    Tree thrs = typeCheckTree(args[5]);

    Obj epp = (Obj)Dynamic.get(:epp);
    Tree newBody;

    MJMethodInfo currentMJMethodInfo
      = MJC.findMethodInfo((Type)Dynamic.get(:typeOfThis),
			   mjName,
			   newFormalParameters);

    Dynamic.bind(:currentMethod, currentMJMethodInfo);
    Dynamic.bind(:varEnv, varEnv);
    Dynamic.bind(:returnValueType, retType.type());
    try {
      newBody = epp!typeCheckMethodBody(body);
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
      Dynamic.unbind();
    }
    Tree[] newArgs = {args[0], args[1], retType, mjName,
		      newFormalParameters,
		      thrs,
		      newBody};
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}


class MJClassTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree className = MJC.mjNameToName(args[3]);
    
    TypeNameTable typeNameTable
      = (TypeNameTable)Dynamic.get(:typeNameTable);
    Type typeOfThis;
    try {
      // $B<+J,$NL>A0!JC1=cL>!K$O!"$3$N4D6-$KEPO?$5$l$F$$$k$b$N$H2>Dj!#(B
      typeOfThis = typeNameTable.get(className);
    } catch (NotFound e){
      throw Epp.fatal(""+ className.nameToString());
    }

    Tree extds = typeCheckTree(args[4]);
    Tree impls = typeCheckTree(args[5]);

    Dynamic.bind(:typeOfThis, typeOfThis);
    try {
      Tree newClassBody;
      newClassBody = typeCheckTree(args[6]);

      Tree[] newArgs = {args[0], args[1], args[2], args[3],
			extds, impls, newClassBody}; 

      return tree.modifyTypeAndArgs(typeOfThis, newArgs);
    } finally {
      Dynamic.unbind();
    }
  }
}

class MJModuleTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 4);
    Tree[] args = tree.args();

    Symbol moduleName = Symbol.intern(args[1].nameToString());


    MJModuleInfo currentModule = MJModuleTable.instance.get(moduleName);

    Tree decls;

    Dynamic.bind(:currentModule, currentModule);
    try {
      decls = typeCheckTree(args[3]);
    } finally {
      Dynamic.unbind();
    }
    Tree[] newTree = { args[0], args[1], args[2], decls };
    return tree.modifyTypeAndArgs(Type.Tvoid, newTree);
  }
}
