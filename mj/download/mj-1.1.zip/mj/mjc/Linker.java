/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */


#epp jp.go.etl.epp.EppLibLevel0


package mjc;

import de.fub.bytecode.*;
import de.fub.bytecode.classfile.*;

import java.lang.reflect.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MJLinker {
  public EditedClassLoader loader = new EditedClassLoader();
  
  public static String MJ_DUMP_PROPERTY_NAME = "mj.dump";
  public static boolean dumpClassFile = false;

  // $B$3$N%a%=%C%I$O!"(B globalProcessAfterTypeCheckingPass() $B$+$i8F$P$l$k!#(B
  // $B$9$G$K7?4X78$N4D6-@_Dj$,=*$o$C$?>uBV$G8F$S=P$5$l$k!#(B
  public void doLink() {
    if (Opts.log) Opts.out.println("MJLinker: Start doLink.");

    // dump $B%*%W%7%g%s(B(property mj.dump) $B$r%A%'%C%/!#(B
    checkDumpOption();

    // dump $B%*%W%7%g%s$,IU$$$F$$$k>l9g$O!"(B runtime $B$r(B dump $B$9$k!#(B
    dumpRuntimeClasses();

    // $B>!<j$K(B MJModuleTable $B$N%$%s%9%?%s%9$r:n$j$J$*$9!#(B
    MJModuleTable mjModuleTable = new MJModuleTable();
    MJModuleTable.instance = mjModuleTable;

    Symbol[] selectedModules = getSelectedModuleNames();
    
    // selectedModules $B$,$9$Y$FB8:_$9$k$+$I$&$+$r3NG'!#(B
    foreach (Symbol moduleName in selectedModules){
      MJModuleInfo m = mjModuleTable.loadAndAddModule(moduleName)
	ifNull{ throw MJLinker.error("Selected module "+ moduleName+
				     " not found."); };
    }

    // $BJd40%b%8%e!<%k$N%j%9%H$rF@$k!#(B
    Vec<Symbol> complerModules
      = new ComplementaryModuleManager(mjModuleTable)
      .checkComplementaryModules();

    Symbol bottomModuleName = :_bottom;

    // bottom module $B$r<j:n$j$7$FF~$l$k!#(B
    {
      TreeVec superModuleNameTrees = new TreeVec();
      foreach (Symbol moduleName in selectedModules){
	superModuleNameTrees
	  .add(Tree.stringToNameTree(moduleName.toString()));
      }
      foreach (Symbol moduleName in complerModules){
	superModuleNameTrees
	  .add(Tree.stringToNameTree(moduleName.toString()));
      }
      mjModuleTable.addHandMadeModule(bottomModuleName,
				      `(moduleSig
					(mjInfo)
					(name
					 ,(new Identifier(bottomModuleName)))
					(mjModuleHeaderDeclarations
					 (extendingModules
					  ,superModuleNameTrees))
					(mjTypeDeclarations)));
    }

    MJModuleInfo module = mjModuleTable.get(bottomModuleName);

    // $B$9$Y$F$N(B module $B$r=i4|2=!#(B
    mjModuleTable.initAllModules();



    // $B$9$Y$F$N(B mjMethodInfo $B$r(B log $B$K=PNO!#(B
    // $B!J$3$3$G!"%a%=%C%I@\B3@)Ls$b!J0lIt!K%A%'%C%/$5$l$k!#!K(B
    // abstract method $B$N%A%'%C%/$r$d$m$&!#(B
    Dynamic.bind(:currentModule, module);
    try {
      foreach (Vec<Symbol> vec in module.usingTypeNameTable.valueIter()){
	foreach (Symbol typeName in vec){
	  checkMJClassInfo(module.getMJClassInfo(typeName));
	}
      }
    } finally {
      Dynamic.unbind();
    }

    // link $B$9$k!#(B
    link(module.linearizedUsingModules);

    // start
    if (Opts.log) Opts.out.println("Start main.");
    try {
      startMain(mjMainArgs);
    } catch (Throwable e){
      // stack trace $B$O$3$3$G=P$9!#(B

      System.err.println(e.getMessage());
      if (Opts.log) Opts.out.println(e.getMessage());
      e.printStackTrace(System.err);
      if (Opts.log) e.printStackTrace(Opts.out);

      Throwable e0 = null;
      if (e instanceof ExceptionInInitializerError){
	e0 = ((ExceptionInInitializerError)e).getException();
      } else if (e instanceof InvocationTargetException){
	e0 = ((InvocationTargetException)e).getTargetException();
      }
      if (e0 != null){
	System.err.println(e0.getMessage());
	if (Opts.log) Opts.out.println(e0.getMessage());
	e0.printStackTrace(System.err);
	if (Opts.log) e0.printStackTrace(Opts.out);
      }

      throw new Error("Error during executing main.");
    }
    if (Opts.log) Opts.out.println("End main.");
  }

  //--------------------------------------------------

  public static String selectedModules; // mjc.MJ $B$G@_Dj$5$l$k!#(B
  public Symbol[] getSelectedModuleNames() {
#+old String prop = System.getProperty("mj.selected");
    String prop = selectedModules;
    if (prop == null) throw MJC.fatal("");
    if (prop.equals("")){
      System.err.println("Usage: mj moduleName");
      System.exit(1);
    }
    
    Vec<String> vec1 = parseProperty(prop);
    Vec<Symbol> vec2 = {};
    foreach (String str in vec1){
      vec2.push(Symbol.intern(str));
    }
    return vec2.toArray();
  }

  public static boolean linkModeFlag = false; // mjc.MJ $B$G@_Dj$5$l$k!#(B
#+old
  public static void checkLinkerOption(){
    String prop = System.getProperty("mj.selected");
    linkModeFlag = (prop != null);
  }

  // class MJ $B$G@_Dj$5$l$k!#(B
  public static String[] mjMainArgs = new String[]{};

  public static Vec<String> parseProperty(String prop){
    Vec<String> vec = {};
    if (prop == null) return vec;

    EppInputStream in = new EppInputStream(prop.toCharArray());
    while (true){
      skipWhiteSpace(in);
      if (in.isEof()) break;
      vec.push(readOneArg(in));
    }
    return vec;
  }

  public static void skipWhiteSpace(EppInputStream in){
    char c;
    while (true) {
      if (in.isEof()) return;
      c = in.getc();
      if (! Character.isWhitespace(c)) {
	in.ungetc(c);
	break;
      }
    }
  }

  public static String readOneArg(EppInputStream in){
    StringBuffer buf = new StringBuffer();
    char c;
    while (true) {
      if (in.isEof()) break;
      c = in.getc();
      if (Character.isWhitespace(c)) {
	in.ungetc(c);
	break;
      }
      buf.append(c);
    }
    return buf.toString();
  }


  //--------------------------------------------------
  // link time check

  public void checkMJClassInfo(MJClassInfo mjClassInfo){
    if (! MJC.hasModifier(:abstract, mjClassInfo.getModifiers())){
      foreach (Vec<MJMethodInfo> vec in mjClassInfo.methodTable.valueIter()){
	foreach (MJMethodInfo m in vec){
	  if (MJC.hasModifier(:abstract, m.getModifiers())){
	    throw MJLinker.error("non-abstract class "+ mjClassInfo.getName()+
				 " has an abstract method : "+ m);
	  }
	}
      }
    }
  }

  //--------------------------------------------------

  public void startMain(String[] gArgs) throws Throwable {
    // dump $B%*%W%7%g%s$,IU$$$F$$$J$$$H$-$N$_<B9T!#(B
    //$B!J$D$$$F$$$k$N$K<B9T$9$k$H!"(B ClassCastException $B$,=P$k!#(B
    if (! MJLinker.dumpClassFile){
      Class c = loader.loadClass("mj.lang.ss.SS");
      SS x = (SS)c.newInstance();
      x.setInstance(x);
      x._init_SS();
      String mainMethodName = System.getProperty("mj.mainMethodName");
      if (mainMethodName == null || mainMethodName.equals("main")){
	x.main(gArgs);
	
      } else {
	// Currently, only method FQN is supported.
	// For example, -Dmjc.main=epp.testCase.test
	String methodFQN = mainMethodName.replace('.', '_');
	Class[] paramTypes = {gArgs.getClass()}; // String[]
	java.lang.reflect.Method m = c.getMethod(methodFQN, paramTypes);
	m.invoke(x, new Object[]{gArgs});
      }
    }
  }


  // key : Symbol (class full name), val : Vector of MJClassData
  // Vec $B$O!"$=$N%/%i%9$N(B super class $B$d(B interface $B$N(B MJClassData $B$O4^$^$J$$!#(B
  public Table<Symbol,Vec<MJClassData> > mjClassDataTable;

  // key : Symbol (class full name), val : Vector of deltaLiName
  // Vec $B$O!"$=$N%/%i%9$N(B super class $B$d(B interface $B$N(B MJClassData $B$O4^$^$J$$!#(B
  public Table<Symbol,Vec<Symbol> > deltaLiNameTable;

  // _G_A -> A $B$H$$$&%/%i%9L>$NJQ49$r9T$&$?$a$N(B replaceTable $B$r:n$k!#(B
  public Table<Symbol, Symbol> replaceTable;
    
    // $B3F%/%i%9$r(B link $B$7$F!"(B EditedClassLoader $B$KEPO?!#(B
    Table<Symbol, Symbol> linkedClassNames = {};

  //--------------------------------------------------

  public void link(Vec<MJModuleInfo> sortedModules){

    mjClassDataTable = makeMJClassDataTable(sortedModules);

    deltaLiNameTable = makeDeltaLiNameTable(sortedModules);

    replaceTable = makeReplaceTable(mjClassDataTable);

    #+debug
    {
      mjClassDataTable.print();
      deltaLiNameTable.print();
      replaceTable.print();
    }
    
    foreach (Symbol className in mjClassDataTable.keyIter()){
      linkMJClassesOrInterfaces(className);
    }
  }


  public Table<Symbol,Vec<MJClassData> > makeMJClassDataTable(Vec<MJModuleInfo>
							      sortedModules) {
    Table<Symbol,Vec<MJClassData> > mjClassDataTable = {};
    foreach (MJModuleInfo module in sortedModules){
      foreach (Symbol className, MJClassData d in module.mjClassDataTable){
	Vec<MJClassData> vec = mjClassDataTable.get(className)
	  ifNull {
	    vec = new Vec<MJClassData>();
	    mjClassDataTable.put(className, vec);
	  };
	vec.push(d);
      }
    }
    return mjClassDataTable;
  }

  public Table<Symbol,Vec<Symbol> > makeDeltaLiNameTable(Vec<MJModuleInfo>
							 sortedModules) {
    Table<Symbol,Vec<Symbol> > deltaLiNameTable = {};
    foreach (MJModuleInfo module in sortedModules){
      foreach (Symbol className, MJClassData d in module.mjClassDataTable){
	Vec<Symbol> vec = deltaLiNameTable.get(className)
	  ifNull {
	    vec = new Vec<Symbol>();
	    deltaLiNameTable.put(className, vec);
	  };
	Symbol deltaLiName
	  = MJC.makeDeltaLiName(module.moduleName, d.fullName);
	vec.push(deltaLiName);
      }
    }
    return deltaLiNameTable;
  }

  public Table<Symbol, Symbol> makeReplaceTable(Table<Symbol,
						Vec<MJClassData> >
						mjClassDataTable){
    Table<Symbol, Symbol> replaceTable = {};
    foreach (Symbol className in mjClassDataTable.keyIter()){
      // E.g. "a.b.c.D" -> "a.b.c._G_D"
      String generatorName = MJC.makeGeneratorClassName(className).toString();
      replaceTable.put(Symbol.intern(loader.classNameToUtf8(generatorName)),
		       Symbol.intern(loader.classNameToUtf8(className.toString())));
    }
    return replaceTable;
  }


  //--------------------------------------------------

  public void linkMJClassesOrInterfaces(Symbol className){
    Vec<MJClassData> vec = mjClassDataTable.get(className)
      ifNull { throw MJC.fatal(""+ className); };
    MJClassData firstMJClassData = vec.get(0);
    if (firstMJClassData.classKeyword == :class){
      linkMJClasses(className);
    } else if (firstMJClassData.classKeyword == :interface){
      linkMJInterfaces(className);
    } else {
      throw MJC.fatal(""+ firstMJClassData.classKeyword);
    }
  }

  // super class $B$b(B on demand $B$K(B linearize $B$9$k!#(B
  public void linkMJClasses(Symbol className){
    if (! linkedClassNames.containsKey(className)){
      // $B$3$N%/%i%9$,(B linkedClassNames $B$K$^$@F~$C$F$J$$>l9g$O!"(B link $B$9$k!#(B
      // $B!J$?$@$7!"$=$NA0$K!"(B super $B$H(B interface $B$r$^$:(B link $B$9$k!#!K(B

      Vec<MJClassData> vec = mjClassDataTable.get(className)
	ifNull { throw MJC.fatal(""+ className); };
      MJClassData firstMJClassData = vec.get(0);

      // implements $B$9$k(B interface $B$N(B link
      // $B$^$?!"(B $B3F(B delta $B$,(B implements $B$9$k(B interface $B$r=8$a$k!#(B
      Vec<String> interfaceNames = {};
      foreach (MJClassData mjClassData in vec){
	linkSuperInterfaces(mjClassData);
	foreach (Type t in mjClassData.interfaceTypes){
	  Symbol interfaceName;
	  if (t.tag() == :class){
	    interfaceName = ((ClassType)t).getName();

	  } else if (t.tag() == :MJclass){
	    interfaceName = ((MJClassType)t).getName();

	  } else {
	    throw MJC.fatal(""+ t);
	  }
	  interfaceNames.push(interfaceName.toString());
	}
      }

      Symbol superName;
      {
	// super $B$N(B link
	Type superType = firstMJClassData.superclassType;
	if (superType.tag() == :class){
	  superName
	    = MJC.makeJavaDeltaLiName(vec.get(0).moduleName,
				      ((ClassType)superType).getName());
	  // $B:F5"E*$K$O8F$P$J$$!#C1$K(B load $B$9$k$@$1!#(B
	  // $B!J$?$@$7=EJ#(B load $B$OHr$1$k!#!K(B
	  if (! linkedClassNames.containsKey(superName)){
	    try {
	      JavaClass superClass
		= loader.javaClassForName(superName.toString());
	      loader.javaClassToClass(superClass);
	    } catch (Exception e){
	      throw MJLinker.error(e.getMessage());
	    }
	    linkedClassNames.put(superName, :dummy);
	  }

	} else if (superType.tag() == :MJclass){
	  superName = ((MJClassType)superType).getName();
	  linkMJClasses(superName);

	} else {
	  throw MJC.fatal(""+ superType);
	}
      }

      // $B$3$N%/%i%9$r(B link $B$9$k!#(B
      // debug
      //System.err.println("className:"+ className);
      //System.err.println("superName:"+ superName);
      Vec<Symbol> deltaLiNameVec = deltaLiNameTable.get(className)
	ifNull { throw MJC.fatal(""+ className); };
      loader.linkAndDefineClass(superName,
				interfaceNames,
				deltaLiNameVec,
				className,
				replaceTable);
      linkedClassNames.put(className, :dummy);
    }
  }


  public void linkMJInterfaces(Symbol className){
    if (! linkedClassNames.containsKey(className)){
      // $B$3$N%/%i%9$,(B linkedClassNames $B$K$^$@F~$C$F$J$$>l9g$O!"(B link $B$9$k!#(B
      Vec<MJClassData> vec = mjClassDataTable.get(className)
	ifNull {
	  // $B%F!<%V%k$K$J$$$H$$$&$3$H$O!"(B MJ interface $B$G$O$J$/(B
	  // Java interfafe $B$J$N$G!"2?$b$7$J$$$GLa$k!#(B
	  return;
	};

      // super interface $B$r$^$:(B link $B$9$k(B $B!#(B
      foreach (MJClassData mjClassData in vec){
	linkSuperInterfaces(mjClassData);
      }

      // $BG0$N$?$a(B super $B$,(B null $B$G$"$k$3$H$r3NG'!#!J$"$H$G:o=|!#!K(B
      {
	MJClassData firstMJClassData = vec.get(0);
	if (firstMJClassData.superclassType != null){
	  throw MJC.fatal(""+ firstMJClassData);
	}
      }

      // $B$3$N(B interface $B$r(B link $B$9$k!#(B
      Vec<Symbol> deltaLiNameVec = deltaLiNameTable.get(className)
	ifNull { throw MJC.fatal(""+ className); };
      loader.linkAndDefineInterface(deltaLiNameVec,
				    className,
				    replaceTable);
      linkedClassNames.put(className, :dummy);
    }
  }

  // mjClassData $B$,(B implements $B$9$k(B interface $B$r(B link $B!#(B
  public void linkSuperInterfaces(MJClassData mjClassData){
    foreach (Type t in mjClassData.interfaceTypes){
      Symbol interfaceName;
      // $B!J$3$3$G(B t.classInfo() $B$r<h$k$H$J$<$+%(%i!<$K$J$k$N$G!"(B
      //   classInfo $B$r:n$i$:$KL>A0$r<hF@$9$k!#!K(B
      if (t.tag() == :class){
	interfaceName = ((ClassType)t).getName();

      } else if (t.tag() == :MJclass){
	interfaceName = ((MJClassType)t).getName();

      } else {
	throw MJC.fatal(""+ t);
      }

      linkMJInterfaces(interfaceName);
    }
  }


  //--------------------------------------------------

  public void checkDumpOption(){
    String prop = System.getProperty(MJ_DUMP_PROPERTY_NAME);
    if (prop == null){
      dumpClassFile = false;
    } else if (prop.equals("false")){
      dumpClassFile = false;
    } else if (prop.equals("true")){
      dumpClassFile = true;
    } else {
      throw MJLinker.error("Illgal property value : "+
			   MJ_DUMP_PROPERTY_NAME+ "="+ prop);
    }
  }


  public static String[] runtimeClasses = { "mjc.Start", "mjc.SS" };
  public void dumpRuntimeClasses(){
    if (MJLinker.dumpClassFile){
      for (int i = 0; i < runtimeClasses.length; i++){
	dumpRuntimeClass(runtimeClasses[i]);
      }
    }
  }
  public void dumpRuntimeClass(String className){
    //System.err.println("Dump runtime class : "+ className);
    try {
      JavaClass javaClass = loader.javaClassForName(className);
      loader.javaClassToClass(javaClass);
    } catch (Throwable e){
      throw MJC.fatal(e.getMessage());
    }
  }

  public static Error error(String msg){
    msg = "MJLinker: "+ msg;
    System.err.println(msg);
    throw Epp.error(msg);
  }
}


//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------

public class ComplementaryModuleManager {
  public MJModuleTable mjModuleTable;

  // load $B$5$l$?Jd40%b%8%e!<%k!#(B
  public Vec<Symbol> complerModules = {};

  // $BJd40%b%8%e!<%k$H!"$=$l$,Jd40$9$k%b%8%e!<%k$N%j%9%H$N%F!<%V%k!#(B
  public Table<Symbol, Vec<Symbol> > complerTable = {};
  // $BJd40$5$l$k%b%8%e!<%k$H!"$=$l$rJd40$9$kJd40%b%8%e!<%k$N%j%9%H$N%F!<%V%k!#(B
  public Table<Symbol, Vec<Symbol> > compleeTable = {};

  public ComplementaryModuleManager(MJModuleTable mjModuleTable){
    this.mjModuleTable = mjModuleTable;
    // $B%G!<%?%Y!<%9$N=i4|2=!#(B
    initDatabase();
  }

  public Vec<Symbol> checkComplementaryModules(){
    // $B$^$:!"8=:_$N$H$3$m(B load $B$5$l$F$$$k%b%8%e!<%k$N%j%9%H$rF@$k!#(B
    Vec<Symbol> loadedModules = {};
    foreach (Symbol moduleName in 
	     mjModuleTable.mjModuleInfoTable.keyIter()){
      loadedModules.push(moduleName);
    }
    // $B$=$N%j%9%H$KBP$7$F!"Jd40%b%8%e!<%k$,I,MW$+$I$&$+$r#1$D$E$D%A%'%C%/!#(B
    // $BI,MW$K1~$8$F!"(B mjModuleTable $B$KJd40%b%8%e!<%k$,(B load $B$5$l$k!#(B
    foreach (Symbol moduleName in loadedModules){
      checkComplementaryModule(moduleName);
    }
    return complerModules;
  }

  public void initDatabase(){
    mjc.MJClassFileReader classFileReader = new mjc.MJClassFileReader();
    Object[] classPathDirs = classFileReader.classPathDirs;

    // CLASSPATH $B$r%9%-%c%s$7!"(B $BJd40%b%8%e!<%k%G!<%?%Y!<%9$r:n$k!#(B
    Vec<Symbol> complName = {};
    foreach (Object classPathElem in classPathDirs){
      if (classPathElem instanceof ZipFile) {
	// in case of archive file
	ZipFile zf = (ZipFile)classPathElem;
	// Even on windows, use '/' .
	String complPrefix = mjc.MJC.COMPLEMENTARY_PACKAGE_PREFIX+ '/';
	for (Enumeration e = zf.entries(); e.hasMoreElements();){
	  ZipEntry entry = (ZipEntry)e.nextElement();
	  //System.out.println(entry.getName());
	  if (entry.getName().startsWith(complPrefix)
	      && entry.getName()
	      .endsWith("/"+
			"MJComplementaryModuleDescripor.class")){
	    // ".class" $B$r$O$.<h$C$F%/%i%9L>$K$9$k!#(B
	    String path = entry.getName();
	    complName.push(Symbol.intern(path.substring(0, path.length() - 6)
					 .replace('/', '.')));
	  }
	}
      } else if (classPathElem instanceof String) {
	File dir = new File((String)classPathElem);
	if (dir.exists()) {
	  String[] list = dir.list(); // $B$H$j$"$($:%U%#%k%?$J$7!#(B
	  foreach (String f in list){
	    if (f.equals(mjc.MJC.COMPLEMENTARY_PACKAGE_PREFIX)){
	      getComplNamesRecursively(dir+ File.separator+ f,
				       f,
				       complName);
	    }
	  }
	}
      } else {
	throw MJC.fatal("");
      }
    }

    // load $B$5$l$?(B MJComplementaryModuleDescripor $B$N%/%i%9$N%F!<%V%k!#(B
    Table<Symbol, Class> loadedDesc = {};

    foreach (Symbol name in complName){
      try {
	// JavaVM $B$K%/%i%9$r(B load $B$5$;$k!#(B CLASSPATH $B$OIaDL$KC5:w$5$l$k!#(B
	// complName $B$K$OF1$8L>A0$,=EJ#$7$F$$$k2DG=@-$,$"$k$,!"(B
	// forName $B$O>o$K:G$bM%@h$9$k(B CLASSPATH $B$+$i(B load $B$9$k!#(B
	Class c = Class.forName(name.toString());
	loadedDesc.put(name, c);
      } catch (Throwable e){
	e.printStackTrace(System.err);
	throw MJC.fatal(""+ e);
      }
    }
    foreach (Class c in loadedDesc.valueIter()){
      Symbol moduleName;
      Symbol[] complees;
      try {
	java.lang.reflect.Field f1 = c.getField("moduleName");
	moduleName = Symbol.intern((String)f1.get(null));
	java.lang.reflect.Field f2 = c.getField("complements");
	String[] compleesStr = (String[])f2.get(null);
	Vec<Symbol> vec = {};
	foreach (String str in compleesStr){
	  vec.push(Symbol.intern(str));
	}
	complees = vec.toArray();
      } catch (Throwable e){
	e.printStackTrace(System.err);
	throw MJC.fatal(""+ e);
      }
      complerTable.put(moduleName, new Vec<Symbol>(complees));
      foreach (Symbol s in complees){
	Vec<Symbol> complers = compleeTable.get(s)
	  ifNull {
	    complers = new Vec<Symbol>();
	    compleeTable.put(s, complers);
	  };
	complers.push(moduleName);
      }
    }
    //complerTable.print("complerTable");
    //compleeTable.print("compleeTable");
  }

  public void getComplNamesRecursively(String path,
				       String className,
				       Vec<Symbol> complName){
    File f = new File(path);
    if (f.isDirectory()){
      String[] list = f.list();
      foreach (String s in list){
	getComplNamesRecursively(path+ File.separator+ s,
				 className+ "."+ s,
				 complName);
      }
    } else {
      if (path.endsWith(File.separator+
			"MJComplementaryModuleDescripor.class")){
	// ".class" $B$r$O$.<h$C$F%/%i%9L>$K$9$k!#(B
	complName.push(Symbol.intern(className
				     .substring(0, className.length() - 6)));
      }
    }
  }

  //--------------------------------------------------

  // $B%b%8%e!<%k$r#1$D!"?7$?$K(B load $B$9$k!#(B
  // $B?7$?$K(B load $B$5$l$?%b%8%e!<%k$O!"(B bottom $B$N(B super module $B$KIU$12C$($k!#(B
  public void loadComplementaryModule(Symbol name){
    if (isAlreadyLoaded(name)) return;

    if (Opts.log) Opts.out.println("ComplementaryModuleManager: load "+ name);
    MJModuleInfo m = mjModuleTable.loadAndAddModule(name)
      ifNull { throw MJC.fatal("Complementary module "+ name+
			       " not found.");
    };
    complerModules.push(name);
    // $B:F5"E*$KJd40%b%8%e!<%k$r%A%'%C%/!#(B
    checkComplementaryModule(name);
  }

  public void checkComplementaryModule(Symbol name){
    Vec<Symbol> complerVec = compleeTable.get(name)
      ifNull {
	// $B$3$N%b%8%e!<%k$rJd40$9$k%b%8%e!<%k$O$J$$$N$G!"(B return $B$9$k!#(B
	return;
      };
    // $B$3$3$NJd40%b%8%e!<%k$r!"(B load $B$9$Y$-$+$I$&$+$r8!::$9$k!#(B
    foreach (Symbol compler in complerVec){
      // $BJd40BP>]$N%b%8%e!<%k$,$9$Y$F(B load $B$:$_$J$i$P!"(B
      // $BJd40%b%8%e!<%k$r(B load $B$9$k!#(B

      // $B$^$:!"$3$NJd40%b%8%e!<%k$NJd40BP>]%b%8%e!<%k$rF@$k!#(B
      Vec<Symbol> compleeVec = complerTable.get(compler)
	ifNull { throw MJC.fatal(""+ compler); };
    tryNext:
      {
	foreach (Symbol complee in compleeVec){
	  if (! isAlreadyLoaded(complee)){
	    // $BJd40BP>]$,(B load $B$5$l$F$$$J$$!"$H$$$&$3$H$O!"(B
	    // $B$3$NJd40%b%8%e!<%k$O(B load $B$9$kI,MW$,$J$$!#(B
	    break tryNext;
	  }
	}
	// $B$3$NJd40%b%8%e!<%k$r(B load $B$9$Y$-$J$N$G(B load $B$9$k!#(B
	this.loadComplementaryModule(compler);
      }
    }

  }

  public boolean isAlreadyLoaded(Symbol name){
    MJModuleInfo info
      = mjModuleTable.mjModuleInfoTable.get(name) ifNull { return false; };
    return true;
  }

}


//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------

public class EditedClassLoader extends ClassLoader {

  public MJClassFileReader classFileReader = new MJClassFileReader();

  Hashtable classCache = new Hashtable();
  
  //--------------------------------------------------
  

  //$B0z?t$GM?$($i$l$?(B delta $B$r(B linearize $B$7$F!"(B
  //  Class $B$r(B defineClass $B$7$F%-%c%C%7%e$KF~$l$F$*$/!#(B
  //$B!J(BjavaClassToClass $B$r8F$S=P$9$H(B defineClass $B$5$l$k!#!K(B
  //$B!J$"$H$G!"(B loadClass $B$,8F$P$l$?;~$K!"$=$N%-%c%C%7%e$+$i<h$j=P$7$FJV$9!#!K(B
  //$B!&$H$j$"$($:(B interface $B$N$3$H$O9M$($J$$!#(B
  //$B!&$3$N%a%=%C%ICf$K=P$F$/$k(B Class $B$O!"$3$N(B ClassLoader $B$G(B load $B$7$?$b$N!#(B
  public void linkAndDefineClass(Symbol superName,
				 Vec<String> interfaceNames,
				 Vec<Symbol> deltaNames,
				 Symbol className,
				 Table<Symbol, Symbol> replaceTable) {
    try {
      JavaClass lastSuper = javaClassForName(superName.toString());
      
      foreach (Symbol name in deltaNames){
	//Opts.out.println("Setting superclass for "+ name);
	JavaClass jc = javaClassForName(name.toString());

	linkInnerClasses(jc, replaceTable);

	setSuperclass(jc, lastSuper);
	replaceClassNames(jc, replaceTable); // G_A -> A
	//printConstantPool(jc);
	lastSuper = jc;
	javaClassToClass(lastSuper);
      }

      JavaClass bottomClass = javaClassForName(className.toString());
      setSuperclass(bottomClass, lastSuper);
      replaceClassNames(bottomClass, replaceTable); // G_A -> A

      // interface $B$NDI2C(B
      {
	int[] interfaceIndexes = new int[interfaceNames.size()];
	foreach (int i, String name in interfaceNames){
	  int index = addClassToConstantPool(bottomClass, name);
	  interfaceIndexes[i] = index;
	}
	bottomClass.setInterfaceNames(interfaceNames.toArray());
	bottomClass.setInterfaces(interfaceIndexes);
      }

      // abstract modifier $B$r$O$:$9!#(B
      {
	int flags = bottomClass.getAccessFlags();
	flags &= (~ de.fub.bytecode.Constants.ACC_ABSTRACT);
	bottomClass.setAccessFlags(flags);
      }


      //printConstantPool(bottomClass);
      javaClassToClass(bottomClass);

    } catch (Exception e){
      e.printStackTrace();
      throw MJC.fatal(e.getMessage());
    }
  }


  // JavaClass $B$NCf$N(B constant_pool $B$N%/%i%9L>$r%9%-%c%s$7$F!"(B
  // $ $B$G$O$8$^$k%/%i%9L>$,$"$l$P!"$=$l$r(B link $B$9$k!#(B
  public Table<String, Symbol> linkedInnerClasses = {};
  public void linkInnerClasses(JavaClass jc,
			       Table<Symbol, Symbol> replaceTable)
    throws Exception {
    //Opts.out.println("**** linkInnerClasses: "+ jc.getClassName());
    Constant[] constant_pool = jc.getConstantPool().getConstantPool();
    for (int i = 1; i < constant_pool.length; i++){
      if (constant_pool[i] instanceof ConstantClass){
	ConstantClass cc = (ConstantClass)constant_pool[i];
	ConstantUtf8 nameConstantUtf8
	  = (ConstantUtf8)constant_pool[cc.getNameIndex()];
	String nameUtf8 = nameConstantUtf8.getBytes();
	if (nameUtf8.indexOf('$') != -1){
	  String className = utf8ToClassName(nameUtf8);
	  if (! linkedInnerClasses.containsKey(className)){
	    linkedInnerClasses.put(className, :dummy);
	    JavaClass inner = javaClassForName(className);
	    replaceClassNames(inner, replaceTable); // G_A -> A
	    javaClassToClass(inner);
	  }
	}
      }
    }
  }
  
  public void setSuperclass(JavaClass jc, JavaClass superClass){

    String origSuperName = jc.getSuperclassName();

    // constant pool $B$NJ}$r=q$-49$($k$N$G!"(B setSuperclassName $B$OITMW!#(B
    /* old
    int class_index = addClassToConstantPool(jc, superClass.getClassName());
    jc.setSuperclassName(superClass.getClassName());
    jc.setSuperclassNameIndex(class_index);
    */

    // <init> $B$d(B super.m() $B$J$I$,!"8E$$(B super class $B$NL>A0$r;2>H$7$F$$$k$N$G!"(B
    //$B$=$l$r?7$7$$(B super $B$KJQ99$9$k!#(B
    replaceClassName(jc, origSuperName, superClass.getClassName());
  }

  public void linkAndDefineInterface(Vec<Symbol> deltaNames,
				     Symbol interfaceName,
				     Table<Symbol, Symbol> replaceTable) {
    // class $B$H$OA4$/0c$&=hM}!#(B
    // bottomInterface $B$K$9$Y$F$N(B delta $B$r(B extends $B$5$;$k!#(B
    // replaceTable $B$N=hM}$OITMW$+!#(B
    try {
      JavaClass bottomInterface = javaClassForName(interfaceName.toString());

      // $BG0$N$?$a!#(B
      if (bottomInterface.getInterfaceNames().length != 0){
	foreach (String name in bottomInterface.getInterfaceNames()){
	  System.err.println("  "+ name);
	}
	throw MJC.fatal("linkAndDefineInterface:"+ interfaceName);
      }

      String[] interfaceNames = new String[deltaNames.size()];
      int[] interfaceIndexes = new int[deltaNames.size()];
      foreach (int i, Symbol sym in deltaNames){
	String name = sym.toString();
	int index = addClassToConstantPool(bottomInterface, name);
	interfaceNames[i] = name;
	interfaceIndexes[i] = index;

	// $B$3$N(B link $B$N=gHV$O!"$^$:$$!#(B
	// delta interface $B$,B>$N(B interface $B$r(B extends $B$7$F$$$k$H$-!"(B
	//$B=g=xDL$j$K(B link $B$5$l$J$/$J$C$F$7$^$&!#(B
	JavaClass jc = javaClassForName(name.toString()); 
	javaClassToClass(jc);
      }
      
      bottomInterface.setInterfaceNames(interfaceNames);
      bottomInterface.setInterfaces(interfaceIndexes);

      javaClassToClass(bottomInterface);

    } catch (Exception e){
      e.printStackTrace();
      throw MJC.fatal(e.getMessage());
    }
  }

  // jc $B$N(B constant pool $B$K!"%/%i%9(B className $B$rDI2C!#(B
  // $B?7$?$K3d$jEv$F$i$l$?(B class_index $B$rJV$9!#(B
  public int addClassToConstantPool(JavaClass jc, String className){
    //Opts.out.println("before addClassToConstantPool:"+ jc+ ":" className);
    //Opts.out.println(jc.getConstantPool().toString());

    Constant[] old_constant_pool = jc.getConstantPool().getConstantPool();
    Constant[] new_constant_pool = new Constant[old_constant_pool.length + 2];
    for (int i = 0; i < old_constant_pool.length; i++){
      new_constant_pool[i] = old_constant_pool[i];
    }
    // $BMWAG$r#2$DDI2C!##1$D$O!"%/%i%9L>$N(B Utf8 $B!#$b$&#1$D$O%/%i%9!#(B
    int name_index = old_constant_pool.length + 0;
    int class_index = old_constant_pool.length + 1;

    String classNameUtf8 = classNameToUtf8(className);
    new_constant_pool[name_index] = new ConstantUtf8(classNameUtf8);
    new_constant_pool[class_index] = new ConstantClass(name_index);

    jc.getConstantPool().setConstantPool(new_constant_pool);

    //Opts.out.println("after addClassToConstantPool:"+ jc+ ":" className);
    //Opts.out.println(jc.getConstantPool().toString());

    return class_index;
  }

  public void replaceClassName(JavaClass jc,
			       String oldClassName,
			       String newClassName){
    Table<Symbol, Symbol> replaceTable = {};
    replaceTable.put(Symbol.intern(classNameToUtf8(oldClassName)),
    		     Symbol.intern(classNameToUtf8(newClassName)));
    replaceClassNames(jc, replaceTable);
  }

  // replaceTable = key : Symbol (old class name),val : Symbol (new class name)
  //		both old and new class names are Utf8 encoded.
  public void replaceClassNames(JavaClass jc,
				Table<Symbol, Symbol> replaceTable){

    //Opts.out.println("replaceClassNames:before:"+ jc);
    //Opts.out.println(jc.getConstantPool().toString());

    Constant[] old_constant_pool = jc.getConstantPool().getConstantPool();
    Vector vec = new Vector();
    for (int i = 0; i < old_constant_pool.length; i++){
      vec.addElement(old_constant_pool[i]);
    }
    int newNameIndex = old_constant_pool.length - 1;

    // $B$a$s$I$&$J$N$G!"Kh2s$"$?$i$7$$(B Utf8 $B%(%s%H%j$r:n$k!#(B
    // $B!JK\Ev$O!"0lEY:n$C$?%(%s%H%j$r:FMxMQ$9$Y$-!#!K(B
    // $B$H$3$m$G!"0lHL$K!"%/%i%9L>$HJ8;zNs$,F1$8(B Utf8info $B$r6&M-$7F@$k!)(B
    for (int i = 1; i < old_constant_pool.length; i++){
      if (old_constant_pool[i] instanceof ConstantClass){
	ConstantClass cc = (ConstantClass)old_constant_pool[i];
	ConstantUtf8 oldNameConstantUtf8
	  = (ConstantUtf8)old_constant_pool[cc.getNameIndex()];
	Symbol oldName = Symbol.intern(oldNameConstantUtf8.getBytes());
	Symbol newName = replaceTable.get(oldName)
	  ifNull { newName = null; };
	if (newName != null){
	  // $B$^$:?7$7$$(B Utf8Info $B$r(B constant pool $B$KDI2C$9$k!#(B
	  ConstantUtf8 newNameConstantUtf8
	    = new ConstantUtf8(newName.toString());
	  vec.addElement(newNameConstantUtf8);
	  newNameIndex++;

	  // $B%/%i%9L>$r!"?7$7$/DI2C$7$?(B Utf8Info $B$KJQ99$9$k!#(B
	  cc.setNameIndex(newNameIndex);
	}
      }
    }
    Constant[] new_constant_pool = new Constant[vec.size()];
    vec.copyInto(new_constant_pool);
    jc.getConstantPool().setConstantPool(new_constant_pool);

    //Opts.out.println("replaceClassNames:after:"+ jc);
    //Opts.out.println(jc.getConstantPool().toString());
  }

  // "a.b.c" $B$N$h$&$J(B unicode $B%/%i%9L>$r(B "a/b/c" $B$H$$$&7A$N(B Utf8 $BJ8;zNs$KJQ49!#(B
  public String classNameToUtf8(String className){
    // $B:#$N$H$3$m%^%k%A%P%$%HJ8;z$K$OL$BP1~!#(B
    return className.replace('.', '/');
  }

  // "a/b/c" $B$N$h$&$J(B Utf8 $BJ8;zNs$r(B "a.b.c" $B$H$$$&7A$N(B unicode $B%/%i%9L>$KJQ49!#(B
  public String utf8ToClassName(String bytes){
    // $B:#$N$H$3$m%^%k%A%P%$%HJ8;z$K$OL$BP1~!#(B
    return bytes.replace('/', '.');
  }

  
  // $B$3$3!"%-%c%C%7%e$7$?J}$,$$$$$N$G$O!)(B
  // $B#1$D$N%/%i%9$,Bg@*$N%/%i%9$+$i7Q>5$5$l$k>l9g$b$"$j$&$k$N$G!#(B
  
  // $B0z?t$O(B Utf8 $B$G$O$J$/!"(B "." $B$G6h@Z$i$l$?(B unicode $B!#(B
  public JavaClass javaClassForName(String className) throws Exception {
    InputStream classFileInputStream
      = classFileReader.findClassFile(className);
    if (classFileInputStream == null){
      throw MJC.fatal("javaClassForName: The class is not found. : "+
			   className);
    }

    // ".class" $B$,$D$$$F$$$F$$$$$N$+!)(B symbolic debug $B$G$-$k$+$I$&$+;n$9$3$H!#(B
    String classFileName = className.replace('.', '/')+ ".class";

    ClassParser parser = new ClassParser(classFileInputStream,
					 classFileName);
    return parser.parse();
  }


  // JavaClass $B$r(B defineClass $B$7$F$3$N(B ClassLoader $B$N%-%c%C%7%e$KF~$l$k!#(B
  // return value $B$O(B void $B$K$9$Y$-$+$b!#(B
  public Class javaClassToClass(JavaClass jc) throws Exception {
    if (Opts.log){
      Opts.out.println("javaClassToClass for "+ jc.getClassName()+ 
		       " extends "+ jc.getSuperclassName());
      if (jc.getInterfaceNames().length > 0){
	Opts.out.println("\t\t implements ");
	foreach (String name in jc.getInterfaceNames()){
	  Opts.out.println("\t\t\t "+ name);
	}
      }
    }
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    jc.dump(new DataOutputStream(bout));
    byte[] buf = bout.toByteArray();
    Class c = defineClass(null,
			  buf, 0, buf.length);
    String name = jc.getClassName();
    classCache.put(name, c);

    dumpJavaClass(jc, buf);

    return c;
  }

  //--------------------------------------------------
  // ClassLoader
  
  public synchronized Class loadClass(String name, boolean resolve)
    throws ClassNotFoundException {
    if (Opts.log){
      Opts.out.println("loadClass : name = "+ name+ ", resolve = "+ resolve);
    }

    Class c;
    c = (Class)classCache.get(name);
    if (c == null){
      // SystemClass $B0J30!"$9$J$o$A(B MJ class $B$O!"(B
      // $B$9$G$K(B javaClassToClass $B$G%-%c%C%7%e$KEPO?$5$l$F$$$k$b$N$H$9$k!#(B
      c = findSystemClass(name);
      if (c == null){
	// findSystemClass $B$,(B null $B$rJV$9$3$H$O$J$$$O$:!#(B
	// ClassNotFoundException $B$rEj$2$k$3$H$O$"$k!#(B
	throw MJC.fatal("findSystemClass returns null. : "+ name);
      } else {
	classCache.put(name, c);
      }
    }
      
    //Opts.out.println("c = "+ c);
      
    if (resolve) resolveClass(c);
    return c;
  }


  //--------------------------------------------------

  // javaClassToClass $B$+$i8F$P$l$k!#(B
  // mj.dump=ture $B$J$i$P!"(B defineClass $B$9$k$?$S$K$=$N(B class file $B$r=PNO$9$k!#(B
  public void dumpJavaClass(JavaClass jc, byte[] buf) {
    if (MJLinker.dumpClassFile){
      try {
	String classFileName = makeClassFileName(jc);

	System.err.println("Dump class : "+ classFileName);

	File aClassFile = new File(classFileName);
	if (aClassFile.getParent() != null){
	  new File(aClassFile.getParent()).mkdirs();
	}
	OutputStream fout = new FileOutputStream(aClassFile);
	fout.write(buf);
	fout.close();
      } catch (IOException e){
	e.printStackTrace();
	throw MJC.fatal(e.getMessage());
      }
    }
  }

  public static String MJ_DUMP_DIRECTORY_NAME
    = "eppout"+ File.separatorChar+ "mjdump";
  public String makeClassFileName(JavaClass jc){
    String className = utf8ToClassName(jc.getClassName());
    String ret = MJ_DUMP_DIRECTORY_NAME+
      File.separator+
      className.replace('.', File.separatorChar)+
      ".class";
    return ret;
  }
}



//--------------------------------------------------
//--------------------------------------------------
//--------------------------------------------------
// MJClassFileReader 
// This code was part of EPP 1.1.0beta12 .

public class MJClassFileReader {

  String targetClasspath = null; // For bootstrap. Currently not used.

  public Object[] classPathDirs;
  
  public MJClassFileReader(){
    String classPath = getClassPath();
    //if (false) Opts.out.println("target classpath = "+ classPath);
    classPathDirs = initClassPath(classPath);
    
    // Test if findClassFile works.
    if (findClassFile("java.lang.Object") == null){
      System.err.println();
      System.err.println("**************************************************");
      System.err.println("MJ Linker could not read the class file of java.lang.Object .");
      System.err.println("Please add rt.jar (or classes.zip) to your CLASSPATH.");
      System.err.println("(Current \"java.class.path\" property is \""+
			 System.getProperty("java.class.path")+
			 "\")");
      System.err.println("**************************************************");
      System.err.println();
      throw MJC.fatal("");
    }
  }
  
  public String getClassPath(){
    if (targetClasspath != null){
      return targetClasspath;

    } else {
      StringBuffer buf = new StringBuffer();
      char sep = File.pathSeparatorChar;

      String bootclasspath = System.getProperty("sun.boot.class.path");
      if (bootclasspath != null && bootclasspath.length() > 0){
	buf.append(bootclasspath);
	buf.append(sep);
      }

      String extdirs = System.getProperty("java.ext.dirs");
      if (extdirs != null && extdirs.length() > 0) {
	int begin = 0;
	while (true){
	  int end = extdirs.indexOf(sep, begin);
	  if (end == -1){
	    appendJarFiles(buf, extdirs.substring(begin));
	    break;
	  }
	  appendJarFiles(buf, extdirs.substring(begin, end));
	  begin = end + 1;
	}
      }

      String classpath = System.getProperty("java.class.path");
      if (classpath != null && classpath.length() > 0) {
	buf.append(classpath);
	buf.append(sep);
      }
      
      String str = buf.toString();
      // Remove the last sep char.
      if (str.length() > 0){
	str = str.substring(0, str.length() - 1);
      }
      return str;
    }
  }

  public void appendJarFiles(StringBuffer buf, String dirName){
    File dir = new File(dirName);
    if (! dir.isDirectory()) return;
    String[] fileList = dir.list();
    for (int i = 0; i < fileList.length; i++){
      if (fileList[i].endsWith(".jar")){
	buf.append(dirName+ File.separatorChar + fileList[i]);
	buf.append(File.pathSeparatorChar);
      }
    }
  }

  
  public Object[] initClassPath(String classPath){
    Vector vec = new Vector();
    int begin = 0;
    while (true){
      int end = classPath.indexOf(File.pathSeparatorChar, begin);
      if (end == -1){
	checkZip(vec, classPath.substring(begin));
	break;
      }
      checkZip(vec, classPath.substring(begin, end));
      begin = end + 1;
    }
    Object[] classPathDirs = new Object[vec.size()];
    vec.copyInto(classPathDirs);
    return classPathDirs;
  }
  
  public void checkZip(Vector vec, String str){
    //System.out.println("checkZip: "+ str);
    if (str.endsWith(".zip") || str.endsWith(".jar")) {
      try {
	vec.addElement(new ZipFile(str));
      } catch (IOException e) {
	// If the zip file does not exists, or format error occured,
	// do nothing.
      }
    } else {
      vec.addElement(str);
    }
  }

  //--------------------------------------------------

  public InputStream findClassFile(String className) {
    // Do not use File.separatorChar instead of '/',
    //because zip file always use '/' as a separator.
    String classFileName = className.replace('.', '/')+ ".class";
    
    for (int i = 0; i < classPathDirs.length; i++){
      Object dir = classPathDirs[i];
      if (dir instanceof ZipFile) {
	// in case of archive file
	ZipFile zf = (ZipFile)dir;
	ZipEntry ze = zf.getEntry(classFileName);
	if (ze != null) {
	  try {
	    return zf.getInputStream(ze);
	  } catch (IOException e){
	    throw MJC.fatal(e.getMessage());
	  }
	}
      } else if (dir instanceof String) {
	File f = new File((String)dir+ File.separatorChar+ classFileName);
	if (f.exists()) {
	  try {
	    return new FileInputStream(f);
	  } catch (IOException e){
	    throw MJC.fatal(e.getMessage());
	  }
	}
      } else {
	throw MJC.fatal("");
      }
    }
    return null;
  }

}

