/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0


package mjc;
import java.util.*;

SystemMixin FileSig {
  class Epp {

    extend void initializationPass() {
      original();
      Dynamic.set(:classTypeTable, new MJClassTypeTable());
    }

    extend void initGlobalProcessor() {
      original();
      Dynamic.set(:classTypeTable, new MJClassTypeTable());
      Dynamic.bind(:typeNameTable, generateTypeNameTable());
    }


    redefine TypeNameTable generateTypeNameTable(){
      return new MJTypeNameTable();
    }

    //--------------------------------------------------
    // $BCj>]9=J8LZ$+$i(B moduleSig $B$X$NJQ49!#(B
    // $B!J$"$i$+$8$a(B normalize $B$7$F$*$$$F!"(B MJXxx $B$X$NJQ49$r$d$j$d$9$/$9$k!#!K(B
    // $B$3$N%a%=%C%I$O!"(B treeToMJModule $B$+$i8F$P$l$k!#(B
    // moduleSig $B$N%U%)!<%^%C%H$O!"(B module $B$NCj>]9=J8LZ$H$[$\F1$8!#(B
    // $B$?$@$7!"(B ClassBody $B$NCf?H$O@55,2=$5$l$F$$$k!#(B
    // $B$^$?!"(B MethodBody $B$O(B emptyStatement $B$K$J$C$F$$$k!#(B
    // $B@hF,$N(B tag $B$O(B mjCompilationUnit, mjModule $B$G$O$J$/(B
    // mjFileSignature, moduleSig $B$H$9$k!#(B
    // $B$^$?!"(B mjMarks $B$NBe$o$j$K(B mjInfo $B$rF~$l$k!#(B
    //$B$=$NB>$N(B tag $B$O(B AST $B$HF1$8!#(B

    define implement Tree normalizeMJCompilationUnit(Tree tree){
      if (tree.tag() == :errorInCompilationUnit) {
	return tree;
      }
      if (tree.tag() != :mjCompilationUnit){
	throw MJC.fatal(""+ tree);
      }
      TreeVec tvec = new TreeVec();
      foreach (Tree moduleTree in tree.args()){
	tvec.add(normalizeMJModule(moduleTree));
      }
      return new Tree(:mjFileSignature, tvec);
    }

    define implement Tree normalizeMJModule(Tree tree){
      Tree[] args = tree.args();
      Tree mjMarks = args[0]; // $B$H$j$"$($:L5;k!#(B
      Tree name = args[1];
      Tree headers = args[2];
      Tree[] moduleDecls = args[3].args();
      TreeVec tvec = new TreeVec();

      // headers $B$K(B extends mj.lang.ss $B$rDI2C!#(B
      Tree[] nameElems = name.args();
      if (! (nameElems.length == 3 &&
	     nameElems[0].idName() == :mj &&
	     nameElems[1].idName() == :lang &&
	     nameElems[2].idName() == :ss)){
	TreeVec newHeaders = new TreeVec();
	foreach (Tree h in headers.args()){
	  newHeaders.push(h);
	}
	newHeaders.add(`(extendingModules (name (id mj)(id lang)(id ss))));
	headers = headers.modifyArgs(newHeaders.toArray());
      }

      // $B$3$3$G!"K\Ev$O(B headers $B$N%(%i!<%A%'%C%/$r$9$k!#(B
      // importSingle $B$b$3$3$G$O$M$k!#(B

      foreach (Tree t in moduleDecls) {
	tvec.add(normalizeMJTypeDeclaration(t));
      }
      return `(moduleSig (mjInfo) ,name ,headers
	       (mjTypeDeclarations ,@tvec));
    }
    
    define implement Tree normalizeMJTypeDeclaration(Tree tree){
      if (tree.tag() == :mjClass){
	return normalizeMJClass(tree);
      } else if (tree.tag() == :emptyTypeDeclaration){
	return tree;
      } else {
	throw Epp.fatal("normalizeMJCompilationUnit: Unknown MJTypeDeclaration: "+
			tree);
      }
    }
    
    define implement Tree normalizeMJClass(Tree tree){
      Tree[] args = tree.args();
      Tree mjMarks = args[0];
      Tree modifiers = args[1];
      Tree classKeyword = args[2];
      Tree name = args[3];
      Tree extds = args[4];
      Tree impls = args[5];
      Tree classBody = args[6];

      TreeVec tvec = new TreeVec();
      foreach (Tree t in classBody.args()){
	normalizeClassBodyDeclaration(tvec, t);
      }
      boolean isDefinition = (mjMarks.args().length > 0);

      TreeVec infoVec = new TreeVec();
      if (isDefinition) infoVec.add(`(id isDefinition));

      return `(mjClass
	       (mjInfo ,@infoVec)
	       ,modifiers ,classKeyword ,name ,extds ,impls
	       (classBody ,@tvec));
    }

    // $B%*%j%8%J%k$N(B normalizeClassBodyDeclaration $B$r3HD%!#(B
    extend void normalizeClassBodyDeclaration(TreeVec tvec,
					      Tree tree){
      Symbol tag = tree.tag();
      if (tag == :mjField){
	normalizeMJFields(tvec, tree);
      } else if (tag == :mjConstructor){
	tvec.add(normalizeMJMethod(tree));
      } else if (tag == :mjMethod){
	tvec.add(normalizeMJMethod(tree));
      } else {
	original(tvec, tree);
      }
    }

    define implement Tree normalizeMJMethod(Tree tree){
      Symbol tag = tree.tag();
      Tree[] args = tree.args();
      Tree mjMarks = args[0];
      Tree modifiers = args[1];
      Tree ret = args[2];
      Tree name = args[3];
      Tree params = normalizeParams(args[4]);
      Tree thrs = args[5];

      TreeVec tvec = new TreeVec();
      if (mjMarks.args().length > 0) tvec.add(`(id isDefinition));

      return new Tree(tag,
		      `(mjInfo ,@tvec),
		      modifiers, ret, name, params, thrs,
		      new Tree(:emptyStatement));
    }
    // Currently not used.
    define implement void normalizeMJFields(TreeVec tvec, Tree tree){
      Tree[] args = tree.args();
      Tree mjMarks = args[0]; // $B$H$j$"$($:L5;k!#(B
      Tree modifiers = args[1];
      Tree type = args[2];
      Tree[] vardecls = args[3].args();
      for (int i = 0; i < vardecls.length; i++){
	Tree var = vardecls[i];
	if (var.tag() == :varInit) {
	  var = var.args()[0];
	}
	Tree[] pair = normalizeVariableDeclaratorId(type, var);
	tvec.add(new Tree(:mjField,
			  `(mjInfo),
			  modifiers,
			  pair[0],
			  new Tree(:vardecls, pair[1])));
      }
    }
    

    //--------------------------------------------------
    // classSig to MJClassData
    
    define implement MJClassData treeToMJClassData(Tree classSig,
						   MJClassType classType,
						   Symbol declaringModule){
      if (classSig.tag() != :mjClass){
	throw Epp.fatal("treeToMJClassData: Unknown format of type declaration is found in the FileSignature. "+ classSig);
      }
      
      
      TypeNameTable typeNameTable = (TypeNameTable)Dynamic.get(:typeNameTable);

      Tree[] args = classSig.args();
      Tree mjInfo = args[0];
      Tree[] modifiers = args[1].args();
      Symbol classKeyword = args[2].idName();
      Tree mjName = args[3];
      Tree extds = args[4];
      Tree impls = args[5];
      Tree classBody = args[6];

      Symbol fullName = classType.fullName;
      Symbol moduleName = classType.moduleName;
      Symbol simpleName = classType.simpleName;

      if (simpleName != MJC.mjNameToSimpleName(mjName)){
	throw MJC.fatal(""+ simpleName+ ":"+ MJC.mjNameToSimpleName(mjName));
      }
	

      boolean isInterface = (classKeyword == :interface);

      if (isInterface &&
	  impls.args().length > 0){
	throw errorAt(impls, "Interface should not implement other interfaces. use \"extends\" instead of \"implements\" .");
      }

      if (MJC.isDefinition(mjInfo)){
	if (mjName.tag() == :id){
	  //moduleName = declaringModule;
	  //fullName = Symbol.intern(moduleName+ "."+ simpleName);
	} else if (mjName.tag() == :mjFQN){
	  //moduleName = MJC.mjFQNToModuleName(mjName);
	  if (declaringModule != moduleName){
	    // $B;XDj$5$l$?(B FQN $B$,L7=b$7$F$$$k!#(B
	    throw errorAt(mjName,
			  "MJ: The module name "+ moduleName+
			  " specified in FQN is not "+
			  "current module's name "+ declaringModule+ " .");
	  }
	  //fullName = Symbol.intern(moduleName+ "."+ simpleName);
	} else {
	  throw MJC.fatal(""+ mjName);
	}
      } else {
	if ((! isInterface ) &&
	    extds.args().length > 0){
	  throw errorAt(extds,
			"MJ: Extension of class should not specify super class. ");
	}

	if (mjName.tag() == :id){
	  //moduleName = null;
	  //fullName = null;
	} else if (mjName.tag() == :mjFQN){
	  //moduleName = MJC.mjFQNToModuleName(mjName);
	  //fullName = Symbol.intern(moduleName+ "."+ simpleName);
	} else {
	  throw MJC.fatal(""+ mjName);
	}
      }

      if (isInterface){
	modifiers = addModifier(modifiers, :abstract);
      }
      
      // superclassType $B$H(B interfaceTypes $B$O!"(B
      // :class $B$+(B :MJclass $B$G$J$$$H$@$a!#$=$l$r$A$c$s$H%A%'%C%/$9$k$3$H!#(B
      
      // Superclass and interfaces
      Type superclassType;
      Tree[] interfaceTrees;
      if (isInterface){
	superclassType = null;
	interfaceTrees = extds.args();
      } else {
	Tree[] supers = extds.args();
	if (supers.length == 1){
	  superclassType = treeToType(supers[0]);
	} else if (supers.length == 0){
	  if (fullName == :"java.lang.Object"){
	    superclassType = null;
	  } else {
	    superclassType = Type.TObject;
	  }
	} else {
	  throw Epp.error("More than one super class is specified.: "+
			  fullName);
	}
	interfaceTrees = impls.args();
      }
      
      Type[] interfaceTypes = new Type[interfaceTrees.length];
      for (int i = 0; i < interfaceTrees.length; i++){
	interfaceTypes[i] = treeToType(interfaceTrees[i]);
      }
      
      Tree[] members = classBody.args();

      
      // Inner classes
      Hashtable innerClassTable = new Hashtable();
      for (int i = 0; i < members.length; i++){
	if (members[i].tag() == :class){
	  throw errorAt(members[i], "MJ: Member class is not supported.");
	}
      }
      

      MJMethodInfo[] constructors;
      Table<Symbol,MJFieldInfo> fieldTable = {};
      Table<Symbol,Vec<MJMethodInfo> > methodTable = {};


      TypeNameTable memberEnv = typeNameTable;

      //MJ class $B$+$i$O!"(B member class $B$r7Q>5$7$J$$$b$N$H$9$k!#(B
#+old
      {
	// interface $B$N(B inner class 
	for (int i = interfaceTypes.length - 1; i >= 0; i--){
	  memberEnv = new MemberTypeNameTable(interfaceTypes[i], memberEnv);
	}
	if (superclassType != null){
	  memberEnv = new MemberTypeNameTable(superclassType, memberEnv);
	}
	//memberEnv = new HashtableTypeNameTable(innerClassTable, memberEnv);
      }
      
      Dynamic.bind(:typeNameTable, memberEnv);
      try {
	
	// Constructors
	{
	  TreeVec tvec = new TreeVec();
	  for (int i = 0; i < members.length; i++){
	    if (members[i].tag() == :mjConstructor){
	      tvec.add(members[i]);
	    }
	  }
	  Tree[] constructorTrees = tvec.toArray();
	  if (constructorTrees.length == 0){
	    // Make a default constructor.
	    constructors = new MJMethodInfo[1];
	    constructors[0] = new MJMethodInfo(declaringModule,
					       classType,
					       `(mjInfo), // $B!)!)(B
					       new Tree[0],
					       Type.Tvoid,
					       :"<init>",
					       :dummy,
					       :dummy,
					       new Type[0],
					       new Type[0]);
	  } else {
	    constructors = new MJMethodInfo[constructorTrees.length];
	    for (int i = 0; i < constructorTrees.length; i++){
	      constructors[i] = treeToMJMethodInfo(constructorTrees[i],
						   isInterface,
						   classType,
						   declaringModule);
	    }
	  }
	}
	
	// Fields
	for (int i = 0; i < members.length; i++){
	  if (members[i].tag() == :decl){
	    // (decl (modifiers) (name ...) (vardecls (id sym)))
	    Symbol name = members[i].args()[2].args()[0].idName();
	    {
	      // $B#2=E@k8@%A%'%C%/!#(B
	      MJFieldInfo f = fieldTable.get(name)
		ifNull{ f = null; };
	      if (f != null){
		throw errorAt(members[i], "Field name \""+ name+
			      "\" already defined at this module.");
	      }
	    }
	    fieldTable.put(name, treeToMJFieldInfo(members[i],
						   isInterface,
						   classType,
						   declaringModule));
	  }
	}
	
	// Methods
	for (int i = 0; i < members.length; i++){
	  if (members[i].tag() == :mjMethod){
	    //(mjMethod MJInfo Modifiers Type MJName
	    //  (formalParameters ...) (throws ...) MethodBody)
	    Tree methodName = members[i].args()[3];
	    Symbol simpleMethodName = MJC.mjNameToSimpleName(methodName);
	    MJMethodInfo m = treeToMJMethodInfo(members[i],
						isInterface,
						classType,
						declaringModule);
	    Vec<MJMethodInfo> vec = methodTable.get(simpleMethodName)
	      ifNull{
		vec = new Vec<MJMethodInfo>();
		methodTable.put(simpleMethodName, vec);
	      };
	    // $B#2=E@k8@%A%'%C%/!#(B
	    foreach (MJMethodInfo m0 in vec){
	      if (doesOverride(m, m0)
		  && m.fullName == m0.fullName // $B!)!)!)(B
		  ){
		throw errorAt(methodName, "Method \""+ simpleMethodName+
			      "\" with the same signature already defined at this module.");
	      }
	    }
	    vec.push(m);
	  }
	}
      } finally {
	Dynamic.unbind();
      }

      MJClassData mjClassData =  new MJClassData(classType,
						 mjInfo,
						 modifiers,
						 classKeyword,
						 fullName,
						 simpleName,
						 moduleName,
						 superclassType,
						 interfaceTypes,
						 constructors,
						 fieldTable,
						 methodTable);

      
      return mjClassData;
    }
    
    define implement MJFieldInfo treeToMJFieldInfo(Tree tree,
						   boolean isInterface,
						   Type declaringClass,
						   Symbol declaringModule){
      Tree[] args = tree.args();
      //old (mjField MJMarks Modifiers Type (vardecls (id name)))
      // (decl Modifiers Type (vardecls (id name)))
      Tree[] modifiers = args[0].args();

      if (isInterface){
	modifiers = addModifier(addModifier(addModifier(modifiers,
							:public),
					    :static),
				:final);
      }

      Symbol simpleName = args[2].args()[0].idName();
      return new MJFieldInfo(declaringModule,
			     declaringClass,
			     args[0],
			     modifiers,
			     treeToType(args[1]),
			     simpleName,
			     Symbol.intern(declaringModule+ "::"+ simpleName),
			     declaringModule);
    }
    
    define implement MJMethodInfo treeToMJMethodInfo(Tree tree,
						     boolean isInterface,
						     Type declaringClass,
						     Symbol declaringModule
						     ){
      Tree[] args = tree.args();
      Tree mjMarks = args[0];
      Tree[] modifiers = args[1].args();
      Tree retTree = args[2];
      Tree mjName = args[3];
      Tree[] paramsTree = args[4].args();
      Tree[] thrsTree = args[5].args();
      Symbol simpleName = MJC.mjNameToSimpleName(mjName);
      Symbol fullName;
      Symbol moduleName;

      if (mjMarks.args().length != 0){
	// define $B$,;XDj$5$l$?>l9g!#(B
	if (mjName.tag() == :id){
	  moduleName = declaringModule;
	  fullName = Symbol.intern(moduleName+ "::"+ simpleName);
	} else if (mjName.tag() == :mjFQN){
	  moduleName = MJC.mjFQNToModuleName(mjName);
	  if (declaringModule != moduleName){
	    // $B;XDj$5$l$?(B FQN $B$,L7=b$7$F$$$k!#(B
	    throw errorAt(mjName,
			  "MJ: The module name "+ moduleName+
			  " specified in FQN is not "+
			  "current module's name "+ declaringModule+ " .");
	  }
	  fullName = Symbol.intern(moduleName+ "::"+ simpleName);
	} else {
	  throw MJC.fatal(""+ mjName);
	}
      } else {
	if (isInterface){
	  // interface $B$N(B method $B$O!"A4$F(B definition $B$G$J$1$l$P$J$i$J$$!#(B
	  throw errorAt(mjName,
			"MJ: Missing \"define\" in this interface member : "+
			simpleName);
	}
	
	if (mjName.tag() == :id){
	  moduleName = null;
	  fullName = null;
	} else if (mjName.tag() == :mjFQN){
	  moduleName = MJC.mjFQNToModuleName(mjName);
	  fullName = Symbol.intern(moduleName+ "::"+ simpleName);
	} else {
	  throw MJC.fatal(""+ mjName);
	}
      }

      /* old
      if (MJC.hasModifier(:static, modifiers)){
	throw errorAt(args[1], "MJ: Definition of static method is not supported.");
      }
      */

      if (isInterface){
	modifiers = addModifier(addModifier(modifiers,
					    :public),
				:abstract);
      }

      Type ret = treeToType(retTree);
      Type[] params = new Type[paramsTree.length];
      for (int i = 0; i < paramsTree.length; i++){
	// Ignores modifiers and variable names of formal parameters.
	// (pdecl (modifiers ...) type (id var))
	params[i] = treeToType(paramsTree[i].args()[1]);
      }
      Type[] thrs = new Type[thrsTree.length];
      for (int i = 0; i < thrsTree.length; i++){
	thrs[i] = treeToType(thrsTree[i]);
      }

      return new MJMethodInfo(declaringModule,
			      declaringClass,
			      mjMarks,
			      modifiers,
			      ret,
			      simpleName,
			      fullName,
			      moduleName,
			      params,
			      thrs);
    }

  }
}





//--------------------------------------------------

public class MJTypeNameTable extends TypeNameTable {
  public Type get(Tree name) throws NotFound {
    MJModuleInfo module = (MJModuleInfo)Dynamic.get(:currentModule);
    if (module == null)
      throw MJC.fatal("MJTypeNameTable: :currentModule is null. ");
    Type t = module.getType(name)
      ifNull {
	throw NotFound.instance;
      };
    return t;
  }
}


//--------------------------------------------------

//
public class MJClassTypeTable extends ClassTypeTable {

  public Type get(Symbol fullName) throws NotFound {
    // $B%-%c%C%7%e$K$"$l$P!"$=$l$rJV$9!#(B
    Type t = (Type)table.get(fullName);
    if (t != null) return t;

    MJModuleInfo module = (MJModuleInfo)Dynamic.get(:currentModule);
    if (module == null)
      throw MJC.fatal("MJClassTypeTable: :currentModule is null. ");
    // $B8=:_$N(B module $B$+$i<h$j=P$;$l$P!"$=$l$rJV$9!#(B
    // $BJL$K%-%c%C%7%e$K$$$l$J$/$F$b$h$$!)(B
    t = module.getMJClassType(fullName)
      ifNull{ t = null; };
    if (t != null) return t;

    //$B$s$C$H!"$^$:%Q%C%1!<%8L>$rJ,N%$7!"(B
    //$B$=$l$,(B MJ module $B$+$I$&$+$rH=Dj$7$J$1$l$P$@$a!#(B
    //$B!JH=Dj7k2L$O%Q%C%1!<%8L>$N%O%C%7%eI=$KEPO?!#!K(B
    if (! isJavaPackage(fullName)){
      throw NotFound.instance;
    }

    // Lj $B$N%/%i%9$G$"$k$3$H$,3NDj$7$?$N$G!"$"$H$OIaDL$K!#(B
    return super.get(fullName);
  }

  // key = package name, value = :java or :mj
  Table<Symbol, Symbol> javaPackage = {};
  {
    // "mjc." has a MJModuleLoader, but it is not a MJ module name.
    javaPackage.put(:"mjc.", :java);
  }

  boolean isJavaPackage(Symbol fullName){
    String str = fullName.toString();
    int lastDot = str.lastIndexOf('.');
    // If lastDot is -1, packageName is :"" .
    Symbol packageName = Symbol.intern(str.substring(0, lastDot + 1));

    Symbol sym = javaPackage.get(packageName) ifNull{
      Obj epp = (Obj)Dynamic.get(:epp);
      Object classFile = epp!readClassFile(Symbol.intern(packageName+
							 "MJModuleLoader"));
      if (classFile == null){
	sym = :java;
      } else {
	sym = :mj;
      }
      javaPackage.put(packageName, sym);
    };
    return sym == :java;
  }
}

//--------------------------------------------------

public class MJClassType extends Type {

  Symbol fullName;
  Symbol simpleName;
  Symbol moduleName;
  MJModuleInfo mjModuleInfo;
  public MJClassType(Symbol fullName,
		     Symbol simpleName,
		     Symbol moduleName,
		     MJModuleInfo mjModuleInfo) {
    super(:MJclass);
    this.fullName = fullName;
    this.simpleName = simpleName;
    this.moduleName = moduleName;
    this.mjModuleInfo = mjModuleInfo;
  }

  public ClassInfo classInfo(){
    return mjClassInfo();
  }
  
  public MJClassInfo mjClassInfo(){
    MJModuleInfo module = (MJModuleInfo)Dynamic.get(:currentModule);
    if (module == null) throw MJC.fatal("");
    return module.getMJClassInfo(fullName);
  }

  public Symbol getName(){ return fullName; }
  public Symbol getSimpleName(){ return simpleName; }
  public Symbol getModuleName(){ return moduleName; }

  // ClassInfo $B$r:n$i$:$K!"(B true $B$+(B false $B$rJV$9!#(B
  // This method is called from TypeNameTable#doesClassExist .
  //old public boolean isPublic() { return true; }

  public Tree toTree(){
    return Tree.stringToNameTree(fullName.toString());
  }
  public String toString(){
    return fullName.toString();
  }
  
}

// isSuperType $B$N<BAu$r3Z$K$9$k$?$a$K!"(B ClassInfo $B$r7Q>5$9$k!#(B
public class MJClassInfo extends ClassInfo {
  // These fields are inherited.
  //Symbol name;
  //Tree[] modifiers;
  //Type declaringClass;
  //boolean isInterface;
  //Type superclassType;
  //Type[] interfaceTypes;
  //MethodInfo[] constructors;
  //Hashtable fieldTable;	// not used
  //Hashtable methodTable;	// not used
  //Hashtable innerClassTable;	// not used
  //Hashtable classProperty;	// not used
  //FieldInfo[] allFields;	// not used
  //MethodInfo[] allMethods;	// not used
  //Type[] allClasses;		// not used

  public Symbol simpleName;
  public Symbol moduleName;
  public MJMethodInfo[] mjConstructors;
  public Table<Symbol,Vec<MJFieldInfo> > fieldTable;
  public Table<Symbol,Vec<MJMethodInfo> > methodTable;

  public MJClassInfo(Symbol fullName,
		     Symbol simpleName,
		     Symbol moduleName,
		     Tree[] modifiers,
		     boolean isInterface,
		     Type superclassType,
		     Type[] interfaceTypes,
		     MJMethodInfo[] mjConstructors,
		     Table<Symbol,Vec<MJFieldInfo> > fieldTable,
		     Table<Symbol,Vec<MJMethodInfo> > methodTable
		     ){
    super(null, modifiers, isInterface, fullName,
	  superclassType, interfaceTypes, null,
	  null, null, null, null);
    this.simpleName = simpleName;
    this.moduleName = moduleName;
    this.mjConstructors = mjConstructors;
    this.fieldTable = fieldTable;
    this.methodTable = methodTable;
  }

  public MJMethodInfo[] getMJConstructors() { return mjConstructors; }

    /* $B8E$$%3%a%s%H!'(B
       $B$3$N%a%=%C%I$O!"(B ClassBody $B$NL>A04D6-$r:n$k$H$-$K8F$P$l$k!#(B
       $B$$$^$O!"6u$NG[Ns$rJV$9$N$G!"%$%s%9%?%s%9JQ?t$N4D6-$b6u$K$J$k!#(B
       $B$=$N$+$o$j$K!"(B VariableDecorator $B$NJ}$G!"(B
       $B%$%s%9%?%s%9JQ?t$N=hM}$r$d$C$F$$$k!#(B
    */
  public FieldInfo[] getFields(){
    // $B$b$O$d;H$o$l$F$$$J$$!)(B
    // $B$I$3$+$G;H$o$l$F$$$k$_$?$$!#(B
    //System.err.println("Warning: MJClassInfo#getFields is invoked.");
    return new FieldInfo[]{};
  }

  // Not used.
  /*
  public MJMethodInfo[] getMJMethods(){
    Vec<MJMethodInfo> vec = {};
    foreach (Vec<MJMethodInfo> v in methodTable.valueIter()){
      foreach (MJMethodInfo m in v){
	vec.push(m);
      }
    }
    return vec.toArray();
  }
  */

  public Type[] getClasses(){ throw MJC.fatal("not implemented"); }
  
  //--------------------------------------------------

  public FieldInfo getField(Symbol sym) throws NotFound {
    throw MJC.fatal("");	// $B!)!)!)(B
  }

  public NullOr<Vec<MJFieldInfo> > getMJFields(Symbol sym) {
    return fieldTable.get(sym);
  }


  //--------------------------------------------------

  public MethodInfo[] getOverloadedMethods(Symbol sym) throws NotFound {
    throw MJC.fatal("");	// $B!)!)!)(B
  }

  // sym $B$O!"%a%=%C%IC1=cL>!#(B
  public NullOr<Vec<MJMethodInfo> > getOverloadedMJMethods(Symbol sym) {
    return methodTable.get(sym);
  }



  //--------------------------------------------------

  public Type getClass(Symbol sym) throws NotFound {
    throw NotFound.instance;
  }

  //public Type getSuperclass() { return superclassType; }

  //public Type[] getInterfaces() { return interfaces; }

  //public boolean isInterface(){ return isInterface; }

  // These methods are only for the implementation of inheritance.
  public Hashtable getFieldTable() { throw MJC.fatal(""); }
  public Hashtable getMethodTable() { throw MJC.fatal(""); }
  public Hashtable getInnerClassTable() { throw MJC.fatal(""); }

  public Object property(Symbol key){ throw MJC.fatal("not implemented"); }

  // debug $BMQ(B
  public String toString() {
    StringBuffer buf = new StringBuffer();
    buf.append("MJClassInfo:"+ Opts.lineSeparator);
    buf.append(modifiersToString()+
	       (isInterface() ? "interface " : "class ")+
	       name);
    Type superclass = getSuperclass();
    if (superclass != null){
      buf.append(" extends "+ superclass.classInfo().getName());
    }
    Type[] interfaces = getInterfaces();
    if (interfaces.length != 0){
      buf.append(" implements ");
      for (int i = 0; i < interfaces.length - 1; i++){
	buf.append(interfaces[i].classInfo().getName().toString());
	buf.append(", ");
      }
      buf.append(interfaces[interfaces.length - 1]
		 .classInfo().getName().toString());
    }
    buf.append(" {"+ Opts.lineSeparator);
    foreach (Vec<MJFieldInfo> vec in fieldTable.valueIter()){
      foreach(MJFieldInfo x in vec){
	buf.append("  "+ x.toString()+ Opts.lineSeparator);
      }
    }
    foreach ( MJMethodInfo x in getMJConstructors()){
      buf.append("  "+ x.toString()+ Opts.lineSeparator);
    }
    foreach (Vec<MJMethodInfo> vec in methodTable.valueIter()){
      foreach(MJMethodInfo x in vec){
	buf.append("  "+ x.toString()+ Opts.lineSeparator);
      }
    }

    buf.append("}"+ Opts.lineSeparator);

    return buf.toString();
  }  
}

//--------------------------------------------------

// $B%/%i%9$NCGJR(B
public class MJClassData {
  public Type classType;	// The class currently processing.
  public Tree[] modifiers;
  public Symbol classKeyword;
  // $B0J2<#3$D$N(B Symbol $B$O;H$o$l$F$$$J$$!#>iD9$J>pJs$+!)(B
  // mjClassInfo $B$,$G$-$l$P!"(B classType $B$+$i<h$j=P$;$k!#(B
  public Symbol fullName;
  public Symbol simpleName;
  public Symbol moduleName;	// delta $B$NDj5A>l=j$G$O$J$/%/%i%9$NDj5A>l=j!#(B
  public Type superclassType;
  public Type[] interfaceTypes;
  public MJMethodInfo[] mjConstructors;
  public Table<Symbol,MJFieldInfo> fieldTable;  // key is simpleName
  public Table<Symbol,Vec<MJMethodInfo> > methodTable;  // key is simpleName

  Tree mjInfo;
  public boolean isDefinition = false;

  public MJClassData(Type classType,
		     Tree mjInfo,
		     Tree[] modifiers,
		     Symbol classKeyword,
		     Symbol fullName,
		     Symbol simpleName,
		     Symbol moduleName,
		     Type superclassType,
		     Type[] interfaceTypes,
		     MJMethodInfo[] mjConstructors,
		     Table<Symbol,MJFieldInfo> fieldTable,
		     Table<Symbol,Vec<MJMethodInfo> > methodTable){
    this.classType = classType;
    this.mjInfo = mjInfo;
    this.modifiers = modifiers;
    this.classKeyword = classKeyword;
    this.fullName = fullName;
    this.simpleName = simpleName;
    this.moduleName = moduleName;
    this.superclassType = superclassType;
    this.interfaceTypes = interfaceTypes;
    this.mjConstructors = mjConstructors;
    this.fieldTable = fieldTable;
    this.methodTable = methodTable;

    if (mjInfo.tag() != :mjInfo) throw MJC.fatal(""+ mjInfo);
    this.mjInfo = mjInfo;
    foreach (Tree info in mjInfo.args()){
      if (info.tag() == :id && info.idName() == :isDefinition){
	isDefinition = true;
      }
    }
  }
  public Tree toTree(){
    Tree mjName = `(mjFQN
		    ,@(Tree.stringToNameTree(fullName.toString()).args()));
    TreeVec extds = new TreeVec();
    TreeVec impls = new TreeVec();
    if (classKeyword == :class){
      // delta $B$K(B extends $B$rF~$l$F$7$^$&$H!"(B
      // treeToMJClassData $B$G%(%i!<$K$J$C$F$7$^$&!#(B
      if (isDefinition){
	extds.add(superclassType.toTree());
      }
      foreach (Type t in interfaceTypes){ impls.add(t.toTree()); }
    } else if (classKeyword == :interface){
      foreach (Type t in interfaceTypes){ extds.add(t.toTree()); }
    } else {
      throw MJC.fatal(""+ classKeyword);
    }

    TreeVec body = new TreeVec();

    // $B%3%s%9%H%i%/%?$O$H$j$"$($:L5;k!#(B
    // $B!V%G%U%)%k%H%3%s%9%H%i%/%?!W$,%@%_!<$GDI2C$5$l$k$N$GCm0U!#(B
    // toTree $B$7$?$"$H!"%?%0$rJQ99$9$k$N$b$o$9$l$:$K!#(B
    //foreach (MJMethodInfo m in mjConstructors) { body.add(m.toTree()); }

    foreach (MJFieldInfo f in fieldTable.valueIter()) { body.add(f.toTree()); }
    foreach (Vec<MJMethodInfo> vec in methodTable.valueIter()) {
      foreach (MJMethodInfo m in vec) { body.add(m.toTree()); }
    }
    return `(mjClass
	     ,mjInfo	// $B$H$j$"$($:$=$N$^$^Kd$a9~$`!#(B
	     (modifiers ,@modifiers)
	     ,(new Identifier(classKeyword))
	     ,mjName
	     (extends ,@extds)
	     (implements ,@impls)
	     (classBody ,body));
  }
}


public class MJFieldInfo extends FieldInfo {
  public Symbol declaringModule;
  public Tree mjInfo;
  public Symbol fullName;
  public Symbol moduleName;
  public MJFieldInfo(Symbol declaringModule,
		     Type declaringClass,
    		     Tree mjInfo,
		     Tree[] modifiers,
		     Type type,
		     Symbol name,
		     Symbol fullName,
		     Symbol moduleName){
    super(declaringClass, modifiers, type, name);
    this.declaringModule = declaringModule;
    this.mjInfo = mjInfo;
    // fullName, moduleName $B$O!"(B null $B$N>l9g$b$"$k!#$=$N>l9g$O$"$H$+$i@_Dj!#(B
    this.fullName = fullName;
    this.moduleName = moduleName;
  }
  public Tree toTree(){
    // mjInfo $B$OL5;k!#(B
    return `(decl
	     (modifiers ,@modifiers)
	     ,(getType().toTree())
	     (vardecls ,(new Identifier(name))));
  }
  public String toString(){
    return modifiersToString()+ getType()+ " "+ fullName;
  }
}

// Java class $B$GDj5A$5$l$?%U%#!<%k%I$r(B MJ class $B$,7Q>5$7$?$b$N!#(B
public class MJJavaFieldInfo extends MJFieldInfo {
  public FieldInfo fieldInfo;
  public MJJavaFieldInfo(Type declaringClass,
			 FieldInfo fieldInfo,
			 Symbol moduleName){
    super(moduleName,    	// $B%-%c%9%H@h(B
	  declaringClass,	// $B%-%c%9%H@h(B
	  `(mjInfo (id isDefinition)),
	  fieldInfo.getModifiers(),
	  fieldInfo.getType(),
	  fieldInfo.getName(),
	  Symbol.intern(MJC.JAVA_MODULE_NAME+ "::"+ fieldInfo.getName()),
	  MJC.JAVA_MODULE_NAME);
    this.fieldInfo = fieldInfo;
  }
}



public class MJMethodInfo extends MethodInfo {
  //Symbol name;
  //Tree[] modifiers;
  //Type declaringClass;
  //Type returnType;
  //Type[] parameterTypes;
  //Type[] exceptionTypes;

  public Symbol declaringModule;
  public Tree mjInfo;
  public Symbol fullName;
  public Symbol moduleName;

  public boolean isDefinition = false;
  public boolean containsOriginal = false;

  // name $B$O!"(B simpleName .   fullName = moduleName+ "::"+ name .
  // moduleName $B$O!"$3$N%a%=%C%I$N!V;EMM!W$r!VDj5A!W$7$?%b%8%e!<%k$NL>A0!#(B
  // $B!J$D$^$j!"7Q>5=hM}$r$7$J$$$H3NDj$7$J$$!#!K(B
  //  moduleName $B$O!"(B target $B$N%-%c%9%H@h$H$7;H$o$l$k!#(B
  // declaringClass $B$O!"$3$N%a%=%C%ICGJR$rDj5A$7$?%/%i%9!#(B
  // $B!J(B super class $B$N(B method $B$r(B subclass $B$G(B override $B$7$?>l9g$O(B subclass $B!#!K(B
  // declaringClass $B$O!"(B Java interface method $B$N8F$S=P$7$NH=Dj$G;H$o$l$k!#(B
  // $B!J%G%P%C%0>pJs=PNO$N:]$K$b=EMW$J>pJs!#!K(B
  // declaringModule $B$O!"$3$N!V%a%=%C%ICGJR!W$rDj5A$7$?%b%8%e!<%k!#(B
  public MJMethodInfo(Symbol declaringModule,
		      Type declaringClass,
		      Tree mjInfo,
		      Tree[] modifiers,
		      Type returnType,
		      Symbol name,
		      Symbol fullName,
		      Symbol moduleName,
		      Type[] parameterTypes,
		      Type[] exceptionTypes){
    super(declaringClass, modifiers, returnType, name,
	  parameterTypes, exceptionTypes);
    this.declaringModule = declaringModule;
    if (mjInfo.tag() != :mjInfo) throw MJC.fatal(""+ mjInfo);
    this.mjInfo = mjInfo;
    foreach (Tree info in mjInfo.args()){
      if (info.tag() == :id && info.idName() == :isDefinition){
	isDefinition = true;
      }
      if (info.tag() == :id && info.idName() == :containsOriginal){
	containsOriginal = true;
      }
    }

    // fullName, moduleName $B$O!"(B null $B$N>l9g$b$"$k!#$=$N>l9g$O$"$H$+$i@_Dj!#(B
    this.fullName = fullName;
    this.moduleName = moduleName;
  }

  public Tree toTree(){
    Tree mjName = `(mjFQN
		    ,@(Tree.stringToNameTree(moduleName.toString()).args())
		    ,(new Identifier(getName()))
		    );
    TreeVec params = new TreeVec();
    foreach (Type pType in getParameterTypes()){
      params.add(`(pdecl (modifiers) ,(pType.toTree()) (id p)));
    }
    TreeVec thrs = new TreeVec();
    foreach (Type t in getExceptionTypes()){
      thrs.add(t.toTree());
    }
    return `(mjMethod
	     ,mjInfo	// $B$H$j$"$($:$=$N$^$^Kd$a9~$`!#(B
	     (modifiers ,@modifiers)
	     ,(getReturnType().toTree())
	     ,mjName
	     (formalParameters ,@params)
	     (throws ,@thrs)
	     (emptyStatement));
  }
  public Tree makeMJInfoTree(){
    TreeVec tvec = new TreeVec();
    if (isDefinition) tvec.add(`(id isDefinition));
    if (containsOriginal) tvec.add(`(id containsOriginal));
    return `(mjInfo ,@tvec);
  }

  public String toString(){
    StringBuffer buf = new StringBuffer();
    // if (isDefinition) buf.append("/***/ ");
    buf.append(modifiersToString()+ getReturnType()+ " ");
    if (fullName == null){
      buf.append(getName());
    } else {
      buf.append(fullName);
    }
    buf.append("(");
    if (getParameterTypes().length > 0){
      buf.append(getParameterTypes()[0].toString());
      for (int i = 1; i < getParameterTypes().length; i++){
	buf.append(", ");
	buf.append(getParameterTypes()[i].toString());
      }
    }
    buf.append(')');
    if (getExceptionTypes().length > 0){
      buf.append(" throws ");
      buf.append(getExceptionTypes()[0].toString());
      for (int i = 1; i < getExceptionTypes().length; i++){
	buf.append(", ");
	buf.append(getExceptionTypes()[i].toString());
      }
    }
    return buf.toString();
  }
  
}

// Java class $B$GDj5A$5$l$?%a%=%C%I$r(B MJ class $B$,7Q>5$7$?$b$N!#(B
// $B<B$O$3$N%/%i%9$OITMW$G!"(B MJMethodInfo $B$N%3%s%9%H%i%/%?$r$b$&#1$D(B
// $B:n$l$P$h$+$C$?$@$1$+$b!#(B
// interface $B$r(B implements $B$9$k;~$K@8$8$k(B "abstractMethod" $B$K$bCm0U!#(B
public class MJJavaMethodInfo extends MJMethodInfo {
  public MethodInfo methodInfo;
  public MJJavaMethodInfo(Type declaringClass,
			  MethodInfo methodInfo,
			  Symbol moduleName){
    super(moduleName,		// $B%-%c%9%H@h$O!"(BJava class delta $B$N>l=j!#(B
	  declaringClass,	// direct super class $B$r;XDj$9$k$3$H$K$9$k!#(B
	  `(mjInfo (id isDefinition)),
	  methodInfo.getModifiers(),
	  methodInfo.getReturnType(),
	  methodInfo.getName(),
	  Symbol.intern(MJC.JAVA_MODULE_NAME+ "::"+ methodInfo.getName()),
	  MJC.JAVA_MODULE_NAME,
	  methodInfo.getParameterTypes(),
	  methodInfo.getExceptionTypes());
    this.methodInfo = methodInfo;
  }
}

