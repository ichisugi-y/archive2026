/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */


/*

 ss plug-in

BUG
---
mj.SS $B0J30$K(B SS $B$H$$$&L>A0$N%/%i%9$,$"$C$F$b!"$=$l$,(B mj.SS $B$@$H(B
$B2r<a$5$l$F$7$^$&!#(B

class SS {...} $B$H$$$&@k8@$r(B a $B9TL\$KL@<(E*$K=q$$$?>l9g!"(B
$B$=$l0JA0$K(B ss $B5-K!$G=q$+$l$?(B SS field/method $B$O$9$Y$F(B a $B9TL\$K=PNO$5$l$k!#(B
$B!J$3$l$O$7$g$&$,$J$$!#L@<(E*$K(B class SS {...} $B$H(B ss $B5-K!$N:.:_$O$J$$$H2>Dj!#!K(B

*/


#epp jp.go.etl.epp.EppLibLevel0
#epp jp.go.etl.epp.Collection

package mjc.ss;
import mjc.*;

BeforeLoadingPlugIn{
  requirePlugIn("mjc.PlugIn");
  //old requirePlugIn("mjc.SSPlugIn");
}

SystemMixin PlugIn {
  class Epp {
    extend  Tree mjClassBodyDeclarationAfterMJMarks(Tree mjMarks){
      if (lookahead() == :ss) {
	matchAny();
	return `(ss ,(original(mjMarks)));
      } else {
	return original(mjMarks);
      } 
    }
    extend Tree mjTypeDeclarationAfterMJMarks(Tree mjMarks){
      if (lookahead() == :ss) {
	matchAny();
	if (lookahead() == :ss) {
	  throw error("Duplicated ss keyword.");
	}
	try {
	  Dynamic.bind(:currentClassName, :SS);
	  return `(ss ,(mjClassBodyDeclarationAfterMJMarks(mjMarks)));
	} finally {
	  Dynamic.unbind();
	}
      } else {
	return original(mjMarks);
      } 
    }

    extend void afterMacroExpansionPass(){
      original();
      self!tree = new TransSS().transCompilationUnit(self!tree);
    }
  }
}

public class TransSS {
  Obj epp = (Obj)Dynamic.get(:epp);

  public Tree transCompilationUnit(Tree tree){
    if (tree.tag() != :mjCompilationUnit) throw MJC.fatal("");
    TreeVec tvec = new TreeVec();
    foreach (Tree t in tree.args()){
      tvec.add(transModule(t));
    }
    return tree.modifyArgs(tvec.toArray());
  }

  public Tree transModule(Tree tree){
    if (tree.tag() != :mjModule) throw MJC.fatal("");
    Tree[] args = tree.args();
    Dynamic.bind(:ssMembers, new TreeVec());
    Dynamic.bind(:ssClass, null);
    try {
      TreeVec newTypeDecls = new TreeVec();
      Tree typeDecls = args[3];
      foreach (Tree t in typeDecls.args()){
	transTypeDecl(t, newTypeDecls);
      }

      Tree[] ssMembers = ((TreeVec)Dynamic.get(:ssMembers)).toArray();
      Tree ssClass = (Tree)Dynamic.get(:ssClass);
      if (ssMembers.length > 0 || ssClass != null){
	newTypeDecls.add(makeNewSSClass(ssClass, ssMembers));
      }

      Tree[]  newArgs = { args[0], args[1], args[2],
			  args[3].modifyArgs(newTypeDecls.toArray()) };
      return tree.modifyArgs(newArgs);
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }

  public void transTypeDecl(Tree tree, TreeVec tvec){
    if (tree.tag() == :ss){
      TreeVec ssMembers = (TreeVec)Dynamic.get(:ssMembers);
      ssMembers.add(tree.args()[0]);
    } else if (isSSClass(tree)){
      transSSClass(tree);
      if (Dynamic.get(:ssClass) != null){
	throw epp!errorAt(tree, "More than one SS class.");
      } else {
	Dynamic.set(:ssClass, tree);
      }
    } else if (tree.tag() == :mjClass){
      tvec.add(transClass(tree));
    } else if (tree.tag() == :emptyTypeDeclaration){
      tvec.add(tree);
    } else {
      throw MJC.fatal(""+ tree);
    }
  }

  public Tree transClass(Tree tree){
    Tree[] args = tree.args();
    TreeVec tvec = new TreeVec();
    Tree classBody = args[6];
    foreach (Tree t in classBody.args()){
      if (t.tag() == :ss){
	TreeVec ssMembers = (TreeVec)Dynamic.get(:ssMembers);
	ssMembers.add(t.args()[0]);
      } else {
	tvec.add(t);
      }
    }
    Tree[]  newArgs = { args[0], args[1], args[2], args[3],
			args[4], args[5],
			classBody.modifyArgs(tvec.toArray()) };
    return tree.modifyArgs(newArgs);
  }

  // $B40A48BDjL>$N>l9g$b$"$k$N$GCm0U!#(B
  // $B!JK\Ev$O!"7?%A%'%C%/%Q%9$K$J$i$J$$$H!"(B mjc.SS $B$+$I$&$+J,$+$i$J$$!*!K(B
  public boolean isSSClass(Tree tree){
    if (tree.tag() != :mjClass) return false;
    Tree mjName = tree.args()[3];
    if (mjName.tag() == :id){
      return mjName.idName() == :SS;
    } else if (mjName.tag() == :mjFQN) {
      // $B$H$j$"$($:!":G8e$NMWAG$,(B SS $B$J$i$P(B true $B$rJV$9!#(B
      Tree[] ids = mjName.args();
      return ids[ids.length - 1].idName() == :SS;
    } else {
      throw MJC.fatal(""+ tree);
    }
  }

  public void transSSClass(Tree tree){
    TreeVec ssMembers = (TreeVec)Dynamic.get(:ssMembers);
    foreach (Tree t in tree.args()[6].args()){
      if (t.tag() == :ss){
	ssMembers.add(t.args()[0]);
      } else {
	ssMembers.add(t);
      }
    }
  }

  public Tree makeNewSSClass(Tree ssClass, Tree[] ssMembers){
    if (ssClass == null){
      return `(mjClass
	       (mjMarks)
	       (modifiers)
	       (id class)
	       (id SS)		// $BC1=cL>$K$7$F$*$/!#(B
	       (extends)
	       (implements)
	       (classBody ,@ssMembers));
    } else {
      Tree[] args = ssClass.args();
      Tree[] newArgs = { args[0], args[1], args[2], args[3],
			 args[4], args[5],
			 args[6].modifyArgs(ssMembers) };
      return ssClass.modifyArgs(newArgs);
    }
  }
}

