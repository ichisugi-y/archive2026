
// class SS $B$,$J$$>l9g!#(B
module ssPlugInTest1 
//extends mj.lang.ss
 {
  define
  class A {
    ss void main(String[] args){
      original(args);
      System.out.println("=========");
      System.out.println("ssPlugInTest1");
    }
    define void foo() { }
    define ss void sssss1() { }
    define ss int fffff1;
    ss int fffff2;
  }
  define ss void sssss2() { }
  define ss int fffff3;
  ss int fffff4;
}

// class SS $B$,$"$k>l9g!#(B
module ssPlugInTest2 extends ssPlugInTest1 {
  define
  class B {
    define void foo() { }
    define ss void sssss3() { }
    define ss int fffff5;
    ss int fffff6;
  }
  ss void main(String[] args){
    original(args);
    System.out.println("ssPlugInTest2");
  }
  define ss void sssss4() { }
  ss void sssss2() { original(); }
  define ss int fffff7;
  ss int fffff8;

  class SS {
    define ss void sssss5() { }
    ss void sssss1() { original(); }
    define ss int fffff9;
    ss int fffff10;
  }
}
