/*

Copyright (c) 2001 Yuuji ICHISUGI, All Rights Reserved.

Use and copying of this software and preparation of derivative works
based upon this software are permitted. Any copy of this software or
of any derivative work must include the above copyright notice of
Yuuji ICHISUGI, this paragraph and the one after it.

This software is made available AS IS, and YUUJI ICHISUGI DISCLAIMS
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YUUJI ICHISUGI IS ADVISED
OF THE POSSIBILITY OF SUCH DAMAGES.


** Acknowledgments

The development of this software is sponsored by:
 - PRESTO program (Sakigake Kenkyu 21)
  of Japan Science and Technology Corporation
 - AIST (National Institute of Advanced Industrial Science and Technology)
 */

#epp jp.go.etl.epp.EppLibLevel0

package mjc;
import java.util.*;

// dump $B$7$?%/%i%9%U%!%$%k$r5/F0$9$k$H$-$KI,MW!#(B
// java mjc.Start $B$H$7$F<B9T$9$k!#(B
public class Start {

  public static void main(String[] args) throws Throwable {
    Class c = Class.forName("mj.lang.ss.SS");
    SS x = (SS)c.newInstance();
    x.setInstance(x);
    x._init_SS();
    x.main(args);
  }
  public static Error abstractError(){
    return new Error("MJ: abstract method has been called.");
  }
}

abstract public class SS {
  //old public static SS instance = null;

  /*
  // static initializer.
  // dump $B$7$?(B application, applet, MIDLet $B$G$@$1!"$3$l$,8F$P$l$FM_$7$$!#(B
  // dump $B$9$k;~$H(B link $B$9$k$H$-$G$O(B mjs.SS $B$r@ZBX$($J$$$HL5M}!#(B
  static {
    System.out.println("Start initialization of mj.lang.ss.SS");
    // $B%f!<%6$,Dj5A$9$k(B SS $B$N40A48BDjL>$O(B mj.lang.ss.SS $B$G$"$k$H$9$k!#(B
    try {
      Class c = Class.forName("mj.lang.ss.SS");
      SS.instance = (SS)c.newInstance();
      SS.instance.init();
      System.out.println("End initialization of mj.lang.ss.SS");
    } catch (Throwable e){
      // stack trace $B$O$3$3$G=P$9!#(B
      e.printStackTrace(System.err);
      System.err.println(e.getMessage());
      throw new Error("Error during executing main.");
    }
  }
  */

  public abstract void setInstance(SS x);
  public void _init_SS(){
    System.err.println("this:"+ this);
    System.err.println("super of this:"+ this.getClass().getSuperclass());
    System.err.println("super of super of this:"+ this.getClass().getSuperclass().getSuperclass());
    throw new Error("FATAL:"+
		    "mjc.SS#_init_SS should be overridden by mj.lang.ss.SS .");
  }
  public void main(String[] args){
    System.err.println("this:"+ this);
    System.err.println("super of this:"+ this.getClass().getSuperclass());
    System.err.println("super of super of this:"+ this.getClass().getSuperclass().getSuperclass());
    throw new Error("FATAL:"+
		    "mjc.SS#main should be overridden by mj.lang.ss.SS .");
  }
}

abstract public class MJModuleLoader {
  abstract public String getModuleSig();
}

abstract public class MJComplementaryModuleDescripor {
}
