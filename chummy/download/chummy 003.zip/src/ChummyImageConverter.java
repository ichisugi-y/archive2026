import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.imageio.*;
import javax.imageio.stream.*;

public class ChummyImageConverter {
    static PrintStream ps;

    public static void main(String[] args) {
	OutputStream os = null;

	try {
	    os = new FileOutputStream("ChummyImageConverter_err.txt");
	}
	catch (IOException e) {
	    System.exit(997);
	}
	ps = new PrintStream(os);
	    
	int ret = 999;
	
	if (args.length > 0) {
	    
	    String command = args[0];
	    if (command.equals("convert")) {
		ret = convert(args);
	    }
	    else if (command.equals("identify")) {
		ret = identify(args[1], args[2]);
	    }
	    else if (command.equals("drawString")) {
		ret = drawString(args);
	    }
	    else if (command.equals("getAvailableFontFamilyNames")) {
		ret = getAvailableFontFamilyNames(args);
	    }
	    else if (command.equals("getWriterFormatNames")) {
		ret = getWriterFormatNames(args);
	    }
	    else if (command.equals("blurImage")) {
		ret=blurImage(args);
	    }
	    else if (command.equals("rotateImage")) {
		ret=rotateImage(args);
	    }
	    else if (command.equals("flipImage")) {
		ret=flipImage(args);
	    }
	    /*
	      else if (command.equals("concatinateImage")) {
	      ret=blurImage(args);
	      }
	      else if (command.equals("cropImage")) {
	      ret = Image(args);
	      }
	    */
	    else if (command.equals("sleep")) {
		ret = sleep(args);
	    }
	    else if (command.equals("wget")) {
		ret = wget(args);
	    }
	}

	ps.close();
	try {
	    os.close();
	}
	catch (IOException e) {
	    System.exit(998);
	}
	    
	System.out.println(ret);
	System.exit(ret);
    }

    static String getSuffix(String filename) throws Exception {
	int i = filename.lastIndexOf('.');
	if (i != -1) {
	    return filename.substring(i + 1);
	}
	else {
	    throw new Exception();
	}
    }

    static boolean isSupportedWriterFormat(String name) {
	String[] formatNames = ImageIO.getReaderFormatNames();
	for (int i = 0; i < formatNames.length; i++) {
	    if (name.equals(formatNames[i])) {
		return true;
	    }
	}
	return false;
    }

    static int convert(String[] args) { // convert -size <size> src dst // size = WIDTHxHEIGHT
	final int errorCode = 10;

	try {
	    int width = 0, height = 0, i;
	    boolean fixedRatio = false;
	    for (i = 1; i < args.length; i++) {
		if (!args[i].startsWith("-")) break;

		if (args[i].equals("-size")) {
		    String s = args[++i];
		    int j = s.indexOf('x');
		    if (j != -1) {
			width = Integer.parseInt(s.substring(0, j));
			height = Integer.parseInt(s.substring(j + 1));
		    }
		}
		else if (args[i].equals("-fixedRatio")) {
		    fixedRatio = true;
		}
		else {
		    i++;
		}
	    }
	    String src = args[i];
	    String dst = args[i + 1];

	    BufferedImage image = ImageIO.read(new File(src));
            if (image == null) {
		return errorCode;
            }

	    /*
	    if (width == 0 && height == 0) {
		width = image.getWidth();
		height = image.getHeight();
	    }
	    else if (width == 0) {
		width = (image.getWidth() * height) / image.getHeight();
	    }
            else if (height == 0) {
		height = (image.getHeight() * width) / image.getWidth();
	    }

	    if (width != 0 && height != 0) {
		Image img1 = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_BGR);
		image.createGraphics().drawImage(img1, 0, 0, null);
	    }
	    */


	    int iwidth = image.getWidth(), iheight = image.getHeight();
	    double sx = (double)width / (double)iwidth;
	    double sy = (double)height / (double)iheight;
	    if (sx == 0) {
		sx = sy;
	    }
	    else if (sy == 0) {
		sy = sx;
	    }
	    else if (fixedRatio) {
		if (sx > sy) {
		    sx = sy;
		}
		else {
		    sy = sx;
		}
	    }

	    if (sx != 0 && sy != 0) {
		AffineTransform atx = AffineTransform.getScaleInstance(sx, sy);
		AffineTransformOp op = new AffineTransformOp(atx, AffineTransformOp.TYPE_BILINEAR);
		image = op.filter(image, null);
		/*
		int newWidth = (int)(iwidth * sx);
		int newHeight = (int)(iheight * sy);
		BufferedImage newImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_BGR);
		newImage.getGraphics().drawImage(image, 0, 0, newWidth - 1, newHeight- 1, 0, 0, iwidth - 1, iheight -1, Color.white, null);
		image = newImage;
		*/
	    }

	    if (!ImageIO.write(recreateImage(image), getSuffix(dst), new File(dst))) {
		return errorCode + 1;
	    }
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }

    static int identify(String src, String outfile) { // identify src resultfile
	final int errorCode = 20;

	try {
	    BufferedImage image = ImageIO.read(new File(src));
	    if (image == null) {
		return errorCode;
	    }
	    PrintStream ps = new PrintStream(new FileOutputStream(outfile));
	    ps.println(image.getWidth() + " " + image.getHeight());
	    ps.close();
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }

    static int drawString(String[] args) { // drawString -font <font> -text <text> -pos <pos> -pointsize <sie> src dst // pos = XPOSxYPOS
	final int errorCode = 30;

	try {
	    String fontFamily = "$B#M#S(B $B#P%4%7%C%/(B";
	    String text = "";
	    int x = -1, y = -1, fontSize = 24, i;
	    for (i = 1; i < args.length; i++) {
		if (!args[i].startsWith("-")) break;

		if (args[i].equals("-font")) {
		    fontFamily = args[++i];
		}
		else if (args[i].equals("-text")) {
		    text = args[++i];
		}
		else if (args[i].equals("-pos")) {
		    String s = args[++i];
		    int j = s.indexOf('x');
		    if (j != -1) {
			x = Integer.parseInt(s.substring(0, j));
			y = Integer.parseInt(s.substring(j + 1));
		    }
		}
		else if (args[i].equals("-pointsize")) {
		    fontSize = Integer.parseInt(args[++i]);
		}
		else {
		    i++;
		}
	    }
	    String src = args[i];
	    String dst = args[i + 1];

	    Font f = new Font(fontFamily, Font.PLAIN, fontSize);
	    Rectangle br = f.getStringBounds(text, new FontRenderContext(null, false, false)).getBounds();

	    BufferedImage image;
	    Color borderColor, textColor;

	    if (!src.equals("none")) {
		image = ImageIO.read(new File(src));
		if (x == -1 || y == -1) {
		    x = 20;
		    y = image.getHeight() - 20;
		}
		borderColor = Color.black;
		textColor = Color.orange;
	    }
	    else {
		image = new BufferedImage(br.width, br.height, BufferedImage.TYPE_INT_BGR);
		Graphics g = image.getGraphics();
		g.setColor(Color.white);
		g.fillRect(0, 0, br.width, br.height);
		x = - br.x;
		y = - br.y;
		borderColor = Color.white;
		textColor = Color.black;
	    }
            if (image == null) {
		return errorCode;
            }

	    Graphics g = image.getGraphics();
	    ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    g.setFont(f);

	    g.setColor(borderColor);
	    for (int k = -1; k <= 1; k++) {
		for (int j = -1; j <= 1; j++) {
		    g.drawString(text, x + k, y + j);
		}
	    }

	    g.setColor(textColor);
	    g.drawString(text, x, y);

	    if (!ImageIO.write(recreateImage(image), getSuffix(dst), new File(dst))) {
		return errorCode + 1;
	    }
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }

    static int getAvailableFontFamilyNames(String[] args) {
	try {
	    String outfile = args[1];

	    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	    String[] fontFamilyNames = ge.getAvailableFontFamilyNames();

	    PrintStream ps = new PrintStream(new FileOutputStream(outfile));
	    for (int i = 0; i < fontFamilyNames.length; i++) {
		ps.println(fontFamilyNames[i]);
	    }
	    ps.close();
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return 10;
	}
    }

    static int getWriterFormatNames(String[] args) {
	final int errorCode = 40;

	try {
	    String outfile = args[1];

	    String[] writerFormatNames = ImageIO.getWriterFormatNames();

	    PrintStream ps = new PrintStream(new FileOutputStream(outfile));
	    for (int i = 0; i < writerFormatNames.length; i++) {
		ps.println(writerFormatNames[i]);
	    }
	    ps.close();
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }

    static void printStackTrace(Exception e) {
	e.printStackTrace();
	e.printStackTrace(ps);
    }

    static int blurImage(String[] args){
	int blurImageErrorFlag=128;

	String iAbsFilePath=args[1];
	String oAbsFilePath=args[2];
	String param1String=args[3];
	//String param2String=args[4];

	int param1=Integer.parseInt(param1String);

	int width=0,height=0;

	File iFile=null;
	try{
	    iFile=new File(iAbsFilePath);
	}catch(Exception e){
	    printStackTrace(e);
	    return 1+blurImageErrorFlag;
	}
	BufferedImage image = null;
	try{
	    image= ImageIO.read(iFile);
	}catch(Exception e){
	    printStackTrace(e);
	    return 2+blurImageErrorFlag;
	}
	if(null == image) {
	    return 3+blurImageErrorFlag;
	}
	width=image.getWidth();
	height=image.getHeight();

	    

	//Graphics g=image.getGraphics();

	///
	    
	BufferedImage resultImg=null;
	try{
	    resultImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_BGR);
	    resultImg.createGraphics().drawImage(image,0,0,null);
	}catch(Exception e) {
	    printStackTrace(e);
	    return 4+blurImageErrorFlag;
	}

	float[] Gauss5x5 = {//$BD6%F%-%H!<(B
	    0.f, 0.f, 0.f, 0.f, 0.f,
	    0.f, 0.f, 0.f, 0.f, 0.f,
	    0.f, 0.f, 1.f, 0.f, 0.f,
	    0.f, 0.f, 0.f, 0.f, 0.f,
	    0.f, 0.f, 0.f, 0.f, 0.f,
	};
	    
	try{
	    Kernel kernel = new Kernel(5,5,Gauss5x5);
	    ConvolveOp cop = new ConvolveOp(kernel);
	    cop.filter(resultImg,image);
	    //cop.filter(image, resultImg);
	}catch(Exception e) {
	    printStackTrace(e);
	    return 5+blurImageErrorFlag;
	}

	try{
	    ImageIO.write(image, getSuffix(oAbsFilePath), new File(oAbsFilePath));
	    //ImageIO.write(resultImg, getSuffix(oAbsFilePath), new File(oAbsFilePath));
	}catch(Exception e){
	    printStackTrace(e);
	    return 6+blurImageErrorFlag;
	}

	return 0;
    }

    static int sleep(String[] args) {
	final int errorCode = 50;

	if (args.length == 2) {
	    int ms = Integer.parseInt(args[1]);
	    try {
		Thread.sleep(ms);
	    }
	    catch (Exception e) {
	    }
	    return 0;
	}
	else {
	    return errorCode + 9;
	}
    }

    static int rotateImage(String[] args) { // rotateImage -angle <angle> <src> <dst>
	final int errorCode = 70;
	try {

	    double angle = 0;
	    int i;

	    for (i = 1; i < args.length; i++) {
		if (!args[i].startsWith("-")) break;

		if (args[i].equals("-angle")) {
		    angle = Double.parseDouble(args[++i]);
		}
		else {
		    i++;
		}
	    }
	    String src = args[i];
	    String dst = args[i + 1];

	    BufferedImage image = ImageIO.read(new File(src));
            if (image == null) {
		return errorCode;
            }

	    AffineTransform atx = AffineTransform.getRotateInstance(Math.toRadians(angle));
	    AffineTransformOp op = new AffineTransformOp(atx, AffineTransformOp.TYPE_BILINEAR);

	    double tx = 0, ty = 0;
	    Rectangle2D br = op.getBounds2D(image);
	    if (br.getX() < 0.) {
		tx = -br.getX();
	    }
	    if (br.getY() < 0.) {
		ty = -br.getY();
	    }
	    
	    atx = new AffineTransform();
	    atx.translate(tx, ty);
	    atx.rotate(Math.toRadians(angle));
	    op = new AffineTransformOp(atx, AffineTransformOp.TYPE_BILINEAR);

	    image = op.filter(image, null);

	    if (!ImageIO.write(recreateImage(image), getSuffix(dst), new File(dst))) {
		return errorCode + 1;
	    }
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }


    static int flipImage(String[] args) { // flipImage -flip <flip> <src> <dst> // flip = H | V | HV
	final int errorCode = 80;
	try {

	    boolean Hflip = false, Vflip = false;
	    int i;

	    for (i = 1; i < args.length; i++) {
		if (!args[i].startsWith("-")) break;

		if (args[i].equals("-flip")) {
		    String s = args[++i];
		    Hflip = s.indexOf('H') != -1;
		    Vflip = s.indexOf('V') != -1;
		}
		else {
		    i++;
		}
	    }
	    String src = args[i];
	    String dst = args[i + 1];

	    BufferedImage image = ImageIO.read(new File(src));
            if (image == null) {
		return errorCode;
            }

	    AffineTransform atx = new AffineTransform();

	    double w = (double)image.getWidth(), h = (double)image.getHeight();
	    atx.translate(Hflip ? w : 0, Vflip ? h : 0);
	    atx.scale(Hflip ? -1 : 1, Vflip ? -1 : 1);

	    AffineTransformOp op = new AffineTransformOp(atx, AffineTransformOp.TYPE_BILINEAR);
	    image = op.filter(image, null);

	    if (!ImageIO.write(recreateImage(image), getSuffix(dst), new File(dst))) {
		return errorCode + 1;
	    }
	    return 0;
	}
	catch (Exception e) {
	    printStackTrace(e);
	    return errorCode + 9;
	}
    }

    static int wget(String[] args) { // wget <URL> <filename>
	final int errorCode = 90;

	if (args.length != 3) {
	    return errorCode + 2;
	}

	byte[] buf = new byte[2048];
	int len = 0;
	try {
	    String urlStr = args[1];
	    URL url = new URL(urlStr);
	    InputStream is = url.openStream();

	    for (;;) {
		int n = is.read(buf, len, 1024);
		if (n < 0) break;
		len += n;
		if (buf.length < len + 1024) {
		    byte[] newbuf = new byte[buf.length * 2];
		    System.arraycopy(buf, 0, newbuf, 0, len);
		    buf = newbuf;
		}
	    }
	    is.close();
	}
	catch (IOException e) {
	    printStackTrace(e);
	    return errorCode;
	}

	try {
	    OutputStream os = new FileOutputStream(args[2]);
	    os.write(buf, 0, len);
	    os.close();

	    return 0;
	}
	catch (IOException e) {
	    printStackTrace(e);
	    return errorCode + 1;
	}
    }

    static BufferedImage recreateImage(BufferedImage image) {
	int iwidth = image.getWidth(), iheight = image.getHeight();
	BufferedImage newImage = new BufferedImage(iwidth, iheight, BufferedImage.TYPE_INT_BGR);
	newImage.getGraphics().drawImage(image, 0, 0, iwidth, iheight, Color.white, null);
	return newImage;
    }
}
