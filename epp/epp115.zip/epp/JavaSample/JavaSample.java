/*
 Sample code of Java.
*/

package testPackage;
import java.util.Vector;
import java.io.*;

// Empty type declaration. 
;

// Interface declaration.
public interface interfaceFoo {
  void foo();
}


// Class declaration.
public class JavaSample extends superClassName implements interfaceFoo {
  // Simple field.
  int field1;

  // Field declaratoin with modifiers and initialization.
  private final int FIELD = 123;

  // Static initializer;
  static {
    field1 = 0;
  }

  // Simple constructor.
  JavaSample(){ field1 = 0; }

  // Complex constructor.
  private JavaSample(int x) throws java.io.IOException {
    super();
    this();
    field1 = 0;
  }

  // Simple method.
  void foo(){ return; }

  // Complex method.
  int[][] foo(int x, int y[], int[] z) throws IOException {
    // Return with a return value.
    return null;
  }

  // A method which returs array.
  int foo(int x)[][] {
    return null;
  }

  // Abstract method.
  abstract void bar();


  void foo(){
    // Variable declarations.
    int a;
    int a, b;
    int a[][];
    int a = 0;
    int a, b = 0, c;
    int[] a, b[];
    int a[] = {0, 1, 2, 3};
    java.lang.Vector v = null;

    // Literals.
    a = -123;
    b = true;
    c = 'c';
    c = '\n';
    c = '"';
    d = 1.000;
    d = 1.2e3;
    d = 1.2e+3;
    s = null;
    s = "string\n";
    s = "\"";

    // Literals (from JLS1.0 book)
    int i = 0 + 2 + 0372 + 0xDadaCafe + 1996 + 0x00FF00FF;
    long l = 0l + 0777L + 0x100000000L + 2147483648L + 0xC0B0L;
    float f = 1e1f + 2.f + .3f + 0f + 3.14f + 6.022137e+23f;
    double d = 1e1 + 2. + .3 + 0.0 + 3.14 + 1e-9d + 1e137;
    int i = 'a' + '"' + '\''+ '\"' + '\n' + '\\' + '\0' + '\00' + '\000';
    String s = "'";

    // Yet another literals.
    double d = 009.0 + 1d + 0Xff + 1.e2 + 1F + 1E+2f + 1E+2D;

    // // These literals are illegal.
    // double d = 1.2e+x + 1.2L + 0x1.2;
    // // These literals are illegal but accepted by current EPP.
    // double d = 009 + 0x + 1e;
    // int i = '\a' + 'aaaa';

    // Expressions.
    a = a + b * c - d / e % f;
    a = a + (b * c) - ((d / e) % f);
    a = b += c -= d;
    a = -a / +b;
    a = a++ / ++b / --c / c--;
    a = ! (x == 0) && (y != 0) || (z > 0);
    a = ~ w ^ x & y | z ;
    a = x << 1 + y >> 2 + z >>> 3;
    a = "string" + exp;
    a = (x instanceof String) ? 0 : 1;
    a = x[0][1];
    a = this;
    
    // Casts.
    int i = (1 + 2) + 3 + (int)+1 + (int[])++x;
    Object o = (T)x + (T[])mmm() + (T)!x + (T)x.b + (T)new T() + (T)(exp);

    // Instantiations
    Object x;
    x = new TestClass(arg1, arg2);
    x = new TestClass[10];
    x = new TestClass[10][][];
    x = new TestClass[10][1024][][];
    x = new very.longpackage.name();

    // Field access;
    a = obj.field1;
    a = System.out;
    a = super.field1;
    a = (exp).a.b;
    a = very.longpackage.name.and.Class.field.value;

    // Method invocations;
    myMethod();
    myMethod(0, 1);
    super.mymethod();
    System.exit(1);
    obj.method();
    (exp).method();
    System.err.println();
    
    // Anonymous Arrays.
    Tree[] a = new Tree[] {a1, a2, a3};
    Tree[][] a = new Tree[][] {a, a,};

    // Statements.
    ; // Empty statement
    if (a == 0) b++;
    if (a == 0) b++; else c++;
    if (a == 0) if (b == 0) a++; else b++;
    for (;;) foo();
    for (int i=0; i < 10; i++) foo(i);
    for (int i=0, j=0; i + j < 10 ; i++, j++) { foo(i); foo(j); }
    for (x=0, y=0; x + y < 10 ; x++, y++) { foo(x); foo(y); }
    while (true) { break; continue; }
    do { foo(); } while(false);
  label1: { break label1; continue label1; }
    switch (exp){
    case 0:
      foo(0); break;
    case 1:
    default:
      // No statements are requied after SwitchLabel.
    }
    synchronized (exp) { foo(); }
    try {
      foo(0);
    } catch (Error e){
      throw new Error("message");
    } finally {
      cleanUp();
    }


        
    // An anonymous class and final local variables.
    Object t = new Anon() {
      final int a;
      // An instance initializer.
      {
	a = 123;
      }
      int Foo(final int x, final int y) {
	final int z;
	return a;
      }
    };

    // An inner class at BlockStatement.
    public class Foo {
      public int a;
      // An inner class at ClassMember.
      public class Bar {
	public int b;
      }
    }

    // Enclosing instance creations.
    Object t = a.b.c.new Foo().d.e;
    Object t = a.b.c.new Foo(){}.d.e;
    Object t = (x).new Foo().d.e;
    Object t = (x).new Foo(){}.d.e;
    
    // A quolified current instance.
    ClassName.this;

    // An explicit constructor invocation within a subclass of a inner class.
    xxx.super();
    
    // Class Literals.
    int.class.a;
    void.class.a;
    int[].class.a;
    SomeClass.class.a;
    SomeClass[].class.a;
    foo.bar.baz.SomeClass.class.a;
    foo.bar.baz.SomeClass[].class.a;


    // Return without return value.
    return;
  }
}
