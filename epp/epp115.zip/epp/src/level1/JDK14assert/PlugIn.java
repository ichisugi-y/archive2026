/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 EPP patch which accepts JDK1.4 assert statement.

Statement
	assert Expression ;
	assert Expression : Expression ;


*/


#epp jp.go.etl.epp.EppLibLevel0

package JDK14assert;

SystemMixin assert {
  class Epp {
    extend Tree statementTop(){
      if (lookahead() == :assert){
	matchAny();
	Tree e1 = expression();
	if (lookahead() == :":"){
	  matchAny();
	  Tree e2 = expression();
	  match(:";");
	  return new Tree(:assert2, e1, e2);
	} else {
	  match(:";");
	  return new Tree(:assert1, e1);
	}
      } else {
	return original();
      }
    }

    extend void initTypeCheckerTable() {
      original();

      defineTypeChecker(:assert1,	new Assert1TypeChecker());
      defineTypeChecker(:assert2,	new Assert2TypeChecker());
    }

    extend void initTranslatorTable() {
      original();
      defineTranslator(:assert1, new DefaultTranslator());
      defineTranslator(:assert2, new DefaultTranslator());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:assert1, new SimpleEmitter("assert (%);"));
      defineEmitter(:assert2, new SimpleEmitter("assert (%) : (%);"));
    }
  }
}
class Assert1TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree e1 = Type.coerce(Type.Tboolean, typeCheckTree(tree.args()[0]));
    return tree.modifyTypeAndArgs(Type.Tvoid, new Tree[]{ e1 });
  }
}
class Assert2TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree e1 = Type.coerce(Type.Tboolean, typeCheckTree(tree.args()[0]));
    Tree e2 = typeCheckTree(tree.args()[1]);
    return tree.modifyTypeAndArgs(Type.Tvoid, new Tree[]{ e1, e2 });
  }
}
