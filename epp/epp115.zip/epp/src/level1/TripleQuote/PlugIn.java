/*

 TripleQuote plug-in


Characteristics
---------------
- At the inside of triple-quoted string,
all double-quotes, newlines and back-slashes 
are not interpreted as special characters.
In other words, TripleQuote plug-in automatically escapes these
special characters.

- Line-separators in triple-quoted strings always become "\n",
independent of the line-separators of the source-code.


Examples
--------
    System.out.println("""\t""".equals("\\t"));
    System.out.println(""" "abc" """.equals(" \"abc\" "));
    System.out.println(""" ""abc"" """.equals(" \"\"abc\"\" "));
    System.out.println("""/\(ab*\)/""".equals("/\\(ab*\\)/"));
    System.out.println("""abc
	def""".equals("abc\n\tdef"));


Differences between TripleQuote plug-in and python's triple quote
-----------------------------------------------------------------

 Like python's triple quote:

- You can use double-quotes without escape charactors.
- You can use newlines at the inside of triple-quoted strings.

 Unlike python's triple quote:

- Back-slashes are not interpreted.
- Triple "single-quote" is not supported. Only triple "double-quote"
is supported.


TIPS
----
If you dare to use escape sequence, exit the triple quote temporary.
Example:
	""" ... """ + "\033" + """ ... """

BUGS
----
- Unicode escapes are actually not supported yet.
- Odd number of double-quote at the inside of triple-quoted string 
will mess up emacs's java-mode.
- String literals with more than 65536 characters 
are not compiled correctly by javac and jikes compilers.


*/

#epp jp.go.etl.epp.EppLibLevel0

package TripleQuote;

SystemMixin TripleQuote {
  class Epp {
    extend Token readStringLiteral(EppInputStream in){
      int begin = in.pointer();
      char c = in.getc();
      if (c != '\"') throw Epp.fatal("readStringLiteral is called but the first charactor is not a double quote.");

      if (in.getc() == '\"' && in.getc() == '\"'){
	StringBuffer buf = new StringBuffer();
	while (true) {
	  c = in.getc();
	  if (c == '\"'){
	    int begin2 = in.pointer();
	    if (in.getc() == '\"' && in.getc() == '\"') {
	      if (in.peekc() == '\"'){
		throw error("More than three double-quote appeared.");
	      } else {
		break;
	      }
	    }
	    in.backtrack(begin2);
	  }

	  if (c == '\\'){
	    buf.append('\\');
	    buf.append('\\');

	  } else if (c == '\"'){
	    buf.append('\\');
	    buf.append('\"');

	  } else if (c == '\n'){
	    buf.append('\\');
	    buf.append('n');

	  } else if (c == '\r'){
	    if (in.peekc() == '\n'){
	      in.getc();
	    }
	    buf.append('\\');
	    buf.append('n');

	  } else {
	    buf.append(c);
	  }
	}
	return new LiteralToken(:string, buf.toString());

      } else {
	in.backtrack(begin);
	return original(in);
      }
    }
  }
}
