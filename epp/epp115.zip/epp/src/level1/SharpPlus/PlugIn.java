/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
Usage
-----

#+ PROP XXX
#- PROP XXX

 XXX is TypeDeclaration, ClassBodyDeclaration or Statement.


NOTE
----
 #+ can be nested.

 Unlike #ifdef or Common Lisp's #+, the statement will not be just skipped
but translated to an empty statement if the condition is false.

*/


#epp jp.go.etl.epp.EppLibLevel0


package SharpPlus;

SystemMixin SharpPlus {
  class Epp {
    
    extend Token readSharp(EppInputStream in){
      char c = in.peekc();
      switch(c){
      case '+':
        in.getc();
	return :"#+";
      case '-':
        in.getc();
	return :"#-";
      default:
	return original(in);
      }
    }
    
    extend Tree statementTop(){
      if (lookahead() == :"#+" || lookahead() == :"#-"){
	// If it is "#+ FALSE" or "#- TRUE", ignore the next expression.
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  statement();
	  return new Tree(:emptyStatement);
	} else {
	  return statement();
	}
      } else {
	return original();
      }
    }
    
    extend Tree classBodyDeclarationTop(){
      if (lookahead() == :"#+" || lookahead() == :"#-"){
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  classBodyDeclaration();
	  return new Tree(:emptyClassBodyDeclaration);
	} else {
	  return classBodyDeclaration();
	}
      } else {
	return original();
      }
    }
    
    extend Tree typeDeclarationTop(){
      if (lookahead() == :"#+" || lookahead() == :"#-"){
	if ((matchAny() == :"#+") ^ (evalSharpPlusExpression(matchAny()))){
	  typeDeclaration();
	  return new Tree(:emptyTypeDeclaration);
	} else {
	  return typeDeclaration();
	}
      } else {
	return original();
      }
    }


    // This method evaluates the value of ifdef expression.
    define implement boolean evalSharpPlusExpression(Token token){
      if (token.isSymbol()){
	String prop = System.getProperty(token.toString());
	return prop != null && ! prop.equals("false");
      } else if (token.literalTag() == :string) {
	String str = token.literalContents();
	int eq = str.indexOf('=');
	String key = str.substring(0, eq);
	String val = str.substring(eq + 1);
	String prop = System.getProperty(key);
	return  prop != null && prop.equals(val);
      } else {
	throw error("Symbol or String is required as an expression for #+/#- .");
      }
    }
  }
}
