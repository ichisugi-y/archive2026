/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
 NOTE:

 This plug-in is no longer supported.



$B"!;EMM(B
$B!&%=!<%9%3!<%ICf$N%3%a%s%H$bCj>]9=J8LZ$K4^$a!"=PNO%U%!%$%k$K$b4^$a$k!#(B

$B!&;DG0$J$,$i!"%3%a%s%H$N0LCV$r@53N$KCj>]9=J8LZCf$N0LCV$KH?1G$5$;$k(B
$BJ}K!$O$J$$!#$=$N$?$a!"Nc$($P!"(B
	{
	  System.out.println(        // comment
			     true);
	}

$B$N$h$&$K<0$NCf$K%3%a%s%H$,$"$k>l9g$O!"(B

	{
	  System.out.println(true);
	  // comment
	}

$B$H=q$+$l$?$+$N$h$&$JCj>]9=J8LZ$K$J$k!#(B

$B!&F1MM$NM}M3$K$h$j!"(B
package $B@k8@$H(B import $B@k8@$h$j0JA0$K%3%a%s%H$,=q$+$l$F$$$k>l9g$b!"(B
package $B@k8@$H(B import $B@k8@$h$j0J9_$K=q$+$l$?$+$N$h$&$JCj>]9=J8LZ$K$J$k!#(B

$B!&(B javadoc $B$rDL$k%=!<%9%3!<%I$O!"JQ498e$b$A$c$s$H(B javadoc $B$rDL$k!J$O$:!K!#(B

$B!&%3%a%s%H$N%N!<%I$K$b$A$c$s$H9THV9f!"3+;O0LCV!"=*N;0LCV>pJs$,$D$/!#(B


$B"!<BAu%a%b(B
$B!&(BLex $B$r3HD%$7!"%3%a%s%H$,=P$F$/$k$H%-%e!<$KJ]B8$9$k$h$&$K$9$k!#(B

$B!&(BtypeDeclarationTop, statementTop, classBodyDeclarationTop $B$r3HD%$9$k!#(B
$B$b$7%-%e!<$K%3%a%s%H$,$"$l$P!"$=$l$r<h$j=P$7$FJV$9!#(B
$B$=$&$G$J$1$l$P!"%*%j%8%J%k$NF0:n$r$9$k!#(B

$B!&$=$l$@$1$@$H!"Nc$($P%V%m%C%/$N:G8e$N(B "}" $B$ND>A0$N%3%a%s%H$,(B
$B<h$j$3$\$5$l$F$7$^$&$N$G!"$=$l$r$5$1$k$?$a!"(B
typeDeclarationsBody, classBodyRest, blockRest $B$N#3$D$N%a%=%C%I$r:FDj5A!#(B

$B!&%3%a%s%H$r%N!<%I$K$7$J$$$G!"(B
 Tree $B$N(B property $B$KJ]B8$9$k$H$$$&<j$b$"$k$,!"$=$&$7$J$$!#(B
block $B$NCf$KC1FH$G%3%a%s%H$,=P$F$/$k$3$H$b$"$k$N$G!#(B 
$BNc!'(B
{
  // comment
}

$B!&J#?t9T$K$o$?$k%3%a%s%H$O!"#19T$E$DJL$N(B CommentLiteral $B$H$7$F(B
$B;z6g2r@O$5$l$k!#$3$l$O!"=PNO$9$k;~!"9THV9f$r9g$o$;$d$9$/$9$k$?$a$H!"(B
$B%W%i%C%H%U%)!<%`0MB8$N2~9T%3!<%I$r(B String $B$NCf$K4^$a$?$/$J$+$C$?$?$a!#(B

$B!&(B Emitter $B$G$O(B :outputLineNumbe $B$r;H$C$F9T$r9g$o$;$k!#(B



AST format
----------

TypeDeclaration:
	<original alternatives>
	Comment

ClassBodyDeclaration
	<original alternatives>
	Comment

Statement:
	<original alternatives>
	Comment

Comment:
	(javadocComment CommentLiteral*)
	(endOfLineComment CommentLiteral*)
	(traditionalComment CommentLiteral*)

CommentLiteral:
	(literalTree commentLiteral String)



*/

#epp jp.go.etl.epp.EppLibLevel0

package ParseComment;
import java.util.Vector;
import java.io.*;

SystemMixin ParseComment {
  class Epp {

    extend void initializationPass() {
      original();
      // Comment queue.
      Dynamic.bind(:comments, new Vector());
    }


    //--------------------------------------------------
    // Extend lex.

    redefine Token readEndOfLineComment(EppInputStream in){
      StringBuffer buf = new StringBuffer();
      char c = in.peekc();
      if (Opts.commentColon && c == ':'){
	in.getc();
	return readToken(in);
      }

      int lineNumber = in.lineNumber();
      int beginning = in.pointer();

      c = in.getc();
      while (true) {
	if (c == '\n' || c == '\r') break;
	buf.append(c);
	c = in.getc();
      }

      TreeVec tvec = new TreeVec();
      tvec.add(commentLiteral(buf.toString(),
			      lineNumber, beginning, in.pointer() - 1));
      putCommentNode(:endOfLineComment, tvec,
		     lineNumber, beginning - 2, in.pointer() - 1);
      // Read next token.
      return readToken(in);
    }

    redefine Token readTraditionalComment(EppInputStream in){
      StringBuffer buf = new StringBuffer();

      int commentLineNumber = in.lineNumber();
      int commentBeginning = in.pointer() - 2;

      char c = in.peekc();

      if (Opts.commentColon && c == ':'){
	in.getc();
	return readToken(in);
      }

      Symbol commentTag;
      if (c == '*'){
	commentTag = :javadocComment;
	int p = in.pointer();
	in.getc();
	if (in.peekc() == '/'){
	  // Special case. "/**/" is a documentation comment.
	  // See JLS 3.7 .
	  // Backtrack the input pointer to "/**/"
	  //                                   ^
	  in.backtrack(p);
	}
      } else {
	commentTag = :traditionalComment;
      }

      TreeVec tvec = new TreeVec();

      int literalLineNumber = in.lineNumber();
      int literalBeginning = in.pointer();

      c = in.getc();
      while (true) {
	if (c == '*') {
	  c = in.getc();
	  if (c == '/') break;
	  buf.append('*');
	} else if (c == '\n' || c == '\r'){
	  int literalEnd = in.pointer() - 1;
	  if (c == '\r'){
	    c = in.getc();
	    if (c != '\n'){
	      in.ungetc(c);
	    }
	  }
	  tvec.add(commentLiteral(buf.toString(),
				  literalLineNumber,
				  literalBeginning,
				  literalEnd));
	  literalLineNumber++;
	  literalBeginning = in.pointer();
	  c = in.getc();
	  buf.setLength(0);
	} else {
	  buf.append(c);
	  c = in.getc();
	}
      }
      tvec.add(commentLiteral(buf.toString(),
			      literalLineNumber,
			      literalBeginning,
			      in.pointer() - 2));

      putCommentNode(commentTag, tvec,
		     commentLineNumber, commentBeginning, in.pointer());

      // Read next token.
      return readToken(in);
    }
    

    //--------------------------------------------------
    // Extend parser.

    extend Tree typeDeclarationTop() {
      if (commentExists()){
	return getCommentNode();
      } else {
	return original();
      }
    }
    
    extend Tree classBodyDeclarationTop() {
      if (commentExists()){
	return getCommentNode();
      } else {
	return original();
      }
    }

    extend Tree statementTop() {
      if (commentExists()){
	return getCommentNode();
      } else {
	return original();
      }
    }


    // In order to pick up the LAST comment,
    //these three methods should be redefined.
    redefine Tree typeDeclarationsBody() {
      TreeVec tvec = new TreeVec();
      while(true) {
	if (lookahead().isLiteralToken() &&
	    lookahead().literalTag() == :eof
	    && ! commentExists()	// Added.
	    ){
	  break;
	} else {
	  tvec.add(typeDeclaration());
	}
      }
      return new Tree(:typeDeclarations, tvec);
    }
    redefine Tree classBodyRest() {
      TreeVec tvec = new TreeVec();
      while (lookahead() != :"}"
	     || commentExists()	// Added.
	     ) {
	tvec.add(classBodyDeclaration());
      }
      match(:"}");
      return new Tree(:classBody, tvec.toArray());
    }
    redefine Tree blockRest() {
      TreeVec tvec = new TreeVec();
      while (lookahead() != :"}"
	     || commentExists()	// Added.
	     ) {
	tvec.add(statement());
      }
      match(:"}");
      return new Tree(:block, tvec);
    }

    
    //--------------------------------------------------
    // Comment queue manipuration.
    
    define implement Tree commentLiteral(String literalContents,
					 int lineNumber,
					 int beginning,
					 int end
					 ){
      Vector comments = (Vector)Dynamic.get(:comments);
      Dynamic.bindInt(:lineNumberOfThisNode, lineNumber);
      Dynamic.bindInt(:beginningPointOfThisNode, beginning);
      Dynamic.bindInt(:endPointOfThisNode, end);
      try {
	return new LiteralTree(:commentLiteral, literalContents);
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }
    
    define implement void putCommentNode(Symbol commentTag,
					 TreeVec commentLiterals,
					 int lineNumber,
					 int beginning,
					 int end
					 ){
      Vector comments = (Vector)Dynamic.get(:comments);
      Dynamic.bindInt(:lineNumberOfThisNode, lineNumber);
      Dynamic.bindInt(:beginningPointOfThisNode, beginning);
      Dynamic.bindInt(:endPointOfThisNode, end);
      try {
	comments.addElement(new Tree(commentTag, commentLiterals));
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }
    
    define implement boolean commentExists(){
      Vector comments = (Vector)Dynamic.get(:comments);
      return (! comments.isEmpty());
    }

    define implement Tree getCommentNode(){
      Vector comments = (Vector)Dynamic.get(:comments);
      Tree commentTree = (Tree)comments.elementAt(0);
      comments.removeElementAt(0);
      return commentTree;
    }
    
    //--------------------------------------------------
    // FileSignature
    extend Tree normalizeTypeDeclaration(Tree tree){
      Symbol tag = tree.tag();
      if (tag == :javadocComment ||
	  tag == :endOfLineComment ||
	  tag == :traditionalComment){
	// Dummy.
	return `(typeDeclarationSignature (id void) (id void));
      } else {
	return original(tree);
      }
    }
    extend void normalizeClassBodyDeclaration(TreeVec tvec,
					      Tree tree){
      Symbol tag = tree.tag();
      if (tag == :javadocComment ||
	  tag == :endOfLineComment ||
	  tag == :traditionalComment){
	// Dummy.
	tvec.add(`(typeDeclarationSignature (id void) (id void)));
      } else {
	original(tvec, tree);
      }
    }
    
    //--------------------------------------------------
    // TypeChecker and Emitter

    extend void initTypeCheckerTable () {
      original();
      defineTypeChecker(:javadocComment,	new Void1TypeChecker());
      defineTypeChecker(:endOfLineComment,	new Void1TypeChecker());
      defineTypeChecker(:traditionalComment,	new Void1TypeChecker());
    }

    extend void initEmitterTable() {
      original();
      defineEmitter(:javadocComment, new TraditionalCommentEmitter());
      defineEmitter(:traditionalComment, new TraditionalCommentEmitter());
      defineEmitter(:endOfLineComment, new EndOfLineCommentEmitter());
    }
  }
}

class TraditionalCommentEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException  {
    Symbol tag = tree.tag();
    Tree[] args = tree.args();
    if (tag == :javadocComment){
      emitString(out, "/**");
    } else if (tag == :traditionalComment){
      emitString(out, "/*");
    } else {
      throw Epp.fatal("");
    }
    int current = Dynamic.getInt(:outputLineNumber);
    for (int i = 0; i < args.length - 1; i++) {
      emitString(out, args[i].literalToken().literalContents());
      emitString(out, Opts.lineSeparator);
      current++;
    }
    emitString(out, args[args.length - 1].literalToken().literalContents());
    Dynamic.setInt(:outputLineNumber, current);
    
    emitString(out, "*/");
  }
}

class EndOfLineCommentEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException  {
    Tree[] args = tree.args();
    emitString(out, "//");
    emitString(out, args[0].literalToken().literalContents());
    
    emitString(out, Opts.lineSeparator);
    int current = Dynamic.getInt(:outputLineNumber);
    Dynamic.setInt(:outputLineNumber, current + 1);
  }
}
