/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

 This plug-in implements operator overloading.
 If the type of the first expression is a class, 
the following binary operators will be translated to method invocations.

	a + b		a.plus(b)
	a - b		a.minus(b)
	a * b		a.times(b)
	a / b		a.divide(b)
	a % b		a.modulus(b)
	a < b		a.lessThan(b)
	a > b		a.greaterThan(b)
	a <= b		! a.greaterThan(b)
	a >= b		! a.lessThan(b)

*/


#epp jp.go.etl.epp.EppLibLevel0

package OperatorOverloading;


SystemMixin OperatorOverloading {
  class Epp {
    extend void initTypeCheckerTable () {
      original();
      extendTypeChecker(:+, new ExpandPlusOperatorOverloading());
      extendTypeChecker(:-, new ExpandOperatorOverloading(:minus));
      extendTypeChecker(:*, new ExpandOperatorOverloading(:times));
      extendTypeChecker(:/, new ExpandOperatorOverloading(:divide));
      extendTypeChecker(:%, new ExpandOperatorOverloading(:modulus));
      extendTypeChecker(:<, new ExpandOperatorOverloading(:lessThan));
      extendTypeChecker(:>, new ExpandOperatorOverloading(:greaterThan));
      extendTypeChecker(:<=, new ExpandOperatorOverloadingNot(:greaterThan));
      extendTypeChecker(:>=, new ExpandOperatorOverloadingNot(:lessThan));
      //extendTypeChecker(:==, new ExpandOperatorOverloading(:));
      //extendTypeChecker(:!=, new ExpandOperatorOverloading(:));
    }
  }
}



class ExpandPlusOperatorOverloading extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    if (t1.tag() == :class
	&& t1.classInfo().getName() != :"java.lang.String"){
      // e1.plus(e2)
      return `(invokeExp ,(newArgs[0])
	       (id plus) (argumentList ,(newArgs[1])));
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

class ExpandOperatorOverloading extends TypeChecker {
  Tree methodName;

  ExpandOperatorOverloading(Symbol methodName){
    this.methodName = new Identifier(methodName);
  }

  public Tree call(Tree tree) {
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    if (t1.tag() == :class){
      // e1.xxx(e2)
      return `(invokeExp ,(newArgs[0])
	       ,methodName (argumentList ,(newArgs[1])));
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}


class ExpandOperatorOverloadingNot extends TypeChecker {
  Tree methodName;

  ExpandOperatorOverloadingNot(Symbol methodName){
    this.methodName = new Identifier(methodName);
  }

  public Tree call(Tree tree) {
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    if (t1.tag() == :class){
      // ! e1.xxx(e2)
      return `(! (invokeExp ,(newArgs[0])
		  ,methodName (argumentList ,(newArgs[1]))));
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}
