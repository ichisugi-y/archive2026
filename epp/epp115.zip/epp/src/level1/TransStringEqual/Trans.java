/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.Symbol
#epp jp.go.etl.epp.BackQuote

package TransStringEqual;
import jp.go.etl.epp.epp.*;

public class Trans {
  String inputFileName;
  Tree compilationUnitTree;

  Trans(String inputFileName, Tree compilationUnitTree){
    this.inputFileName = inputFileName;
    this.compilationUnitTree = compilationUnitTree;
  }

  Tree start(){
    return translateStringEquals(compilationUnitTree);
  }

  Tree translateStringEquals(Tree tree){
    Tree[] args = tree.args();
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){
      newArgs[i] = translateStringEquals(args[i]);
    }
    
    if (tree.tag() == :"==" &&
	isString(args[0]) && isString(args[1])) {
      return StringNode.gen("(%t).equals(%t)", newArgs[0], newArgs[1]);
      
    } else if (tree.tag() == :"!="  &&
	       isString(args[0]) && isString(args[1])) {
      return StringNode.gen(" ! (%t).equals(%t)", newArgs[0], newArgs[1]);
      
    } else {
      return tree.modifyArgs(newArgs);
    }
  }

  boolean isString(Tree tree){
    return (tree.type().tag() == :class &&
	    tree.type().classInfo().getName() == :"java.lang.String");
  }
}
