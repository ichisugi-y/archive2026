/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

 This plug-in is an example of global source code translation
using "StringNode" .
 The following translation will be applied to all input files.


	s1 == s2	-->	s1.equals(s2)
	s1 != s2	-->	! s1.equals(s2)


 Usage:
	epp -global -type-check -plug-in TransStringEqual -r .

*/


#epp jp.go.etl.epp.EppLibLevel0

package TransStringEqual;


SystemMixin TransStringEqual {
  class Epp {
    extend void globalProcessAfterTypeCheckingPass() {
      original();
      
      for (int i = 0; i < (self!allFileInfo).length; i++){
	Trans translator
	  = new Trans((self!allFileInfo)[i].getInputFileName(),
		      (self!allFileInfo)[i].getTree());
	(self!allFileInfo)[i].setTree(translator.start());
      }
    }
  }
}
