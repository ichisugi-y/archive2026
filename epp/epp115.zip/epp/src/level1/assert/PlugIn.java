/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 If epp is invoked with -DNDEBUG=true option,
"assert(p);" will be expanded to an empty statement.

Now, the syntax of assert statement becomes JDK1.4 compatible.

Statement:
	<original alternatives>
	assert Expression ;
	assert Expression : Expression ;

*/


#epp jp.go.etl.epp.EppLibLevel0

package assert;

SystemMixin assert {
  class Epp {

    extend Tree statementTop(){
      if (lookahead() == :assert){
	matchAny();
	Tree exp1 = expression();
	if (lookahead() == :":"){
	  matchAny();
	  Tree exp2 = expression();
	  match(:";");
	  return new Tree(:assert, exp1, exp2);
	} else {
	  match(:";");
	  return new Tree(:assert, exp1);
	}
      } else {
	return original();
      }
    }

    extend void initInvokeStyleMacroTable() {
      original();
      defineMacro(:assert, new AssertMacro());
    }
  }
}

class AssertMacro extends Macro {

  public Tree call(Tree tree){
    Tree[] args = tree.args();
    if (isNDEBUG()){
      return `(emptyStatement);
    } else {
      if (args.length == 1){
	Tree message = new LiteralTree(:string, "Assertion failed.");
	return simpleAssert(args[0], message);

      } else {
	Tree message =
	  `(+ ,(new LiteralTree(:string, "Assertion failed : "))
	  ,(args[1]));
	return simpleAssert(args[0], message);
      }
    }
  }

  public Tree simpleAssert(Tree exp, Tree message){
    return `(if (! ,exp)
	     (throw
	      (new (name (id Error))
	       (argumentList ,message)))
	     (emptyStatement));
  }

  public boolean isNDEBUG(){
    String prop = System.getProperty("NDEBUG");
    if (prop == null || prop.equals("false")){
      return false;
    } else if (prop.equals("true")){
      return true;
    } else {
      throw Epp.error("assert plug-in: Illgal property value : "+
		      "NDEBUG="+ prop);
    }
  }
}
