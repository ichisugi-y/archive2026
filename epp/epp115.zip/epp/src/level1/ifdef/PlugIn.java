/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
 Usage:

  #ifdef PROP1
  #elif PROP2
  #elif PROP3
  ...
  #else
  #endif


NOTE
----
 #ifdef can be nested.
 #ifndef can be used.
 #define is not supported.
 Expression for the ifdef condition are not supported.

 The user should not insert #ifdef command at inside of
language constructs which executes backtracks.

*/


#epp jp.go.etl.epp.EppLibLevel0

package ifdef;
import java.util.Stack;

SystemMixin ifdef {
  class Epp {
    Stack ifdefStack;
    
    extend void initializationPass() {
      original();
      self!ifdefStack = new Stack();
    }
    
    
    extend Token readSharp(EppInputStream in){
      int p = in.pointer();
      Token t = readId(in);
      
      if (t == :ifdef){
	return :"#ifdef";
	
      } else if (t == :ifndef) {
	return :"#ifndef";
	
      } else if (t == :elif) {
	return :"#elif";
	
      } else if (t == :else) {
	return :"#else";
	
      } else if (t == :endif){
	return :"#endif";
	
      } else {
	in.backtrack(p);
	return original(in);
      }
    }
    
    
    // I assumed that this is the last extention of the readToken method.
    // What will happen if other plug-in extends this method ?
    extend Token readToken(EppInputStream in){
      Token token = original(in);
      
      if (token == :"#ifdef" || token == :"#ifndef"){
	if (evalIfDefExpression(in) ^ (token == :"#ifndef")) {
	  self!ifdefStack.push(new IfdefSelected(true));
	  return readToken(in);
	} else {
	  self!ifdefStack.push(new IfdefSelected(false));
	  return readTokenAfterCurrentClause(in);
	}
	
      } else if (token == :"#elif") {
	if (self!ifdefStack.isEmpty()){
	  throw error("Unbalanced #elif is found.");
	}
	boolean val = evalIfDefExpression(in);
	if (((IfdefSelected)self!ifdefStack.peek()).flag) {
	  return readTokenAfterEndIf(in);
	} else if (val) {
	  ((IfdefSelected)self!ifdefStack.peek()).flag = true;
	  return readToken(in);
	} else {
	  return readTokenAfterCurrentClause(in);
	}
	
      } else if (token == :"#else") {
	if (self!ifdefStack.isEmpty()){
	  throw error("Unbalanced #else is found.");
	}
	if (((IfdefSelected)self!ifdefStack.peek()).flag){
	  return readTokenAfterEndIf(in);
	} else {
	  ((IfdefSelected)self!ifdefStack.peek()).flag = true;
	  return readToken(in);
	}
	
      } else if (token == :"#endif"){
	if (self!ifdefStack.isEmpty()){
	  throw error("Unbalanced #endif is found.");
	}
	self!ifdefStack.pop();
	return readToken(in);
	
      } else {
	if (token.isLiteralToken() && token.literalTag() == :eof &&
	    ! self!ifdefStack.isEmpty()){
	  // Actually, I should make the message easy to understand.
	  throw error("Unexpected EOF appeared at inside of #ifdef .");
	}
	return token;
      }
    }
    
    
    define implement Token readTokenAfterCurrentClause(EppInputStream in){
      int level = self!ifdefStack.size();
      Object currentIfdef = self!ifdefStack.peek();
      Token token = null;
      // Skip tokens until
      //	#endif of current ifdef is found by readToken
      //    OR  #elif with true value is found if no clause are selected yet.
      // Inside of nested #ifdef is also skipped.
      while (level < self!ifdefStack.size() ||
	     (level == self!ifdefStack.size() &&
	      self!ifdefStack.peek() == currentIfdef &&
	      (((IfdefSelected)self!ifdefStack.peek()).flag == false)
	      )){
	token = readToken(in);
      }
      if (token == null) throw Epp.fatal("");
      return token;
    }

    
    define implement Token readTokenAfterEndIf(EppInputStream in){
      int level = self!ifdefStack.size();
      Object currentIfdef = self!ifdefStack.peek();
      Token token = null;

      // Skip tokens until #endif of current ifdef is found by readToken.
      // Inside of nested #ifdef is also skipped.
      while (level < self!ifdefStack.size() ||
	     (level == self!ifdefStack.size() &&
	      self!ifdefStack.peek() == currentIfdef)
	     ){
	token = readToken(in);
      }
      if (token == null) throw Epp.fatal("");
      return token;
    }
    
    
    // This method evaluates the value of ifdef expression.
    define implement boolean evalIfDefExpression(EppInputStream in){
      Token token = readToken(in);
      if (token.isSymbol()){
	String prop = System.getProperty(token.toString());
	return prop != null && ! prop.equals("false");
      } else if (token.literalTag() == :string) {
	String str = token.literalContents();
	int eq = str.indexOf('=');
	String key = str.substring(0, eq);
	String val = str.substring(eq + 1);
	String prop = System.getProperty(key);
	return  prop != null && prop.equals(val);
      } else {
	throw error("Symbol or String is required as an expression for #ifdef .");
      }
    }
  }
}


class IfdefSelected {
  boolean flag;
  IfdefSelected(boolean flag) { this.flag = flag; }
}
