/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
 typeof macro.

*/


#epp jp.go.etl.epp.EppLibLevel0

package typeof;
import java.util.Hashtable;


SystemMixin typeof {
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :typeof) {
	matchAny();
	match(:"(");
	Tree id = identifier();
	match(:")");
	return new Tree(:typeof, id);
      } else {
	return original();
      }
    }

    extend Tree convertExpressionToType(Tree tree){
      if (tree.tag() == :typeof){
	return tree;
      } else {
	return original(tree);
      }
    }


    //--------------------------------------------------
    // Extend type system.
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:typeof, new TypeofTypeNameChecker());
    }
  }
}


class TypeofTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree var = TypeChecker.typeCheckTree(tree.args()[0]);
    return var.type().toTree();
  }
}
