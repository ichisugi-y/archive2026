/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

 This plug-in checkes "==" and "!=" operator whose arguments are objects.

 Usage:
	epp -global -type-check -no-code-emitting \
		-plug-in jp.go.etl.epp.CheckEqual -r .

*/


#epp jp.go.etl.epp.EppLibLevel0

package CheckEqual;


SystemMixin CheckEqual {
  class Epp {
    extend void globalProcessAfterTypeCheckingPass() {
      original();
      
      for (int i = 0; i < (self!allFileInfo).length; i++){
	EqualChecker checker
	  = new EqualChecker((self!allFileInfo)[i].getInputFileName(),
			     (self!allFileInfo)[i].getTree());
	checker.start();
      }
    }
  }
}
