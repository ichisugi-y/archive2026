/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

package CheckEqual;

public class EqualChecker{
  String inputFileName;
  Tree compilationUnitTree;

  EqualChecker(String inputFileName, Tree compilationUnitTree){
    this.inputFileName = inputFileName;
    this.compilationUnitTree = compilationUnitTree;
  }

  void start(){
    check(compilationUnitTree);
  }

  void check(Tree tree){
    Tree[] args = tree.args();

    if ((tree.tag() == :"==" || tree.tag() == :"!=") &&
	(args[0].type().tag() == :class || args[1].type().tag() == :class)){

      System.err.println(inputFileName+ ":"+ tree.lineNumber()+ ": "+
			 args[0].type()+ " == "+ args[1].type());

    }

    for (int i = 0; i < args.length; i++){
      check(args[i]);
    }
  }
}
