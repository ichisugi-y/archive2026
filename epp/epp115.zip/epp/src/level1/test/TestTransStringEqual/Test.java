
package TestTransStringEqual;

class Test {
  public static void main(String[] args){
    System.out.println(1 + 2 == 3);
    System.out.println("a123".equals("a" + 123));
    System.out.println("a123" == "a" + 123);
    System.out.println("aaa" != null);
    System.out.println(null == null);
    System.out.println((1 + 2 == 3) != ("a123" != "a" + 123));
    System.out.println(("x" + ("a123" == "a" + 123)) == "xtrue");
  }
}
