package TestCollection;

public class Test {
  public static void main(String[] args){
    // ifNull and NullOr
    {
      {
	NullOr<String> x = null;
	String s1 = x ifNull{ System.out.println(x == null); }
	s1 = x ifNull{ System.out.println(x == null); } 
	// { System.out.println(s1); } // Error, s1 is not assigned.

	x = "abc";
	String s2 = x ifNull{ throw new Error(); }
	System.out.println(s2.equals("abc"));
	s2 = null;
	s2 = x ifNull{ throw new Error(); }
	System.out.println(s2.equals("abc"));

	NullOr<int> y = null;
	int i1 = y ifNull{ System.out.println(y == null); }
	i1 = y ifNull{ System.out.println(y == null); }
	// { System.out.println(i1); } // Error, i1 is not assigned.

	y = 123;
	int i2 = y ifNull{ throw new Error(); }
	System.out.println(i2 == 123);
	i2 = 0;
	i2 = y ifNull{ throw new Error(); }
	System.out.println(i2 == 123);
      

	String str = "a" ifNull{ throw new Error(); }
	str = "a" ifNull{ throw new Error(); };
      }
      {
	AnotherClass x = new AnotherClass();
	String str1 = x.getString(true) ifNull{ throw new Error(); }
	System.out.println(str1.equals("a"));
	String str2 = x.getString(false) ifNull{ str2 = "default"; }
	System.out.println(str2.equals("default"));
	int i1 = x.getInt(true) ifNull{ throw new Error(); }
	System.out.println(i1 == 123);
	int i2 = x.getInt(false) ifNull{ i2 = -1; }
	System.out.println(i2 == -1);
      }

      // Subtyping test.
      {
	NullOr<String> x = null;
	NullOr<Object> x1 = x;
	x1 = "abc";
	Object x2 = x;

	NullOr<int> y = null;
	byte b = 127;
	y = b;
	Object y2 = y;
      }

      // Type error test.
      {
	NullOr<Object> x = null;
	//{ NullOr<String> x1 = x; }
	//{ String str = x ifNull { str = "a"; }; }
	//{ Object x1 = null; NullOr<String> x2 = x1; }

	NullOr<int> y = null;
	//{ Integer i1 = y ifNull { y = null; }; }
	//{ Object y2 = null; y = y2; }
      }
	
    }


    {
      // print
      Table<String, String> a = {};
      a.put("key1", "val1");
      a.put("key2", "val2");
      a.print();
      System.out.println(a.toString());
      Vec<String> s = {"aaa", "bbb", "\n"};

      Table<Vec<String>, Vec<String> > b = {};
      b.put(s, s);
      b.print();
      System.out.println(b.toString());

      Vec<String>[] ss = new Vec<String>[]{ s, s, s };
      System.out.println(ss.length);

    }

    // top, remove, containsKey
    {
      Table<String, Vec<String> > table = {};
      Vec<String> vec1 = {"aaa", "bbb", "\n"};
      Vec<String> vec2 = {"\"\t\""};
      table.put("key1", vec1);
      table.put("key2", vec2);
      //Vec<String> v = table.print("table:").get("key1").print("v:")
      //  ifNotFound{ throw new Error(); };
      System.out.println(vec1.top().equals("\n"));
      System.out.println(vec1.top().equals("\n"));
      System.out.println(vec1.top().length() == 1);
      System.out.println(table.containsKey("key1") == true);
      System.out.println(table.containsKey("keyXXX") == false);
      table.remove("key1");
      System.out.println(table.containsKey("key1") == false);
      // error
      //System.out.println(table.containsKey(234) == true);
      //System.out.println(table.remove(234) == true);
    }
    // wrap/unwrap of top, remove, containsKey, toArray
    {
      Table<int, Vec<int> > table = {};
      Vec<int> vec1 = {123, 456, 789};
      Vec<int> vec2 = {999};
      table.put(1000, vec1);
      table.put(2000, vec2);
      //Vec<int> v = table.print("table:").get(1000).print("v:")
      //  ifNotFound{ throw new Error(); };
      System.out.println(vec1.top() == 789);
      System.out.println(vec1.top() == 789);
      System.out.println(table.containsKey(1000) == true);
      System.out.println(table.containsKey(1001) == false);
      table.remove(1000);
      System.out.println(table.containsKey(1000) == false);
      //
      //foreach (int x in vec1){ System.out.println("a:"+ x); }
      Vec<int> aivec = new Vec<int>(new int[] {1111, 2222, 3333});
      //foreach (int x in aivec){ System.out.println("aivec:"+ x); }
      int[] ai = vec1.toArray();
      //foreach (int x in ai){ System.out.println("ai:"+ x); }
      Vec<int> thousand = {};
      foreach (int x in 1000) { thousand.push(x); }
      int sum = 0;
      foreach (int i in thousand) { sum += i; }
      System.out.println(sum == 499500);
    }


    // cast to/from java.lang.Object
    {
      Table<String, Vec<String> > table = {};
      Vec<String> vec = {"aaa", "bbb", "\n"};
      
      Object x;
      x = table;
      table = (Table<String, Vec<String> >)x;
      System.out.println(table.size() == 0);
      x = vec;
      x = vec.iter();

      int n = 123;
      boolean b = (n < 0);	// This is not cast. Parser should not coufuse.

      Vec<String> rvec = (Vec<String>)reverseVec(vec);
      foreach (int index, String val in vec){
	System.out.println(val.equals(rvec.get(rvec.size() - index - 1)));
      }
      //vec.print("vec");
      //rvec.print("rvec");
    }

    {
      // Vec
      {
	// push, pop, put, get
	Vec<String> v = {};
	v.push("aaa");
	v.push("bbb");
	System.out.println(v.get(0).charAt(0) == 'a');
	System.out.println(v.get(1).charAt(0) == 'b');
	v.put(0, "000");
	System.out.println(v.pop().charAt(0) == 'b');
	System.out.println(v.pop().charAt(0) == '0');

      }
      {
	// push, pop, put, get (wrap/unwrap for int)
	//Vec<int> v = {111, 222}; // Not implemented.
	Vec<int> v = {};
	v.push(111);
	v.push(222);
	System.out.println(v.get(0) == 111);
	System.out.println(v.get(1) == 222);
	v.put(0, 0);
	System.out.println(v.pop() == 222);
	System.out.println(v.pop() == 0);
      }
      {
	// Constructors.
	Vec<String> v = { "aaa" };
	System.out.println(v.get(0).charAt(0) == 'a');

	v = new Vec<String>();
	v.push("bbb");
	System.out.println(v.get(0).charAt(0) == 'b');

	v = new Vec<String>(new String[]{ "ccc" });
	System.out.println(v.get(0).charAt(0) == 'c');

	java.util.Vector vector = new java.util.Vector();
	vector.addElement("ddd");
	v = new Vec<String>(vector);
	System.out.println(v.get(0).charAt(0) == 'd');
      }
      {
	// Other methods.
	Vec<String> v = { "123", "456" };
	System.out.println(v.size() == 2);

	String[] array = v.toArray();
	System.out.println(array.length == 2);
	System.out.println(array[0] == "123");

	String[] rep = v.getRepresentationArray();
	System.out.println(rep.length > 2);
	System.out.println(rep[0] == "123");
      }
    }

    {
      // Table
      {
	// put, get
	Table<String, String> a = {};
	a.put("key1", "val1");
	a.put("key2", "val2");
	{
	  String val = a.get("key1")
	    ifNull { throw new Error(); };
	  System.out.println(val.equals("val1"));
	}
	{
	  String val = a.get("key2")
	    ifNull { throw new Error(); };
	  System.out.println(val.equals("val2"));
	}
	String ret = a.get("keyX")
	  ifNull { ret = "not-found"; };
	System.out.println(ret.equals("not-found"));
      }
      {
	// put, get (wrap/unwrap for int)
	Table<int, int> a = {};
	a.put(111, 100);
	a.put(222, 200);
	{
	  int val = a.get(111)
	    ifNull { throw new Error(); };
	  System.out.println(val + 3 == 103);
	}
	{
	  int val = a.get(222)
	    ifNull { throw new Error(); };
	  System.out.println(val + 3 == 203);
	}
	int ret = a.get(333)
	  ifNull { ret = -1; };
	System.out.println(ret == -1);
      }
      {
	// Constructors.
	Table<String, int> a;
	a = new Table<String, int>();
	a.put("key1", 100);
	int val = a.get("key1")
	  ifNull { throw new Error(); };
	System.out.println(val == 100);
      }
      {
	// Other methods.
	Table<String, int> a = {};
	a.put("key1", 123);
	a.put("key2", 456);
	System.out.println(a.size() == 2);
	a.remove("key1");
	System.out.println(a.size() == 1);
	a.clear();
	System.out.println(a.size() == 0);
      }
    }

    {
      // Iter
      {
	// next, hasNext
	Vec<String> v = { "aaa", "bbb" };
	Iter<String> iter = v.iter();
	System.out.println(iter.next().charAt(0) == 'a');
	System.out.println(iter.hasNext() == true);
	System.out.println(iter.next().charAt(0) == 'b');
	System.out.println(iter.hasNext() == false);
      }
      {
	// next, hasNext (wrap/unwrap for int)
	Vec<int> v = {};
	v.push(111);
	v.push(222);
	Iter<int> iter = v.iter();
	System.out.println(iter.next() == 111);
	System.out.println(iter.hasNext() == true);
	System.out.println(iter.next() == 222);
	System.out.println(iter.hasNext() == false);
      }
    }

    {
      //foreach
      {
	// foreach1
	int c;

	c = 0;
	foreach (int x in 5) { c += x; }
	System.out.println(c == 10);

	c = 0;
	int[] array = { 10, 20, 30 };
	foreach (int x in array) { c += x; }
	System.out.println(c == 60);

	Vec<String> v = {"a", "b", "c"};
	String s = "";
	foreach (String x in v) { s += x; }
	System.out.println(s.equals("abc"));

	Table<int, int> a = {};
	a.put(111, 100);
	a.put(222, 200);
	c = 0;
	foreach (int x in a.keyIter()) { c += x; }
	System.out.println(c == 333);
	c = 0;
	foreach (int x in a.valueIter()) { c += x; }
	System.out.println(c == 300);
      }
      {
	// foreach2
	int c;

	c = 0;
	int[] array = { 10, 20, 30 };
	foreach (int i, int x in array) { c += i; c += x; }
	System.out.println(c == 63);

	Vec<String> v = {"a", "b", "c"};
	c = 0;
	String s = "";
	foreach (int i, String x in v) { c += i; s += x; }
	System.out.println(c == 3);
	System.out.println(s.equals("abc"));

	Table<int, int> a = {};
	a.put(111, 100);
	a.put(222, 200);
	c = 0;
	foreach (int i, int x in a) { c += i; c += x; }
	System.out.println(c == 633);
      }
    }

    // super type and subtype of Vec, Table, Iter
    {
      Vec<String> vec = null;
      Table<String,String> table = null;
      Iter<String> iter = null;

      Object obj;
      obj = vec;
      obj = table;
      obj = iter;
    }

    {
      // Combination of types.
      
      Vec<String> v = {"aaa", "bbb"};
      Table<Vec<String>, Vec<String> > a = {};
      a.put(v, v);
      {
	Vec<String> val = a.get(v)
	  ifNull { throw new Error(); };
	System.out.println(val.get(0).charAt(0) == 'a');
      }

      Vec<String>[] vecArray = new Vec<String>[]{ v, v, v };
      System.out.println(vecArray.length == 3);
      System.out.println(vecArray[0].get(1).charAt(0) == 'b');

      Vec<int[]> intArrayVec = { {10, 20, 30}, {100, 200, 300, }, };
      System.out.println(intArrayVec.size() == 2);
      System.out.println(intArrayVec.get(0).length == 3);
      System.out.println(intArrayVec.get(0)[0] == 10);
    }

    /*
    {
      // error message test
      {
	// Table
	Table<String, String> a = {};
	{Table<Object, Object> a0 = a;}      // Type error.
	{Table<Object, String> a1 = a;}      // Type error.
	{Table<String, Object> a2 = a;}      // Type error.
	a = new java.util.Hashtable();      // Type error.
	a.put(new Integer(0), new Integer(0));  // method not found error.
	o.set(new java.util.Hashtable());  // method not found error.
      }
      {
	// foreach
	Table<String, String> a = {};
	Table<String, int> b = {};
	Vec<String> c = {};
	Vec<int> d = {};
	foreach (boolean x in 5) { System.out.println(x); }
	foreach (boolean x in strings) { System.out.println(x); }
	foreach (boolean x in a.keyIter()) { System.out.println(x); }
	foreach (boolean x in a.valueIter()) { System.out.println(x); }
	foreach (long x in d) { System.out.println(x); }
	foreach (long i, String x in strings) { System.out.println(i+ ":"+ x);}
	foreach (long i, String x in a) { System.out.println(i+ ":"+ x); }
	foreach (long i, int x in b) { System.out.println(i+ ":"+ x); }
	foreach (long i, String x in c) { System.out.println(i+ ":"+ x); }
	foreach (long i, int x in d) { System.out.println(i+ ":"+ x); }
	foreach (int i, long x in strings) { System.out.println(i+ ":"+ x); }
	foreach (String i, long x in a) { System.out.println(i+ ":"+ x); }
	foreach (String i, long x in b) { System.out.println(i+ ":"+ x); }
	foreach (int i, long x in c) { System.out.println(i+ ":"+ x); }
	foreach (int i, long x in d) { System.out.println(i+ ":"+ x); }
      }
    }
    // */
  }

  static Object reverseVec(Object obj){
    Vec<Object> oldVec = (Vec<Object>)obj;
    Vec<Object> newVec = {};
    for (int i = oldVec.size() - 1; i >= 0; i--){
      newVec.push(oldVec.get(i));
    }
    return newVec;
  }
}


class AnotherClass {
  Table<String, String> var;
  Table<String, String> get(){
    return var;
  }
  void set(Table<String, String> var){
    this.var = var;
  }
  String find(String key){
    String ret = var.get(key) ifNull {
      String val = "default";
      var.put(key, val);
      ret = val;
    };
    return ret;
  }

  NullOr<String> getString(boolean flag){
    if (flag){
      return "a";
    } else {
      return null;
    }
  }
  NullOr<int> getInt(boolean flag){
    if (flag){
      return 123;
    } else {
      return null;
    }
  }
}
