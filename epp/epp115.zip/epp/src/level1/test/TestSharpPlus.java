#epp SharpPlus

/*
 How to test this file is:

	epp -f TestSharpPlus.java
	epp -f -Dfoo=true TestSharpPlus.java
	epp -f -Dfoo TestSharpPlus.java
	epp -f -Dbar TestSharpPlus.java
	epp -f -Dfoo -Dbar TestSharpPlus.java

*/


class TestSharpPlus {
  
  public static void main(String argv[]){
#+foo
    {
      System.out.println("foo!");

    // Nested #+ .
#+bar
      System.out.println("foo and bar!");
    }

#-foo #+bar
    System.out.println("bar!");
#-foo #-bar
    System.out.println("Neither foo nor bar!");


#-foo
    System.out.println("Not defined foo.");
#+foo
    System.out.println("foo.");

    
#+ "user.timezone=JST"
    System.out.println("Japan.");
#- "user.timezone=JST"
    System.out.println("Not Japan.");

  }
}


#+debug
class Debug {
#+foo
  int x;
  String s;
}
