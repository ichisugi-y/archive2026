package TestJDK14assert;

class Test  {
  public static void main(String[] args){
    assert args != null;
    assert args != null : "Assertion faild.";
    assert args.length == 0 : "Assertion faild : "+ args.length;
    System.out.println(true);
  }
}
