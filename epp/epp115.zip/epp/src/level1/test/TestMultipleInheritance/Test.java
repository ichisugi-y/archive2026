#epp jp.go.etl.epp.AutoSplitFiles

package TestMultipleInheritance;

class Test {
  public static void main(String[] args){
    A3 a = new A3();
    System.out.println(a.m11() == 11);
    System.out.println(a.m12() == 12);
    System.out.println(a.m21() == 21);
    System.out.println(a.m22() == 22);
    System.out.println(a.m31() == 31);
    System.out.println(a.m32() == 32);

    C4 c = new C4();
    System.out.println(c.m11() == 11);
    System.out.println(c.m12() == 12);
    System.out.println(c.m21() == 21);
    System.out.println(c.m22() == 22);
    System.out.println(c.m31() == 31);
    System.out.println(c.m32() == 32);
    System.out.println(c.m41() == 41);
    System.out.println(c.m42() == 42);

    Object x = new C4();
    System.out.println(x instanceof C1);
    System.out.println(! (x instanceof C2));
    System.out.println(! (x instanceof C3));
    System.out.println(x instanceof C4);
  }
}


public class A1 {
  int m11() { return 11; }
  int m12() { return 12; }
}

public class A2 {
  int m21() { return 21; }
  int m22() { return 22; }
}


public class C4 extends C1, C2, C3 {
  int m41() { return 41; }
  int m42() { return 42; }
}
