#epp jp.go.etl.epp.AutoSplitFiles

package TestMultipleInheritance;


public class C1 {
  int m11() { return 11; }
  int m12() { return 12; }
}

public class C2 {
  int m21() { return 21; }
  int m22() { return 22; }
}

public class C3 {
  int m31() { return 31; }
  int m32() { return 32; }
}


public class A3 extends A1, A2 {
  int m31() { return 31; }
  int m32() { return 32; }
}
