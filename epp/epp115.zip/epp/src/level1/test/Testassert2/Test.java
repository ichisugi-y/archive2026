package Testassert2;

class Test {
  public static void main(String args[]){

    assert(div(10, 2) == 5);

    try {
      div(10, 0);
    } catch (Error e){
      System.err.println(e);
    }

    try {
      div2(10, 0);
    } catch (Error e){
      System.err.println(e);
    }

    try {
      double d = 10;
      assert(d / 2 > d + 2);
    } catch (Error e){
      System.err.println(e);
    }
  }

  static int div(int x, int y){
    assert y != 0;
    return x / y;
  }


  static int div2(int x, int y){
    assert y != 0 : "Zero divide.";
    return x / y;
  }
}
