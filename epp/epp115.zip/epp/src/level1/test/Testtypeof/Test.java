
package Testtypeof;

class Test {
  public static void main(String[] args){
    int x = 1;
    int y = 2;
    {
      typeof(x) tmp;
      tmp = x;
      x = y;
      y = tmp;
    }
    System.out.println(x == 2);
    System.out.println(y == 1);

    String[] s = {"a", "b"};
    typeof(s) s2;
  }
}
