/*

 This program itself is meaningless.
 Try this:
	testplugin -tree TestParseParen.java

*/

#epp ParseParen

class TestParseParen {
  public static void main(String[] args){
    int x, y;
    x = (1 * 2) + 3;
    y = 1 * 2 + 3;
    System.out.println(x == y);
  }
}
