#epp TripleQuote

class TestTripleQuote {
  public static void main(String[] args){
    System.out.println("""\t""".equals("\\t"));
    System.out.println(""" "abc" """.equals(" \"abc\" "));
    System.out.println(""" ""abc"" """.equals(" \"\"abc\"\" "));
    System.out.println("""/\(ab*\)/""".equals("/\\(ab*\\)/"));
    System.out.println("""abc
	def""".equals("abc\n\tdef"));
  }
}
