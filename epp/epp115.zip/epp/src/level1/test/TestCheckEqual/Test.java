
package TestCheckEqual;

class Test {
  public static void main(String[] args){
    String str = "a";
    System.out.println(1 + 2 == 3);
    System.out.println("a123".equals(str + 123));
    System.out.println("a123" != str + 123);
    System.out.println("aaa" != null);
    System.out.println(null == null);
    System.out.println((1 + 2 == 3) == ("a123" != str + 123));
  }
}
