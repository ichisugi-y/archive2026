/*
 * This is a test file of ParseComment plug-in.
 */

package TestParseComment;

/**
 This is a test class for ParseComment plug-in.
*/
class Test {

  /**
    Main method of TestComment class.
    */
  public static void main(String[] args){
    // Just print true.
    System.out.println(true);

    /* This statement also just prints true. */
    System.out. /* comment1 */ println(/* comment2 */true); // comment3


    // Comment4
    // Comment5
  }

  // This method is not used.
  /**
    Sample method.
    */
  public void foo(){
    // Do nothing.
  }
}

/**
 Class AnotherClass does nothing. Just for test.
*/
class AnotherClass {
  public void foo(){
    /**/ 
    {
      /* */
    }
    /***/
    {
      /* **/
    }
    /******/
    {
      /** **/
    }
  }
}
