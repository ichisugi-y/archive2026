#epp EmbedCopyright

class TestEmbedCopyright {
  int x;

  public static void main(String argv[]){
    System.out.println(true);
  }
}

class Foo extends TestEmbedCopyright {
  int x;
}
