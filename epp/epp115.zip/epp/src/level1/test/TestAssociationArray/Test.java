package TestAssociationArray;

class Test {
  public static void main(String[] args){

    AssociationArray(String, String) a
      = new AssociationArray(String, String);

    a["key1"] = "val1";
    a["key2"] = "val2";
    System.out.println(a["key1"].equals("val1"));

    //AssociationArray(Object, Object) a0 = a;      // Type error.
    //AssociationArray(Object, String) a1 = a;      // Type error.
    //AssociationArray(String, Object) a2 = a;      // Type error.

    AnotherClass o = new AnotherClass();

    // o.set(new java.util.Hashtable()); // Type error.

    o.set(a);
    System.out.println(o.get() == a);
  }
}
