package TestAssociationArray;

class AnotherClass {
  AssociationArray(String, String) var;
  AssociationArray(String, String) get(){
    return var;
  }
  void set(AssociationArray(String, String) var){
    this.var = var;
  }
}
