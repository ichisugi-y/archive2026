#epp assert

class Testassert {
  public static void main(String args[]){

    System.out.println(div(10, 2) == 5);

    try {
      div(10, 0);
    } catch (Error e){
      System.err.println(e);
    }

    try {
      div2(10, 0);
    } catch (Error e){
      System.err.println(e);
    }
  }

  static int div(int x, int y){
    assert y != 0;
    return x / y;
  }


  static int div2(int x, int y){
    assert y != 0 : "Zero divide.";
    return x / y;
  }
}
