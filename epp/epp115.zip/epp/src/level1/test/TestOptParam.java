#epp OptParam

class TestOptParam {
  public static void main(String[] argv){
    System.out.println(foo(0) == 123);
    System.out.println(foo(0, 0) == 22);
    System.out.println(foo(0, 0, 0) == 0);
    System.out.println(foo(1, 2, 3, 4) == 1234);
    //
    System.out.println(bar() == 3);
    int a[] = {1, 2};
    System.out.println(bar(a) == 2);

    baz();
  }
  
  static int foo(int w, int x = 1, int y = 2, int z = w + x + y){
    return w * 1000 + x * 100 + y * 10 + z;
  }
  
  static int bar(int x[] = {1,2,3}){
    return x.length;
  }

  static void baz(int x = 123){
    ;
  }
}
