
package TestOperatorOverloading;

class Test {
  public static void main(String[] args){
    TestClass x = new TestClass(1000);
    System.out.println(1 + 2 == 3);
    System.out.println("a123".equals("a" + 123));
    System.out.println(x + 123 == 1123);
    System.out.println(x - x == 0);
    System.out.println(x > 999);
    System.out.println(x >= 1000);
  }
}


class TestClass {
  int val;
  TestClass(int x) {
    val = x;
  }

  int plus(int x){
    return x + val;
  }

  int minus(TestClass x){
    return val - x.val;
  }

  boolean lessThan(int x){
    return val < x;
  }

  boolean greaterThan(int x){
    return val > x;
  }
}
