/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 This is a sample plug-in which emulates multiple-inheritance
using delegation.

*/


#epp jp.go.etl.epp.EppLibLevel0

package MultipleInheritance;
import java.util.*;

SystemMixin MultipleInheritance {
  class Epp {
    extend ClassData treeToClassData(Symbol fullName,
				     Type outerClass,
				     Tree classSig,
				     Type declaringClass){
      if (classSig.tag() != :class
	  || ! AddDelegationCode.isMultipleInheritanceClass(classSig)){
	return original(fullName, outerClass, classSig, declaringClass);
      }
      
      Object[] pair = AddDelegationCode.extractExtraSupers(classSig);
      Tree classWithSingleSuper = (Tree)pair[0];
      Type[] extraSupers = (Type[])pair[1];
      
      ClassData originalClassData
	= original(fullName, outerClass, classWithSingleSuper, declaringClass);
      Hashtable originalMethodTable = originalClassData.methodTable;
      Hashtable newMethodTable = new Hashtable();

      // Concatenate all methods.
      //(Method collision is not checked. It will be detected by javac.)
      for (int i = 0; i < extraSupers.length; i++){
	inheritMethodInfo1(newMethodTable,
			   extraSupers[i].classInfo().getMethodTable());
      }
      // Methods declared by exta-supers are overrided by the original methods.
      inheritMethodInfo1(newMethodTable, originalMethodTable);

      return new ClassData(outerClass,
			   declaringClass,
			   originalClassData.modifiers,
			   originalClassData.isInterface,
			   originalClassData.fullName,
			   originalClassData.superclassType,
			   originalClassData.interfaceTypes,
			   originalClassData.constructors,
			   originalClassData.fieldTable,
			   newMethodTable,
			   originalClassData.innerClassTable,
			   originalClassData.classProperty
			   );
    }

    extend void initTypeCheckerTable () {
      original();
      extendTypeChecker(:class, new AddDelegationCode());
    }
  }
}



class AddDelegationCode extends TypeChecker {
  public Tree call(Tree tree) {
    if (! AddDelegationCode.isMultipleInheritanceClass(tree)){
      return orig.call(tree);
    }

    Object[] pair = extractExtraSupers(tree);
    Tree classWithSingleSuper = (Tree)pair[0];
    Type[] extraSupers = (Type[])pair[1];

    tree = orig.call(classWithSingleSuper);
    
    Tree[] args		= tree.args();
    Tree modifiers	= args[0];
    Tree keyword	= args[1];
    Tree className	= args[2];
    Tree extds		= args[3];
    Tree impls		= args[4];
    Tree classBody	= args[5];
    
    TreeVec tvec = new TreeVec();
    tvec.addA(classBody.args());
    for (int i = 0; i < extraSupers.length; i++){
      ClassInfo superClassInfo = extraSupers[i].classInfo();
      Tree superClassName = new Identifier(superClassInfo.getName());
      Tree superVar = new Identifier(genTemp("_X"));

      // private SuperClass _X1 = new SuperClass();
      tvec.add(
	       `(decl (modifiers (id private))
		 ,superClassName
		 (vardecls (varInit
			    ,superVar
			    (new ,superClassName
			     (argumentList)))))
	       );
      
      MethodInfo[] extraMethods = superClassInfo.getMethods();
      for (int j = 0; j < extraMethods.length; j++){
	if (checkModifier(:abstract, extraMethods[j].getModifiers())){
	  throw error("Can not delegate to abstract method.");
	} else {
	  // $BK\Ev$O!"!V<+J,!W$+!VK\Ev$N(B super class $B$H$=$N@hAD!W$G(B
	  //$BDj5A$5$l$F$$$k%a%=%C%I0J30$r(B delegate $B$9$k$h$&$K<BAu$9$kI,MW$"$j!#(B
	  // static $B$bLdBj!#(B private $B$J$I$bLdBj!#(B
	  if (extraMethods[j].getDeclaringClass().classInfo().getName()
	      != :"java.lang.Object"){
	    tvec.add(delegationCode(superVar, extraMethods[j]));
	  }
	}
      }
    }
    
    Tree newClassBody = classBody.modifyArgs(tvec.toArray());
    Tree newArgs[] = {modifiers, keyword, className,
		      extds, impls, newClassBody };
    return tree.modifyArgs(newArgs);
  }

  Tree delegationCode(Tree target, MethodInfo methodInfo){
    Tree[] modifiers	= removeNativeModifier(methodInfo.getModifiers());
    Type retType	= methodInfo.getReturnType();
    Tree name		= new Identifier(methodInfo.getName());
    Type[] params	= methodInfo.getParameterTypes();
    Type[] thrws	= methodInfo.getExceptionTypes();

    Tree[] pdecls =  new Tree[params.length];
    Tree[] fparams = new Tree[params.length];
    for (int i = 0; i < params.length; i++){
      fparams[i] = new Identifier(genTemp("_P"));
      pdecls[i] = `(pdecl (modifiers) ,(params[i].toTree()) ,(fparams[i]));
    }
    
    Tree[] throwsTrees = new Tree[thrws.length];
    for (int i = 0; i < thrws.length; i++){
      throwsTrees[i] = thrws[i].toTree();
    }
    
    // target.name(fparams...)
    Tree invocationCode = `(invokeExp
			    ,target ,name
			    (argumentList ,@fparams));
    
    Tree returnCode;
    if (retType.tag() == :void){
      returnCode = `(expressionStatement ,invocationCode);
    } else {
      returnCode = `(returnWithExp ,invocationCode);
    }

    return `(method
	     (modifiers ,@modifiers)
	     ,(retType.toTree())
	     ,name
	     (formalParameters ,@pdecls)
	     (throws ,@throwsTrees)
	     (block ,returnCode));
  }
    
  boolean checkModifier(Symbol m, Tree[] modifiers){
    for (int i = 0; i < modifiers.length; i++){
      if (modifiers[i].idName() == m){
	return true;
      }
    }
    return false;
  }
  
  // Delegation method should not have a native modifier.
  Tree[] removeNativeModifier(Tree[] modifiers){
    TreeVec tvec = new TreeVec();
    for (int i = 0; i < modifiers.length; i++){
      if (modifiers[i].idName() != :native){
	tvec.add(modifiers[i]);
      }
    }
    return tvec.toArray();
  }

  //--------------------------------------------------
  // static methods.

  // Returns false iff the tree represents an interface definition,
  //or class definition with 0 or 1 super class.
  static boolean isMultipleInheritanceClass(Tree tree){
    Tree keyword	= tree.args()[1];
    Tree extds		= tree.args()[3];
    if (keyword.idName() == :interface) {
      return false;
    } else {
      if (extds.args().length < 2){
	return false;
      } else {
	return true;
      }
    }
  }

  // Returns two values:
  //	Tree classWithSingleSuper
  //	Type[] extraSupers
  static Object[] extractExtraSupers(Tree tree){
    Tree[] args		= tree.args();
    Tree modifiers	= args[0];
    Tree keyword	= args[1];
    Tree className	= args[2];
    Tree[] extds	= args[3].args();
    Tree impls		= args[4];
    Tree classBody	= args[5];


    Tree classWithSingleSuper
      = `(class ,modifiers ,keyword ,className
	  (extends ,(extds[0]))
	  ,impls ,classBody);


    TypeNameTable typeNameTable
	= (TypeNameTable)Dynamic.get(:typeNameTable);

    Type[] extraSupers = new Type[extds.length - 1];
    for (int i = 0; i < extds.length - 1; i++){
      try {
	extraSupers[i] = typeNameTable.get(extds[i + 1]);
      } catch (NotFound e){
	throw Epp.error("Super class of "+ className.nameToString()+
			" not found : "+ extds[i + 1].nameToString());
      }
    }

    Object[] ret = { classWithSingleSuper, extraSupers };
    return ret;
  }
}
