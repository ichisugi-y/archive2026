/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*


Translation rule
----------------
Exp ifNotFound Block ;
	-> try { Exp } catch (NotFound e) Block

{ Prev Type Var = Exp ifNotFound Block ; Rest }
	-> { Prev 
             { Type Var;
               try { Var = Exp; } catch (NotFound e) Block  
               Rest } 
           }


Syntax
------
Statement
	<original alternatives>
	Expression ifNotFound Block ;
	Type Identifier = Expression ifNotFound Block ;


AST
---
(ifNotFound Statement Block)
(ifNotFound Decl Block)


Illegal Syntax
--------------
	return table.get(key) ifNotFound { return defaultValue; };
	x = table.get(key) ifNotFound { throw fatal(); } + 1;


*/


#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin IfNotFound {
  class Epp {
    extend Tree statementOtherwise2(Tree tree, Token nextToken) {
      if (nextToken == :ifNotFound) {
	tree = expression();
	matchAny();
	Tree block = block();
	match(:";");
	return new Tree(:ifNotFound,
			new Tree(:expressionStatement, tree),
			block);

      } else {
	return original(tree, nextToken);
      }
    }

    // $B$3$l$b(B redefine $B!#(B
    redefine Tree localVariableDecl() {
      Tree modifiers = modifiers();
      if (lookahead() == :class || lookahead() == :interface) {
	// An inner class at the toplevel of a Block.
	return classDeclaration(modifiers);
      } else {
	Tree type = type();
	Tree vardecls = variableDeclarators();

	// $B$3$3$rJQ99!#(B
	return localVariableDecl2(modifiers, type, vardecls);
      }
    }

    define Tree localVariableDecl2(Tree modifiers, Tree type, Tree vardecls){
      if (lookahead() == :ifNotFound) {
	// $BK\Ev$O!"(BType Identifier = Expression ifNotFound Block ; $B$H$$$&(B
	//$B7A$K$J$C$F$$$k$+$I$&$+$r$3$3$G%A%'%C%/$9$kI,MW$"$j!#(B
	matchAny();
	Tree decl = new Tree(:decl, modifiers, type, vardecls);
	Tree block = block();
	match(:";");
	return new Tree(:ifNotFound,
			decl,
			block);
      } else {
	match(:";");
	return new Tree(:decl, modifiers, type, vardecls);
      }
    }

    //--------------------------------------------------

    extend void typeCheckBlockStatement(Tree tree,
					int i,
					Tree[] args,
					TreeVec newArgs){
      // (ifNotFound (decl (modifiers) (name ...) ...) (block ...))
      if (tree.tag() == :ifNotFound &&
	  tree.args()[0].tag() == :decl){
	Tree[] dargs = tree.args()[0].args();
	Tree modifiers = dargs[0];
	Tree type = dargs[1];
	Tree vardecls = dargs[2];
	if (vardecls.args().length != 1){
	  throw errorAt(vardecls, "Only one variable declaration is allowed "+
			"for the declaration before ifNotFound .");
	}
	Tree varInit = vardecls.args()[0];
	if (varInit.tag() != :varInit){
	  throw errorAt(varInit, "VariableInitializer should be supplied "+
			"for the declaration before ifNotFound .");
	}
	if (varInit.args()[0].tag() == :arrayVar){
	  throw errorAt(varInit, "var[] is not supported "+
			"for the declaration before ifNotFound .");
	}
	if (varInit.args()[1].tag() == :arrayInitializer){
	  // $BL$CN$N(B VariableInitializer $B$N%A%'%C%/$,$G$-$J$$!*!*!*(B
	  throw errorAt(varInit, "ArrayInitializer is not supported "+
			"for the declaration before ifNotFound .");
	}
	Tree var = varInit.args()[0];
	Tree exp = varInit.args()[1];
	Tree block = tree.args()[1];
	Tree tmp = new Identifier(Macro.genTemp("_e"));

	TreeVec rest = new TreeVec();
	for (; i < args.length; i++){
	  rest.add(args[i]);
	}
	Tree newTree =
	  `(block (decl ,modifiers ,type (vardecls ,var))
	    (try (block (expressionStatement
			 (= ,var ,exp)))
	     (catch
	      (pdecl (modifiers)
	       (name (id jp)(id go)(id etl)(id epp)(id epp)(id NotFound))
	       ,tmp)
	      ,block))
	    ,@rest);
	newTree = TypeChecker.remakeTree(newTree, tree);
	newArgs.add(TypeChecker.typeCheckTree(newTree));
	return;
      } else {
	original(tree, i, args, newArgs);
      }
    }

    //--------------------------------------------------
    // Extend assignment and array access TypeChecker.
    extend void initTypeCheckerTable () {
      original();
      defineTypeChecker(:ifNotFound, new IfNotFoundTypeChecker());
    }
  }
}



class IfNotFoundTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // (ifNotFound Statement Block)
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree tmp = new Identifier(genTemp("_e"));
    return
      remakeTree(`(try (block ,(args[0]))
		   (catch
		    (pdecl (modifiers)
		     (name (id jp)(id go)(id etl)(id epp)(id epp)(id NotFound))
		     ,tmp)
		    ,(args[1]))),
      tree);
  }
}
