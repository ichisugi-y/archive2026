/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

/*
$B!&(B Vec<Type> $B$O!"$^$:!"(B
 (genericType (name (id Vec)) (argumentList Type)) 
$B$N$h$&$K9=J82r@O$5$l$k!#(B
$B$=$l$r(B GenericTypeNameChecker $B$G%^%/%mE83+$7$F(B (vec Type) $B$K$9$k!#(B

 */

package Collection;


SystemMixin Parser {
  class Epp {
    //--------------------------------------------------
    // Parser extension.
    
    extend Tree statementOtherwise(){
      int p = inputPointer();
      Tree modifiers = modifiers();
      boolean GclassFlag = lookingGInstantiatedType();
      backtrack(p);
      if (GclassFlag) {
	return localVariableDecl();
      } else {
	return original();
      }
    }

    extend Tree type(){
      if (lookingGInstantiatedType()){
	// Parse T[] .
	Tree tree = genericTypeName();
	Tree newTree;
	while (true){
	  newTree = primaryLeft(tree);
	  if (newTree == null) break;
	  tree = newTree;
	}
	return tree;
      } else {
	return original();
      }
    }

    // collection $B7?$N7?L>$r9=J82r@O$9$k!#(B
    define implement Tree genericTypeName(){
      Tree name = name();
      match(:"<");
      TreeVec tvec = new TreeVec();
      if (lookahead() != :">") {
	checkGTGT();
	tvec.add(type());
	while (lookahead() != :">"){
	  checkGTGT();
	  match(:",");
	  tvec.add(type());
	}
      }
      match(:">");
      return new Tree(:genericType, name,
		      new Tree(:argumentList, tvec.toArray()));
    }
    define implement void checkGTGT(){
      if (lookahead() == :">>"){
	throw error("Current parser does not support \">>\" for collection type names. "+
		    "Please insert a space between two \">\" . ");
      }
    }
    
    extend Tree instanceCreation() {
      int p = inputPointer();
      match(:new);
      if (lookingGInstantiatedType()){
	Tree name = genericTypeName();
	//Tree args = argumentList();
	//return new Tree(:new, name, args);
	if (lookahead() == :"(") {
	  Tree args = argumentList();
	  if (lookahead() == :"{") {
	    return new Tree(:anonymousClass, name, args, classBody());
	  } else {
	    return new Tree(:new, name, args);
	  }
	} else if (lookahead() == :"[") {
	  return arrayCreation(name);
	} else {
	  throw error(""+ lookahead()+
		      " appeared after \"new TypeName\".");
	}
      } else {
	backtrack(p);
	return original();
      }
    }

    extend Tree primaryTop() {
      if (lookahead() == :"(") {
	int p = inputPointer();
	matchAny();
	if (lookingGInstantiatedType()){
	  Tree tree = genericTypeName();
	  match(:")");
	  return new Tree(:cast,
			  tree,
			  unaryExpression());
	} else {
	  backtrack(p);
	  return original();
	}
      } else {
	return original();
      }
    }

    // Check if tokens are "Vec<" or "Table<" or "Iter<" or "NullOr<".
    define boolean lookingGInstantiatedType(){
      int p = inputPointer();
      try {
	Token token = matchAny();
	return (token == :Vec || token == :Table || token == :Iter
		|| token == :NullOr)
	  && (matchAny() == :"<");
      } finally {
	backtrack(p);
      }
    }

    /*old
    // Check if tokens look like "a.b.c.d<" .
    define boolean lookingGInstantiatedType(){
      int p = inputPointer();
      try {
	while (true){
	  Token token = matchAny();
	  if (! (token.isSymbol()
		 && ((Symbol)token).maybeIdentifier())){
	    return false;
	  }
	  token = matchAny();
	  if (token == :"<"){
	    return true;
	  } else if (token == :"."){
	    // Do nothing. Check next token.
	  } else {
	    return false;
	  }
	}
      } finally {
	backtrack(p);
      }
    }
    */


    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:genericType, new GenericTypeNameChecker());
    }

  }
}


// (genericType Name (argumentList Type))
class GenericTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Obj epp = (Obj)Dynamic.get(:epp);

    // $B$H$j$"$($:!"(B Vec, Table, Iter, NullOr $B$O40A48BDjL>$G$O$J$/C1=cL>$N$_!#(B
    Tree name = tree.args()[0];
    if (name.args().length != 1){
      throw epp!errorAt(tree, "Illegal generic type name : "+
			name.nameToString());
    }
    Symbol tag = name.args()[0].idName();
    Tree[] params = tree.args()[1].args();
    int length = params.length;

    if (tag == :Vec){
      if (length != 1){
	throw epp!errorAt(tree, "One parameter is required to the generic type Vec<T> but "+ length+ " are supplied.");
	
      }
      return TypeChecker.remakeTree(`(vec ,(params[0])), tree);

    } else if (tag == :Table) {
      if (length != 2){
	throw epp!errorAt(tree, "Two parameters are required to the generic type Table<T1, T2> but "+ length+ " are supplied.");
	
      }
      return TypeChecker.remakeTree(`(table ,(params[0]) ,(params[1])), tree);

    } else if (tag == :Iter) {
      if (length != 1){
	throw epp!errorAt(tree, "One parameter is required to the generic type Iter<T> but "+ length+ " are supplied.");
	
      }
      return TypeChecker.remakeTree(`(iter ,(params[0])), tree);

    } else if (tag == :NullOr) {
      if (length != 1){
	throw epp!errorAt(tree, "One parameter is required to the generic type NullOr<T> but "+ length+ " are supplied.");
	
      }
      return TypeChecker.remakeTree(`(nullOr ,(params[0])), tree);

    } else {
      throw epp!errorAt(tree, "Illegal generic type name : "+
			name.nameToString());
    }
  }

}
