/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

Syntax
------
foreach (String x in c){...}
foreach (int index, String elem in c){...}

*/

#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin Foreach {
  class Epp {
    extend Tree statementTop(){
      if (lookahead() == :foreach) {
	matchAny();
	match(:"(");
	Tree decl1 = declWithoutSemicolon();
	Tree decl2;
	if (lookahead() == :",") {
	  matchAny();
	  decl2 = declWithoutSemicolon();
	} else {
	  decl2 = null;
	}
	match(:in);
	Tree exp = expression();
	match(:")");
	Tree body = block();
	if (decl2 == null){
	  return new Tree(:foreach1, decl1, exp, body);
	} else {
	  return new Tree(:foreach2, decl1, decl2, exp, body);
	}
      } else {
	return original();
      }
    }

    define implement Tree declWithoutSemicolon(){
      Tree modifiers = modifiers();
      if (lookahead() == :class || lookahead() == :interface){
	throw error("class or interface is not allowed here.");
	//return classDeclaration(modifiers);
      } else {
	Tree type;
	// type() $B$O(B NonTerminal $B$8$c$J$$$N$G!"0LCV>pJs$rIU$1$k$?$a$K!"(B
	//$BL@<(E*$K4D6-$r:n$C$F8F$S=P$9!#(B
	Dynamic.bindInt(:lineNumberOfThisNode, Dynamic.getInt(:lineNumber));
	Dynamic.bindInt(:beginningPointOfThisNode,
			Dynamic.getInt(:beginningPoint));
	try {
	  type = type();
	} finally {
	  Dynamic.unbindInt();
	  Dynamic.unbindInt();
	}
	// $BK\Ev$O(B int a[] $B$O5v$7$?$$!#(B
	Tree var = identifier();
	Tree vardecls = `(vardecls ,var);
	//match(:";");
	return new Tree(:decl, modifiers, type, vardecls);
      }
    }


    //--------------------------------------------------
    // Extend assignment and array access TypeChecker.
    extend void initTypeCheckerTable () {
      original();

      defineTypeChecker(:foreach1, new Foreach1TypeChecker());
      defineTypeChecker(:foreach2, new Foreach2TypeChecker());
    }

    extend void initTranslatorTable () {
      original();
    }

  }
}


class Foreach1TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // (foreach1 decl1 exp body)
    checkArgsLength(tree, 3);
    Obj epp = Type.epp();
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[1]);
    Type expType = exp.type();
    Symbol tag = expType.tag();

    Tree varTypeTree = typeNameCheckTree(args[0].args()[1]);
    Tree var = args[0].args()[2].args()[0];
    Tree body = args[2];

    Tree tmpA = new Identifier(Macro.genTemp("_t")); 
    Tree tmpI = new Identifier(Macro.genTemp("_t")); 

    if (tag == :int){
      if (varTypeTree.type().tag() != :int){
	throw epp!errorAt(varTypeTree,
			  "foreach: Can not convert int to "+
			  varTypeTree.type()+ " .");
      }

      return `(block
	       (decl (modifiers) (name (id int))
		(vardecls (varInit ,tmpA ,exp)))
	       (for
		(decl
		   (modifiers)
		   ,varTypeTree
		   (vardecls (varInit ,var (literalTree int "0"))))
		(forArg (< ,var ,tmpA)) (forArg (postInc ,var))
		,body));

    } else if (tag == :arrayOf){
      elementTypeCheck(varTypeTree, expType,
		       ((ArrayType)expType).getComponentType());
      return `(block
	       (decl (modifiers) (arrayOf ,varTypeTree)
		(vardecls (varInit ,tmpA ,exp)))
	       (for (decl (modifiers) (name (id int))
		       (vardecls (varInit ,tmpI (literalTree int "0"))))
		(forArg (< ,tmpI (fieldExp ,tmpA (id length))))
		(forArg (postInc ,tmpI))
		(block
		 (decl (modifiers) ,varTypeTree
		  (vardecls (varInit ,var (array ,tmpA ,tmpI))))
		 ,body)));

    } else if (tag == :vec){
      elementTypeCheck(varTypeTree, expType,
		       ((VecType)expType).getValueType());
      if (varTypeTree.type().isPrimitiveType()){
	return `(block
		 (decl (modifiers) (iter ,varTypeTree)
		  (vardecls (varInit ,tmpI
			     (invokeExp ,exp
			      (id iter)
			      (argumentList)))))
		 (while
		  (invokeExp ,tmpI (id hasNext) (argumentList))
		  (block
		   (decl (modifiers) ,varTypeTree
		    (vardecls
		     (varInit ,var
		      (invokeExp ,tmpI (id next) (argumentList)))))
		   ,body)));
      } else {
	Tree tmpSize = new Identifier(Macro.genTemp("_t")); 
	Tree tmpExp = new Identifier(Macro.genTemp("_t")); 
	Tree tmpArray = new Identifier(Macro.genTemp("_t")); 
	return `(block
		 (decl (modifiers) ,(expType.toTree())
		  (vardecls (varInit ,tmpExp ,exp)))
		 (decl (modifiers) (name (id int))
		  (vardecls (varInit ,tmpSize
			     (invokeExp ,tmpExp (id size) (argumentList)))))
		 (decl (modifiers) (arrayOf ,varTypeTree)
		  (vardecls (varInit ,tmpArray
			     (invokeExp ,tmpExp
			      (id getRepresentationArray) (argumentList)))))
		 (for (decl (modifiers) (name (id int))
			 (vardecls (varInit ,tmpI (literalTree int "0"))))
		  (forArg (< ,tmpI ,tmpSize))
		  (forArg (postInc ,tmpI))
		  (block
		   (decl (modifiers) ,varTypeTree
		    (vardecls (varInit ,var (array ,tmpArray ,tmpI))))
		   ,body)));
      }


    } else if (tag == :iter){
      elementTypeCheck(varTypeTree, expType,
		       ((IterType)expType).getValueType());
      return `(block
	       (decl (modifiers) (iter ,varTypeTree)
		(vardecls (varInit ,tmpA ,exp)))
	       (while
		(invokeExp ,tmpA (id hasNext) (argumentList))
		(block
		 (decl (modifiers) ,varTypeTree
		  (vardecls (varInit ,var
			     (invokeExp ,tmpA (id next) (argumentList)))))
		 ,body)));

    } else {
      // error
      throw epp!errorAt(args[1],
			"foreach: The expression is neither Vec<T>, Iter<T>, "+
			"T[] nor int : "+ exp.type());
    }
  }

  void elementTypeCheck(Tree varTypeTree, Type expType, Type elementType){
    Obj epp = Type.epp();
    Type varType = varTypeTree.type();
    if (! (epp!equals(varType, elementType))){
      throw epp!errorAt(varTypeTree,
			"foreach: Can not convert "+
			elementType+ 
			" to "+ varType+ " .");
    }
  }
}



class Foreach2TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // (foreach1 decl1 decl2 exp body)
    checkArgsLength(tree, 4);
    Obj epp = Type.epp();
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[2]);
    Type expType = exp.type();
    Symbol tag = expType.tag();

    Tree indexTypeTree = typeNameCheckTree(args[0].args()[1]);
    Tree index = args[0].args()[2].args()[0];
    Tree varTypeTree = typeNameCheckTree(args[1].args()[1]);
    Tree var = args[1].args()[2].args()[0];
    Tree body = args[3];

    Tree tmpA = new Identifier(Macro.genTemp("_t")); 
    Tree tmpI = new Identifier(Macro.genTemp("_t")); 
    Tree tmpKeyIter = new Identifier(Macro.genTemp("_t")); 
    Tree tmpValueIter = new Identifier(Macro.genTemp("_t")); 

    if (tag == :arrayOf){
      indexTypeCheck(indexTypeTree, expType,
		    Type.Tint);
      elementTypeCheck(varTypeTree, expType,
		       ((ArrayType)expType).getComponentType());
      return `(block
	       (decl (modifiers) (arrayOf ,varTypeTree)
		(vardecls (varInit ,tmpA ,exp)))
	       (for (decl (modifiers) (name (id int))
		       (vardecls (varInit ,index (literalTree int "0"))))
		(forArg (< ,index (fieldExp ,tmpA (id length))))
		(forArg (postInc ,index))
		(block
		 (decl (modifiers) ,varTypeTree
		  (vardecls (varInit ,var (array ,tmpA ,index))))
		 ,body)));

    } else if (tag == :table){
      indexTypeCheck(indexTypeTree, expType,
		     ((TableType)expType).getKeyType());
      elementTypeCheck(varTypeTree, expType,
		       ((TableType)expType).getValueType());
      return `(block
	       (decl (modifiers) (table ,indexTypeTree ,varTypeTree)
		(vardecls (varInit ,tmpA ,exp)))
	       (decl (modifiers) (iter ,indexTypeTree)
		(vardecls (varInit ,tmpKeyIter
			   (invokeExp ,tmpA (id keyIter) (argumentList)))))
	       (decl (modifiers) (iter ,varTypeTree)
		(vardecls (varInit ,tmpValueIter
			   (invokeExp ,tmpA (id valueIter) (argumentList)))))
	       (while
		(invokeLong (name ,tmpKeyIter) (id hasNext) (argumentList))
		(block
		 (decl (modifiers) ,indexTypeTree
		  (vardecls (varInit ,index (invokeExp ,tmpKeyIter (id next)
					     (argumentList)))))
		 (decl (modifiers) ,varTypeTree
		  (vardecls (varInit ,var (invokeExp ,tmpValueIter (id next)
					   (argumentList)))))
		 ,body)));

    } else if (tag == :vec){
      indexTypeCheck(indexTypeTree, expType,
		     Type.Tint);
      elementTypeCheck(varTypeTree, expType,
		       ((VecType)expType).getValueType());
      if (varTypeTree.type().isPrimitiveType()){
	return `(block
		 (decl (modifiers) (name (id int))
		  (vardecls (varInit ,index (unaryMinus (literalTree int "1")))))
		 (decl (modifiers) (iter ,varTypeTree)
		  (vardecls (varInit ,tmpValueIter (invokeExp ,exp (id iter)
						    (argumentList)))))
		 (while
		  (invokeLong (name ,tmpValueIter) (id hasNext) (argumentList))
		  (block
		   (decl (modifiers) ,varTypeTree
		    (vardecls (varInit ,var (invokeLong (name ,tmpValueIter)
					     (id next)
					     (argumentList)))))
		   (expressionStatement (postInc ,index))
		   ,body)));
      } else {
	Tree tmpSize = new Identifier(Macro.genTemp("_t")); 
	Tree tmpExp = new Identifier(Macro.genTemp("_t")); 
	Tree tmpArray = new Identifier(Macro.genTemp("_t"));
	tmpI = index;
	return `(block
		 (decl (modifiers) ,(expType.toTree())
		  (vardecls (varInit ,tmpExp ,exp)))
		 (decl (modifiers) (name (id int))
		  (vardecls (varInit ,tmpSize
			     (invokeExp ,tmpExp (id size) (argumentList)))))
		 (decl (modifiers) (arrayOf ,varTypeTree)
		  (vardecls (varInit ,tmpArray
			     (invokeExp ,tmpExp
			      (id getRepresentationArray) (argumentList)))))
		 (for (decl (modifiers) (name (id int))
			 (vardecls (varInit ,tmpI (literalTree int "0"))))
		  (forArg (< ,tmpI ,tmpSize))
		  (forArg (postInc ,tmpI))
		  (block
		   (decl (modifiers) ,varTypeTree
		    (vardecls (varInit ,var (array ,tmpArray ,tmpI))))
		   ,body)));
      }


    } else {
      throw epp!errorAt(args[1],
			"The expression is neither collection "+
			"nor array : "+ exp.type());
    }
  }

  void indexTypeCheck(Tree indexTypeTree, Type expType, Type indexType){
    Obj epp = Type.epp();
    Type varType = indexTypeTree.type();
    if (! (epp!equals(varType, indexType))){
      throw epp!errorAt(indexTypeTree,
			"foreach: Can not convert "+
			indexType+ 
			" to "+ varType+ " .");
    }
  }

  void elementTypeCheck(Tree varTypeTree, Type expType, Type elementType){
    Obj epp = Type.epp();
    Type varType = varTypeTree.type();
    if (! (epp!equals(varType, elementType))){
      throw epp!errorAt(varTypeTree,
			"foreach: Can not convert "+
			elementType+ 
			" to "+ varType+ " .");
    }
  }
}
