/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin Vec {
  class Epp {

    //--------------------------------------------------
    // Extend type system.
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:vec, new VecTypeNameChecker());
    }

    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :vec){
	if (t2.tag() == :vec){
	  VecType a1 = (VecType)t1;
	  VecType a2 = (VecType)t2;
	  return equals(a1.getValueType(), a2.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    extend boolean isSuperType(Type t1, Type t2){
      if (t1.tag() == :vec){
	if (t2.tag() == :vec){
	  return equals(t1, t2);
	} else {
	  return t2.tag() == :null;
	}
	// collection $B7?$b(B Object $B$N(B subtype $B!#(B
	// $B>/$7$G$bB.$/$J$k$h$&$K!"(B t2 $B$NJ}$+$i%F%9%H$9$k!#(B
      } else if (t2.tag() == :vec
		 && t1.tag() == :class
		 && t1.classInfo().getName() == :"java.lang.Object"){
	return true;
      } else {
	return original(t1, t2);
      }
    }

    //--------------------------------------------------
    // Extend VariableInitializer.

    extend Tree coerceVariableInitializer(Type type,
					  Tree tree){
      Symbol tag = tree.tag();
      Symbol s1 = type.tag();
      Symbol s2 = tree.type().tag();
      if (tag == :arrayInitializer && s1 == :vec){
	Tree newTree;
	if (tree.args().length != 0){
	  // Vec<String> a = {"a", "b"}; $B$N(B  {"a", "b"}$B$O!"(B
	  // new Vec<String>(new String[]{"a", "b"}); $B$KE83+!#(B
	  Type valueType = ((VecType)type).getValueType();
	  Tree genTypeTree = valueType.toTree() ;
	  newTree = `(new ,(type.toTree())
		      (argumentList
		       (anonymousArray
			(arrayOf ,genTypeTree)
			,tree)));
	} else {
	  // Vec<String> a = {}; $B$N(B {} $B$O(B Vec<int> a = new Vec<int>(); $B$KE83+!#(B
	  newTree = `(new ,(type.toTree()) (argumentList));
	}
	newTree = TypeChecker.remakeTree(newTree, tree);
	return TypeChecker.typeCheckTree(newTree);
      } else {
	return original(type, tree);
      }
    }


    //--------------------------------------------------

    extend void initTypeCheckerTable () {
      original();

      extendTypeChecker(:new,	new VecNewTypeChecker());
      //extendTypeChecker(:"=",	new VecPutMacroTypeChecker());
      //extendTypeChecker(:array,	new VecGetMacroTypeChecker());
      extendTypeChecker(:invokeExp,	new VecInvokeMacroTypeChecker());

      defineTypeChecker(:vecPut,	new VecPutTypeChecker());
      defineTypeChecker(:vecGet,	new VecGetTypeChecker());
      defineTypeChecker(:vecPush,	new VecPushTypeChecker());
      defineTypeChecker(:vecPop,	new VecPopTypeChecker());
      defineTypeChecker(:vecTop,	new VecTopTypeChecker());
      defineTypeChecker(:vecGetRepArray,new VecGetRepArrayTypeChecker());
      defineTypeChecker(:vecToArray,	new VecToArrayTypeChecker());
    }

    extend void initTranslatorTable () {
      original();
      defineTranslator(:vec, new VecTypeTranslator());
      defineTranslator(:vecNew, new VecNewTranslator());
      defineTranslator(:vecPut, new VecPutTranslator());
      defineTranslator(:vecGet, new VecGetTranslator());
      defineTranslator(:vecPush, new VecPushTranslator());
      defineTranslator(:vecPop, new VecPopTranslator());
      defineTranslator(:vecTop, new VecTopTranslator());
      defineTranslator(:vecGetRepArray,new VecGetRepArrayTranslator());
      defineTranslator(:vecToArray, new VecToArrayTranslator());
    }
  }
}

public class VecType extends Type {
  Type valueType;
  public VecType(Type valueType){
    super(:vec);
    this.valueType = valueType;
  }
  public Type getValueType() { return valueType; }
  public String toString(){
    return "Vec<"+ valueType+ ">";
  }
  public Tree toTree(){
    return `(vec ,(valueType.toTree()));
  }
}



// (vec Type)
class VecTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeNameCheckTree(args[0]),
    };
    Type t = new VecType(newArgs[0].type());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}


// new Vec<T>() $B$OJQ498e$N%3!<%I$G$O0z?t$K(B generator $B$r<h$k$N$G!"(B
// $BCf4V%N!<%I(B vecNew $B$rF3F~$7$F$=$N(B translater $B$rDj5A$9$kI,MW$,$"$k!#(B
//$B!J(B :new $B$N(B translator $B$,<+J,$N7?$r8+$FJ,4t$7$F!"(B
//$BJQ49$7$F$O$$$1$J$$$N$@$m$&$+!)!K(B
// (new (vec Type) (argumentList ...))
// -> (vecNew Type (argumentList ...))
class VecNewTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree params = typeCheckTree(args[1]);
    if (typeTree.type().tag() == :vec){
      // $BK\Ev$O(B vecNew $B$N(B TypeChecker $B$r$A$c$s$HDj5A$7!"(B
      // $B%Q%i%a%?!<$N%A%'%C%/$r$7$J$1$l$P$J$i$J$$$,!">JN,!#(B
      //$B!J%Q%i%a%?%A%'%C%/$O$$$A$*$&(B javac $B$,$d$C$F$/$l$k!#!K(B
      Tree newTree = `(vecNew ,(typeTree.args()[0]) ,params);
      return newTree.modifyTypeAndArgs(typeTree.type(), newTree.args());
    } else {
      return orig.call(tree.modifyArgs(new Tree[]{ typeTree, params }));
    }
  }
}


// a.put(index, val)  =>  (vecPut a index val)
// a.get(index)  => (vecGet type a index)
// a.push(x)  =>  (vecPush a x)
// a.pop()  =>  (vecPop type a)
// a.top()  =>  (vecTop type a)
// ##a.iter()  =>  (vecIter a)
// a.getRepresentationArray()  =>  (vecGetRepArray type a)
// a.toArray()  =>  (vecToArray type a)
// a.foo(...) => (invokeCollection a (id foo) (argumentList ...))
class VecInvokeMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree a = typeCheckTree(args[0]);
    Tree m = args[1];
    Tree argumentList = typeCheckTree(args[2]);
    Tree[] aargs = argumentList.args();

    if (a.type().tag() == :vec){
      VecType aType = (VecType)a.type();
      Symbol methodName = m.idName();
      if (methodName == :put){
	checkArgumentListLength(tree, 2);
	return remakeTree(`(vecPut
			    ,a
			    ,(aargs[0])
			    ,(aargs[1])), tree);

      } else if (methodName == :get){
	checkArgumentListLength(tree, 1);
	return remakeTree(`(vecGet
			    ,(aType.getValueType().toTree())
			    ,a
			    ,(aargs[0])), tree);

      } else if (methodName == :push){
	checkArgumentListLength(tree, 1);
	return remakeTree(`(vecPush
			    ,a
			    ,(aargs[0])), tree);

      } else if (methodName == :pop){
	checkArgumentListLength(tree, 0);
	return remakeTree(`(vecPop
			    ,(aType.getValueType().toTree())
			    ,a), tree);

      } else if (methodName == :top){
	checkArgumentListLength(tree, 0);
	return remakeTree(`(vecTop
			    ,(aType.getValueType().toTree())
			    ,a), tree);

      } else if (methodName == :getRepresentationArray){
	checkArgumentListLength(tree, 0);
	Type elemType = aType.getValueType();
	Type arrayType = elemType.isPrimitiveType()
	  ? new ArrayType(Type.TObject) : new ArrayType(elemType);
	return remakeTree(`(vecGetRepArray
			    ,(arrayType.toTree())
			    ,a), tree);

      } else if (methodName == :toArray){
	checkArgumentListLength(tree, 0);
	Type elemType = aType.getValueType();
	return remakeTree(`(vecToArray
			    ,(elemType.toTree())
			    ,a), tree);

      } else {
	// $B0J2<!"0z?t$N%A%'%C%/$O(B javac $B$K$^$+$;$k!#(B
	Type retType;
	if (methodName == :iter){
	  retType = new IterType(aType.getValueType());
	} else if (methodName == :size){
	  retType = Type.Tint;
	} else if (methodName == :equals){
	  retType = Type.Tboolean;
	} else if (methodName == :clone){
	  retType = Type.TObject;
	} else if (methodName == :toString){
	  retType = Type.TString;
	} else if (methodName == :print){
	  retType = aType;
	} else {
	  throw errorAt(tree, "Method "+ methodName+ " is not defined for "+
			" Vec<T> .");
	}
	Tree newTree = `(invokeCollection ,a ,m ,argumentList);
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(retType,
					 newTree.args());
      }

    } else {
      return orig.call(tree.modifyArgs(new Tree[]{ a, m, argumentList}));
    }
  }

  static void checkArgumentListLength(Tree tree, int n){
    Symbol methodName = tree.args()[1].idName();
    Tree[] aargs = tree.args()[2].args();
    if (aargs.length != n){
      Obj epp = (Obj)Dynamic.get(:epp);
      throw epp!errorAt(tree, "Method "+ methodName+ " requires "+ n+
			" args but "+ aargs.length+ " were supplied.");
    }
  }
}


/* Currently not used.
// $B$$$C$?$s!"(B invokeExp $B$KE83+$9$k$h$&$K$9$Y$-!#(B
// a[index] = val;  =>  (vecPut a index val)
class VecPutMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    // $BG[Ns$8$c$J$$BeF~J8!#(B a = exp; $B$J$I!#(B
    if (tree.args()[0].tag() != :array) return orig.call(tree);

    Tree array = tree.args()[0];
    Tree a = typeCheckTree(array.args()[0]);
    Tree index = typeCheckTree(array.args()[1]);
    Tree val = typeCheckTree(tree.args()[1]);

    if (a.type().tag() != :vec) {
      // Repeated type checking of "a" will be avoided.
      Tree[] arrayArgs = { a, index };
      Tree[] newArgs = { array.modifyArgs(arrayArgs),
			 val };
      return orig.call(tree.modifyArgs(newArgs));
    } else {
      return remakeTree(`(vecPut ,a ,index ,val), tree);
    }
  }
}

// a[index]  => (vecGet type a index)
class VecGetMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    Tree[] args = typeCheckArgs(tree);
    if (args[0].type().tag() == :vec){
      VecType t = (VecType)args[0].type();
      return remakeTree(`(vecGet
	       ,(t.getValueType().toTree())
	       ,(args[0])
	       ,(args[1])), tree);
    } else {
      // Repeated type checking of args will be avoided.
      return orig.call(tree.modifyArgs(args));
    }
  }
}
*/





// (vecPut a index val)
class VecPutTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    Tree[] args = typeCheckArgs(tree);
    VecType aType = (VecType)args[0].type();
    Tree key = Type.coerce(Type.Tint, args[1]);
    Tree val = Type.coerce(aType.getValueType(), args[2]);

    return tree.modifyTypeAndArgs(Type.Tvoid, typeCheckArgs(tree));
  }
}

// (vecGet type a index)
class VecGetTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    Tree index = typeCheckTree(args[2]);

    // a $B$,(B vec $B$G$"$k$3$H$r3N$+$a$k!#0c$C$?$i(B fatal error $B!#(B
    if (a.type().tag() != :vec) throw Epp.fatal("");
    VecType aType = (VecType)a.type();
    index = Type.coerce(Type.Tint, index);

    return tree.modifyTypeAndArgs(aType.getValueType(),
				  new Tree[]{ typeName, a, index });
  }
}

// (vecPush a val)
class VecPushTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree a = typeCheckTree(args[0]);
    Tree val = typeCheckTree(args[1]);

    if (a.type().tag() != :vec) throw Epp.fatal("");
    VecType aType = (VecType)a.type();
    val = Type.coerce(aType.getValueType(), val);

    return tree.modifyTypeAndArgs(Type.Tvoid, new Tree[]{ a, val });
  }
}

// (vecPop type a)
class VecPopTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    if (a.type().tag() != :vec) throw Epp.fatal("");
    VecType aType = (VecType)a.type();
    return tree.modifyTypeAndArgs(aType.getValueType(),
				  new Tree[]{ typeName, a });
  }
}

// (vecTop type a)
class VecTopTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    if (a.type().tag() != :vec) throw Epp.fatal("");
    VecType aType = (VecType)a.type();
    return tree.modifyTypeAndArgs(aType.getValueType(),
				  new Tree[]{ typeName, a });
  }
}

// (vecGetRepArray type a)
class VecGetRepArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    if (a.type().tag() != :vec) throw Epp.fatal("");
    return tree.modifyTypeAndArgs(typeName.type(),
				  new Tree[]{ typeName, a });
  }
}

// (vecToArray type a)
class VecToArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    if (a.type().tag() != :vec) throw Epp.fatal("");
    return tree.modifyTypeAndArgs(new ArrayType(typeName.type()),
				  new Tree[]{ typeName, a });
  }
}



// Translator

// new Vec<T>()  => new Vec(agen) 
// (vecNew Type (argumentList ...))
class VecNewTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = translateArgs(tree);
    Tree valueTypeTree = args[0]; // $B!VJQ498e!W$NMWAG$N7?L>!#(B
    Tree[] origParams = args[1].args();
    TreeVec tvec = new TreeVec();
    for (int i = 0; i < origParams.length; i++){
      tvec.add(origParams[i]);
    }
    // $B$H$j$"$($:!"(B Vec<int> $B$N>l9g$O(B Integer[] $B$r@8@.$9$k$3$H$K$9$k!#(B
    Tree genTypeTree = tree.args()[0].type().isPrimitiveType() ?
     `(name (id java)(id lang)(id Integer)) : valueTypeTree ;

    Tree tmpVar = new Identifier(Macro.genTemp("_agen")); 

    TreeVec classBody
      = (TreeVec)Dynamic.get(:afterCurrentClassBodyDeclaration);
    classBody.add(`(decl
		    (modifiers (id private) (id static) (id final))
		    (name (id jp) (id go) (id etl) (id epp) (id util)
		     (id ArrayGenerator))
		    (vardecls
		     (varInit
		      ,tmpVar
		      (anonymousClass
		       (name (id jp) (id go) (id etl) (id epp) (id util)
			(id ArrayGenerator))
		       (argumentList)
		       (classBody
			(method
			 (modifiers
			  (id public))
			 (arrayOf
			  (name
			   (id Object)))
			 (id generate)
			 (formalParameters
			  (pdecl
			   (modifiers)
			   (name
			    (id int))
			   (id size)))
			 (throws)
			 (block
			  (returnWithExp
			   (newArray
			    (dimExpr
			     ,genTypeTree
			     (id size)))))))))))
		  );


    tvec.add(tmpVar);
    return `(new (name (id jp)(id go)(id etl)(id epp)(id util)(id Vec))
	     (argumentList ,tvec));
  }
}


// Vec<T> => jp.go.etl.epp.util.Vec
class VecTypeTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    // $B7k2L$O;H$o$J$$$,!":F5"=hM}$OI,MW!#(B
    Tree[] args = translateArgs(tree);
    return `(name (id jp)(id go)(id etl)(id epp)(id util)(id Vec));
  }
}


// (vecPut a index val)  =>  a.put(index, val)
class VecPutTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    VecType aType = (VecType)tree.args()[0].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree a = args[0];
    Tree index = args[1];
    Tree val = args[2];
    // primitive $B7?$N(B wrap $B$N=hM}$O(B runtime $B$,$d$k!#(B
    return `(invokeExp ,a (id put) (argumentList ,index ,val));
  }
}

// (vecGet type a index)  =>  (type)a.get(index)
class VecGetTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    VecType aType = (VecType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];
    Tree val = args[2];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id getInt)
		 (argumentList ,val));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id get)
		(argumentList ,val)));
    }
  }
}


// (vecPush a val)  =>  a.push(val)
class VecPushTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    VecType aType = (VecType)tree.args()[0].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree a = args[0];
    Tree val = args[1];
    // primitive $B7?$N(B wrap $B$N=hM}$O(B runtime $B$,$d$k!#(B
    return `(invokeExp ,a (id push) (argumentList ,val));
  }
}

// (vecPop type a)  =>  (type)a.pop()
class VecPopTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    VecType aType = (VecType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id popInt)
		 (argumentList));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id pop)
		(argumentList)));
    }
  }
}

// (vecTop type a)  =>  (type)a.top()
class VecTopTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    VecType aType = (VecType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id topInt)
		 (argumentList));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id top)
		(argumentList)));
    }
  }
}

// (vecGetRepArray type a)  =>  (type)a.getRepresentationArray()
class VecGetRepArrayTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    VecType aType = (VecType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];

    return `(cast ,type
	     (invokeExp ,a (id getRepresentationArray)
	      (argumentList)));
  }
}

// (vecToArray type a)  =>  (type)a.toArray()
class VecToArrayTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    VecType aType = (VecType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id toArrayInt)
		 (argumentList));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast (arrayOf ,type)
	       (invokeExp ,a (id toArray)
		(argumentList)));
    }
  }
}
