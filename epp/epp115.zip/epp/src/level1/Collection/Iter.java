/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin Iter {
  class Epp {

    //--------------------------------------------------
    // Extend type system.
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:iter, new IterTypeNameChecker());
    }

    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :iter){
	if (t2.tag() == :iter){
	  IterType a1 = (IterType)t1;
	  IterType a2 = (IterType)t2;
	  return equals(a1.getValueType(), a2.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    extend boolean isSuperType(Type t1, Type t2){
      if (t1.tag() == :iter){
	if (t2.tag() == :iter){
	  return equals(t1, t2);
	} else {
	  return t2.tag() == :null;
	}
      } else if (t2.tag() == :iter
		 && t1.tag() == :class
		 && t1.classInfo().getName() == :"java.lang.Object"){
	return true;
      } else {
	return original(t1, t2);
      }
    }

    //--------------------------------------------------

    extend void initTypeCheckerTable () {
      original();
      extendTypeChecker(:invokeExp,	new IterInvokeMacroTypeChecker());
      defineTypeChecker(:iterNext,	new IterNextTypeChecker());
    }

    extend void initTranslatorTable () {
      original();
      defineTranslator(:iter, new IterTypeTranslator());
      defineTranslator(:iterNext, new IterNextTranslator());
    }
  }
}

public class IterType extends Type {
  Type valueType;
  public IterType(Type valueType){
    super(:iter);
    this.valueType = valueType;
  }
  public Type getValueType() { return valueType; }
  public String toString(){
    return "Iter<"+ valueType+ ">";
  }
  public Tree toTree(){
    return `(iter ,(valueType.toTree()));
  }
}



// (iter Type)
class IterTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeNameCheckTree(args[0]),
    };
    Type t = new IterType(newArgs[0].type());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}


// a.hasNext()  => (iterHasNext a)
class IterHasNextMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree a = typeCheckTree(args[0]);
    Tree m = args[1];
    Tree argumentList = typeCheckTree(args[2]);
    Tree[] aargs = argumentList.args();

    if (a.type().tag() == :iter &&
	m.idName() == :hasNext){
      // $B$3$3$G0z?t$N?t$H7?$N%A%'%C%/$,I,MW!#(B
      return remakeTree(`(iterHasNext
			  ,a), tree);
    } else {
      return orig.call(tree.modifyArgs(new Tree[]{ a, m, argumentList}));
    }
  }
}


// a.next()  =>  (iterNext type a)
// a.foo(...) => (invokeCollection a (id foo) (argumentList ...))
class IterInvokeMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree a = typeCheckTree(args[0]);
    Tree m = args[1];
    Tree argumentList = typeCheckTree(args[2]);
    Tree[] aargs = argumentList.args();

    if (a.type().tag() == :iter){
      IterType aType = (IterType)a.type();
      Symbol methodName = m.idName();
      if (methodName == :next){
	checkArgumentListLength(tree, 0);
	return remakeTree(`(iterNext
			    ,(aType.getValueType().toTree())
			    ,a), tree);

      } else {
	// $B0J2<!"0z?t$N%A%'%C%/$O(B javac $B$K$^$+$;$k!#(B
	Type retType;
	if (methodName == :hasNext){
	  retType = Type.Tboolean;
	} else if (methodName == :equals){
	  retType = Type.Tboolean;
	} else if (methodName == :toString){
	  retType = Type.TString;
	} else if (methodName == :print){
	  retType = aType;
	} else {
	  throw errorAt(tree, "Method "+ methodName+ " is not defined for "+
			" Iter<T> .");
	}
	Tree newTree = `(invokeCollection ,a ,m ,argumentList);
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(retType,
					 newTree.args());
      }

    } else {
      return orig.call(tree.modifyArgs(new Tree[]{ a, m, argumentList}));
    }
  }

  static void checkArgumentListLength(Tree tree, int n){
    Symbol methodName = tree.args()[1].idName();
    Tree[] aargs = tree.args()[2].args();
    if (aargs.length != n){
      Obj epp = (Obj)Dynamic.get(:epp);
      throw epp!errorAt(tree, "Method "+ methodName+ " requires "+ n+
			" args but "+ aargs.length+ " were supplied.");
    }
  }
}


// (iterNext type a)
class IterNextTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    if (a.type().tag() != :iter) throw Epp.fatal("");
    IterType aType = (IterType)a.type();
    return tree.modifyTypeAndArgs(aType.getValueType(),
				  new Tree[]{ typeName, a });
  }
}




// Translator


// Iter(String) a = new Iter(String);
//  => jp.go.etl.epp.util.Iter a = new jp.go.etl.epp.util.Iter();
// Iter() $B$H$$$&%3%s%9%H%i%/%?$,$J$$$+$i(B new Iter<T>() $B$O%(%i!<$K$J$k!#(B
class IterTypeTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = translateArgs(tree);
    return `(name (id jp)(id go)(id etl)(id epp)(id util)(id Iter));
  }
}


// (iterNext type a)  =>  (type)a.next()
class IterNextTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);

    IterType aType = (IterType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id nextInt)
		 (argumentList));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id next)
		(argumentList)));
    }
  }
}

