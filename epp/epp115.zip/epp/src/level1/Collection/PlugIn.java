/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

package Collection;

BeforeLoadingPlugIn{
  // Extract prefix of this collection name, e.g. "jp.go.etl.epp." . 
  String name = ((Symbol)SystemMixin_Collection.instance.name).toString();
  String prefix = name.substring(0, name.lastIndexOf("Collection.Collection"));

  requirePlugIn(prefix+ "Collection.Foreach");
  requirePlugIn(prefix+ "Collection.Table");
  requirePlugIn(prefix+ "Collection.Vec");
  requirePlugIn(prefix+ "Collection.Iter");
  // localVariableDecl $B$KCm0U!#(B redefine $B$7$F$$$k$N$G=g=x0MB8!#(B
  requirePlugIn(prefix+ "Collection.IfNotFound");
  // IfNull $B$O!"(B IfNotFound $B$GDj5A$5$l$?(B hook localVariableDecl2 $B$r3HD%!#(B
  requirePlugIn(prefix+ "Collection.IfNull");
  requirePlugIn(prefix+ "Collection.Parser");
}

SystemMixin Collection {
  class Epp {
    extend void initTranslatorTable () {
      original();
      defineTranslator(:invokeCollection, new InvokeCollectionTranslator());
    }
  }
}

//--------------------------------------------------
//  (invokeCollection a m argumentList) $B$O!"(B Collection $B7?$N(B
//$B!V$=$NB>!W$N%a%=%C%I8F$S=P$7<0!#(B
// TableInvokeMacroTypeChecker $B$J$I$G!"E83+$5$l$k!#(B
// invokeCollection $B$N(B TypeChecker $B$OB8:_$7$J$$!#(B
//$B!J:n$k$N$,$a$s$I$&$J$N$G!"(B TableInvokeMacroTypeChecker $B$J$I$G(B
//  $B7?%A%'%C%/$^$G$d$C$F$7$^$&!#(B
// $B$3$NJ}K!$O!"(B composability $B$,0-$$$N$GK\Ev$O$h$/$J$$!#!K(B
// $B0z?t$N%(%i!<%A%'%C%/$O(B javac $B$K$^$+$;$k!#(B

// (invokeCollection a m argumentList) -> a.m()
class InvokeCollectionTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    return `(invokeExp
	     ,(translateTree(args[0])) ,(args[1])
	     ,(translateTree(args[2])));
  }
}
