/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*


Translation rule
----------------

	T var = exp ifNull block  rest;
->
	{ T var;
	  NullOr<T> tmp = exp;
	  if (tmp != null)
	    var = (coerceTfromNullOrT tmp);
	  else
	    block
          rest;
        }


	var = exp ifNull block
->
	{ NullOr<T> tmp = exp;
	  if (tmp != null)
	    var = (coerceTfromNullOrT tmp);
	  else
	    block
        }


Syntax
------
Statement
	<original alternatives>
	Type Identifier = Expression . get ( Expression ) ifNull Block
	Identifier = Expression . get ( Expression ) ifNull Block

AST
---
(ifNull Statement Block)
(ifNull Decl Block)


Illegal Syntax
--------------
	return table.get(key) ifNull { return defaultValue; }
	x = table.get(key) ifNull { throw fatal(); } + 1;
	a[n] = table.get(key) ifNull { throw fatal(); }

*/


#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin IfNull {
  class Epp {
    extend Tree statementOtherwise2(Tree tree, Token nextToken) {
      if (nextToken == :ifNull) {
	tree = expression();
	matchAny();
	Tree block = block();
	//old  match(:";");
	return new Tree(:ifNull,
			new Tree(:expressionStatement, tree),
			block);

      } else {
	return original(tree, nextToken);
      }
    }

    // IfNotFound.java $B$GDj5A$5$l$F$$$k(B hook $B$r3HD%!#(B
    extend Tree localVariableDecl2(Tree modifiers, Tree type, Tree vardecls){
      if (lookahead() == :ifNull) {
	// $BK\Ev$O!"(BType Identifier = Expression ifNull Block ; $B$H$$$&(B
	//$B7A$K$J$C$F$$$k$+$I$&$+$r$3$3$G%A%'%C%/$9$kI,MW$"$j!#(B
	matchAny();
	Tree decl = new Tree(:decl, modifiers, type, vardecls);
	Tree block = block();
	//old  match(:";");
	return new Tree(:ifNull,
			decl,
			block);
      } else {
	return original(modifiers, type, vardecls);
      }
    }

    //--------------------------------------------------

    extend void typeCheckBlockStatement(Tree tree,
					int i,
					Tree[] args,
					TreeVec newArgs){
      // (ifNull (decl (modifiers) (name ...) ...) (block ...))
      if (tree.tag() == :ifNull &&
	  tree.args()[0].tag() == :decl){
	Tree[] dargs = tree.args()[0].args();
	Tree modifiers = dargs[0];
	Tree type = dargs[1];
	Tree vardecls = dargs[2];
	if (vardecls.args().length != 1){
	  throw errorAt(vardecls, "Only one variable declaration is allowed "+
			"for the declaration before ifNull .");
	}
	Tree varInit = vardecls.args()[0];
	if (varInit.tag() != :varInit){
	  throw errorAt(varInit, "VariableInitializer should be supplied "+
			"for the declaration before ifNull .");
	}
	if (varInit.args()[0].tag() == :arrayVar){
	  throw errorAt(varInit, "var[] is not supported "+
			"for the declaration before ifNull .");
	}
	if (varInit.args()[1].tag() == :arrayInitializer){
	  // $BL$CN$N(B VariableInitializer $B$N%A%'%C%/$,$G$-$J$$!*!*!*(B
	  throw errorAt(varInit, "ArrayInitializer is not supported "+
			"for the declaration before ifNull .");
	}
	Tree var = varInit.args()[0];
	Tree exp = varInit.args()[1];
	Tree block = tree.args()[1];
	Tree tmp = new Identifier(Macro.genTemp("_e"));

	TreeVec rest = new TreeVec();
	for (; i < args.length; i++){
	  rest.add(args[i]);
	}

	Tree newTree =
	  `(block (decl ,modifiers ,type (vardecls ,var))
	    (decl (modifiers) (nullOr ,type)
	     (vardecls (varInit ,tmp ,exp)))
	    (if (!= ,tmp (id null))
	     (expressionStatement (= ,var (coerceTfromNullOrT ,tmp)))
	     ,block)
	    ,@rest);

	newTree = TypeChecker.remakeTree(newTree, tree);
	newArgs.add(TypeChecker.typeCheckTree(newTree));
	return;
      } else {
	original(tree, i, args, newArgs);
      }
    }

    //--------------------------------------------------
    // Extend type system.

    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :nullOr){
	if (t2.tag() == :nullOr){
	  NullOrType a1 = (NullOrType)t1;
	  NullOrType a2 = (NullOrType)t2;
	  return equals(a1.getValueType(), a2.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    // NullOr<T1> < NullOr<T2>  if  T1 < T2
    // NullOr<T1> < T2  if  T1 < T2 or T2 == null
    extend boolean isSuperType(Type t1, Type t2){
      if (t1.tag() == :nullOr){
	NullOrType a1 = (NullOrType)t1;

	if (t2.tag() == :nullOr){
	  NullOrType a2 = (NullOrType)t2;
	  return isSuperType(a1.getValueType(), a2.getValueType());

	} else if (t2.tag() == :null){
	  return true;

	} else {
	  return isSuperType(a1.getValueType(), t2);
	}

      } else if (t2.tag() == :nullOr
		 && t1.tag() == :class
		 && t1.classInfo().getName() == :"java.lang.Object"){
	return true;

      } else {
	return original(t1, t2);
      }
    }

    extend Tree assignmentConversion(Type type, Tree tree){
      if (type.tag() == :nullOr){
	if (tree.type().tag() == :null){
	  // null $B$N>l9g$O(B coerce $B$7$J$$$3$H$K$9$k!#(B
	  return tree;
	} else if (tree.type().tag() == :nullOr){
	  return coerce(type, tree);
	} else {
	  Tree newTree = `(coerceNullOrTfromT
			   ,(type.toTree()) // $B>iD9!)(B
			   ,(coerce(type, tree)));
	  return TypeChecker
	    .typeCheckTree(TypeChecker.remakeTree(newTree, tree));
	}
      } else {
	return original(type, tree);
      }
    }

    //--------------------------------------------------

    extend void initTypeCheckerTable () {
      original();
      defineTypeChecker(:ifNull, new IfNullTypeChecker());
      defineTypeChecker(:coerceNullOrTfromT, new CoerceNullOrTfromTTypeChecker());
      defineTypeChecker(:coerceTfromNullOrT, new CoerceTfromNullOrTTypeChecker());
    }

    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:nullOr, new NullOrTypeNameChecker());
    }

    extend void initTranslatorTable () {
      original();
      defineTranslator(:nullOr, new NullOrTranslator());
      defineTranslator(:coerceNullOrTfromT, new CoerceNullOrTfromTTranslator());
      defineTranslator(:coerceTfromNullOrT, new CoerceTfromNullOrTTranslator());
    }
  }
}



class IfNullTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // (ifNull (expressionStatement (= var exp)) Block)
    checkArgsLength(tree, 2);
    Tree statement = tree.args()[0];
    Tree block = tree.args()[1];
    if (statement.tag() != :expressionStatement ||
	statement.args()[0].tag() != :"="){
      throw errorAt(statement, "Only assignment expression is allowed "+
		    "before ifNull .");
    }
    Tree var = statement.args()[0].args()[0];
    Tree exp = statement.args()[0].args()[1];
    if (var.tag() != :id){
      throw errorAt(var, "Only Identifier is allowed "+
		    "for the left hand side of assignment before ifNull .");
    }

    Tree typedVar = typeCheckTree(var);
    Tree type = typedVar.type().toTree();
    Tree tmp = new Identifier(genTemp("_e"));

    Tree newTree =
      `(block (decl (modifiers) (nullOr ,type)
	       (vardecls (varInit ,tmp ,exp)))
	(if (!= ,tmp (id null))
	 (expressionStatement (= ,var (coerceTfromNullOrT ,tmp)))
	 ,block));
    return remakeTree(newTree, tree);
  }
}



public class NullOrType extends Type {
  Type valueType;
  public NullOrType(Type valueType){
    super(:nullOr);
    this.valueType = valueType;
  }
  public Type getValueType() { return valueType; }
  public String toString(){
    return "NullOr<"+ valueType+ ">";
  }
  public Tree toTree(){
    return `(nullOr ,(valueType.toTree()));
  }
}


// (nullOr Type)
class NullOrTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeNameCheckTree(args[0]),
    };
    Type t = new NullOrType(newArgs[0].type());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

class CoerceTfromNullOrTTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeCheckTree(args[0]),
    };
    NullOrType type = (NullOrType)newArgs[0].type();
    return tree.modifyTypeAndArgs(type.getValueType(), newArgs);
  }
}

class CoerceNullOrTfromTTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeNameCheckTree(args[0]),
      typeCheckTree(args[1]),
    };
    Type t = new NullOrType(newArgs[0].type());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}





// NullOr<T> a = new NullOr<T>();
//  => T a = new T();
class NullOrTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Type type = tree.args()[0].type();
    Tree[] args = translateArgs(tree);
    if (type.tag() == :int){
      return `(name (id java)(id lang)(id Integer));
    } else {
      return args[0];
    }
  }
}

// (coerceTfromNullOrT exp)
// exp $B$NCM$,(B null $B$G$O$J$$$3$H$O!"(B ifNull $B9=J8$,J]>Z$9$k!#(B
class CoerceTfromNullOrTTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Type type = tree.type();
    Tree[] args = translateArgs(tree);
    if (type.tag() == :int){
      return `(invokeExp ,(args[0]) (id intValue) (argumentList));
    } else {
      return args[0];
    }
  }
}

// (coerceNullOrTfromT type exp)
class CoerceNullOrTfromTTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    NullOrType type = (NullOrType)tree.args()[0].type();
    Tree[] args = translateArgs(tree);
    if (type.getValueType().tag() == :int){
      return `(invokeStatic
	       (name (id jp)(id go)(id etl)(id epp)(id util)(id Wrapper))
	       (id wrap) (argumentList ,(args[1])));
    } else {
      return args[1];
    }
  }
}
