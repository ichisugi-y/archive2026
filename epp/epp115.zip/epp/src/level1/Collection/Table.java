/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp jp.go.etl.epp.EppLibLevel0

package Collection;


SystemMixin Table {
  class Epp {

    //--------------------------------------------------
    // Extend type system.
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:table, new TableTypeNameChecker());
    }

    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :table){
	if (t2.tag() == :table){
	  TableType a1 = (TableType)t1;
	  TableType a2 = (TableType)t2;
	  return equals(a1.getKeyType(), a2.getKeyType()) &&
	    equals(a1.getValueType(), a2.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    extend boolean isSuperType(Type t1, Type t2){
      if (t1.tag() == :table){
	if (t2.tag() == :table){
	  return equals(t1, t2);
	} else {
	  return t2.tag() == :null;
	}
      } else if (t2.tag() == :table
		 && t1.tag() == :class
		 && t1.classInfo().getName() == :"java.lang.Object"){
	return true;
      } else {
	return original(t1, t2);
      }
    }

    //--------------------------------------------------
    // Extend VariableInitializer.

    extend Tree coerceVariableInitializer(Type type,
					  Tree tree){
      Symbol tag = tree.tag();
      Symbol s1 = type.tag();
      Symbol s2 = tree.type().tag();
      if (tag == :arrayInitializer && s1 == :table){
	if (tree.args().length != 0){
	  throw errorAt(tree,
			"ArrayInitializer for Table<T> is not fully supported. "+
			"Currently, only empty ArrayInitializer \"{}\" "+
			"is supported.");
	}
	Tree newTree = `(new ,(type.toTree()) (argumentList));
	newTree = TypeChecker.remakeTree(newTree, tree);
	return TypeChecker.typeCheckTree(newTree);
      } else {
	return original(type, tree);
      }
    }


    //--------------------------------------------------

    extend void initTypeCheckerTable () {
      original();

      extendTypeChecker(:new,		new TableNewTypeChecker());
      extendTypeChecker(:invokeExp,	new TableInvokeMacroTypeChecker());
      defineTypeChecker(:tablePut,	new TablePutTypeChecker());
      defineTypeChecker(:tableGet,	new TableGetTypeChecker());
      //defineTypeChecker(:tableRemove,	new TableRemoveTypeChecker());
      //defineTypeChecker(:tableContainsKey,new TableContainsKeyTypeChecker());
    }

    extend void initTranslatorTable () {
      original();
      defineTranslator(:table, new TableTypeTranslator());
      defineTranslator(:tableGet, new TableGetTranslator());
      defineTranslator(:tablePut, new TablePutTranslator());
      //defineTypeChecker(:tableRemove,	new TableRemoveTranslator());
      //defineTypeChecker(:tableContainsKey,new TableContainsKeyTranslator());
    }
  }
}


//--------------------------------------------------





public class TableType extends Type {
  Type keyType;
  Type valueType;
  public TableType(Type keyType, Type valueType){
    super(:table);
    this.keyType = keyType;
    this.valueType = valueType;
  }
  public Type getKeyType() { return keyType; }
  public Type getValueType() { return valueType; }
  public String toString(){
    return "Table<"+ keyType+ ", "+ valueType+ ">";
  }
  public Tree toTree(){
    return `(table ,(keyType.toTree()) ,(valueType.toTree()));
  }
}



// (table Type Type)
class TableTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree[] newArgs = {
      typeNameCheckTree(args[0]),
      typeNameCheckTree(args[1]),
    };
    Type t = new TableType(newArgs[0].type(),
				newArgs[1].type());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}



class TableNewTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree argumentList = typeCheckTree(args[1]);
    Type targetType = typeTree.type();
    Tree[] newArgs = { typeTree, argumentList };
    Symbol tag = targetType.tag();
    if (tag == :table){
      // Actually, I should check constructor arguments.
      return tree.modifyTypeAndArgs(typeTree.type(), newArgs);
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}




// invokeExp $B$K(B decorator $B$rIU$1$k$N$O!"$A$g$C$HLLE]!#(B
// $B<!$N$h$&$K$d$C$F$7$^$&$H!"(B (id get) $B$,<0$H$7$F7?%A%'%C%/$5$l$F$7$^$$!"(B
// "Variable get not declared." $B$H$$$&%(%i!<$K$J$C$F$7$^$&$N$GCm0U!#(B
// Tree[] args = typeCheckArgs(tree);
//$B<!4|(B EPP $B$G$O$3$N$"$?$j$,4JC1$K$J$k$O$:!#(B

// a.put(key, val)  =>  (tablePut a key val)
// a.get(key)  => (tableGet type a key)
// a.keyIter()  =>  (tableKeyIter a)
// a.valueIter()  =>  (tableValueIter a)
// a.foo(...) => (invokeCollection a (id foo) (argumentList ...))
class TableInvokeMacroTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree a = typeCheckTree(args[0]);
    Tree m = args[1];
    Tree argumentList = typeCheckTree(args[2]);
    Tree[] aargs = argumentList.args();

    if (a.type().tag() == :table){
      TableType aType = (TableType)a.type();
      Symbol methodName = m.idName();
      if (methodName == :put){
	checkArgumentListLength(tree, 2);
	return remakeTree(`(tablePut
			    ,a
			    ,(aargs[0])
			    ,(aargs[1])), tree);

      } else if (methodName == :get){
	checkArgumentListLength(tree, 1);
	return remakeTree(`(tableGet
			    ,(aType.getValueType().toTree())
			    ,a
			    ,(aargs[0])), tree);

      } else {
	Tree[] newArgs = new Tree[aargs.length];
	for (int i = 0; i < aargs.length; i++){
	  newArgs[i] = aargs[i];
	}
	Type retType;
	if (methodName == :keyIter){
	  checkArgumentListLength(tree, 0);
	  retType = new IterType(aType.getKeyType());
	} else if (methodName == :valueIter){
	  checkArgumentListLength(tree, 0);
	  retType = new IterType(aType.getValueType());
	} else if (methodName == :size){
	  checkArgumentListLength(tree, 0);
	  retType = Type.Tint;
	} else if (methodName == :remove){
	  checkArgumentListLength(tree, 1);
	  newArgs[0] = Type.coerce(aType.getKeyType(), newArgs[0]);
	  retType = Type.Tvoid;
	} else if (methodName == :containsKey){
	  checkArgumentListLength(tree, 1);
	  newArgs[0] = Type.coerce(aType.getKeyType(), newArgs[0]);
	  retType = Type.Tboolean;
	} else if (methodName == :clear){
	  checkArgumentListLength(tree, 0);
	  retType = Type.Tvoid;

	  // $B0J2<!"0z?t$N%A%'%C%/>JN,!#(B javac $B$K$^$+$;$k!#(B
	} else if (methodName == :equals){
	  retType = Type.Tboolean;
	} else if (methodName == :clone){
	  retType = Type.TObject;
	} else if (methodName == :toString){
	  retType = Type.TString;
	} else if (methodName == :print){
	  retType = aType;
	} else {
	  throw errorAt(tree, "Method "+ methodName+ " is not defined for "+
			" Table<T> .");
	}
	Tree newTree = `(invokeCollection ,a ,m
			 ,(argumentList.modifyArgs(newArgs)));
	newTree = remakeTree(newTree, tree);
	return newTree.modifyTypeAndArgs(retType,
					 newTree.args());
      }

    } else {
      return orig.call(tree.modifyArgs(new Tree[]{ a, m, argumentList}));
    }
  }

  // Vec $B$K$bF1$8%a%=%C%I$,$"$k!#(B
  // Util $B$H$$$&%/%i%9$r:n$C$F!"$=$3$K$^$H$a$k$Y$-$+!)(B
  static void checkArgumentListLength(Tree tree, int n){
    Symbol methodName = tree.args()[1].idName();
    Tree[] aargs = tree.args()[2].args();
    if (aargs.length != n){
      Obj epp = (Obj)Dynamic.get(:epp);
      throw epp!errorAt(tree, "Method "+ methodName+ " requires "+ n+
			" args but "+ aargs.length+ " were supplied.");
    }
  }
}

// (tablePut a key val)
class TablePutTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    Tree[] args = typeCheckArgs(tree);
    TableType aType = (TableType)args[0].type();
    Tree key = Type.coerce(aType.getKeyType(), args[1]);
    Tree val = Type.coerce(aType.getValueType(), args[2]);

    // $B$3$N%N!<%I$O!"(B a.put(key, val) $B$KJQ49$5$l$k$,!"(B
    // $B$=$N7?$O(B Java $B8@8l$G$O(B Object $B$J$N$G!"F1$87?$K$7$F$*$/!#(B
    return tree.modifyTypeAndArgs(Type.TObject, typeCheckArgs(tree));
  }
}

// (tableGet type a key)
class TableGetTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree typeName = typeNameCheckTree(args[0]);
    Tree a = typeCheckTree(args[1]);
    Tree key = typeCheckTree(args[2]);

    // a $B$,(B table $B$G$"$k$3$H$r3N$+$a$k!#0c$C$?$i(B fatal error $B!#(B
    if (a.type().tag() != :table) throw Epp.fatal("");
    TableType aType = (TableType)a.type();
    key = Type.coerce(aType.getKeyType(), key);

    return tree.modifyTypeAndArgs(new NullOrType(aType.getValueType()),
				  new Tree[]{ typeName, a, key });
  }
}




// Translator


// Table(String, String) a = new Table(String, String);
//  => jp.go.etl.epp.util.Table a = new jp.go.etl.epp.util.Table();
class TableTypeTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    // $BK\Ev$O!":F5"=hM}$9$kI,MW$"$j!#7k2L$O;H$o$J$$!#(B
    Tree[] args = translateArgs(tree);
    return `(name (id jp)(id go)(id etl)(id epp)(id util)(id Table));
  }
}

// (tablePut a key val)  =>  a.put(key, val)
class TablePutTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    TableType aType = (TableType)tree.args()[0].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree a = args[0];
    Tree key = args[1];
    Tree val = args[2];

    return `(invokeExp ,a (id put) (argumentList ,key ,val));
  }
}

// (tableGet type a key)  =>  (type)a.get(key)
class TableGetTranslator extends Translator {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);

    TableType aType = (TableType)tree.args()[1].type();
    Symbol tag = aType.getValueType().tag();

    Tree[] args = translateArgs(tree);
    Tree type = args[0];
    Tree a = args[1];
    Tree val = args[2];

    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(cast (name (id java)(id lang)(id Integer))
		 (invokeExp ,a (id get)
		  (argumentList ,val)));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id get)
		(argumentList ,val)));
    }
    /* old
    if (tree.args()[0].type().isPrimitiveType()){
      if (tag == :int){
	return `(invokeExp ,a (id getInt)
		 (argumentList ,val));
      } else {
	// $B$H$j$"$($:(B int $B$N$_!#(B
	throw Epp.error("Collectoin: Not implemented: "+ tree);
      }
    } else {
      return `(cast ,type
	       (invokeExp ,a (id get)
		(argumentList ,val)));
    }
    */
  }
}
