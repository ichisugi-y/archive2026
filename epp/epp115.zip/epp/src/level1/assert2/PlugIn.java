/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 assert2 plug-in.

 It produces better error message than assert plug-in.
 The assert2 plug-in requires type-checking pass.

 ---

 If epp is invoked with -DNDEBUG=true option,
"assert(p);" will be expanded to an empty statement.

 The syntax of assert statement is JDK1.4 compatible.

Statement:
	<original alternatives>
	assert Expression ;
	assert Expression : Expression ;

*/


#epp jp.go.etl.epp.EppLibLevel0

package assert2;

SystemMixin assert2 {
  class Epp {

    extend Tree statementTop(){
      if (lookahead() == :assert){
	matchAny();
	Tree exp1 = expression();
	if (lookahead() == :":"){
	  matchAny();
	  Tree exp2 = expression();
	  match(:";");
	  return new Tree(:assert, exp1, exp2);
	} else {
	  match(:";");
	  return new Tree(:assert, exp1);
	}
      } else {
	return original();
      }
    }

    extend void initTypeCheckerTable() {
      original();
      defineTypeChecker(:assert, new AssertTypeChecker());
    }
  }
}

class AssertTypeChecker extends TypeChecker {

  public Tree call(Tree tree){
    if (isNDEBUG()){
      return `(emptyStatement);
    } else {
      Tree[] args = tree.args();
      Tree pred = args[0];
      if (args.length == 1){
	Symbol tag = pred.tag();
	if (tag == :"==" || tag == :"!="
	    || tag == :"<" || tag == :">"
	    || tag == :"<=" || tag == :">="){
	  Tree tmp1 = new Identifier(Macro.genTemp("_t"));
	  Tree tmp2 = new Identifier(Macro.genTemp("_t"));
	  Tree exp1 = typeCheckTree(pred.args()[0]);
	  Tree exp2 = typeCheckTree(pred.args()[1]);
	  Tree type1 = exp1.type().toTree();
	  Tree type2 = exp2.type().toTree();
	  Tree newPred = new Tree(tag, tmp1, tmp2);
	  Tree message
	    =  `(+ (+ (+ (+ (literalTree string "Assertion failed : (")
			  ,tmp1)
		       ,(new LiteralTree(:string,
					 " "+ tag+ " ")))
		    ,tmp2)
		 (literalTree string ") is not true."));
		 
	  return `(block
		   (decl (modifiers) ,type1 (vardecls (varInit ,tmp1 ,exp1)))
		   (decl (modifiers) ,type2 (vardecls (varInit ,tmp2 ,exp2)))
		   (if (! ,(remakeTree(newPred, pred)))
		    (throw
		     (new (name (id Error))
		      (argumentList ,message)))
		    (emptyStatement)));

	} else {
	  Tree message = `(literalTree string "Assertion failed : ");
	  return simpleAssert(pred, message);
	}

      } else {
	// args.length == 2
	Tree message = `(+ (literalTree string "Assertion failed : ")
			 ,(args[1]));
	return simpleAssert(pred, message);
      }
    }
  }

  public Tree simpleAssert(Tree pred, Tree message){
    return `(if (! ,pred)
	     (throw
	      (new (name (id Error))
	       (argumentList ,message)))
	     (emptyStatement));
  }

  public boolean isNDEBUG(){
    String prop = System.getProperty("NDEBUG");
    if (prop == null || prop.equals("false")){
      return false;
    } else if (prop.equals("true")){
      return true;
    } else {
      throw Epp.error("assert plug-in: Illgal property value : "+
		      "NDEBUG="+ prop);
    }
  }
}
