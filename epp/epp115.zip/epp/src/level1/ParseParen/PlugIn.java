/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 With this plug-in, EPP makes ":paren" nodes in AST.
(The default EPP never make AST containing any ":paren" nodes.)

*/

#epp jp.go.etl.epp.EppLibLevel0

package ParseParen;

SystemMixin ParseParen {
  class Epp {
    extend Tree makeParenNode(Tree tree){
      return new Tree(:paren, tree);
    }
  }
}
