/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*

 This plug-in parses comments.
 Parsed comments are stored into a TreeVec, epp!commentNodes .

 Emitting of the parsed comments are not implemented yet.



AST format
----------

Comment:
	(javadocComment CommentLiteral*)
	(endOfLineComment CommentLiteral*)
	(traditionalComment CommentLiteral*)

CommentLiteral:
	(literalTree commentLiteral String)



*/

#epp jp.go.etl.epp.EppLibLevel0

package ParseComment2;
import java.util.Vector;
import java.io.*;

SystemMixin ParseComment2 {
  class Epp {
    TreeVec commentNodes;

    extend void initializationPass() {
      original();
      self!commentNodes = new TreeVec();
    }
    
    extend void afterParsingPass() {
      original();
      if (Opts.printTree){
	Tree[] trees = self!commentNodes.toArray();
	Opts.out.println();
	Opts.out.println("commentNodes:");
	for (int i = 0; i < trees.length; i++){
	  trees[i].print();
	}
	Opts.out.println("End of commentNodes.");
	Opts.out.println();
      }
    }


    //--------------------------------------------------
    // Extend lex.

    redefine Token readEndOfLineComment(EppInputStream in){
      StringBuffer buf = new StringBuffer();
      char c = in.peekc();
      if (Opts.commentColon && c == ':'){
	in.getc();
	return readToken(in);
      }

      int lineNumber = in.lineNumber();
      int beginning = in.pointer();

      c = in.getc();
      while (true) {
	if (c == '\n' || c == '\r') break;
	buf.append(c);
	c = in.getc();
      }

      TreeVec tvec = new TreeVec();
      tvec.add(commentLiteral(buf.toString(),
			      lineNumber, beginning, in.pointer() - 1));
      putCommentNode(:endOfLineComment, tvec,
		     lineNumber, beginning - 2, in.pointer() - 1);
      // Read next token.
      return readToken(in);
    }

    redefine Token readTraditionalComment(EppInputStream in){
      StringBuffer buf = new StringBuffer();

      int commentLineNumber = in.lineNumber();
      int commentBeginning = in.pointer() - 2;

      char c = in.peekc();

      if (Opts.commentColon && c == ':'){
	in.getc();
	return readToken(in);
      }

      Symbol commentTag;
      if (c == '*'){
	commentTag = :javadocComment;
	int p = in.pointer();
	in.getc();
	if (in.peekc() == '/'){
	  // Special case. "/**/" is a documentation comment.
	  // See JLS 3.7 .
	  // Backtrack the input pointer to "/**/"
	  //                                   ^
	  in.backtrack(p);
	}
      } else {
	commentTag = :traditionalComment;
      }

      TreeVec tvec = new TreeVec();

      int literalLineNumber = in.lineNumber();
      int literalBeginning = in.pointer();

      c = in.getc();
      while (true) {
	if (c == '*') {
	  c = in.getc();
	  if (c == '/') break;
	  buf.append('*');
	} else if (c == '\n' || c == '\r'){
	  int literalEnd = in.pointer() - 1;
	  if (c == '\r'){
	    c = in.getc();
	    if (c != '\n'){
	      in.ungetc(c);
	    }
	  }
	  tvec.add(commentLiteral(buf.toString(),
				  literalLineNumber,
				  literalBeginning,
				  literalEnd));
	  literalLineNumber++;
	  literalBeginning = in.pointer();
	  c = in.getc();
	  buf.setLength(0);
	} else {
	  buf.append(c);
	  c = in.getc();
	}
      }
      tvec.add(commentLiteral(buf.toString(),
			      literalLineNumber,
			      literalBeginning,
			      in.pointer() - 2));

      putCommentNode(commentTag, tvec,
		     commentLineNumber, commentBeginning, in.pointer());

      // Read next token.
      return readToken(in);
    }
    

    
    //--------------------------------------------------
    // Comment queue manipuration.
    
    define implement Tree commentLiteral(String literalContents,
					 int lineNumber,
					 int beginning,
					 int end
					 ){
      Dynamic.bindInt(:lineNumberOfThisNode, lineNumber);
      Dynamic.bindInt(:beginningPointOfThisNode, beginning);
      Dynamic.bindInt(:endPointOfThisNode, end);
      try {
	return new LiteralTree(:commentLiteral, literalContents);
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }
    
    define implement void putCommentNode(Symbol commentTag,
					 TreeVec commentLiterals,
					 int lineNumber,
					 int beginning,
					 int end
					 ){
      Dynamic.bindInt(:lineNumberOfThisNode, lineNumber);
      Dynamic.bindInt(:beginningPointOfThisNode, beginning);
      Dynamic.bindInt(:endPointOfThisNode, end);
      try {
	Tree t = new Tree(commentTag, commentLiterals);

	//Opts.out.println(t);

	self!commentNodes.add(t);
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }
    
    //--------------------------------------------------
    // Emitter

    extend void initEmitterTable() {
      original();
      defineEmitter(:javadocComment, new TraditionalCommentEmitter());
      defineEmitter(:traditionalComment, new TraditionalCommentEmitter());
      defineEmitter(:endOfLineComment, new EndOfLineCommentEmitter());
    }
  }
}

class TraditionalCommentEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException  {
    Symbol tag = tree.tag();
    Tree[] args = tree.args();
    if (tag == :javadocComment){
      emitString(out, "/**");
    } else if (tag == :traditionalComment){
      emitString(out, "/*");
    } else {
      throw Epp.fatal("");
    }
    int current = Dynamic.getInt(:outputLineNumber);
    for (int i = 0; i < args.length - 1; i++) {
      emitString(out, args[i].literalToken().literalContents());
      emitString(out, Opts.lineSeparator);
      current++;
    }
    emitString(out, args[args.length - 1].literalToken().literalContents());
    Dynamic.setInt(:outputLineNumber, current);
    
    emitString(out, "*/");
  }
}

class EndOfLineCommentEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException  {
    Tree[] args = tree.args();
    emitString(out, "//");
    emitString(out, args[0].literalToken().literalContents());
    
    emitString(out, Opts.lineSeparator);
    int current = Dynamic.getInt(:outputLineNumber);
    Dynamic.setInt(:outputLineNumber, current + 1);
  }
}
