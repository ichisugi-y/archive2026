/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
Syntax
------

Type:
	<original alternatives>
	AssociationArray(Type, Type)

*/


#epp jp.go.etl.epp.EppLibLevel0

package AssociationArray;

SystemMixin AssociationArray {
  class Epp {
    //--------------------------------------------------
    // Extend parser.

    // Firstly, AssociationArray(String, String) is parsed as an expression:
    //  (invoke1 (id AssociationArray) (argumentList (id String) (id String)))
    // This method converts it to the type name:
    //  (assocArray (name (id String)) (name (id String)))
    extend Tree convertExpressionToType(Tree tree) {
      if (tree.tag() == :invoke1 &&
	  tree.args()[0].idName() == :AssociationArray) {
	Tree[] args = tree.args()[1].args();
	if (args.length != 2){
	  throw error("Type constructor AssociationArray requires two types.");
	}
	return new Tree(:assocArray,
			convertExpressionToType(args[0]),
			convertExpressionToType(args[1]));
      } else {
	return original(tree);
      }
    }

    // new AssociationArray(String, String) is parsed as:
    //  (new (assocArray (name (id String)) (name (id String))) (argumentList))
    extend Tree instanceCreation(){
      int p = inputPointer();
      match(:new);
      Tree tree = expression();
      if (tree.tag() == :invoke1 &&
	  tree.args()[0].idName() == :AssociationArray) {
	return `(new ,(convertExpressionToType(tree)) (argumentList));
      } else {
	backtrack(p);
	return original();
      }
    }




    //--------------------------------------------------
    // Extend type system.
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:assocArray, new AssocArrayTypeNameChecker());
    }

    extend boolean equals(Type t1, Type t2){
      if (t1.tag() == :assocArray){
	if (t2.tag() == :assocArray){
	  AssocArrayType a1 = (AssocArrayType)t1;
	  AssocArrayType a2 = (AssocArrayType)t2;
	  return equals(a1.getKeyType(), a2.getKeyType()) &&
	    equals(a1.getValueType(), a2.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
    }

    extend boolean isSuperType(Type t1, Type t2){
      if (t1.tag() == :assocArray){
	if (t2.tag() == :assocArray){
	  return equals(t1, t2);
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
      
      /* old
      if (t1.tag() == :assocArray){
	if (t2.tag() == :assocArray){
	  AssocArrayType a1 = (AssocArrayType)t1;
	  AssocArrayType a2 = (AssocArrayType)t2;
	  return isSuperType(a1.getKeyType(), a2.getKeyType()) &&
	    isSuperType(a2.getValueType(), a1.getValueType());
	} else {
	  return false;
	}
      } else {
	return original(t1, t2);
      }
      */
    }

    //--------------------------------------------------
    // Extend assignment and array access TypeChecker.
    extend void initTypeCheckerTable () {
      original();

      extendTypeChecker(:array,	new AssocArrayTypeChecker());
      extendTypeChecker(:"=",	new AssocArrayAssignmentOperatorTypeChecker());
      extendTypeChecker(:new,	new AssocArrayNewTypeChecker());
    }
  }
}

// AssociationArray(String,String) a = new AssociationArray(String,String);
//   will be converted to
// java.util.Hashtable a = new Java.util.Hashtable();
class AssocArrayTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();

    // Extended type.
    Type t = new AssocArrayType(typeNameCheckTree(args[0]).type(),
				typeNameCheckTree(args[1]).type());
    // Java representation.
    Tree ret = `(name (id java) (id util) (id Hashtable));
    return ret.modifyTypeAndArgs(t, ret.args());
  }
}




public class AssocArrayType extends Type {
  Type keyType;
  Type valueType;
  public AssocArrayType(Type keyType, Type valueType){
    super(:assocArray);
    this.keyType = keyType;
    this.valueType = valueType;
  }
  public Type getKeyType() { return keyType; }
  public Type getValueType() { return valueType; }
  public String toString(){
    return keyType+ "["+ valueType+ "]";
  }
  public Tree toTree(){
    return `(assocArray ,(keyType.toTree()) ,(valueType.toTree()));
  }
}


// a["foo"]  => (String)a.get("foo");
class AssocArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    if (newArgs[0].type().tag() == :assocArray){
      Tree a = newArgs[0];
      Tree val = newArgs[1];

      AssocArrayType varType = (AssocArrayType)a.type();
      
      // Change the type of "a" so that type checking of invokeExp succeeds.
      ClassTypeTable classTypeTable
	= (ClassTypeTable)Dynamic.get(:classTypeTable);
      Type hashtableType;
      try {
	hashtableType = classTypeTable.get(:"java.util.Hashtable");
      } catch (NotFound e){
	throw Epp.fatal("The class java.util.Hashtable not found.");
      }
      a = a.resetType();
      a = a.modifyTypeAndArgs(hashtableType, a.args());

      val = Type.coerce(varType.getKeyType(), val);
      return `(cast ,(varType.getValueType().toTree())
	       (invokeExp ,a (id get)
		(argumentList ,val)));
    } else {
      // Repeated type checking of args will be avoided.
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

// a[index] = rhs;  =>  a.put(index, rhs)
class AssocArrayAssignmentOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    
    if (tree.args()[0].tag() != :array) return orig.call(tree);
    Tree array = tree.args()[0];
    Tree a = typeCheckTree(array.args()[0]);
    Tree index = typeCheckTree(array.args()[1]);
    Tree rhs = typeCheckTree(tree.args()[1]);

    if (a.type().tag() != :assocArray) {
      // Repeated type checking of "a" will be avoided.
      Tree[] arrayArgs = { a, index };
      Tree[] newArgs = { array.modifyArgs(arrayArgs),
			 rhs };
      return orig.call(tree.modifyArgs(newArgs));
    }

    AssocArrayType varType = (AssocArrayType)a.type();
    index = Type.coerce(varType.getKeyType(), index);
    rhs = Type.coerce(varType.getValueType(), rhs);
    
    // Change the type of "a" so that type checking of invokeExp succeeds.
    ClassTypeTable classTypeTable
      = (ClassTypeTable)Dynamic.get(:classTypeTable);
    Type hashtableType;
    try {
       hashtableType = classTypeTable.get(:"java.util.Hashtable");
    } catch (NotFound e){
      throw Epp.fatal("The class java.util.Hashtable not found.");
    }
    a = a.resetType();
    a = a.modifyTypeAndArgs(hashtableType, a.args());

    return `(invokeExp ,a (id put) (argumentList ,index ,rhs));
  }
}

class AssocArrayNewTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree argumentList = typeCheckTree(args[1]);
    Type targetType = typeTree.type();
    Tree[] newArgs = { typeTree, argumentList };
    if (targetType.tag() == :assocArray){
      // Actually, I should check constructor arguments.
      return tree.modifyTypeAndArgs(typeTree.type(), newArgs);
    } else {
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}
