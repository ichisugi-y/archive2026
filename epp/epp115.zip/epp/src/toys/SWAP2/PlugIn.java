/*
 *
 * Copyright (C) 1997, 1998, 1999 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

 Another SWAP macro implementation using StringNode.

*/

#epp jp.go.etl.epp.EppLibLevel0

package SWAP2;

SystemMixin SWAP2 {
  class Epp {

    extend void initInvokeStyleMacroTable() {
      original();
      defineInvokeStyleMacro(:SWAP, new SWAPMacro());
    }
  }
}

class SWAPMacro extends InvokeStyleMacro {
  
  public Tree call(Tree tree, Tree[] args){
    Tree tmp = new Identifier(genTemp("_T"));
    return StringNode.gen("{ %t %t = (%t); "+
			  "  %t = (%t); "+
			  "  %t = (%t); "+
			  "}",
			  new Tree[]{
			    args[0], tmp, args[1], 
			    args[1], args[2],
			    args[2], tmp,
			  });
  }
}
