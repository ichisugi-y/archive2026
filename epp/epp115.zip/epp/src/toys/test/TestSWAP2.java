#epp SWAP2

class TestSWAP2 {
  public static void main(String argv[]){
    int a = 1, b = 2;
    System.out.println(a == 1 && b == 2);
    SWAP(int, a, b);
    System.out.println(a == 2 && b == 1);

    // The following code will cause a syntax error because of
    //an extra semi-colon after the expanded macro.
    //if (true) SWAP(int, a, b); else ;
  }
}
