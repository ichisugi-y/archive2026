/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote

package EppMacros;
import epp.*;
import SystemMixinRuntimes.*;


SystemMixin EppMacros {
  
  class Epp {
    extend Tree typeDeclarationTop () {
      if (lookahead() == :defineNonTerminal ) {
	matchAny();
	match(:"(");
	Tree id = identifier() ;
	match(:",");
	Tree exp = expression() ;
	match(:")");
	match(:";") ;
	return new Tree(:defineNonTerminal , id , exp );
      } else if (lookahead()  == :defineBinaryOperator ) { 
	matchAny();
	match(:"(");
	Tree mixin = identifier() ;
	match(:",");
	Tree op = expressionNoComma() ;
	match(:",");
	Tree precedence = identifier() ;
	match(:")");
	match(:";") ;
	return new Tree(:defineBinaryOperator , mixin , op , precedence );
      } else {
	return original() ;
      }
    }
    
    extend void initMacroTable () {
      original();
      defineMacro(:defineNonTerminal , new DefineNonTerminalMacro());
      defineMacro(:defineBinaryOperator , new DefineBinaryOperatorMacro());
    }
  }
}


class DefineNonTerminalMacro extends Macro {
  
  public Tree call(Tree tree){
    checkArgsLength(tree, 2);
    
    Tree[] args = tree.args();
    Tree x = args[0];		//NonTerminal name.
    String xStr = x.idName().toString();
    Tree mixinName
      = new Identifier(Symbol.intern(""+
				     Character.toUpperCase(xStr.charAt(0))+
				     xStr.substring(1)));
    Tree next = args[1];
    Tree x1 = new Identifier(Symbol.intern(xStr+ "1"));
    Tree xTop = new Identifier(Symbol.intern(xStr+ "Top"));
    Tree xRight = new Identifier(Symbol.intern(xStr+ "Right"));
    Tree xLeft = new Identifier(Symbol.intern(xStr+ "Left"));
    
    return
      `(systemMixin ,mixinName
	(class
	 (modifiers)
	 (id class)
	 (id Epp)
	 (extends)
	 (implements)
	 (classBody
	  (method
	   (modifiers (id define))
	   (name (id Tree))
	   ,x
	   (formalParameters)
	   (throws)
	   (block 
	    (expressionStatement
	     (invokeLong (name (id Dynamic)) (id bindInt)
	      (argumentList (symbol
			     (id lineNumberOfThisNode))
	       (invokeLong (name (id Dynamic))
		(id getInt)
		(argumentList
		 (symbol (id lineNumber))))
	       )))
	    (expressionStatement
	     (invokeLong (name (id Dynamic)) (id bindInt)
	      (argumentList (symbol
			     (id beginningPointOfThisNode))
	       (invokeLong (name (id Dynamic))
		(id getInt)
		(argumentList
		 (symbol (id beginningPoint))))
	       )))
	    (try (block (decl (modifiers) (name (id Tree))
			 (vardecls
			  (id tree)))
		  (expressionStatement
		   (= (id tree)
		    (invoke1 ,xTop (argumentList))))
		  (decl (modifiers) (name (id Tree))
		   (vardecls (id newTree)))
		  (while (id true)
		   (block
		    (expressionStatement
		     (= (id newTree)
		      (invoke1 ,xLeft
		       (argumentList (id tree)))))
		    (if
		     (== (id newTree) (id null))
		     (break) (emptyStatement))
		    (expressionStatement
		     (= (id tree) (id newTree)))))
		  (returnWithExp (id tree)))
	     (finally (block
		       (expressionStatement
			(invokeLong (name (id Dynamic))
			 (id unbindInt) (argumentList)))
		       (expressionStatement
			(invokeLong (name (id Dynamic))
			 (id unbindInt) (argumentList))))))))
	  (method
	   (modifiers (id define))
	   (name (id Tree))
	   ,xTop
	   (formalParameters)
	   (throws)
	   (block (returnWithExp
		   (invoke1 ,xRight
		    (argumentList (invoke1 ,x1 (argumentList)))))))
	  (method
	   (modifiers (id define))
	   (name (id Tree))
	   ,xRight
	   (formalParameters
	    (pdecl (modifiers) (name (id Tree)) (id tree)))
	   (throws)
	   (block (returnWithExp (id tree))))
	  (method
	   (modifiers (id define))
	   (name (id Tree))
	   ,xLeft
	   (formalParameters
	    (pdecl (modifiers) (name (id Tree)) (id tree)))
	   (throws)
	   (block (returnWithExp (id null))))
	  (method
	   (modifiers (id define))
	   (name (id Tree))
	   ,x1
	   (formalParameters)
	   (throws)
	   (block (returnWithExp
		   ,next))))));
  }
}


class DefineBinaryOperatorMacro extends Macro {
  
  public Tree call(Tree tree){
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree mixin = args[0];
    Tree opSym = args[1];
    String xStr = args[2].idName().toString();
    String opFormat = "(%) "+ opSym.args()[0].idName().toString() + " (%)";
    Tree x1 =  new Identifier(Symbol.intern(xStr+ "1"));
    Tree xLeft =  new Identifier(Symbol.intern(xStr+ "Left"));
    return 
      `(systemMixin
	,mixin
	(class
	 (modifiers)
	 (id class)
	 (id Epp)
	 (extends)
	 (implements)
	 (classBody
	  (method
	   (modifiers (id extend))
	   (name (id Tree))
	   ,xLeft
	   (formalParameters
	    (pdecl (modifiers) (name (id Tree)) (id tree)))
	   (throws)
	   (block (if (== (invoke1 (id lookahead) (argumentList))
		       ,opSym)
		   (block (returnWithExp
			   (new (name (id Tree))
			    (argumentList
			     (cast (name (id Symbol))
			      (invoke1 (id matchAny)
			       (argumentList)))
			     (id tree)
			     (invoke1 ,x1 (argumentList))))))
		   (block (returnWithExp
			   (original (argumentList (id tree))))))))
	  (method
	   (modifiers (id extend))
	   (name (id void))
	   (id initEmitterTable)
	   (formalParameters)
	   (throws)
	   (block (expressionStatement (original (argumentList)))
	    (expressionStatement
	     (invoke1 (id defineEmitter)
	      (argumentList ,opSym
	       (new (name (id SimpleEmitter))
		(argumentList
		 ,(new LiteralTree(:string, opFormat))))))))))));
  }
}



/*

// Sample of non-terminal:

SystemMixin Exp {
  class Epp {
    define Tree exp(){
      Dynamic.bindInt(:lineNumberOfThisNode, Dynamic.getInt(:lineNumber));
      Dynamic.bindInt(:beginningPointOfThisNode,
		      Dynamic.getInt(:beginningPoint));
      try {
	Tree tree;
	tree = expTop();
	Tree newTree;
	while (true){
	  newTree = expLeft(tree);
	  if (newTree == null) break;
	  tree = newTree;
	}
	return tree;
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }
    define Tree expTop(){
      return expRight(exp1());
    }
    define Tree expRight (Tree tree) { return tree; }
    define Tree expLeft (Tree tree) { return null; }
    define Tree exp1 () { return term(); }
  }
}


// Old version. (Before 1.1.0beta5)
// Sample of non-terminal:
SystemMixin Exp {
  class Epp {
    define Tree exp(){
      Object lineNumber = Dynamic.get(:lineNumber);
      //old: parserTraceInfo(:exp, lineNumber);
      Dynamic.bind(:lineNumberOfThisNode, lineNumber);
      try {
	Tree tree; //old: = allNonTerminalsTop();
	//old: if (tree != null) return tree;
	tree = expTop();
	Tree newTree;
	while (true){
	  newTree = expLeft(tree);
	  if (newTree == null) break;
	  tree = newTree;
	}
	return tree;
      } finally {
	Dynamic.unbind();
      }
    }
    define Tree expTop(){
      return expRight(exp1());
    }
    define Tree expRight (Tree tree) { return tree; }
    define Tree expLeft (Tree tree) { return null; }
    define Tree exp1 () { return term(); }
  }
}


// Sample of binary operator:
SystemMixin Plus {
  class Epp {
    extend Tree expLeft (Tree tree) {
      if (lookahead()  == :"+") {
	return new Tree(((Symbol)matchAny()), tree, exp1());
      } else {
	return original(tree);
      }
    }
    
    extend void initEmitterTable () {
      original();
      defineEmitter(:"+", new SimpleEmitter("(%) + (%)"));
    }
  }
}

*/

