/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*
 This plug-in is only for plug-in programmers.
 The effect of 

	#epp jp.go.etl.epp.EppLibLevel0

is almost same as:

	#epp jp.go.etl.epp.Symbol
	#epp jp.go.etl.epp.AutoSplitFiles
	#epp jp.go.etl.epp.SystemMixin
	#epp jp.go.etl.epp.BackQuote
	#epp jp.go.etl.epp.EppMacros
	import jp.go.etl.epp.epp.*;
	import jp.go.etl.epp.SystemMixinRuntimes.*;

*/

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote

package EppLibLevel0;
import epp.*;
import SystemMixinRuntimes.*;


// NOTE: This declaration is ignored by lisp-epp.
// This file should be translated by Java-epp.
BeforeLoadingPlugIn{
  requirePlugIn("jp.go.etl.epp.Symbol.PlugIn");
  requirePlugIn("jp.go.etl.epp.AutoSplitFiles.PlugIn");
  requirePlugIn("jp.go.etl.epp.SystemMixin.PlugIn");
  requirePlugIn("jp.go.etl.epp.BackQuote.PlugIn");
  requirePlugIn("jp.go.etl.epp.EppMacros.PlugIn");
}

SystemMixin EppLibLevel0 {
  class Epp {
    extend void initExtraImportDeclarations(){
      original();

      addExtraImportDeclaration(`(importOnDemand
				  (name
				   (id jp)
				   (id go)
				   (id etl)
				   (id epp)
				   (id epp))));
      addExtraImportDeclaration(`(importOnDemand
				  (name
				   (id jp)
				   (id go)
				   (id etl)
				   (id epp)
				   (id SystemMixinRuntimes))));
    }
  }
}
