/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

BUGS
----
 Currently, the following expression is not supported within back quote.

	(,tag ...)
	(id ,name)
	(literalTree ,literalTag ,literalContents)

 Use the following expression instead of the above ones.

	,(new Tree(tag, ...))
	,(new Identifier(name))
	,(new LiteralTree(literalTag, literalContents))


Syntax
------

Primary
	<original grammar rules>
	BackQuote

BackQuote
	` BackQuoteElem

BackQuoteElem
	( id BackQuoteSymbol )
	( literalTree BackQuoteSymbol StringLiteral )
	( BackQuoteSymbol BackQuoteElems )
	, Identifier
	, ( Expression )
	, @ Identifier
	, @ ( Expression )

BackQuoteSymbol
	Identifier
	StringLiteral
	+
	-
	...
	# Actually, all tokens are regarded as BackQuoteSymbol.

BackQuoteElems
	BackQuoteElem BackQuoteElems
	BackQuoteElem

*/


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros
#epp BackQuote

package BackQuote;
import SystemMixinRuntimes.*;
import epp.*;


defineNonTerminal(backquoteElem, backquoteElemOtherwise());


SystemMixin Backquote {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :"`") {
	matchAny();
	return new Tree(:backquote, backquoteElem());
      } else {
	return original();
      }
    }
    
    extend Tree backquoteElemTop() {
      if (lookahead() == :"(") {
	TreeVec elems = new TreeVec();
	matchAny();
	if (lookahead() == :")") {
	  throw error("backquote:  \"`()\" is syntax error.");
	}
	Tree tag = backquoteSymbol();
	if (tag.idName() == :id) {
	  Tree sym = backquoteSymbol();
	  match(:")");
	  return new Tree(:backquoteId, sym);
	} else if (tag.idName() == :literalTree) {
	  Tree literalTag = backquoteSymbol();
	  Tree contents = expression();
	  if (contents.tag() != :literalTree){
	    throw error("backquoteElem : StringLiteral is required as the second argument of literalTree.");
	  }
	  match(:")");
	  return new Tree(:backquoteLiteral, literalTag, contents);
	} else { 
	  elems.add(tag);
	  while(lookahead() != :")") {
	    elems.add(backquoteElem());
	  }
	  matchAny();
	  return new Tree(:backquoteList, elems);
	}
      } else if (lookahead() == :",") {
	matchAny();
	Symbol tag;
	Tree exp;
	if (lookahead() == :"@") {
	  matchAny();
	  tag = :backquoteCommaAt;
	} else {
	  tag = :backquoteComma;
	}
	if (lookahead() == :"(") {
	  matchAny();
	  exp = expression();
	  match(:")");
	} else {
	  exp = identifier();
	}
	return new Tree(tag, exp);
      } else {
	return original();
      }
    }
    
    define implement Identifier backquoteSymbol() {
      Token token = matchAny();
      return new Identifier(token.isSymbol() ?
			    (Symbol)token :
			    Symbol.intern(token.literalContents()));
    }

    define implement Tree backquoteElemOtherwise(){
      throw error("backquoteElem is required here.");
    }
    
    extend void initMacroTable() {
      original();
      defineMacro(:backquote, new BackquoteMacro());
    }
  }
}



class BackquoteMacro extends Macro {
  
  public Tree call(Tree tree){
    checkArgsLength(tree, 1);
    return expandBackquoteElem(tree.args()[0]);
  }
  
  Tree expandBackquoteElem(Tree tree){
    Symbol tag = tree.tag();
    if (tag == :backquoteId){
      return expandBackquoteId(tree);
    } else if (tag == :backquoteLiteral){
      return expandBackquoteLiteral(tree);
    } else if (tag == :backquoteList){
      return expandBackquoteList(tree);
    } else if (tag == :backquoteCommaAt){
      throw error("backquote: \",@\" appears illegal context.");
    } else if (tag == :backquoteComma) {
      return tree.args()[0];
    } else {
      throw error("FATAL: Illegal node within BackQuote macro : "+ tree);
    }
  }
  
  Tree expandBackquoteId(Tree tree) {
    checkArgsLength(tree, 1);
    // new Identifier(:name) or new Identifier(:"name") 
    return `(new (name (id Identifier))
	     (argumentList (symbol ,(tree.args()[0]))));
  }
  
  Tree expandBackquoteLiteral(Tree tree){
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree literalTag = `(symbol ,(args[0]));
    Tree contents = args[1];
    return `(new (name (id LiteralTree))
	     (argumentList (new (name (id LiteralToken))
			    (argumentList ,literalTag ,contents))));
  }
  
  Tree expandBackquoteList(Tree tree){
    Tree[] args = tree.args();
    Tree tag = `(symbol ,(args[0]));
    
    boolean thereAreCommaAt = false;
    for (int i = 1; i < args.length; i++){
      if (args[i].tag() == :backquoteCommaAt) {
	thereAreCommaAt = true;
	break;
      }
    }
    
    if (args.length == 0) {
      throw error("Number of Args of backquoteList is 0.");
      
    } else if (args.length == 1) {
      return `(new (name (id Tree)) (argumentList ,tag));
      
    } else if (args.length == 2 && thereAreCommaAt) {
      return `(new (name (id Tree))
	       (argumentList ,tag ,(args[1].args()[0])));
      
    } else if (thereAreCommaAt) {
      return `(new (name (id Tree))
	       (argumentList ,tag 
		(invokeExp ,(backquoteAppendCode(tree))
		 (id toArray) (argumentList))));
      
    } else {
      Tree[] elems = new Tree[args.length];
      elems[0] = tag;
      for (int i = 1; i < args.length; i++){
	elems[i] = expandBackquoteElem(args[i]);
      }
      return `(new (name (id Tree)) (argumentList ,@elems));
    }
  }
  
  Tree backquoteAppendCode(Tree tree) {
    Tree[] args = tree.args();
    
    Tree code = `(new (name (id TreeVec)) (argumentList));
    // Because the first arg is tag, I should start loop from index 1.
    for (int i = 1; i < args.length; i++) {
      Symbol tag = args[i].tag();
      if (tag == :backquoteList || tag == :backquoteComma
	  || tag == :backquoteId || tag == :backquoteLiteral) {
	code = `(invokeExp ,code
		 (id add)
		 (argumentList ,(expandBackquoteElem(args[i]))));
      } else if (tag == :backquoteCommaAt) {
	code = `(invokeExp
		 ,code
		 (id addA) (argumentList
			    ,(args[i].args()[0])));
      } else {
	throw error("FATAL: Illegal node within BackQuote macro : "+ args[i]);
      }
    }
    return code;
  }
}
