/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */



#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles

package AutoSplitFiles;
import epp.*;
import SystemMixinRuntimes.*;
import java.io.*;

SystemMixin AutoSplitFiles {
  class Epp {
    
    redefine void codeEmittingPass() {
      String inputFileName = (String)Dynamic.get(:inputFileName);
      String outputFileName = (String)Dynamic.get(:outputFileName);
      Tree[] compilerUnitArgs	= self!tree.args();
      Tree[] typeDecls		= compilerUnitArgs[2].args();

      Dynamic.bind(:package, compilerUnitArgs[0]);
      Dynamic.bind(:import, compilerUnitArgs[1]);
      try{
	TreeVec origFileContents = new TreeVec();
	
	String outDirName = new File(outputFileName).getParent();
	Symbol mainClassName =
	  Symbol.intern(Epp.getClassNameFromFileName(inputFileName));

	for (int i = 0; i < typeDecls.length; i++){
	  Symbol tag = typeDecls[i].tag();
	  if (tag == :emptyTypeDeclaration){
	    ;			// Do nothing;

	  } else if (tag == :class || tag == :interface){
	    Symbol className = typeDecls[i].args()[2].idName();

	    if (className == mainClassName ||
		! isPublicClass(typeDecls[i])){
	      origFileContents.add(typeDecls[i]);
	    } else {
	      emit1(outDirName+ File.separator+ className+ ".java",
		    typeDecls[i]);
	    }
	  } else {
	    throw error("Unknown type declaration node:"+ typeDecls[i]);
	  }
	}

	// Output original file.
	emit1(outputFileName,
	      new Tree(:typeDeclarations, origFileContents));
      } finally {
	Dynamic.unbind();
	Dynamic.unbind();
      }
    }
    
    extend void emitAdditionalHeader(Writer out){
      original(out);
      Emitter.emitTree(out, (Tree)Dynamic.get(:package));
      Emitter.emitTree(out, (Tree)Dynamic.get(:import));
    }

    define implement boolean isPublicClass(Tree classTree){
      Tree[] modifiers = classTree.args()[0].args();
      for (int i = 0; i < modifiers.length; i++){
	if (modifiers[i].idName() == :public){
	  return true;
	}
      }
      return false;
    }
  }
}

