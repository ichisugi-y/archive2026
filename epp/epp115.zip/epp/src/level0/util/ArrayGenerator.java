/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.util.*;

public abstract class ArrayGenerator {
  public abstract Object[] generate(int size);
}
