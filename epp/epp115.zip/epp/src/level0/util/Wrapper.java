/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.util.*;

public class Wrapper {
  public static int minInt = 0;
  public static int maxInt = 0;
  static Integer[] cache = null;
  static {
    setCacheRange(-10, 1024);
  }
  
  public static void setCacheRange(int min, int max){
    minInt = min; maxInt = max;
    cache = new Integer[max - min];
    for (int i = 0; i < cache.length; i++){
      cache[i] = new Integer(min + i);
    }
  }

  public static Integer wrap(int x){
    if (minInt <= x && x < maxInt){
      return cache[x - minInt];
    } else {
      return new Integer(x);
    }
  }

  public static Double wrap(double x){
    return new Double(x);
  }

  // Test.
  public static void main(String[] argv){
    System.out.println(wrap(minInt - 1));
    System.out.println(wrap(minInt));
    System.out.println(wrap(minInt + 1));
    System.out.println(wrap(maxInt - 1));
    System.out.println(wrap(maxInt));
    System.out.println(wrap(maxInt + 1));
    System.out.println(wrap(minInt - 1) == wrap(minInt - 1));	// false
    System.out.println(wrap(minInt) == wrap(minInt));		// true
    System.out.println(wrap(minInt + 1) == wrap(minInt + 1));	// true
    System.out.println(wrap(maxInt - 1) == wrap(maxInt - 1));	// true
    System.out.println(wrap(maxInt) == wrap(maxInt));		// false
    System.out.println(wrap(maxInt + 1) == wrap(maxInt + 1));	// false
  }
}
