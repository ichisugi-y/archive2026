/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.util.*;
import java.io.*;

public class Iter {
  Enumeration rep;

  public Iter(Enumeration e) { rep = e; }

  public Object next() { return rep.nextElement(); }
  public int nextInt() { return ((Integer)rep.nextElement()).intValue(); }

  public boolean hasNext() { return rep.hasMoreElements(); }

  public boolean equals(Object x) { return rep.equals(x); }

  public String toString() { return "Iter<T>("+ rep.toString()+ ")"; }

  public Iter print() { return print(""); }
  public Iter print(String prefix) {
    PrintFunction.printWithPrefix(prefix, this);
    return this;
  }
  // This method is called from PrintFunction.
  public void print(PrintWriter out, String indent) {
    out.print(indent);
    out.print(this.toString());
  }
}

