/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.util.*;
import java.io.*;

public final class Vec {
  static final int initialCapacity = 10;
  int size = 0;
  Object[] rep;
  ArrayGenerator agen;

  public Vec(ArrayGenerator agen){
    rep = agen.generate(initialCapacity);
    this.agen = agen;
  }

  public Vec(Object[] a, ArrayGenerator agen){
    this(agen);
    for (int i = 0; i < a.length; i++){
      push(a[i]);
    }
  }

  public Vec(int[] a, ArrayGenerator agen){
    this(agen);
    for (int i = 0; i < a.length; i++){
      push(Wrapper.wrap(a[i]));
    }
  }

  public Vec(Vector a, ArrayGenerator agen){
    this(agen);
    for (Enumeration e = a.elements(); e.hasMoreElements(); ){
      push(e.nextElement());
    }
  }

  public final void push(Object x){
    if (rep.length == size){
      Object[] newRep = agen.generate(size * 2);
      for (int i = 0; i < size; i++){
	newRep[i] = rep[i];
      }
      rep = newRep;
    }
    rep[size++] = x;
  }
  public final void push(int x){
    push(Wrapper.wrap(x));
  }

  public final Object pop() {
    return rep[--size];
  }
  public final int popInt() {
    return ((Integer)pop()).intValue();
  }

  public final void put(int index, Object x){
    if (index >= size) throw new ArrayIndexOutOfBoundsException();
    rep[index] = x;
  }
  public final void put(int index, int x){
    put(index, Wrapper.wrap(x));
  }

  public final Object get(int index) {
    if (index >= size) throw new ArrayIndexOutOfBoundsException();
    return rep[index];
  }
  public final int getInt(int index) {
    return ((Integer)get(index)).intValue();
  }

  public final Object top(){
    return rep[size - 1];
  }
  public final int topInt() {
    return ((Integer)top()).intValue();
  }

  public final Object[] toArray() {
    Object[] ret = agen.generate(size);
    for (int i = 0; i < size; i++){
      ret[i] = rep[i];
    }
    return ret;
  }
  public final int[] toArrayInt() {
    int[] ret = new int[size];
    for (int i = 0; i < size; i++){
      ret[i] = ((Integer)rep[i]).intValue();
    }
    return ret;
  }

  public final Iter iter() { return new VecIter(rep, size); }

  public final Object[] getRepresentationArray() { return rep; }

  public final int size() { return size; }

  public boolean equals(Object x) {
    if (! (x instanceof Vec)) return false;
    Vec v = (Vec)x;
    if (v.size != size) return false;
    Object[] vrep = v.rep;
    for (int i = 0; i < size; i++){
      if (! vrep[i].equals(rep[i])) return false;
    }
    return true;
  }

  public Object clone() {
    Vec v = new Vec(agen);
    for (int i = 0; i < size; i++){
      v.push(rep[i]);
    }
    return v;
  }

  public String toString() { return "Vec<T>("+ rep.toString()+ ")"; }

  public Vec print() { return print(""); }
  public Vec print(String prefix) {
    PrintFunction.printWithPrefix(prefix, this);
    return this;
  }
  // This method is called from PrintFunction.
  public void print(PrintWriter out, String indent) {
    out.print(indent);
    out.println("{");
    String newIndent = indent+ "  ";
    for (int i = 0; i < size; i++){
      PrintFunction.printFunction.call(out, newIndent, rep[i]);
      out.println(",");
    }
    out.print(indent);
    out.print("}");
  }

  // Test.
  public static void main(String[] argv){
    Vec t = new Vec(new ArrayGenerator(){
      public Object[] generate(int size) { return new String[size]; }
    });
    t.push("aaa");
    t.push("bbb");
    t.push("\n");
    t.push("\"\\n\"");
    t.print("*").print("!");

    Vec tt = new Vec(new ArrayGenerator(){
      public Object[] generate(int size) { return new Vec[size]; }
    });
    tt.push(t);
    tt.push(t);
    tt.print("**").print("!!");

    Vec ttt = new Vec(new ArrayGenerator(){
      public Object[] generate(int size) { return new Symbol[size]; }
    });
    ttt.push(Symbol.intern("aaa"));
    ttt.push(Symbol.intern("\n"));
    ttt.print("***").print("!!!");
  }
}

class VecIter extends Iter {
  Object[] rep;
  int size;
  int index = 0;

  public VecIter(Object[] rep, int size) {
    super(null);
    this.rep = rep; this.size = size;
  }

  public Object next() {
    if (index >= size) throw new NoSuchElementException();
    return rep[index++];
  }
  public int nextInt() {
    if (index >= size) throw new NoSuchElementException();
    return ((Integer)(rep[index++])).intValue();
  }

  public boolean hasNext() { return index < size; }

  public boolean equals(Object x) { return x == this; }

  public String toString() { return "Iter<T>("+ rep.toString()+ ")"; }

  // This method is called from PrintFunction.
  public void print(PrintWriter out, String indent) {
    out.print(indent);
    out.print(this.toString());
  }
}
