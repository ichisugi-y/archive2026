/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.io.*;

public class PrintFunction {
  // The user can extend this function with decorator pattern.
  public static PrintFunction printFunction = new PrintFunction();

  public void call(PrintWriter out, String indent, Object x){
    if (x instanceof Vec){
      ((Vec)x).print(out, indent);

    } else if (x instanceof Table){
      ((Table)x).print(out, indent);

    } else if (x instanceof Iter){
      ((Iter)x).print(out, indent);

    } else if (x instanceof String){
      out.print(indent);
      out.print(Tree.quoteString((String)x));

    } else if (x instanceof Symbol){
      out.print(indent);
      out.print(":"+ Tree.quoteString(((Symbol)x).toString()));

    } else {
      out.print(indent);
      out.print(x.toString());
    }
  }

  // Utility for printing.
  public static void printWithPrefix(String prefix, Object x){
    PrintWriter out
      = new PrintWriter(new BufferedWriter(new FileWriter(FileDescriptor.err)),
			true);
    out.println(prefix);
    PrintFunction.printFunction.call(out, "", x);
    out.println();
  }
}
