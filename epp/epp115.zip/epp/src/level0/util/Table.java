/*
 *
 * Copyright (C) 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package util;

import epp.*;
import java.util.*;
import java.io.*;

public class Table {
  Hashtable rep;

  public Table(){ rep = new Hashtable(); }

  public void put(Object key, Object x){ rep.put(key, x); }
  public void put(int key, Object x){ put(Wrapper.wrap(key), x); }
  public void put(Object key, int x){ put(key, Wrapper.wrap(x)); }
  public void put(int key, int x){ put(Wrapper.wrap(key), Wrapper.wrap(x)); }

  public Object get(Object key) {
    return rep.get(key);
  }
  public Object get(int key) {
     return get(Wrapper.wrap(key));
  }

  public void remove(Object key) {
    Object val = rep.remove(key);
    if (val == null){
      throw new Error("Table<T>#remove: Key "+ key+ " not found.");
    }
  }
  public void remove(int key) {
    rep.remove(Wrapper.wrap(key));
  }

  // obsolete
  public Object getOrThrowNotFound(Object key) throws NotFound {
    Object val = rep.get(key);
    if (val == null){
      throw NotFound.instance;
    } else {
      return val;
    }
  }
  public int getIntOrThrowNotFound(Object key) throws NotFound {
    return ((Integer)get(key)).intValue();
  }
  public Object getOrThrowNotFound(int key) throws NotFound {
     return get(Wrapper.wrap(key));
  }
  public int getIntOrThrowNotFound(int key) throws NotFound {
    return ((Integer)get(key)).intValue();
  }

  public void removeOrThrowNotFound(Object key) throws NotFound {
    Object val = rep.remove(key);
    if (val == null){
      throw NotFound.instance;
    }
  }
  public void removeOrThrowNotFound(int key) throws NotFound {
    Object val = rep.remove(Wrapper.wrap(key));
    if (val == null){
      throw NotFound.instance;
    }
  }

  public boolean containsKey(Object key){
    return rep.containsKey(key);
  }
  public boolean containsKey(int key){
    return rep.containsKey(Wrapper.wrap(key));
  }

  public Iter keyIter() { return new Iter(rep.keys()); }

  public Iter valueIter() { return new Iter(rep.elements()); }

  public int size() { return rep.size(); }

  public void clear() { rep.clear(); }

  public boolean equals(Object x) { return rep.equals(x); }

  public Object clone() { return rep.clone(); }

  public String toString() { return "Table<T,T>("+ rep.toString()+ ")"; }

  public Table print() { return print(""); }
  public Table print(String prefix) {
    PrintFunction.printWithPrefix(prefix, this);
    return this;
  }
  // This method is called from PrintFunction.
  public void print(PrintWriter out, String indent) {
    String newIndent = indent+ "  ";
    Iter keyIter = keyIter();
    Iter valueIter = valueIter();
    if (keyIter.hasNext()) {
      out.println(indent+ "{");
      out.println(indent+ " {");
      Object key = keyIter.next();
      Object value = valueIter.next();
      PrintFunction.printFunction.call(out, newIndent, key);
      out.println(",");
      PrintFunction.printFunction.call(out, newIndent, value);
      out.println("");
      while (keyIter.hasNext()){
	out.println(indent+ " }, {");
	key = keyIter.next();
	value = valueIter.next();
	PrintFunction.printFunction.call(out, newIndent, key);
	out.println(",");
	PrintFunction.printFunction.call(out, newIndent, value);
	out.println("");
      }
      out.println(indent+ " }");
      out.print(indent+ "}");
    } else {
      out.print(indent);
      out.print("{/*empty Table*/}");
    }
  }

  // Test.
  public static void main(String[] argv){
    Table t0 = new Table();

    Table t1 = new Table();
    t1.put("111", "aaa");

    Table t2 = new Table();
    t2.put("222", "bbb");
    t2.put("333", "ccc");
    t2.print("*").print("!");

    Table tt = new Table();
    tt.put(t0, t0);
    tt.put(t1, t1);
    tt.put(t2, t2);
    tt.print("**").print("!!");
  }
}
