/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

$B"!;EMM(B
$B!&DI2C$9$k(B prefix $B$r!"%W%m%Q%F%#$GM?$($k!#(B
$BNc!'(B
	epp -plug-in RenamePackage -Depp.packagePrefix=jp.go.etl.epp -r .

$B!&(B package $B@k8@$H(B import $B@k8@$N$_$,JQ49$NBP>]$H$J$k!#(B
$B%W%m%0%i%`Cf$K8=$l$k40A48BDjL>$OJQ49$7$J$$!#(B
$B!J$=$l$r$d$k$?$a$K$O!"7?%A%'%C%/$,I,MW$K$J$C$F$/$k$N$GLLE]!#!K(B

$B@53N$K$$$&$H!"(B package $BL>$N@hF,$r8+$F!"(B
$BF1$8L>A0$N%G%#%l%/%H%j$,%+%l%s%H%G%#%l%/%H%j$N2<$K$"$l$P!"(B
$B$=$l$K$O(B prefix $B$r$D$1$k!#(B

$B!&%?%$%`%9%?%s%W$NHf3S$O!"$d$i$J$$!#(B

---
 This plug-in changes the package of Java programs without modifying
their source code.
(This plug-in is used for bootstrapping of EPP,
but it can be used for general purpose.)

 Example:
	epp -plug-in RenamePackage -Depp.packagePrefix=jp.go.etl.epp -r .

If there are the following declarations in a file:

	package epp;
	import SystemMixinRuntimes.*;
	import java.util.*;

the effect of translation is as follows:

	package jp.go.etl.epp.epp;
	import jp.go.etl.epp.SystemMixinRuntimes.*;
	import java.util.*;

 This plug-in translates import declarations
if and only if directories with the same names exist 
in the current directory.
(For example, if there are no directory named "SystemMixinRuntimes"
in the current directory, the first import declaration will not be translated.)


BUGS:

 Only package and import declarations will be translated.
(Fully qualified name appeard in the program body will not translated.)

 If this plug-in is used, the time stamp checking mechanism of EPP
will not work.
(All source files will be re-translated.)

*/


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles


package RenamePackage;
import epp.*;
import SystemMixinRuntimes.*;
import java.io.*;


SystemMixin RenamePackage {
  class Epp {

    String packagePrefix;	// Ex. "jp.go.etl.epp"

    extend void initializationPass(){
      original();

      self!packagePrefix = System.getProperty("epp.packagePrefix");
      if (self!packagePrefix == null || self!packagePrefix.length() == 0){
	throw error("RenamePackage: "+
		    "Usage: epp -plug-in jp.go.etl.epp.RenamePackage -Depp.packagePrefix=PREFIX -r .");
      }

      String outputFileName = (String)Dynamic.get(:outputFileName);
      String inputFileName = (String)Dynamic.get(:inputFileName);
      
      if ((! outputFileName.startsWith("eppout"))
	  || (! outputFileName.endsWith(inputFileName))){
	Opts.out.println();
	Opts.out.println("RenamePackage: inputFileName and outputFileName format error.");
	Opts.out.println("inputFileName  = "+ inputFileName);
	Opts.out.println("outputFileName = "+ outputFileName);
	throw Epp.fatal("RenamePackage");
      }
      
      outputFileName = "eppout"+ File.separatorChar+
	self!packagePrefix.replace('.', File.separatorChar)+
	  File.separatorChar+ inputFileName;
      
      Dynamic.set(:outputFileName, outputFileName);
    }



    extend void beforeMacroExpansionPass() {
      original();

      // Make the "prefix", that is an array of Identifiers.
      String pPrefix = self!packagePrefix+ ".";
      TreeVec tvec = new TreeVec();
      int begin = 0;
      while (true){
	int end = pPrefix.indexOf('.', begin);
	if (end == -1) break;
	String elem = pPrefix.substring(begin, end);
	tvec.add(new Identifier(Symbol.intern(elem)));
	begin = end + 1;
      }
      Tree[] prefix = tvec.toArray();

      // Make the "dirs", that is an array of directory names
      //contained in the current directory.
      Symbol[] dirs;
      File cur = new File(".");
      String[] list = cur.list();
      dirs = new Symbol[list.length];
      for (int i = 0; i < list.length; i++){
	if (new File(list[i]).isDirectory()){
	  dirs[i] = Symbol.intern(list[i]);
	} else {
	  dirs[i] = null;	// dummy
	}
      }

      // Translate the package declaration and import declarations.
      Tree compilationUnit = self!tree;
      Tree[] compilationUnitArgs = compilationUnit.args();
      Tree packageDeclaration = compilationUnitArgs[0];
      Tree importDeclarations = compilationUnitArgs[1];
      Tree typeDeclarations = compilationUnitArgs[2];

      Tree[] packageDeclarationArgs = packageDeclaration.args();
      Tree[] newPackageDeclarationArgs = new Tree[1];
      if (packageDeclarationArgs.length == 0){

	newPackageDeclarationArgs[0] = new Tree(:name, prefix);

      } else if (packageDeclarationArgs.length == 1){
	newPackageDeclarationArgs[0] =
	  addPackagePrefixIfNecessarry(packageDeclarationArgs[0],
				       prefix,
				       dirs);
      } else {
	throw Epp.fatal("");
      }
      
      Tree[] importDeclarationsArgs = importDeclarations.args();
      Tree[] newImportDeclarationsArgs =
	new Tree[importDeclarationsArgs.length];
      for (int i = 0; i < importDeclarationsArgs.length; i++){
	Tree name = importDeclarationsArgs[i].args()[0];
	Tree[] newImportArgs = {addPackagePrefixIfNecessarry(name,
							     prefix,
							     dirs)
				};
	newImportDeclarationsArgs[i] =
	  importDeclarationsArgs[i].modifyArgs(newImportArgs);
      }

      Tree[] newCompilationUnitArgs = {
	packageDeclaration.modifyArgs(newPackageDeclarationArgs),
	importDeclarations.modifyArgs(newImportDeclarationsArgs),
	typeDeclarations
	};

      self!tree = compilationUnit.modifyArgs(newCompilationUnitArgs);
    }


    define Tree addPackagePrefixIfNecessarry(Tree name,
					     Tree[] prefix,
					     Symbol[] dirs){
      Tree[] nameArgs = name.args();
      if (nameArgs.length == 0) throw Epp.fatal("");
      for (int i = 0; i < dirs.length; i++){
	if (dirs[i] != null && nameArgs[0].idName() == dirs[i]){
	  TreeVec tvec = new TreeVec();
	  tvec.addA(prefix);
	  tvec.addA(nameArgs);
	  return name.modifyArgs(tvec.toArray());
	}
      }
      return name;
    }
  }
}
