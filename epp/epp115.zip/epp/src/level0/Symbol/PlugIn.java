/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote
#epp EppMacros

package Symbol;
import epp.*;
import SystemMixinRuntimes.*;

// NOTE: This macro implicitly defines a SystemMixin named "Symbol".
defineNonTerminal(symbol, symbolOtherwise());


// I should not use the SystemMixin name "Symbol" here because
// it is already defined by the above defineNonTerminal macro.
SystemMixin SymbolRep {
  class Epp {

    extend Tree primaryTop() {
      if (lookahead() == :":") {
	return symbol();
      } else {
	return original();
      }
    }
    
    extend Tree symbolTop() {
      if (lookahead() == :":") {
	matchAny();
	Token next = matchAny();
	if (next.isSymbol()){
	  // :foo  or  :+  or ...
	  return new Tree(:symbol, new Identifier((Symbol)next));
	} else if (next.isLiteralToken()){
	  // :"foo"  or  :123  or ...
	  String contents = next.literalContents();
	  return new Tree(:symbol, new Identifier(Symbol.intern(contents)));
	} else {
	  // Never executed.
	  throw error("Symbol plug-in: "+ next+ "appeared after \":\" .");
	}
      } else {
	return original();
      }
    }

    define implement Tree symbolOtherwise(){
      throw error("symbol is required here.");
    }

    extend void initMacroTable() {
      original();
      defineMacro(:symbol, new SymbolMacro());
    }

    extend void initEmitterTable() {
      original();
      // Actually, I should quote the contents of the string.
      defineEmitter(:symbol, new SimpleEmitter(":\"%\""));
    }
  }
}


class SymbolMacro extends Macro {
  public Tree call(Tree tree){
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    String str = args[0].idName().toString();
    Tree var = new Identifier(genTemp("_Sym"));

    addTree(:beginningOfClassBody,
	    `(decl (modifiers (id private) (id static)
		     (id final))
	       (name (id Symbol))
	       (vardecls
		(varInit ,var
		 (invokeLong (name (id Symbol)) (id intern)
		  (argumentList ,(new LiteralTree(:string, str))))))));
    return var;
  }
}



//#epp "Symbol"
//
//class EppTest {
//
//  static public void main(String args[]){
//    String s1 = :foo;
//    String s2 = :bar;
//    System.out.println(s1);		// foo
//    System.out.println(s1 == :"foo");	// true
//    System.out.println(s1 == s2);	// false
//    System.out.println(:++);		// ++
//  }
//}
