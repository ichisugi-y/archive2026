/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros

package epp;
import SystemMixinRuntimes.*;
import java.io.Writer;
import java.io.IOException;



defineNonTerminal(typeDeclaration, typeDeclarationOtherwise());
     
     
SystemMixin EmptyTypeDeclaration {
  
  class Epp {
    extend Tree typeDeclarationTop() {
      if (lookahead() == :";") {
	matchAny();
	return new Tree(:emptyTypeDeclaration);
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:emptyTypeDeclaration, new SimpleEmitter(";"));
    }
  }
}



SystemMixin TypeDeclarationOtherwise {
  
  class Epp {
    define implement Tree typeDeclarationOtherwise(){
      throw error("typeDeclaration is expected here.");
    }
  }
}



// Note:
// I can use "extends", "implements" and "throws" as a method name of Ld-2,
// because these are not treated as keywords by Ld-2.

defineNonTerminal(extends, extendsOtherwise());

SystemMixin ExtendsOtherwise {
  
  class Epp {
    define Tree extendsOtherwise() {
      TreeVec tvec = new TreeVec();
      if (lookahead() == :extends) {
	matchAny();
	while(true) {
	  tvec.add(name());
	  if (lookahead() == :",") {
	    matchAny();
	  } else {
	    break;
	  }
	}
      }
      return new Tree(:extends, tvec.toArray());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:extends, new ExtendsEmitter());
    }
  }
}

class ExtendsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitString(out, "extends ");
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++) {
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
      out.write(' ');
    }
  }
}



defineNonTerminal(implements, implementsOtherwise());

SystemMixin ImplementsOtherwise {
  
  class Epp {
    define Tree implementsOtherwise() {
      {
	TreeVec tvec = new TreeVec();
	if (lookahead() == :implements) {
	  matchAny();
	  while(true) {
	    tvec.add(name());
	    if (lookahead() == :",") {
	      matchAny();
	    } else {
	      break;
	    }
	  }
	}
	return new Tree(:implements, tvec.toArray());
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:implements, new ImplementsEmitter());
    }
  }
}

class ImplementsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitString(out, "implements ");
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++) {
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
      out.write(' ');
    }
  }
}



defineNonTerminal(throws, throwsOtherwise());

SystemMixin ThrowsOtherwise {
  
  class Epp {
    define Tree throwsOtherwise() {
      TreeVec tvec = new TreeVec();
      if (lookahead() == :throws) {
	matchAny();
	while(true) {
	  tvec.add(name());
	  if (lookahead() == :",") {
	    matchAny();
	  } else {
	    break;
	  }
	}
      }
      return new Tree(:throws, tvec.toArray());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:throws, new ThrowsEmitter());
    }
  }
}

class ThrowsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitString(out, "throws ");
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++) {
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
      out.write(' ');
    }
  }
}



defineNonTerminal(formalParameter, formalParameterOtherwise());

SystemMixin FormalParameterList {
  
  class Epp {
    define Tree formalParameterList() {
      {
	TreeVec tvec = new TreeVec();
	if (lookahead() != :")") {
	  while(true) {
	    tvec.add(formalParameter());
	    if (lookahead() == :",") {
	      matchAny();
	    } else {
	      break;
	    }
	  }
	}
	return new Tree(:formalParameters, tvec.toArray());
      }
    }
    
    define Tree formalParameterOtherwise() {
      return new Tree(:pdecl, modifiers(), type(), variableDeclaratorId());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:pdecl, new SimpleEmitter("%% %"));
      defineEmitter(:formalParameters, new FormalParametersEmitter());
    }
  }
}

class FormalParametersEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++) {
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
    }
  }
}


     
SystemMixin Class {
  
  class Epp {
    implement Tree typeDeclarationOtherwise() {
      Tree modifiers = modifiers();
      if (lookahead() == :class || lookahead() == :interface){
	return classDeclaration(modifiers);
      } else {
	return original();
      }
    }
    
    define implement Tree classDeclaration(Tree modifiers){
      Tree keyword = identifier();
      Tree name = identifier();
      Tree extds = extends();
      Tree implmnts = implements();
      Tree classBody;
      
      Dynamic.bind(:currentClassName, name.idName());
      try {
	classBody = classBody();
	return new Tree(:class,
			modifiers, keyword, name, extds, implmnts,
			classBody);
      } finally {
	Dynamic.unbind();
      }
    }
    
    define implement Tree classBody() {
      match(:"{");
      if (Opts.nocatch){
	return classBodyRest();
      } else {
	try {
	  return classBodyRest();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught during parsing a ClassBody. Skipping until the end of the ClassBody.");
	  int level = 1;
	  while (level > 0){
	    Token token = matchAny();
	    if (token == :"{") {
	      level++;
	    } else if (token == :"}"){
	      level--;
	    } else if (token.isLiteralToken() &&
		       token.literalTag() == :eof){
	      throw error("Unexpected EOF.");
	    }
	  }
	  return new Tree(:errorInClassBody);
	}
      }
    }

    define implement Tree classBodyRest() {
      TreeVec tvec = new TreeVec();
      while (lookahead() != :"}") {
	tvec.add(classBodyDeclaration());
      }
      match(:"}");
      return new Tree(:classBody, tvec.toArray());
    }
    
    extend void initMacroTable() {
      original();
      defineMacro(:classBody, new ClassBodyMacro());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:classBody, new ClassBodyEmitter());
      defineEmitter(:class, new SimpleEmitter("%% % %%%"));
      defineEmitter(:errorInClassBody,
		    new SimpleEmitter("{ <errorInClassBody> }"));
    }
  }
}

class ClassBodyMacro extends Macro {
  public Tree call(Tree tree){
    Dynamic.bind(:beginningOfClassBody, new TreeVec());
    Dynamic.bind(:beforeCurrentClassBodyDeclaration, null);
    Dynamic.bind(:afterCurrentClassBodyDeclaration, null);
    try{
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();

      for (int i = 0; i < args.length; i++){
	Dynamic.set(:beforeCurrentClassBodyDeclaration, new TreeVec());
	Dynamic.set(:afterCurrentClassBodyDeclaration, new TreeVec());

        Tree earg = macroExpandTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentClassBodyDeclaration));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentClassBodyDeclaration));
      }
      
      TreeVec beginning = (TreeVec)Dynamic.get(:beginningOfClassBody);
      beginning.addA(tvec);
      
      return tree.modifyArgs(beginning.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}

class ClassBodyEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    out.write('{');

    Dynamic.bindInt(:outputIndent,
		    Dynamic.getInt(:outputIndent) + 2);
    try {
      Tree[] args = tree.args();
      for (int i = 0; i < args.length; i++) {
	outputNewlineForReadability(out);
	emitTree(out, args[i]);
	outputNewlineForReadability(out);
      }
      out.write('}');
    } finally {
      Dynamic.unbindInt();
    } 
  }
}



defineNonTerminal(classBodyDeclaration,
		  classBodyDeclarationAfterModifiers(modifiers()));
     
     

SystemMixin ClassBody {
  
  class Epp {

    define Tree classBodyDeclarationAfterModifiers(Tree modifiers){
      if (lookahead() == :class || lookahead() == :interface){
	// An inner class at the ClassBody.
	return classDeclaration(modifiers);
      } else {
	int p = inputPointer();
	Token firstToken = matchAny();

	// NOTE: The following is not a constructor.
	// class Foo { Foo m(){...} }
	boolean isConstructor 
	  = (firstToken == Dynamic.get(:currentClassName) &&
	     lookahead() == :"(");

	backtrack(p);
	if (isConstructor){
	  return constructorDeclaration(modifiers);
	} else {
	  return methodOrFieldDeclaration(modifiers);
	}
      }
    }

    define Tree constructorDeclaration(Tree modifiers) {
      Tree result = new Tree(:name, new Identifier(:void)); // dummy value
      Tree name = identifier();
      match(:"(");
      Tree args = formalParameterList();
      match(:")");
      Tree thrs = throws();
      Tree body = block();
      return new Tree(:constructor, modifiers, result, name, args, thrs, body);
    }
    
    define Tree methodOrFieldDeclaration(Tree modifiers) {
      Tree result = type();
      int p = inputPointer();
      identifier();
      boolean isMethod = (lookahead() == :"(");
      backtrack(p);
      if (isMethod) {
	return methodDeclaration(modifiers, result);
      } else {
	return fieldDeclaration(modifiers, result);
      }
    }
    
    define Tree methodDeclaration(Tree modifiers, Tree result) {
      Tree name = identifier();
      match(:"(");
      Tree args = formalParameterList();
      match(:")");
      while(true) {
	if (lookahead() == :"[") {
	  matchAny();
	  match(:"]");
	  result = new Tree(:arrayOf, result);
	} else {
	  break;
	}
      }
      Tree thrs = throws();
      Tree body;
      if (lookahead() == :";"){
	// body is emptyStatement.
	body = statement();
      } else {
	body = block();
      }
      return new Tree(:method, modifiers, result, name, args, thrs, body);
    }

    define Tree fieldDeclaration(Tree modifiers, Tree type) {
      Tree decls = variableDeclarators();
      match(:";");
      return new Tree(:decl, modifiers, type, decls);
    }

    extend void initEmitterTable() {
      original();
      defineEmitter(:method, new SimpleEmitter("%% %(%)%%"));
      defineEmitter(:constructor, new ConstructorEmitter());
      defineEmitter(:emptyClassBodyDeclaration, new SimpleEmitter(""));
    }
  }
}

class ConstructorEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    emitTree(out, args[0]);
    // args[1] is ignored.
    emitTree(out, args[2]);
    out.write('(');
    emitTree(out, args[3]);
    out.write(')');
    emitTree(out, args[4]);
    emitTree(out, args[5]);
  }
}



SystemMixin StaticInitializer {
  
  class Epp {
    extend Tree classBodyDeclarationTop(){
      if (lookahead() == :static) {
	int p = inputPointer();
	matchAny();
	boolean isStaticInitializer = (lookahead() == :"{");
	backtrack(p);
	if (isStaticInitializer) {
	  return staticInitializer();
	} else {
	  return original();
	}
      } else {
	return original();
      }
    }
    
    define Tree staticInitializer() {
      match(:static);
      return new Tree(:staticInitializer, block());
    }

    extend void initEmitterTable() {
      original();
      defineEmitter(:staticInitializer, new SimpleEmitter("static %"));
    }
  }
}



SystemMixin InstanceInitializer {
  
  class Epp {
    extend Tree classBodyDeclarationTop(){
      if (lookahead() == :"{") {
	return new Tree(:instanceInitializer, block());
      } else {
	return original();
      }
    }

    extend void initEmitterTable() {
      original();
      defineEmitter(:instanceInitializer, new SimpleEmitter("%"));
    }
  }
}



SystemMixin ClassBodySemicolon {
  
  class Epp {
    extend Tree classBodyDeclarationTop(){
      if (lookahead() == :";") {
	matchAny();
	// emptyClassBodyDeclaration seems to become valid since JLS2.0 .
	return new Tree(:emptyClassBodyDeclaration);
      } else {
	return original();
      }
    }
  }
}



SystemMixin StartByTypeDeclaration {
  
  class Epp {
    default Tree start() {
      return typeDeclaration();
    }
  }
}
