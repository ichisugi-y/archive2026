/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote


package epp;
import SystemMixinRuntimes.*;
import java.io.*;
import java.util.*;



//--------------------------------------------------

public class NotFound extends Exception {
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static NotFound instance = new NotFound();
  // private constructor
  private NotFound(){}
}

//--------------------------------------------------
//--------------------------------------------------

SystemMixin FileSig {
  
  class Epp {
    
    // This method is called from EPP main routine.
    define implement Tree makeFileSignature(){
      if (Opts.log) Opts.out.println("Start making FileSignature "+
				     (String)Dynamic.get(:inputFileName)+
				     " .");
      Tree ret;
      if (Opts.nocatch){
	ret = normalizeCompilationUnit(self!tree);
      } else {
	try {
	  ret = normalizeCompilationUnit(self!tree);
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught by makeFileSignature().");
	  ret = new Tree(:errorInCompilationUnit);
	}
      }
      if (Opts.printFileSignature || Opts.printTree) {
	Opts.out.println("FileSignature:");
	ret.print();
      }
      if (Opts.log) Opts.out.println("End making FileSignature "+
				     (String)Dynamic.get(:inputFileName)+
				     " .");
      if (ret.tag() == :errorInCompilationUnit){
	// An empty file signature.
	ret = `(fileSignature
		(packageDeclaration)
		(importDeclarations)
		(typeDeclarations));
      }
      return ret;
    }
    
    
    //--------------------------------------------------
    // FileSignature $B$N:n@.!#(B
    // $B$3$N%a%=%C%I$O!"%^%/%mE83+%Q%9$,=*$C$F$+$i!"8F$S=P$5$l$k!#(B
    // CompilationUnit $B$N(B Tree $B$+$i!"%a%=%C%IDj5AK\BN$r<h$j=|$-!"(B
    //FileSignature $B$H$$$&%U%)!<%^%C%H$N(B tree $B$r:n$C$FJV$9!#(B
    // $B!&(B modifier $B$N=g=x$O<+M3!#(B
    // $B!&(B extends, implements $B$N0z?t$d$9$Y$F$N7?L>$O!"$=$N$^$^!#(B
    // $B!&(B class $B$NL>A0$b(B id $B$N$^$^!#(B
    // $B!&(B method, field $B$NJB$S$O<+M3!#(B
    // $B!&(B static initializer, instance initializer $B$O<h$j=|$/!#(B
    // $B!&(B field $B$O!"#1$D$E$D(B type id; $B$N7A$K!#(B [] $B$O(B type $B$K$D$1$k!#(B
    define implement Tree normalizeCompilationUnit(Tree tree){
      if (tree.tag() == :errorInCompilationUnit) {
	return tree;
      }
      Tree[] args = tree.args();
      Tree[] typeDecls = args[2].args();
      TreeVec tvec = new TreeVec();
      for (int i = 0; i < typeDecls.length; i++){
	tvec.add(normalizeTypeDeclaration(typeDecls[i]));
      }
      Tree[] newArgs = { args[0], args[1],
			 new Tree(:typeDeclarations, tvec)};
      return new Tree(:fileSignature, newArgs);
    }
    
    define implement Tree normalizeTypeDeclaration(Tree tree){
      if (tree.tag() == :class){
	return normalizeClass(tree);
      } else if (tree.tag() == :emptyTypeDeclaration){
	// Return dummy value.
	return `(typeDeclarationSignature (id void) (id void));
      } else {
	throw Epp.fatal("normalizeCompilationUnit: Unknown TypeDeclaration: "+
			tree);
      }
    }
    
    define implement Tree normalizeClass(Tree tree){
      Tree[] args = tree.args();
      Tree modifiers = args[0];
      Tree keyword = args[1];
      Tree name = args[2];
      Tree extds = args[3];
      Tree impls = args[4];
      
      Tree classBody = args[5];
      Tree[] classBodyArgs = classBody.args();
      TreeVec tvec = new TreeVec();
      for (int i = 0; i < classBodyArgs.length; i++){
	normalizeClassBodyDeclaration(tvec, classBodyArgs[i]);
      }
      return `(typeDeclarationSignature
	       ,name
	       ,(new Tree(:class, modifiers, keyword, name, extds, impls,
			  new Tree(:classBody, tvec))));
    }
    // This method accepts both (classBody ...) and (errorInClassBody) .
    define implement void normalizeClassBodyDeclaration(TreeVec tvec,
							Tree tree){
      Symbol tag = tree.tag();
      if (tag == :decl){
	normalizeFields(tvec, tree);
      } else if (tag == :constructor){
	tvec.add(normalizeMethod(tree));
      } else if (tag == :method){
	tvec.add(normalizeMethod(tree));
      } else if (tag == :staticInitializer ||
		 tag == :instanceInitializer ||
		 tag == :emptyClassBodyDeclaration) {
	; // Do nothing.
      } else if (tag == :class){
	// inner class
	Tree entry = normalizeClass(tree);
	// (typeDeclarationSignature (id simpleName) typeSig errorMessage)
	Tree typeSig = entry.args()[1];
	tvec.add(typeSig);
      } else {
	throw Epp.fatal("normalizeClassBodyDeclaration: "+
			"Unknown ClassBodyDeclaration : "+
			tree);
      }
    }
    define implement Tree normalizeMethod(Tree tree){
      Symbol tag = tree.tag();
      Tree[] args = tree.args();
      Tree modifiers = args[0];
      Tree ret = args[1];
      Tree name = args[2];
      Tree params = normalizeParams(args[3]);
      Tree thrs = args[4];
      return new Tree(tag, modifiers, ret, name, params, thrs,
		      new Tree(:emptyStatement));
    }
    define implement void normalizeFields(TreeVec tvec, Tree tree){
      Tree[] args = tree.args();
      Tree modifiers = args[0];
      Tree type = args[1];
      Tree[] vardecls = args[2].args();
      for (int i = 0; i < vardecls.length; i++){
	Tree var = vardecls[i];
	if (var.tag() == :varInit) {
	  var = var.args()[0];
	}
	Tree[] pair = normalizeVariableDeclaratorId(type, var);
	tvec.add(new Tree(:decl,
			  modifiers,
			  pair[0],
			  new Tree(:vardecls, pair[1])));
      }
    }
    define implement Tree normalizeParams(Tree tree){
      Tree[] args = tree.args();
      Tree[] newArgs = new Tree[args.length];
      for (int i = 0; i < args.length; i++){
	Tree[] pargs = args[i].args();
	Tree[] pair = normalizeVariableDeclaratorId(pargs[1], pargs[2]);
	newArgs[i] = new Tree(:pdecl, pargs[0], pair[0], pair[1]);
      }
      return new Tree(:formalParameters, newArgs);
    }
    define implement Tree[] normalizeVariableDeclaratorId(Tree type, Tree var){
      if (var.tag() == :id){
	Tree[] ret = { type, var };
	return ret;
      } else if (var.tag() == :arrayVar) {
	return normalizeVariableDeclaratorId(new Tree(:arrayOf, type),
					     var.args()[0]);
      } else {
	throw Epp.fatal("normalizeVariableDeclaratorId: Unknown VariableDeclaratorId: "+ var);
      }
    }
    
    
    //--------------------------------------------------

    // plug-in $B$O$3$3$r3HD%$7$F!"?7$?$J!V%0%m!<%P%k7?!W$rDI2C$G$-$k!#(B
    define implement Type makeTypeFromTypeSignatureTree(Symbol fullName,
							Tree entry,
							TypeNameTable
							typeNameTable){
      // entry :(typeDeclarationSignature (id simpleName) typeSig errorMessage)
      Tree typeSig = entry.args()[1];

      if (typeSig.tag() == :class){
	return new ClassType(fullName, typeSig, typeNameTable, null, null);
      } else {
	if (entry.args().length > 2){
	  // (id "error message"); 
	  Tree errorMessage = entry.args()[2];
	  throw Epp.fatal(errorMessage.idName().toString());
	} else {
	  throw Epp.fatal("Unknown type signature : "+ typeSig);
	}
      }
    }


    define implement ClassInfo makeClassInfoFromClassData(ClassData classData){
      classData = processInheritance(classData);
      return new ClassInfo(classData.outerClass,
			   classData.modifiers,
			   classData.isInterface,
			   classData.fullName,
			   classData.superclassType,
			   classData.interfaceTypes,
			   classData.constructors,
			   classData.fieldTable,
			   classData.methodTable,
			   classData.innerClassTable,
			   classData.classProperty
			   );
    }

    
    define implement ClassData treeToClassData(Symbol fullName,
					       Type outerClass,
					       Tree classSig,
					       Type declaringClass){
      if (classSig.tag() != :class){
	throw Epp.fatal("treeToClassData: Unknown format of type declaration is found in the FileSignature. "+ classSig);
      }
      
      
      TypeNameTable typeNameTable = (TypeNameTable)Dynamic.get(:typeNameTable);

      Tree[] args = classSig.args();
      
      Tree[] modifiers = args[0].args();
      
      boolean isInterface = (args[1].idName() == :interface);
      if (isInterface){
	modifiers = addModifier(modifiers, :abstract);
      }
      
      // Superclass and interfaces
      Type superclassType;
      Tree[] interfaceTrees;
      if (isInterface){
	superclassType = null;
	interfaceTrees = classSig.args()[3].args();
      } else {
	Tree[] supers = classSig.args()[3].args();
	if (supers.length == 1){
	  superclassType = treeToType(supers[0]);
	} else if (supers.length == 0){
	  if (fullName == :"java.lang.Object"){
	    superclassType = null;
	  } else {
	    superclassType = Type.TObject;
	  }
	} else {
	  throw Epp.error("More than one super class is specified.: "+
			  fullName);
	}
	interfaceTrees = args[4].args();
      }
      
      Type[] interfaceTypes = new Type[interfaceTrees.length];
      for (int i = 0; i < interfaceTrees.length; i++){
	interfaceTypes[i] = treeToType(interfaceTrees[i]);
      }
      
      Tree[] members = args[5].args();

      
      // Inner classes
      Hashtable innerClassTable = new Hashtable();
      for (int i = 0; i < members.length; i++){
	if (members[i].tag() == :class){
	  Symbol name = members[i].args()[2].idName();
	  innerClassTable.put(name, treeToInnerClassType(members[i],
							 isInterface,
							 fullName,
							 declaringClass));
	}
      }
      

      MethodInfo[] constructors;
      Hashtable fieldTable = new Hashtable();
      Hashtable methodTable = new Hashtable();

      // $B<+J,<+?H$N(B member $B$N%/%i%9$b8+$($k4D6-$G!"(B
      // inner class $B0J30$N%a%s%P!<$r@8@.!#(B
      // inner class $B<+?H$O(B lazy $B$K@8@.$5$l$k!#(B
      TypeNameTable memberEnv = typeNameTable;
      // interface $B$N(B inner class $B$C$FK\Ev$O$I$&$$$&07$$$J$s$@$m$&!#(B
      for (int i = interfaceTypes.length - 1; i >= 0; i--){
	memberEnv = new MemberTypeNameTable(interfaceTypes[i], memberEnv);
      }
      if (superclassType != null){
	// $B$3$l$@$H(B super $B$N(B private $B$J%a%s%P$b8+$($F$7$^$&$,!"$H$j$"$($:!#(B
	memberEnv = new MemberTypeNameTable(superclassType, memberEnv);
      }
      memberEnv = new HashtableTypeNameTable(innerClassTable, memberEnv);
      
      Dynamic.bind(:typeNameTable, memberEnv);


      try {
	
	// Constructors
	{
	  TreeVec tvec = new TreeVec();
	  for (int i = 0; i < members.length; i++){
	    if (members[i].tag() == :constructor){
	      tvec.add(members[i]);
	    }
	  }
	  Tree[] constructorTrees = tvec.toArray();
	  if (constructorTrees.length == 0){
	    // Make a default constructor.
	    constructors = new MethodInfo[1];
	    constructors[0] = new MethodInfo(declaringClass,
					     new Tree[0],
					     Type.Tvoid,
					     :"<init>",
					     new Type[0],
					     new Type[0]);
	  } else {
	    constructors = new MethodInfo[constructorTrees.length];
	    for (int i = 0; i < constructorTrees.length; i++){
	      constructors[i] = treeToMethodInfo(constructorTrees[i],
						 isInterface,
						 declaringClass);
	    }
	  }
	}
	
	// Fields
	for (int i = 0; i < members.length; i++){
	  if (members[i].tag() == :decl){
	    // (decl (modifiers) (name ...) (vardecls (id sym)))
	    Symbol name = members[i].args()[2].args()[0].idName();
	    fieldTable.put(name, treeToFieldInfo(members[i],
						 isInterface,
						 declaringClass));
	  }
	}
	
	// Methods
	for (int i = 0; i < members.length; i++){
	  if (members[i].tag() == :method){
	    Symbol name = members[i].args()[2].idName();
	    MethodInfo m = treeToMethodInfo(members[i],
					    isInterface,
					    declaringClass);
	    MethodInfo[] a = (MethodInfo[])methodTable.get(name);
	    if (a == null){
	      methodTable.put(name, new MethodInfo[]{ m });
	    } else {
	      // Add an overloaded method to the array of MethodInfo.
	      //I do not use Vector because overloading is a minor case,
	      MethodInfo[] newA = new MethodInfo[a.length + 1];
	      for (int j = 0; j < a.length; j++){
		newA[j] = a[j];
	      }
	      newA[a.length] = m;
	      methodTable.put(name, newA);
	    }
	  }
	}
      } finally {
	Dynamic.unbind();
      }

      ClassData classData =  new ClassData(outerClass,
					   declaringClass,
					   modifiers,
					   isInterface,
					   fullName,
					   superclassType,
					   interfaceTypes,
					   constructors,
					   fieldTable,
					   methodTable,
					   innerClassTable,
					   null);

      classData.classProperty = treeToClassProperty(classSig,
						    classData);
      
      return classData;
    }
    
    define implement FieldInfo treeToFieldInfo(Tree tree,
					       boolean isInterface,
					       Type declaringClass){
      Tree[] args = tree.args();
      // (decl (modifiers) (name ...) (vardecls (id sym)))
      Tree[] modifiers = args[0].args();
      if (isInterface){
	modifiers = addModifier(addModifier(addModifier(modifiers,
							:public),
					    :static),
				:final);
      }
      return new FieldInfo(declaringClass,
			   modifiers,
			   treeToType(args[1]),
			   args[2].args()[0].idName());
    }
    
    define implement MethodInfo treeToMethodInfo(Tree tree,
						 boolean isInterface,
						 Type declaringClass){
      Tree[] args = tree.args();
      Tree[] modifiers = args[0].args();
      if (isInterface){
	modifiers = addModifier(addModifier(modifiers,
					    :public),
				:abstract);
      }
      Type ret = treeToType(args[1]);
      Symbol name = args[2].idName();
      Tree[] paramsTree = args[3].args();
      Type[] params = new Type[paramsTree.length];
      for (int i = 0; i < paramsTree.length; i++){
	// Ignores modifiers and variable names of formal parameters.
	// (pdecl (modifiers ...) type (id var))
	params[i] = treeToType(paramsTree[i].args()[1]);
      }
      Tree[] thrsTree = args[4].args();
      Type[] thrs = new Type[thrsTree.length];
      for (int i = 0; i < thrsTree.length; i++){
	thrs[i] = treeToType(thrsTree[i]);
      }
      return new MethodInfo(declaringClass,
			    modifiers,
			    ret,
			    name,
			    params,
			    thrs);
    }

    define implement Type treeToInnerClassType(Tree tree,
					       boolean isInterface,
					       Symbol declaringClassName,
					       Type declaringClass){
      TypeNameTable typeNameTable = (TypeNameTable)Dynamic.get(:typeNameTable);
      TypeNameTable innerEnv = new MemberTypeNameTable(declaringClass,
						       typeNameTable);
      String simpleName = tree.args()[2].idName().toString();
      Symbol fullName = Symbol.intern(declaringClassName+
				      "$"+
				      simpleName);
      // Inner classes is not registered in ClassTypeTable.
      return new ClassType(fullName,
			   tree, innerEnv,
			   declaringClass, null);
    }

    define implement Hashtable treeToClassProperty(Tree tree,
						   ClassData classData){
      return new Hashtable();
    }
    
    define implement Type treeToType(Tree tree){
      Tree newTree = TypeChecker.typeNameCheckTree(tree);
      return newTree.type();
    }
    
    define implement Tree[] addModifier(Tree[] modifiers, Symbol newModifier){
      Tree[] newArgs = new Tree[modifiers.length + 1];
      for (int i = 0; i < modifiers.length; i++){
	if (modifiers[i].idName() == newModifier) return modifiers;
	newArgs[i] = modifiers[i];
      }
      newArgs[modifiers.length] = new Identifier(newModifier);
      return newArgs;
    }
    

    //--------------------------------------------------
    // Inheritance.
    
    define implement ClassData processInheritance(ClassData classData){
      return new ClassData(classData.outerClass,
			   classData.declaringClass,
			   classData.modifiers,
			   classData.isInterface,
			   classData.fullName,
			   classData.superclassType,
			   classData.interfaceTypes,
			   classData.constructors,
			   inheritFieldInfo(classData),
			   inheritMethodInfo(classData),
			   inheritInnerClassInfo(classData),
			   inheritClassProperty(classData)
			   );
    }
    

    define implement Hashtable inheritFieldInfo(ClassData classData){
      Type declaringClass = classData.declaringClass;
      Type superclassType = classData.superclassType;
      Type[] interfaceTypes = classData.interfaceTypes;
      Hashtable thisFieldTable = classData.fieldTable;
      
      // key : Symbol, val : FieldInfo
      Hashtable newFieldTable = new Hashtable();
      
      for (int i = 0; i < interfaceTypes.length; i++){
	inheritFieldInfo1(newFieldTable,
			  interfaceTypes[i].classInfo().getFieldTable(),
			  false,
			  declaringClass);
      }
      if (superclassType != null){
	inheritFieldInfo1(newFieldTable,
			  superclassType.classInfo().getFieldTable(),
			  false,
			  declaringClass);
      }
      inheritFieldInfo1(newFieldTable, thisFieldTable, true, declaringClass);
      return newFieldTable;
    }
    
    // Add fields of addingFieldTable into existingFieldTable.
    define implement void inheritFieldInfo1(Hashtable existingFieldTable,
					    Hashtable addingFieldTable,
					    boolean canHide,
					    Type declaringClass){
      Enumeration eKey = addingFieldTable.keys();
      Enumeration eVal = addingFieldTable.elements();
      while (eKey.hasMoreElements()){
	Symbol name = (Symbol)eKey.nextElement();
	FieldInfo addingField = (FieldInfo)eVal.nextElement();
	FieldInfo existingField = (FieldInfo)existingFieldTable.get(name);
	if (existingField == null){
	  // Add the new field to the table.
	  existingFieldTable.put(name, addingField);
	} else if (canHide){
	  // Hide the existing field.
	  existingFieldTable.put(name, addingField);
	} else if (addingField == existingField){
	  // It is defined at the same interface.
	  // Do nothing.
	} else {
	  // AmbiguousFieldInfo.
	  AmbiguousFieldInfo ambiguousFieldInfo;
	check:
	  {
	    if (existingField.isAmbiguousField()){
	      FieldInfo[] fields =
		((AmbiguousFieldInfo)existingField).getAmbiguousFields();
	      for (int i = 0; i < fields.length; i++){
		if (fields[i] == addingField){
		  // If the addingField is already a member of ambiguousFields,
		  //re-use the instance of AmbiguousFieldInfo.
		  ambiguousFieldInfo = (AmbiguousFieldInfo)existingField;
		  break check;
		}
	      }
	      // If the addingField is a new ambigous field,
	      //create a new AmbiguousFieldInfo.
	      FieldInfo[] ambiguousFields = new FieldInfo[fields.length + 1];
	      for (int i = 0; i < fields.length; i++){
		ambiguousFields[i] = fields[i];
	      }
	      ambiguousFields[fields.length] = addingField;
	      ambiguousFieldInfo = new AmbiguousFieldInfo(declaringClass,
							  name,
							  ambiguousFields);
	    } else {
	      FieldInfo[] ambiguousFields = { existingField, addingField };
	      ambiguousFieldInfo = new AmbiguousFieldInfo(declaringClass,
							  name,
							  ambiguousFields);
	    }
	  }
	  existingFieldTable.put(name, ambiguousFieldInfo);
	}
      }
    }
    
    define implement Hashtable inheritMethodInfo(ClassData classData){
      Type superclassType = classData.superclassType;
      Type[] interfaceTypes = classData.interfaceTypes;
      Hashtable thisMethodTable = classData.methodTable;

      // All interfaces inherits method from java.lang.Object implicitly.
      if (classData.isInterface){
	superclassType = Type.TObject;
      }

      // key : Symbol, val : MethodInfo[]
      Hashtable newMethodTable = new Hashtable();
      
      for (int i = 0; i < interfaceTypes.length; i++){
	inheritMethodInfo1(newMethodTable,
			   interfaceTypes[i].classInfo().getMethodTable());
      }
      if (superclassType != null){
	inheritMethodInfo1(newMethodTable,
			   superclassType.classInfo().getMethodTable());
      }
      inheritMethodInfo1(newMethodTable, thisMethodTable);
      return newMethodTable;
    }
    
    // Add methods of addingMethodTable into existingMethodTable.
    define implement void inheritMethodInfo1(Hashtable existingMethodTable,
					     Hashtable addingMethodTable){
      Enumeration eKey = addingMethodTable.keys();
      Enumeration eVal = addingMethodTable.elements();
      while (eKey.hasMoreElements()){
	Symbol name = (Symbol)eKey.nextElement();
	MethodInfo[] addingMethods = (MethodInfo[])eVal.nextElement();
	MethodInfo[] existingMethods
	  = (MethodInfo[])existingMethodTable.get(name);
	if (existingMethods == null){
	  // Add the methods to the table.
	  existingMethodTable.put(name, addingMethods);
	} else {
	  // The adding methods are overriding or overloading existing methods.

	  MethodInfo[] newArray = new MethodInfo[existingMethods.length];
	  for (int i = 0; i < existingMethods.length; i++){
	    newArray[i] = existingMethods[i];
	  }
	nextAddingMethods:
	  for (int i = 0; i < addingMethods.length; i++){
	    for (int j = 0; j < existingMethods.length; j++){
	      if (doesOverride(addingMethods[i], existingMethods[j])){
		// This method overrides the existing method.
		newArray[j] = addingMethods[i];
		continue nextAddingMethods;
	      }
	    }
	    // The method is a new overloading method.
	    // Append it to newArray.
	    MethodInfo[] a = new MethodInfo[newArray.length + 1];
	    for (int j = 0; j < newArray.length; j++){
	      a[j] = newArray[j];
	    }
	    a[newArray.length] = addingMethods[i];
	    newArray = a;
	  }
	  // Replace existingMethods to newArray.
	  existingMethodTable.put(name, newArray);
	}
      }
    }

    // Returns true iff method m1 overrides m2 . 
    define implement boolean doesOverride(MethodInfo m1, MethodInfo m2){
      Type[] p1 = m1.getParameterTypes();
      Type[] p2 = m2.getParameterTypes();
      if (p1.length != p2.length) return false;
      for (int i = 0; i < p1.length; i++){
	if (! Type.equals(p1[i], p2[i])) return false;
      }
      return true;
    }


    define implement Hashtable inheritInnerClassInfo(ClassData classData){
      Type superclassType = classData.superclassType;
      Type[] interfaceTypes = classData.interfaceTypes;
      Hashtable thisInnerClassTable = classData.innerClassTable;

      // key : Symbol, val : InnerClassInfo
      Hashtable newInnerClassTable = new Hashtable();

      for (int i = 0; i < interfaceTypes.length; i++){
	inheritInnerClassInfo1(newInnerClassTable,
			       interfaceTypes[i].classInfo().getInnerClassTable(),
			       false);
      }
      if (superclassType != null){
	inheritInnerClassInfo1(newInnerClassTable,
			       superclassType.classInfo().getInnerClassTable(),
			       false);
      }
      inheritInnerClassInfo1(newInnerClassTable, thisInnerClassTable, true);
      return newInnerClassTable;
    }
    
    // Add inner classes of addingInnerClassTable into existingInnerClassTable.
    define implement
      void inheritInnerClassInfo1(Hashtable existingInnerClassTable,
				  Hashtable addingInnerClassTable,
				  boolean canHide){
      Enumeration eKey = addingInnerClassTable.keys();
      Enumeration eVal = addingInnerClassTable.elements();
      while (eKey.hasMoreElements()){
	Symbol name = (Symbol)eKey.nextElement();
	Type addingInnerClass = (Type)eVal.nextElement();
	Type existingInnerClass = (Type)existingInnerClassTable.get(name);
	if (existingInnerClass == null){
	  // Add the innerClass to the table.
	  existingInnerClassTable.put(name, addingInnerClass);
	} else if (canHide) {
	  existingInnerClassTable.put(name, addingInnerClass);
	} else if (addingInnerClass == existingInnerClass){
	  // It is defined at the same interface.
	  // Do nothing.
	} else {
	  // Ambiguous.
	  // I do not know what should I do.
	  System.err.println("WARNING: Ambiguous inner class name."+ name);
	  // Just override.
	  existingInnerClassTable.put(name, addingInnerClass);
	}
      }
    }

    define implement Hashtable inheritClassProperty(ClassData classData){
      // The default behavior does not inherit any class properties.
      return new Hashtable();
    }

  }
}



//--------------------------------------------------
//--------------------------------------------------

public class ClassType extends Type {

  protected Symbol fullName = null;
  protected Tree classSig = null;
  protected Object inputFileName = null;
  protected Object eppInputStream = null;
  protected TypeNameTable typeNameTable = null;
  protected Type outerClass = null;
  protected ClassInfo classInfo = null;
  protected Object classFile = null;
  protected int initializingState = UNINITIALIZED;
  // $B$3$3$G$O$^$@(B Symbol $B$,;H$($J$$!#(B
  protected static int UNINITIALIZED = 0;
  protected static int INITIALIZING = 1;
  protected static int INITIALIZED = 2;
  protected static int ERROR = 3;

  public ClassType(Symbol fullName,
		   Tree classSig, // class file $B$+$i:n$k;~$O(B null $B!#(B
		   TypeNameTable typeNameTable,
		   Type outerClass,
		   Object classFile
		   ) {
    // Type.TString $B$J$I$N=i4|2=$,(B ClassType $B$N(B static field $B$N=i4|2=$h$j@h!#(B
    super(:class == null ? Symbol.intern("class") : :class);
    // super(:class);

    //System.out.println("new ClassType("+ fullName+ ")");

    this.fullName = fullName;
    this.classSig = classSig;
    this.inputFileName
      = Dynamic.get(:inputFileName == null ? Symbol.intern("inputFileName")
		    : :inputFileName);
    this.eppInputStream
      = Dynamic.get(:eppInputStream == null ? Symbol.intern("eppInputStream")
		    : :eppInputStream);
    this.typeNameTable = typeNameTable;
    this.outerClass = outerClass;
    this.classFile = classFile;
  }
  
  public ClassInfo classInfo(){
    if (classInfo == null) {
      if (initializingState == UNINITIALIZED) {
	initializingState = INITIALIZING;
      } else if (initializingState == INITIALIZING) {
	throw new EppTypeError("Type dependency loop is detected: "+ fullName);
      } else if (initializingState == ERROR){
	throw new EppTypeError("Error occured during processing the type : "+ fullName);
      } else {
	throw Epp.fatal("initializingState:"+ initializingState);
      }
      Dynamic.bind(:inputFileName, inputFileName);
      Dynamic.bind(:eppInputStream, eppInputStream);
      try {
	Obj epp = (Obj)Dynamic.get(:epp);
	ClassData classData;
	if (classFile == null){
	  // Make classData from classSig.
	  Dynamic.bind(:typeNameTable, typeNameTable);
	  try {
	    classData = epp!treeToClassData(fullName,
					    outerClass,
					    classSig,
					    this);
	  } finally {
	    Dynamic.unbind();
	  }
	} else {
	  classData = epp!classFileToClassData(classFile, this);
	}
	classInfo = epp!makeClassInfoFromClassData(classData);

	if (Opts.printClassInfo) {
	  if (classFile == null){
	    Opts.out.println("ClassInfo generated from FileSignature:");
	  } else {
	    Opts.out.println("ClassInfo generated from class file:");
	  }
	  Opts.out.println(classInfo);
	}
      
	// Garbage.
	classSig = null;
	typeNameTable = null;
	outerClass = null;
	classFile = null;

	initializingState = INITIALIZED;
      } finally {
	if (initializingState == INITIALIZING){
	  initializingState = ERROR;
	}
	Dynamic.unbind();
	Dynamic.unbind();
      }
    }
    return classInfo;
  }

  // ClassInfo $B$r:n$i$:$K!"$3$N(B ClassType $B$NL>A0$rJV$9!#(B
  // $B7Q>5=hM}$G(B doesOverride $B$N=hM}$r$9$k;~$K!"(B dependency loop $B$r(B
  //$BHr$1$k$?$a$KI,MW!#(B
  // This method is called from Epp!equals(t1, t2) .
  public Symbol getName(){
    return fullName;
  }
  
  // ClassInfo $B$r:n$i$:$K!"(B true $B$+(B false $B$rJV$9!#(B
  // This method is called from GlobalTypeNameTable#doesClassExist .
  public boolean isPublic() {
    Tree[] modifiers;
    if (classInfo == null){
      if (classSig == null){
	// classInfo $B$r:n$k!#(B
	modifiers = classInfo().getModifiers();
      } else {
	// classInfo $B$r:n$i$:$K(B public $B$+$I$&$+$rH=Dj$9$k!#(B
	modifiers = classSig.args()[0].args();
      }
    } else {
      modifiers = classInfo.getModifiers();
    }
    for (int i = 0; i < modifiers.length; i++){
      if (modifiers[i].idName() == :public){
	return true;
      }
    }
    return false;
  }

  public Tree toTree(){
    return Tree.stringToNameTree(fullName.toString());
  }
  public String toString(){
    return fullName.toString();
  }
}


// This class is instantiated by ReadClassFile.java .
public class NotFoundClassType extends ClassType {
  public String referringClass;

  public NotFoundClassType(Symbol fullName,
			   String referringClass) {
    super(fullName, null, null, null, null);
    this.referringClass = referringClass;
  }
  
  public ClassInfo classInfo(){
    reportError();
    throw Epp.fatal("");
  }
  
  public boolean isPublic(){
    reportError();
    throw Epp.fatal("");
  }

  public void reportError(){
    throw Epp.error("Type "+ fullName+ " refered to by "+ referringClass+
		    " is not found.");
  }
}



//--------------------------------------------------
//--------------------------------------------------
// $B40A48BDjL>$H%/%i%9$H$NBP1~I=!#(B
//
// $B40A48BDjL>$H%/%i%97?$H$NBP1~$O!"%0%m!<%P%k$K0l0U$K7h$^$k$H2>Dj!#(B
// $B$3$N%F!<%V%k$N%$%s%9%?%s%9$O!"%;%C%7%g%sFb$G#1$D$@$1@8@.$5$l$k!#(B
//
// $B!VL>A0$N$D$$$?7?!W$O!"I8=`$N(B Java $B$G$O(B class $B$H(B interface $B$N$_!#(B
//$B$7$+$7!"(B plug-in $B$O!"?7$?$J(B ClassType $B$rDI2C$G$-$k!#(B
// $B!J$?$@$7!"%W%m%8%'%/%HFb$G!"(B ClassType $B$N%;%^%s%F%#%C%/%9$N0l4S@-$N0];}$O!"(B
// $B$$$^$N$H$3$m(B EPP $B$OJ]>Z$7$J$$!#%f!<%6$+(B plug-in $B%W%m%0%i%^$N@UG$!#!K(B

// $B6a$$$&$A$K!"!V(B :class $B0J30$N7?$r(B class file $B$K(B encode $B$9$k(B plug-in$B!W$r(B
//$B%5%]!<%H$9$k$3$H$K$9$k!#(B
// ClassTypeTable $B$O!"@53N$K$O!"!V(Bclass file $B$K(B encode $B$5$l$?7?L>$N%F!<%V%k!W!#(B
// get $B$,8F$P$l$F%-%c%C%7%e$K$J$$>l9g$O!"(B
//$B$9$0$K(B FileSignature $B$r<h$j$@$7!"$=$l$,(B :class $B$+!"$=$l0J30$rH=JL!#(B
//$B!J(B FileSignature $B$N<h$j=P$7$N$?$a$K$O!"$^$:(B class file $B$rFI$s$G!"(B
// $B$D$$$G$K(B ClassData $B$r:n$C$F$7$^$$!"$"$H$G;H$&$^$G;}$C$F$$$k!#!K(B
// $B$=$7$F!"(B :class $B$J$i$P(B ClassType $B$r:n$k!#(B
// $B$=$l0J30$N>l9g$b(B Epp $B$G(B hook $B$r$+$1$k$h$&$K$7$F$*$/!#%G%U%)%k%H$O%(%i!<!#(B
//$B!J$=$N;~$N%(%i!<%a%C%;!<%8$b(B FileSignature $B$KKd$a9~$a$k$h$&$K$9$k!#!K(B
//  :class $B0J30$N7?$NAj8_;2>H$b!"$J$s$i$+$N7A$GEvA3%5%]!<%H$9$k!#(B
//
// $B$3$N%/%i%9$O!"(B TypeNameTable $B$H!"(B ReadJavaClass.java 
//$B$+$i$N$_%"%/%;%9$5$l$k!#(B Type.TObject $B$J$I$N=i4|2=$K$b;H$o$l$k!#(B
// $BB>$+$i$O!"40A4$K1#JC$5$l$F$$$k!#(B
public class ClassTypeTable {
  
  // $B$3$NJQ?t$NCM$O!"3F(B EPP $B%W%j%W%m%;%C%5$N=i4|2=%k!<%A%s$+$i$N$_;H$o$l$k!#(B
  // $B=i4|2=%k!<%A%s$G$O!"$3$NCM$rF0E*%9%3!<%WJQ?t(B :classTypeTable $B$KF~$l$k!#(B
  // $B$9$Y$F$N(B EPP $B%W%j%W%m%;%C%5$O!"F0E*%9%3!<%WJQ?t$rDL$7$F!"(B
  // ClassTypeTable $B$N%$%s%9%?%s%9$r6&M-$9$k!#(B
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static final ClassTypeTable instance = new ClassTypeTable();
  
  
  // key : fullName, val : Type;
  public Hashtable table = new Hashtable();
  
  // $B0z?t$G;XDj$5$l$?%/%i%9$N7?>pJs$r8!:w!#(B
  // $B0z?t$N(B name $B$O!"40A48BDjL>$rI=$9%7%s%\%k!#Nc!'(B :"java.lang.vector" $B!#(B
  // $B$^$:!"%-%c%C%7%e$K$J$$$+D4$Y$k!#(B
  // $B<!$K!"%+%l%s%H%G%#%l%H%j$N2<$K$"$k$J$i!"$9$G$K7?>pJs$,%U%!%$%k$K$"$k$O$:!#(B
  //$B$=$l$r$5$,$9!#!JL$<BAu!#!K(B
  // $B$=$l$G$b$J$$$H$$$&$3$H$O!"%+%l%s%H%G%#%l%/%H%j0J30$J$N$G!"(B
  //EPP $B$N;EMM$K$h$j!"(B CLASSPATH $B$N$I$3$+$K(B class file $B$,$"$k$b$N$H2>Dj$7!"(B
  //$B$=$l$r(B read $B$7$F(B ClassInfo $B$r@8@.$9$k!#(B
  // $B7?$,8+$D$+$i$J$$>l9g$O!"(B null $B$rJV$9!#(B
  public Type get(Symbol fullName) throws NotFound {
    Type t = (Type)table.get(fullName);
    if (t != null) return t;
    
    // FileSignature $B$,$"$k$J$P!"$9$G$K(B Type $B$O:n$i$l$F$$$k$O$:!#(B
    // $B$=$&$G$J$$$J$i!"(B class file $B$+$i!J(Blazy $B$K!K:n$k$b$N$H$9$k!#(B
    Obj epp = (Obj)Dynamic.get(:epp);
    Object classFile = epp!readClassFile(fullName);
    if (classFile == null){
      // class file $B$,B8:_$7$J$$>l9g$O!"(B null $B$rJV$9!#(B
      // $B$3$NJVCM$O!"(B GlobalTypeNameTable#doesClassExist $B$G%A%'%C%/$5$l$k!#(B
      throw NotFound.instance;
    }
    Tree classSig = epp!getEncodedClassSignatureTable(classFile);
    if (classSig == null){
      t = new ClassType(fullName, null, null, null, classFile);
    } else {
      throw Epp.fatal("Not implemented.");
      //t = new ClassType(fullName, classSig, typeNameTable, null);
    }
    if (t == null) throw Epp.fatal("");
    table.put(fullName, t);
    return t;
  }
  
  // EPP main routine $B$O!"(B
  // Phase1 $B$,=*$C$?$i!"$3$l$r;H$C$F(B FileSignature $B$rEPO?$9$k!#(B
  public void addFileSignature(Tree fileSig){
    if (fileSig.tag() != :fileSignature){
      throw Epp.fatal("Illegal FileSignature : "+ fileSig);
    }
    
    Tree packageDeclaration = fileSig.args()[0];
    Tree packageName;
    if (packageDeclaration.args().length == 0){
      packageName = `(name);
    } else {
      packageName = packageDeclaration.args()[0];
    }
    
    Tree[] typeDecls = fileSig.args()[2].args();
    for (int i = 0; i < typeDecls.length; i++){
      Tree lastNameTree = typeDecls[i].args()[0];
      if (lastNameTree.idName() != :void){
	Tree fullNameTree = `(name ,@(packageName.args()) ,lastNameTree);
	Symbol fullName = Symbol.intern(fullNameTree.nameToString());
	if (table.get(fullName) != null){
	  if (fullName == :"java.lang.String"
	      || fullName == :"java.lang.Object"
	      || fullName == :"java.lang.Class"){
	    // ClassType for these three classes are already instantiated
	    //as Type.TString, Type.TObject and Type.TClass .
	    System.err.println("NOTE: EPP creates Type from source code : "+
			       fullName);
	  } else {
	    throw Epp.fatal("ClassTypeTable.addFileSignature: "+
			    "The type "+ fullName+
			    " already exists in this table.");
	  }
	}
	// $B$3$l$O(B factory method $B$rDL$5$J$/$F$bNI$$!)(B
	TypeNameTable typeNameTable = new GlobalTypeNameTable(fileSig);
	// DVenv $B$OD>A0$K=hM}$7$?%U%!%$%k$N4D6-$,;D$C$F$$$k!#(B
	Obj epp = (Obj)Dynamic.get(:epp);
	Type t = epp!makeTypeFromTypeSignatureTree(fullName,
						   typeDecls[i],
						   typeNameTable);
	table.put(fullName, t);
      }
    }
  }

  
  // $B!V7?L>"*%U%!%$%kL>!WJQ49I=$r;H$C$F!"(B FileSignature $B%U%!%$%k$N(B
  //$B>l=j$r$5$,$7!"(B read $B$7$FJV$9!#(B
  public Tree readFileSignatureFile(Symbol fullName){
    throw Epp.fatal("Not implemented.");
    /*
      File file = new File(nameToFileSignatureFileName(fullName));
    if (file.exists()){
      
      try {
	ObjectInputStream in
	  = new ObjectInputStream(new FileInputStream(file));
	try {
	  return (Tree)in.readObject();
	}  finally {
	  in.close();
	}
      } catch (Exception e){
	throw Epp.fatal(e.toString());
      }
    } else {
      return null;
    }
    */
  }
  
  // eppout $B$N2<$K!"(B FileInputStream $B$r=q$-=P$9!#(B
  public void writeFileSignatureFile(Tree sig){
    throw Epp.fatal("Not implemented.");
    /*
      File file = new File(nameToFileSignatureFileName(fullName));
    try {
      ObjectWriter out
	= new ObjectWriter(new FileWriter(file));
      try {
	out.writeObject(sig);
      } finally {
	out.close();
      }
    } catch (Exception e){
      throw Epp.fatal(e.toString());
    }
    */
  }
  
  
  
  // $BG[Ns$N%a%=%C%I!&%U%#!<%k%I$K%"%/%;%9$9$k$?$a$KJX59E*$J(B ClassInfo $B$rJV$9!#(B
  public ClassInfo arrayClassInfo = null;
  public ClassInfo getArrayClassInfo(){
    if (arrayClassInfo == null){
      Obj epp = (Obj)Dynamic.get(:epp);
      
      // See JLS1.0 10.7 .
      //public class ArrayClassInfo implements Cloneable {
      //  public final int length = ...;
      //  public Object clone(){ return ...; }
      //}
      Tree classSig
	= `(class (modifiers (id public)) (id class) (id ArrayClassInfo)
	    (extends) (implements (name (id Cloneable)))
	    (classBody
	     (decl (modifiers (id public) (id final))
	      (name (id int)) (vardecls (id length)))
	     (method (modifiers (id public)) (name (id Object)) (id clone)
	      (formalParameters) (throws) (emptyStatement))));
      Tree dummyFileSig = `(fileSignature
			    (packageDeclaration)
			    (importDeclarations)
			    (typeDeclarations));
      Type dummyType = Type.TObject;
      TypeNameTable dummyTypeNameTable = new GlobalTypeNameTable(dummyFileSig);
      ClassData classData;
      Dynamic.bind(:typeNameTable, dummyTypeNameTable);
      try {
	classData = epp!treeToClassData(:"<array>",
					null,
					classSig,
					dummyType);
      } finally {
	Dynamic.unbind();
      }
      arrayClassInfo = epp!makeClassInfoFromClassData(classData);

      //System.out.println(arrayClassInfo);
    }
    return arrayClassInfo;
  }
}





//--------------------------------------------------
//--------------------------------------------------


public abstract class MemberInfo {
  protected Symbol name;
  protected Tree[] modifiers;
  protected Type declaringClass;

  public MemberInfo(Type declaringClass, Tree[] modifiers, Symbol name){
    this.declaringClass = declaringClass;
    this.modifiers = modifiers;
    this.name = name;
  }
  public Type getDeclaringClass(){ return declaringClass; }
  public Symbol getName() { return name; }
  public Tree[] getModifiers() { return modifiers; }
  //public boolean equals(Object obj)  { }
  //public int hashCode() { }
  public abstract String toString();
  public String modifiersToString(){
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < modifiers.length; i++){
      buf.append(modifiers[i].idName().toString());
      buf.append(' ');
    }
    return buf.toString();
  }
}

public class FieldInfo extends MemberInfo {
  Type type;
  
  // The tree should be normalized tree.
  public FieldInfo(Type declaringClass,
		   Tree[] modifiers, Type type, Symbol name){
    super(declaringClass, modifiers, name);
    this.type = type;
  }
  public boolean isAmbiguousField() { return false; }
  public Type getType() { return type; }
  public String toString(){
    return modifiersToString()+ type+ " "+ name;
  }
}
public class AmbiguousFieldInfo extends FieldInfo {
  FieldInfo[] ambiguousFields;
  
  // The tree should be normalized tree.
  public AmbiguousFieldInfo(Type declaringClass,
			    Symbol name, FieldInfo[] ambiguousFields){
    super(declaringClass, null, null, name);
    this.ambiguousFields = ambiguousFields;
  }
  public boolean isAmbiguousField() { return true; }
  public Tree[] getModifiers() {
    throw Epp.error("Ambiguous field name: "+ name);
  }
  public Type getType() {
    throw Epp.error("Ambiguous field name: "+ name);
  }

  public FieldInfo[] getAmbiguousFields() { return ambiguousFields; }

  public String toString(){
    StringBuffer buf = new StringBuffer();
    buf.append("AmbiguousFieldInfo(");
    for (int i = 0; i < ambiguousFields.length; i++){
      buf.append(ambiguousFields[i].toString()+ ", ");
    }
    buf.append(')');
    return buf.toString();
  }
}

public class MethodInfo extends MemberInfo {
  Type returnType;
  Type[] parameterTypes;
  Type[] exceptionTypes;
  
  // The tree should be normalized tree.
  public MethodInfo(Type declaringClass,
		    Tree[] modifiers,
		    Type returnType,
		    Symbol name,
		    Type[] parameterTypes,
		    Type[] exceptionTypes){
    super(declaringClass, modifiers, name);
    this.returnType = returnType;
    this.parameterTypes = parameterTypes;
    this.exceptionTypes = exceptionTypes;
  }
  public Type getReturnType() { return returnType; }
  public Type[] getParameterTypes() { return parameterTypes; }
  public Type[] getExceptionTypes() { return exceptionTypes; }
  public String toString(){
    StringBuffer buf = new StringBuffer();
    buf.append(modifiersToString()+ returnType+ " "+ name+ "(");
    if (parameterTypes.length > 0){
      buf.append(parameterTypes[0].toString());
      for (int i = 1; i < parameterTypes.length; i++){
	buf.append(", ");
	buf.append(parameterTypes[i].toString());
      }
    }
    buf.append(')');
    if (exceptionTypes.length > 0){
      buf.append(" throws ");
      buf.append(exceptionTypes[0].toString());
      for (int i = 1; i < exceptionTypes.length; i++){
	buf.append(", ");
	buf.append(exceptionTypes[i].toString());
      }
    }
    return buf.toString();
  }
}


public class ClassInfo extends MemberInfo {
  
  boolean isInterface;
  Type superclassType;
  Type[] interfaceTypes;
  MethodInfo[] constructors;
  Hashtable fieldTable;
  Hashtable methodTable;
  Hashtable innerClassTable;
  Hashtable classProperty;
  FieldInfo[] allFields;
  MethodInfo[] allMethods;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  Type[] allClasses;

  public ClassInfo(Type declaringClass,
		   Tree[] modifiers,
		   boolean isInterface,
		   Symbol fullName,
		   Type superclassType,
		   Type[] interfaceTypes,
		   MethodInfo[] constructors,
		   Hashtable fieldTable,
		   Hashtable methodTable,
		   Hashtable innerClassTable,
		   Hashtable classProperty){
    super(declaringClass, modifiers, fullName);
    this.isInterface = isInterface;
    this.superclassType = superclassType;
    this.interfaceTypes = interfaceTypes;
    this.constructors = constructors;
    this.fieldTable = fieldTable;
    this.methodTable = methodTable;
    this.innerClassTable = innerClassTable;
    this.classProperty = classProperty;
  }

  public MethodInfo[] getConstructors() { return constructors; }

  public FieldInfo[] getFields(){
    if (allFields == null) {
      Vector allFieldVec = new Vector();
      for (Enumeration e = fieldTable.elements(); e.hasMoreElements();){
	allFieldVec.addElement(e.nextElement());
      }
      allFields = new FieldInfo[allFieldVec.size()];
      allFieldVec.copyInto(allFields);
    }
    return allFields;
  }

  public MethodInfo[] getMethods(){
    if (allMethods == null) {
      Vector allMethodVec = new Vector();
      for (Enumeration e = methodTable.elements(); e.hasMoreElements();){
	MethodInfo[] methods = (MethodInfo[])e.nextElement();
	for (int i = 0; i < methods.length; i++){
	  allMethodVec.addElement(methods[i]);
	}
      }
      allMethods = new MethodInfo[allMethodVec.size()];
      allMethodVec.copyInto(allMethods);
    }
    return allMethods;
  }

  public Type[] getClasses(){
    if (allClasses == null) {
      Vector allClassVec = new Vector();
      for (Enumeration e = innerClassTable.elements(); e.hasMoreElements();){
	allClassVec.addElement(e.nextElement());
      }
      allClasses = new Type[allClassVec.size()];
      allClassVec.copyInto(allClasses);
    }
    return allClasses;
  }
  
  public FieldInfo getField(Symbol sym) throws NotFound {
    FieldInfo fieldInfo = (FieldInfo)fieldTable.get(sym);
    if (fieldInfo == null) {
      throw NotFound.instance;
    } else {
      return fieldInfo;
    }
  }

  public MethodInfo[] getOverloadedMethods(Symbol sym) throws NotFound {
    MethodInfo[] methodInfos = (MethodInfo[])methodTable.get(sym);
    if (methodInfos == null) {
      throw NotFound.instance;
    }
    return methodInfos;
  }
  
  public Type getClass(Symbol sym) throws NotFound {
    Type t = (Type)innerClassTable.get(sym);
    if (t == null) {
      throw NotFound.instance;
    } else {
      return t;
    }
  }

  public Type getSuperclass() { return superclassType; }

  public Type[] getInterfaces() { return interfaceTypes; }

  public boolean isInterface(){ return isInterface; }

  // These methods are only for the implementation of inheritance.
  public Hashtable getFieldTable() { return fieldTable; }
  public Hashtable getMethodTable() { return methodTable; }
  public Hashtable getInnerClassTable() { return innerClassTable; }

  public Object property(Symbol key){
    return classProperty.get(key);
  }
  
  public String toString(){
    StringBuffer buf = new StringBuffer();

    if (declaringClass != null){
      buf.append("Inner class of "+ declaringClass.classInfo().getName()+ ":"+
		 Opts.lineSeparator);
    }

    buf.append(modifiersToString()+
	    (isInterface() ? "interface " : "class ")+
	    name);
    Type superclass = getSuperclass();
    if (superclass != null){
      buf.append(" extends "+ superclass.classInfo().getName());
    }
    Type[] interfaces = getInterfaces();
    if (interfaces.length != 0){
      buf.append(" implements ");
      for (int i = 0; i < interfaces.length - 1; i++){
	buf.append(interfaces[i].classInfo().getName().toString());
	buf.append(", ");
      }
      buf.append(interfaces[interfaces.length - 1]
		 .classInfo().getName().toString());
    }
    buf.append(" {"+ Opts.lineSeparator);
    addMemberString(buf, getFields());
    addMemberString(buf, getConstructors());
    addMemberString(buf, getMethods());

    for (Enumeration e = innerClassTable.keys(); e.hasMoreElements();){
      buf.append("  Inner class : "+ e.nextElement()+ Opts.lineSeparator);
    }

    buf.append("}"+ Opts.lineSeparator);

    return buf.toString();
  }

  protected void addMemberString(StringBuffer buf, MemberInfo[] members){
    for (int i = 0; i < members.length; i++){
      buf.append("  ");
      buf.append(members[i].toString());
      Type declaringClass = members[i].getDeclaringClass();
      if (declaringClass != null){
	buf.append(" (declared in "+
		   declaringClass.classInfo().getName()+
		   ")");
      }
      buf.append(Opts.lineSeparator);
    }
  }
}

// ClassInfo $B$r:n$kA0CJ3,$N>pJs$r<uEO$7$9$k$?$a$N9=B$BN!#(B
public class ClassData {
  public Type outerClass;
  public Type declaringClass;	// The class currently processing.
  public Tree[] modifiers;
  public boolean isInterface;
  public Symbol fullName;
  public Type superclassType;
  public Type[] interfaceTypes;
  public MethodInfo[] constructors;
  public Hashtable fieldTable;
  public Hashtable methodTable;
  public Hashtable innerClassTable;
  public Hashtable classProperty;
  public ClassData(Type outerClass,
		   Type declaringClass,
		   Tree[] modifiers,
		   boolean isInterface,
		   Symbol fullName,
		   Type superclassType,
		   Type[] interfaceTypes,
		   MethodInfo[] constructors,
		   Hashtable fieldTable,
		   Hashtable methodTable,
		   Hashtable innerClassTable,
		   Hashtable classProperty){
    this.outerClass = outerClass;
    this.declaringClass = declaringClass;
    this.modifiers = modifiers;
    this.isInterface = isInterface;
    this.fullName = fullName;
    this.superclassType = superclassType;
    this.interfaceTypes = interfaceTypes;
    this.constructors = constructors;
    this.fieldTable = fieldTable;
    this.methodTable = methodTable;
    this.innerClassTable = innerClassTable;
    this.classProperty = classProperty;
  }
}



//--------------------------------------------------
//--------------------------------------------------

// $B%+%l%s%H%Q%C%1!<%8Fb$N%/%i%9L>$+!"(B import $B$5$l$?%/%i%9L>$+$i!"(B
//$B40A48BDjL>$r8!:w$9$k$?$a$N%/%i%9!#(B
public abstract class TypeNameTable {
  public abstract Type get(Tree name) throws NotFound ;
}


//
//
// TypeNameTable $B$b!"%;%C%7%g%sFb$G%-%c%C%7%e$9$Y$-!#Kh2s:n$kI,MW$J$$!#(B
// $B!J(BFileSignature $B$K$/$C$D$1$F$*$/$Y$-!#!K(B
public class GlobalTypeNameTable extends TypeNameTable {
  public Tree fileSig;

  public Tree packageName;
  public Tree[] importOnDemandNames;
  public String[] importOnDemandPrefixes; // Not used in the current version.
  // key : symbol without ".", val : tree of full name
  public Hashtable table = new Hashtable();
  
  // This table contains inner classes declared by import declarations.
  // key : Symbol, val : Type or Tree
  public Hashtable innerClassTable = new Hashtable();
  
  // $B%3%s%9%H%i%/%?$O!"(B FileSignature $B$N(B fileSig $B$r<u$1$H$k!#(B
  public GlobalTypeNameTable(Tree fileSig){
    // $B0z?t$O!"(B fileSignature $B$7$+Mh$J$$$h$&$KE}0l$7$?$$$,!":#$N$H$3$m!"(B
    // generateTypeNameTable $B$+$i8F$P$l$k;~$O!"(B CompilationUnit $B$,(B
    //$BEO$5$l$F$/$k!#(B
    //if (fileSig.tag() != :fileSignature){
    //  throw Epp.fatal("TypeNameTable: This is not a FileSignature: "+
    //                    fileSig);
    //}
    if (fileSig.tag() == :errorInCompilationUnit){
      // An empty file signature.
      fileSig = `(fileSignature
		  (packageDeclaration)
		  (importDeclarations)
		  (typeDeclarations));
    }

    this.fileSig = fileSig;

    // packageName is used by doesClassExist .
    Tree packageDeclaration = fileSig.args()[0];
    if (packageDeclaration.args().length == 0){
      // Actually, (name) is illegal as a AST
      //but I use it temporary for convenience.
      packageName = `(name);
    } else {
      packageName = packageDeclaration.args()[0];
    }
  }

  public void initialize(){

    table.put(:void, `(name (id void)));
    table.put(:char, `(name (id char)));
    table.put(:byte, `(name (id byte)));
    table.put(:short, `(name (id short)));
    table.put(:int, `(name (id int)));
    table.put(:long, `(name (id long)));
    table.put(:float, `(name (id float)));
    table.put(:double, `(name (id double)));
    table.put(:boolean, `(name (id boolean)));
    
    Tree importDeclaratoins = fileSig.args()[1];
    Tree[] args = importDeclaratoins.args();
    Vector onDemands = new Vector();
    onDemands.addElement(`(name (id java) (id lang))); // import java.lang.*;
    for (int i = 0; i < args.length; i++){

      if (args[i].tag() == :importSingle){
	Tree name = args[i].args()[0];
	Symbol sym = name.args()[name.args().length - 1].idName();
	Tree innerClassStaticTree = checkIfInnerClassName(name);
	if (innerClassStaticTree == null){
	  // It is not an inner class import declaration.
	  
	  if (table.get(sym) == null){
	    table.put(sym, name);
	  } else if (Tree.nameEqual((Tree)table.get(sym), name)) {
	    // If the same fullName is already declared, do nothing.
	  } else {
	    // If the name which has the same simple name
	    //has been already declared, error.
	    throw Epp.error("The name declared by the import declaration has been already declared. : "+ sym);
	  }
	} else {
	  // It is an inner class import declaration.
	  // Actually, I should check ambigous names.
	  innerClassTable.put(sym, innerClassStaticTree);
	}
	
      } else if (args[i].tag() == :importOnDemand){
	Tree name = args[i].args()[0];
	Tree innerClassStaticTree
	  = checkIfInnerClassName(`(name ,@(name.args())
				    ,(new Identifier(:dummy))));
	if (innerClassStaticTree == null){

	  // It is not an inner class import declaration.
	  Tree[] a = vectorToTreeArray(onDemands);
	found:
	  {
	    for (int j = 0; j < a.length; j++){
	      if (Tree.nameEqual(a[j], name)){
		// If the same name is already declared, do nothing.
		break found;
	      }
	    }
	    // If the same name has not been declared, add it to the Vector.
	    onDemands.addElement(name);
	  }
	} else {
	  // It is an inner class import declaration.
	  // Add all class members of the declared class into the table.
	  // ClassInfo of the outer class is instantiated.

	  // Remove the dummy field name. 
	  Tree outerClassTree = innerClassStaticTree.args()[0];
	  Type outer = innerClassStaticTreeToType(outerClassTree);
	  Hashtable iTable = outer.classInfo().getInnerClassTable();
	  for (Enumeration e = iTable.keys(); e.hasMoreElements();){
	    Symbol innerName = (Symbol)e.nextElement();
	    // Actually, I should check access flag.
	    // Actually, I should check ambigous names.
	    Type t = (Type)iTable.get(innerName);
	    innerClassTable.put(innerName, t);
	  }
	}
      } else {
	throw Epp.fatal("Illegal import declaration tree : "+ args[i]);
      }
    }
    importOnDemandNames = vectorToTreeArray(onDemands);

    // Setup importOnDemandNames.
    // However, this variable is not used.
    importOnDemandPrefixes = new String[importOnDemandNames.length];
    for (int i = 0; i < importOnDemandNames.length; i++){
      importOnDemandPrefixes[i] = importOnDemandNames[i].nameToString()+ ".";
    }

    fileSig = null;
  }

  // If  "import a.b.c.d.e;"  is declared,
  //check if a class named  a,  a.b,  a.b.c  or  a.b.c.d  exists.
  // If the class exists, the declaration is assumed to be
  //an inner class name.
  // Returns null or (innerClassStatic Type Identifier)
  public Tree checkIfInnerClassName(Tree name){
    Tree[] args = name.args();
    for (int i = 1; i < args.length; i++){
      Tree[] newArgs = new Tree[i];
      for (int j = 0; j < i; j++){
	newArgs[j] = args[j];
      }
      Tree newName = `(name ,@newArgs);
      if (doesClassExist(newName)){
	// a.b.c.D.E.F -> (((a.b.c.D).E).F)
	//         ^i
	// (The generated tree is only used by innerClassStaticTreeToType.)
	Tree ret = newName;
	for (int j = i; j < args.length; j++){
	  ret = `(innerClassStatic ,ret ,(args[j]));
	}
	return ret;
      }
    }
    return null;
  }

  public Type innerClassStaticTreeToType(Tree tree){
    if (tree.tag() == :name){
      ClassTypeTable classTypeTable
	= (ClassTypeTable)Dynamic.get(:classTypeTable);
      Symbol fullName = Symbol.intern(tree.nameToString());
      try {
	return classTypeTable.get(fullName);
      } catch (NotFound e){
	throw Epp.fatal("Class "+ tree+ " should exist.");
      }
    } else if (tree.tag() == :innerClassStatic){
      Type outer = innerClassStaticTreeToType(tree.args()[0]);
      Symbol name = tree.args()[1].idName();
      try {
	// Actually, I should check access flag.
	return outer.classInfo().getClass(name);
      } catch (NotFound e){
	// This case is a user error. Not fatal.
	throw Epp.error("Class "+ outer.classInfo().getName()+
			" is appeared at an import declaration "+
			"but it does not have a member "+ name+ " .");
      }
    } else {
      throw Epp.fatal(""+ tree);
    }
  }


  // $BC1=cL>$^$?$O40A48BDjL>$+$i7?$r8!:w$7$FJV$9!#(B
  // $B$J$$>l9g$O!"(B NotFound $B$r(B throw $B$9$k!#(B
  // $B$J$*!"$3$N%a%=%C%I$O!"(B ambigous $B$J(B name $B$r(B resolve $B$7$J$$!#(B
  // resolve $B$7$?$$!J$9$J$o$A(B ClassName.InnerClassName $B$r2r<a$7$?$$!K$H$-$O(B
  //epp!treeToType $B$r;H$&$3$H!#(B
  public Type get(Tree name) throws NotFound {
    if (fileSig != null){
      // inner class $B$N(B importOnDemand $B$N=hM}$b(B lazy $B$K9T$J$&!#(B
      //$B$9$Y$F$N%=!<%9$N(B FileSignature $B$,=PB7$&$^$($K(B
      //$B%/%i%9$K%"%/%;%9$9$k$H$*$+$7$/$J$k$N$G!#(B
      initialize();
    }

    Tree[] args = name.args();
    if (args.length == 1) {
      Symbol typeName = args[0].idName();
      if (typeName == :void){
	return Type.Tvoid;
      }

      Type prim = (Type)Type.primitiveTypeTable.get(typeName);
      if (prim != null){
	return prim;
      }

      Object obj = innerClassTable.get(typeName);
      if (obj == null){
	// Do nothing. Go ahead.
      } else if (obj instanceof Type){
	return (Type)obj;
      } else if (obj instanceof Tree){
	// Instanciate the type of inner class lazily
	//in order to create ClassInfo of the outer class lazily.
	Type ret = innerClassStaticTreeToType((Tree)obj);
	innerClassTable.put(typeName, ret);
	return ret;
      } else {
	throw Epp.fatal(""+ obj);
      }
    }

    ClassTypeTable classTypeTable
      = (ClassTypeTable)Dynamic.get(:classTypeTable);
    Symbol fullName = Symbol.intern(nameToFullName(name).nameToString());
    return classTypeTable.get(fullName);
  }

  // Utility.
  Tree[] vectorToTreeArray(Vector vec){
    Tree[] a = new Tree[vec.size()];
    vec.copyInto(a);
    return a;
  }

  
  // (name ...) $B$H$$$&7A$N(B Tree $B$r!"(B
  //$B40A48BDjL>$N%7%s%\%k$KJQ49$9$k%a%=%C%I!#(B
  // $B0J2<$N%k!<%k$KCm0U!#(B
  //$B!&=EJ#$7$?(B import $B@k8@$OL5;k$9$k!#(B
  //$B!&!JJQ?t$d!"%U%#!<%k%I$,$"$l$P!"$b$A$m$s$=$l$rM%@h!#!K(B
  //$B!&%7%s%0%k%$%s%]!<%H@k8@$r$^$:M%@h!#(B
  //$B!&<!$K!"8=:_$N%Q%C%1!<%8$GDj5A$5$l$F$$$l$P$=$l$rM%@h!#(B
  //$B!&:G8e$K!"(Bimport on demand $B@k8@$+$i!"C5$9!#J#?t8+$D$+$C$?$i!"%(%i!<!#(B 
  //$B!&(B importOnDemand $B$O!"(B public $B$J7?$N$_$r(B import $B$9$k!#(B
  //$B!&$3$N%a%=%C%I$O(B inner class $B$K$O4XCN$7$J$$!#(B
  public Tree nameToFullName(Tree tree) throws NotFound {
    if (tree.tag() != :name){
      throw Epp.fatal("TypeNameTable.nameToFullName: The arg is not a (name ...) : "+ tree);
    }
    Tree[] args = tree.args();
    if (args.length >= 2){
      // $BD9$5$,#20J>e$J$i$P!"$9$G$K40A48BDjL>!#$=$l$r$=$N$^$^JV$9!#(B
      //$B!J$=$N%/%i%9$,B8:_$9$k$+$I$&$+$O!"3N$+$a$J$$$3$H$K$9$k!#!K(B
      return tree;
    } else if (args.length < 1){
      throw Epp.fatal("");
    }
    // args.length == 1 .

    Symbol sym = args[0].idName();
    
    // $B%-%c%C%7%e$K$"$l$P!"$=$l$rJV$9!#(B
    Tree cachedName = (Tree)table.get(sym);
    if (cachedName != null) return cachedName;
    
    // $B!V%+%l%s%H%Q%C%1!<%8!W$K$"$k$+$I$&$+$r!"C5$9!#(B
    Tree nameInCurrentPackage = `(name ,@(packageName.args())
				  ,(args[0]));
    if (doesClassExist(nameInCurrentPackage)){
      table.put(sym, nameInCurrentPackage);
      return nameInCurrentPackage;
    } else {
      // importOnDemand $B$G@k8@$5$l$?(B prefix $B$r$D$1$F!"(B
      //public $B$J%/%i%9$,B8:_$9$k$+$I$&$+$I$&$+D4$Y$F$_$k!#$"$l$P!"$=$l$rJV$9!#(B
      // $BJ#?t8+$D$+$C$?$i%(%i!<!#(B
      Tree found = null;
      for (int i = 0; i < importOnDemandNames.length; i++){
	Tree check = `(name ,@(importOnDemandNames[i].args())
		       ,(args[0]));
	if (doesClassExist(check)){
	  if (found != null) {
	    throw Epp.error("import: "+ sym+ " is ambiguous: "+
			    found.nameToString()+ " or "+
			    check.nameToString()
			    );
	  }
	  found = check;
	}
      }
      if (found == null){
	throw NotFound.instance;
      } else {
	table.put(sym, found);
	return found;
      }
    }
  }

  // This method is called from nameToFullName.
  // This method returns true iff the class is accessible from
  //the current package.
  public boolean doesClassExist(Tree fullName){
    if (fullName.tag() != :name){
      throw Epp.fatal("doesClassExist: The argument is not a name:"+ fullName);
    }

    // If the finding class is in the same package, it may not be public class.
    // If in the other class, it must be public class.
    boolean mustBePublic = ! isSamePackage(fullName);
    
    ClassTypeTable classTypeTable
      = (ClassTypeTable)Dynamic.get(:classTypeTable);
    try {
      Type t = classTypeTable.get(Symbol.intern(fullName.nameToString()));
      if (! mustBePublic){
	return true;
      } else {
	return t.isPublic();
      }
    } catch (NotFound e){
      return false;
    }
  }

  public boolean isSamePackage(Tree fullName){
    Tree[] current = packageName.args();
    Tree[] finding = fullName.args();
    if (current.length != finding.length - 1) return false;
    for (int i = 0; i < current.length; i++){
      if (current[i].idName() != finding[i].idName()) return false;
    }
    return true;
  }
}


public class MemberTypeNameTable extends TypeNameTable {
  Type outerType;
  TypeNameTable next;
  public MemberTypeNameTable(Type outerType, TypeNameTable next){
    if (outerType == null) throw Epp.fatal("");
    this.outerType = outerType;
    this.next = next;
  }

  public Type get(Tree name) throws NotFound {
    if (name.args().length > 1){
      return next.get(name);
    }
    ClassInfo classInfo = outerType.classInfo();
    try {
      return classInfo.getClass(name.args()[0].idName());
    } catch (NotFound e){
      return next.get(name);
    }
  }
}


public class BlockTypeNameTable extends TypeNameTable {
  Symbol simpleName;
  Type type = null;
  TypeNameTable next;
  public BlockTypeNameTable(Symbol simpleName, TypeNameTable next){
    this.simpleName = simpleName;
    this.next = next;
  }

  public void setType(Type type){
    this.type = type;
  }

  public Type get(Tree name) throws NotFound {
    if (name.args().length > 1){
      return next.get(name);
    } else if (name.args()[0].idName() == simpleName){
      if (type == null) throw Epp.fatal(""+ name);
      return type;
    } else {
      return next.get(name);
    }
  }
}


public class HashtableTypeNameTable extends TypeNameTable {
  Hashtable innerClassTable;
  TypeNameTable next;
  public HashtableTypeNameTable(Hashtable innerClassTable,
				TypeNameTable next){
    this.innerClassTable = innerClassTable;
    this.next = next;
  }

  public Type get(Tree name) throws NotFound {
    if (name.args().length > 1) return next.get(name);
    Type t = (Type)innerClassTable.get(name.args()[0].idName());
    if (t == null){
      return next.get(name);
    } else {
      return t;
    }
  }
}
