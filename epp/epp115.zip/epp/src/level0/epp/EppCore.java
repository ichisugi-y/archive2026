/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles


package epp;
import SystemMixinRuntimes.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Stack;
import java.io.*;


SystemMixin AbstractEpp {
  define class Epp {
    Tree tree;

    // Constructor of Epp.
    define implement void Epp(String inputFileName, String outputFileName) {
      Dynamic.bind(:epp, self);
      Dynamic.bindInt(:lineNumberOfThisNode, -1);
      Dynamic.bindInt(:beginningPointOfThisNode, -1);
      Dynamic.bindInt(:endPointOfThisNode, -1);
      Dynamic.bind(:inputFileName, inputFileName);
      Dynamic.bind(:outputFileName, outputFileName);
      Dynamic.bind(:eppInputStream, null);
      //Dynamic.bindInt(:errorCounter, 0);
    }
    
    define implement void initializationPass(){ }
    define abstract void doParsingPass();
    define abstract void doMacroExpansionPass();
    define abstract void doTypeCheckingPass();
    define abstract void doCodeEmittingPass();
    
    define implement Error error(String str){
      printErrorMessage(str);
      // See also errorAt at TypeCheck.java .
      //old Dynamic.setInt(:errorCounter, Dynamic.getInt(:errorCounter) + 1);
      Opts.errorCounter++;
      return Epp.error(str);
    }

    // This method will be extended in order to print current status.
    define implement void printErrorMessage(String str){
      if (Opts.log) Opts.out.println(str);
      System.err.println(str);
    }
    define implement void printErrorMessageWithPointIndicator(int lineNumber,
							      int begin,
							      int end,
							      String str){

      EppInputStream in = (EppInputStream)Dynamic.get(:eppInputStream);
      String pointIndicator;
      if (in == null){
	pointIndicator = "";
      } else {
	pointIndicator =
	  Opts.lineSeparator+
	  in.errorPointIndicator(begin, end);
      }

      String mess = (String)Dynamic.get(:inputFileName)+ ":"+
	lineNumber+ ": "+ str+ pointIndicator;

      if (Opts.log) Opts.out.println(mess);
      System.err.println(mess);
    }

    /* old
    define implement Error error(String str){
      if (Opts.log) Opts.out.println("error(\""+ str+ "\") is called.");
      System.err.println(str);
      Dynamic.setInt(:errorCounter,
		     Dynamic.getInt(:errorCounter) + 1);
      return Epp.error(str);
    }
    */

  }
}

public class EppUserError extends Error {
  public EppUserError(String s){ super(s); }
}



SystemMixin AbstractParser {
  class Epp {
    define abstract Token lookahead();
    define abstract Token match(Token token);
    define abstract Token matchAny();
    define abstract Tree start();
  }
}




SystemMixin AbstractLex {
  class Epp {
    define abstract Token readToken(EppInputStream in);
  }
}

     
     
SystemMixin Parser {
  class Epp {
    
    Token token;
    
    extend void initializationPass() {
      original();
      Dynamic.set(:eppInputStream,
		  openEppInputStream((String)Dynamic.get(:inputFileName)));
      Dynamic.bindInt(:lineNumber, -1);
      Dynamic.bindInt(:beginningPoint, -1);
      Dynamic.bindInt(:endPoint, -1);
    }
    
    define default EppInputStream openEppInputStream(String inputFileName){
      return new EppInputStream(inputFileName);
    }
    
    implement Token lookahead() {
      return self!token;
    }
    
    implement Token match(Token token) {
      if (self!token == token) {
	return matchAny();
      } else {
	throw error("\""+ token+ "\" is expected before \""+
		    self!token+ "\"."); 
      }
    }
    
    implement Token matchAny() {
      EppInputStream eppIn = (EppInputStream)Dynamic.get(:eppInputStream);

      // Before invoking this method:
      //                  token1  \n    token2  ...
      //       self!token ^     ^ lex
      //
      // After invoking this method:
      //                  token1  \n    token2  ...
      //                     self!token ^     ^ lex
      Token token = self!token;
      self!token = readToken(eppIn);

      // Before invoking this method:
      //                  token1  \n    token2  ...
      //                        ^ endPoint
      //
      // After invoking this method:
      //                  token1  \n    token2  ...
      //     endPointOfThisNode ^             ^ endPoint
      Dynamic.setInt(:endPointOfThisNode, Dynamic.getInt(:endPoint));
      Dynamic.setInt(:endPoint, eppIn.pointer());

      if (Opts.printToken) Opts.out.println("Token : "+ self!token);
      return token;
    }

    // This method is redefined by another file.
    default Tree start() {
      throw Epp.fatal("Grammar rule for Start is not defined.");
    }

    implement void doParsingPass() {
      beforeParsingPass();

      if (Opts.log) Opts.out.println("Start parsing "+ (String)Dynamic.get(:inputFileName)+ " .");
      
      parsingPass();

      if (Opts.log) Opts.out.println("End parsing "+ (String)Dynamic.get(:inputFileName)+ " .");

      if (Opts.printTree) Opts.out.println("Parsed Tree:");
      if (Opts.printTree) self!tree.print(Opts.out);

      /*old
      if (! Opts.forceNextPass && Dynamic.getInt(:errorCounter) > 0){
	throw error(""+ Dynamic.getInt(:errorCounter)+ " errors");
      }
      */

      afterParsingPass();
    }
    
    define implement void beforeParsingPass(){}
    
    define implement void parsingPass(){
      Dynamic.bindInt(:lineNumber, 1);
      Dynamic.bindInt(:beginningPoint, 0);
      Dynamic.bindInt(:endPoint, -1);
      Dynamic.bindInt(:lineNumberOfThisNode, Dynamic.getInt(:lineNumber));
      Dynamic.bindInt(:beginningPointOfThisNode,
		      Dynamic.getInt(:beginningPoint));
      try {
	self!token = :dummy;
	matchAny();
	if (Opts.nocatch){
	  self!tree = start();
	} else {
	  try {
	    self!tree = start();
	  } catch (EppUserError e){
	    if (Opts.log) Opts.out.println("An error is caught by parsingPass().");
	    self!tree = new Tree(:errorInCompilationUnit);
	  }
	}
      } finally {
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }

    define implement void afterParsingPass(){}


    extend void printErrorMessage(String str){
      if (Dynamic.getInt(:lineNumber) != -1){
	if (Opts.log) Opts.out.println("Current token is \""+
				       lookahead()+ "\" : ");
	printErrorMessageWithPointIndicator(Dynamic.getInt(:lineNumber),
					    Dynamic.getInt(:beginningPoint),
					    Dynamic.getInt(:endPoint),
					    str);
      } else {
	original(str);
      }
    }

    /* old
    extend Error error(String str){
      if (Dynamic.getInt(:lineNumber) != -1){
	System.err.print((String)Dynamic.get(:inputFileName)+ ":"+
			 Dynamic.getInt(:lineNumber)+ ": "
			 );
	if (Opts.log) Opts.out.println("Current token is \""+ lookahead()+ "\" : ");
      }
      return original(str);
    }
    */
    
  }
}





SystemMixin Backtrack {
  
  class Epp {
    int lastPointer;

    extend Token matchAny() {
      EppInputStream eppIn = (EppInputStream)Dynamic.get(:eppInputStream);
      self!lastPointer = eppIn.pointer();
      return original();
    }

    define implement int inputPointer(){
      return self!lastPointer;
    }

    define implement void backtrack(int p){
      if (Opts.printToken) Opts.out.println("backtrack() is called.");

      // Before invoking this method:
      //                  token1    ...    tokenX
      //                p ^     self!token ^     ^ lex
      //
      // After invoking this method:
      //                  token1    ...    tokenX
      //       self!token ^     ^ lex


      // Before invoking this method:
      //                  token1    ...    tokenX
      //                p ^                      ^ endPoint
      //
      // After invoking this method:
      //                  token1    ...    tokenX
      //                        ^ endPoint
      // The value of endPointOfThisNode becomes -1.
      // Therefore, the endPoint of a Tree generated
      //just after backtrack becomes -1.

      EppInputStream eppIn = (EppInputStream)Dynamic.get(:eppInputStream);
      eppIn.backtrack(p);
      Dynamic.setInt(:endPoint, -1);
      matchAny();
    }
  }
}





SystemMixin Macro {
  
  class Epp {
    extend void initializationPass() {
      original();
      Dynamic.bind(:macroTable, new Hashtable());
      Dynamic.bind(:macroExpandingTree, null);
      initMacroTable();
    }
    
    define implement void initMacroTable() {
    }

    define implement void defineMacro(Symbol tag, Macro func) {
      Hashtable macroTable = (Hashtable)Dynamic.get(:macroTable);
      if (macroTable.get(tag) != null){
	throw Epp.fatal("Macro for :"+ tag+ " is already defined.");
      }
      macroTable.put(tag, func);
    }

    define implement void extendMacro(Symbol tag, Macro func) {
      Hashtable macroTable = (Hashtable)Dynamic.get(:macroTable);
      Macro orig = (Macro)macroTable.get(tag);
      if (orig == null){
	throw Epp.fatal("Macro for :"+ tag+ " is not defined.");
      }
      func.orig = orig;
      macroTable.put(tag, func);
    }

    implement void doMacroExpansionPass() {
      beforeMacroExpansionPass();

      if (Opts.log) Opts.out.println("Start macro expansion "+ (String)Dynamic.get(:inputFileName)+ " .");
      macroExpansionPass();
      if (Opts.log) Opts.out.println("End macro expansion "+ (String)Dynamic.get(:inputFileName)+ " .");
      if (Opts.printTree) {
	Opts.out.println();
	Opts.out.println("Macro expanded Tree:");
	self!tree.print(Opts.out);
      }

      /*old
      if (! Opts.forceNextPass && Dynamic.getInt(:errorCounter) > 0){
	throw error(""+ Dynamic.getInt(:errorCounter)+ " errors");
      }
      */

      afterMacroExpansionPass();
    }
    
    define implement void beforeMacroExpansionPass(){}
    
    define implement void macroExpansionPass() {
      if (Opts.nocatch){
	self!tree = Macro.macroExpandTree(self!tree);
      } else {
	try {
	  self!tree = Macro.macroExpandTree(self!tree);
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught by macroExpandTree().");
	  self!tree = new Tree(:errorInCompilationUnit);
	}
      }
    }

    define implement void afterMacroExpansionPass(){}

    extend void printErrorMessage(String str){
      Tree tree = (Tree)Dynamic.get(:macroExpandingTree);
      if (tree != null){
	printErrorMessageWithPointIndicator(tree.lineNumber(),
					    tree.beginningPoint(),
					    tree.endPoint(),
					    "Macro expansion error: "+ str);
      } else {
	original(str);
      }
    }
    /* old
       extend Error error(String str){
       Tree tree = (Tree)Dynamic.get(:macroExpandingTree);
       if (tree != null){
       System.err.println("User Error during macro expansion.");
       System.err.println("Line number of expanding tree :"+
       tree.lineNumber());
       }
       return original(str);
       }
    */

  }
}

public abstract class Macro {
  
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Macro orig = null;
  
  public abstract Tree call(Tree tree);
  
  public static Tree macroExpandTree(Tree tree){
    Hashtable macroTable = (Hashtable)Dynamic.get(:macroTable);
    Dynamic.bind(:macroExpandingTree, tree);
    try {
      Symbol lastTag = null;
      while(true) {
	Symbol tag = tree.tag();
	if (tag == lastTag) break;
	lastTag = tag;
	Macro func = (Macro)macroTable.get(tag);
	if (func != null) {
	  tree = func.call(tree);
	} else {
	  // This is the default macro expansion function.
	  // The following block does almost same job as:
	  // tree = tree.modifyArgs(macroExpandArray(tree.args()));
	  {
	    Tree[] args = tree.args();
	    int i;
	    Tree expanded;
	  changed:
	    {
	      for (i = 0; i < args.length; i++){
		expanded = macroExpandTree(args[i]);
		if (expanded != args[i]) break changed;
	      }
	      // Tree is not changed.
	      return tree;
	    }
	    Tree[] newArgs = new Tree[args.length];
	    for (int j = 0; j < i; j++){
	      newArgs[j] = args[j];
	    }
	    newArgs[i] = expanded;
	    for (i = i + 1; i < args.length; i++){
	      newArgs[i] = macroExpandTree(args[i]);
	    }
	    tree = tree.modifyArgs(newArgs);
	  }
	}
      }
      return tree;
    } finally {
      Dynamic.unbind();
    }
  }
  
  public static Tree macroExpand1(Tree tree){
    Hashtable macroTable = (Hashtable)Dynamic.get(:macroTable);
    Macro func = (Macro)macroTable.get(tree.tag());
    if (func == null) {
      return tree;
    } else {
      return func.call(tree);
    }
  }
  
  public static Tree[] macroExpandArray(Tree[] args){
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){
      newArgs[i] = macroExpandTree(args[i]); 
    }
    return newArgs;
  }

  public static void checkArgsLength(Tree tree, int argc){
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("The Macro requires "+ argc+
		      " args but supplied "+ args.length+ " :"+ tree);
    }
  }

  public static void addTree(Symbol sym, Tree tree){
    TreeVec tvec = (TreeVec)Dynamic.get(sym);
    tvec.add(macroExpandTree(tree));
  }


  // NOTE: Uniqueness of the returned Symbol is guaranteed only
  //  during one session of EPP.
  public static int genTempCounter = 0;
  public static Symbol genTemp(String prefix){
    return Symbol.intern(prefix + genTempCounter++);
  }

  public static Error error(String str){
    Obj epp = (Obj)Dynamic.get(:epp);
    return epp!error(str);
  }
}
       



     
SystemMixin InvokeStyleMacro {
  
  class Epp {
    
    extend void initializationPass() {
      original();
      Dynamic.bind(:invokeStyleMacroTable, new Hashtable());
      initInvokeStyleMacroTable();
    }
    
    define void defineInvokeStyleMacro(Symbol tag, InvokeStyleMacro func) {
      Hashtable invokeStyleMacroTable
	= (Hashtable)Dynamic.get(:invokeStyleMacroTable);
      if (invokeStyleMacroTable.get(tag) != null){
	throw Epp.fatal("InvokeStyleMacro for "+ tag+ " is already defined.");
      }
      invokeStyleMacroTable.put(tag, func);
    }
    
    define void redefineInvokeStyleMacro(Symbol tag, InvokeStyleMacro func) {
      Hashtable invokeStyleMacroTable
	= (Hashtable)Dynamic.get(:invokeStyleMacroTable);
      invokeStyleMacroTable.put(tag, func);
    }
    
    define void initInvokeStyleMacroTable() {
    }
    
    extend void initMacroTable() {
      original();
      defineMacro(:invoke1, new MacroForInvokeStyleMacro());
    }
  }
}


public class MacroForInvokeStyleMacro extends Macro {
  
  public Tree call(Tree tree) {
    Hashtable invokeStyleMacroTable
      = (Hashtable)Dynamic.get(:invokeStyleMacroTable);
    Symbol lastMethodName = null;
    while (true){
      // (invoke1 (id methodName) (argumentList ...))
      Tree[] args = tree.args();
      if (args[0].tag() != :id) {
	throw Epp.fatal("The first arg of invoke-1 is :"+ args[0]);
      }
      if (args[1].tag() != :argumentList) {
	throw Epp.fatal("The second arg of invoke-1 is :"+ args[1]);
      }

      Symbol methodName = args[0].idName();
      if (methodName == lastMethodName) break;
      lastMethodName = methodName;
      InvokeStyleMacro func =
	(InvokeStyleMacro)invokeStyleMacroTable.get(methodName);
      if (func != null) {
	tree = func.call(tree, args[1].args());
	// If the expanded tree is invoke1 again, continue this loop.
	// Otherwise, exit this loop. In this case, 
	//the new tree will be expanded by macroExpandTree .
	if (tree.tag() != :invoke1) break;
      } else {
	// This is the default invokeStyleMacro .
	tree = tree.modifyArgs(macroExpandArray(tree.args()));
      }
    }
    return tree;
  }
}

public abstract class InvokeStyleMacro {

  public abstract Tree call(Tree tree, Tree[] args);

  // Utility functions for macro programers.
  
  public static void checkInvocationArgsLength(Tree tree, int argc){
    // tree : (invoke1 (id "foo") (argumentList ...))
    Tree[] args = tree.args()[1].args();
    if (args.length != argc){
      throw error("InvokeStyleMacro: This macro requires "+ argc+
		  " args but supplied "+ args.length+ " :"+ tree);
    }
  }

  public static Symbol genTemp(String prefix){
    return Macro.genTemp(prefix);
  }

  public static Error error(String str){
    return Macro.error(str);
  }
}




     
SystemMixin Emitter {
  
  class Epp {

    extend void initializationPass() {
      original();
      Dynamic.bind(:emitterTable, new Hashtable());
      initEmitterTable();
    }
    
    define void initEmitterTable() {
    }
    
    define void defineEmitter(Symbol tag, Emitter func) {
      Hashtable emitterTable = (Hashtable)Dynamic.get(:emitterTable);
      if (emitterTable.get(tag) != null){
	throw Epp.fatal("Emitter for :"+ tag+ " is already defined.");
      }
      emitterTable.put(tag, func);
    }
    
    define void redefineEmitter(Symbol tag, Emitter func) {
      Hashtable emitterTable = (Hashtable)Dynamic.get(:emitterTable);
      emitterTable.put(tag, func);
    }
    
    implement void doCodeEmittingPass() {
      beforeCodeEmittingPass();
      codeEmittingPass();
      afterCodeEmittingPass();
    }

    define implement void beforeCodeEmittingPass(){}
    
    define implement void codeEmittingPass() {
      emit1((String)Dynamic.get(:outputFileName), self!tree);
    }

    define implement void afterCodeEmittingPass(){}
    
    define void emit1(String outputFileName, Tree tree){
      
      File outFile = new File(outputFileName);

      if (outFile.exists() && ! Epp.isGeneratedFile(outputFileName)){
	throw error("The output file "+ outputFileName+ " already exists and "+
		    "it seems not to be generated by EPP.");
      }

      // Make subdirectries under eppout if necessary.
      String outDirName = outFile.getParent();
      if (outDirName != null) {
	if (new File(outDirName).mkdirs()){
	  if (Opts.log) Opts.out.println("A directory is created: "+
					 outDirName);
	}
      }

      Writer out;
      try {
	if (Opts.encoding == null){
	  out = new BufferedWriter
	    (new OutputStreamWriter(new FileOutputStream(outputFileName)));
	} else {
	  out = new BufferedWriter
	    (new OutputStreamWriter(new FileOutputStream(outputFileName),
				    Opts.encoding));
	}
      } catch (IOException e){
	System.err.println(e);
	throw Epp.fatal("Output file "+ outputFileName+
			" could not be opened.");
      }
      
      Dynamic.bindInt(:outputIndent, 0);
      Dynamic.bindInt(:outputLineNumber, 1);
      try {
	if (Opts.log) Opts.out.println("Start emitting "+ outputFileName+ " .");
	emitAdditionalHeader(out);
	Emitter.emitTree(out, tree);
	if (Opts.log) Opts.out.println("End emitting.");
      } finally {
	try {
	  String nl = Opts.lineSeparator;
	  for (int i = 0; i < nl.length(); i++) out.write(nl.charAt(i));
	  out.close();
	} catch (IOException e){
	  throw error(e.toString());
	}
	Dynamic.unbindInt();
	Dynamic.unbindInt();
      }
    }

    define implement void emitAdditionalHeader(Writer out){
      ;				// Do nothing. 
    }
  }
}

public abstract class Emitter {
  
  public abstract void call(Writer out, Tree tree) throws IOException;
  
  // Utility functions.
  public static void emitTree(Writer out, Tree tree){
    try {
      
      int lineNumber = tree.lineNumber();
      if (lineNumber != -1 && ! Opts.newlineForReadability){
	int to = lineNumber;
	int current = Dynamic.getInt(:outputLineNumber);
	while (current < to) {
	  outputNewlineAndIndent(out);
	  current++;
	}
	Dynamic.setInt(:outputLineNumber, current);
      }
      
      Hashtable emitterTable = (Hashtable)Dynamic.get(:emitterTable);
      Emitter func = (Emitter)emitterTable.get(tree.tag());
      if (func != null) {
	func.call(out, tree);
      } else {
	System.err.println("Emitter fuction is not defined for "+ tree.tag());
	// fastjavac of "JDK1.1.3/jws:1997.09.16" ignores this exception.
	throw Epp.fatal("Emitter fuction is not defined for "+ tree.tag());
      }
    } catch (IOException e){
      throw error(e.toString());
    }
  }
  
  public static void emitString(Writer out, String str)
    throws IOException {
      for (int i = 0; i < str.length(); i++){
	out.write(str.charAt(i));
      }
    }
  
  public static void checkArgsLength(Tree tree, int argc){
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("The Emitter requires "+ argc+
		      " args but supplied "+ args.length+ " :"+ tree);
    }
  }
  
  public static void outputNewlineAndIndent(Writer out)
    throws IOException {
      // Newline
      String nl = Opts.lineSeparator;
      for (int i = 0; i < nl.length(); i++) out.write(nl.charAt(i));
      // Indent
      int indent = Dynamic.getInt(:outputIndent);
      for (int i = 0; i < indent; i++) out.write(' ');
    }
  
  public static void outputNewlineForReadability(Writer out)
    throws IOException{
      if (Opts.newlineForReadability){
	outputNewlineAndIndent(out);
      }
    }

  public static Error error(String str){
    Obj epp = (Obj)Dynamic.get(:epp);
    return epp!error(str);
  }
}

public class SimpleEmitter extends Emitter {
  
  public String format;
  public int argc;
  
  public SimpleEmitter(String format){
    this.format = format;
    argc = 0;
    int length = format.length();
    for (int i = 0; i < length; i++){
      if (format.charAt(i) == '%') argc++;
    }
  }
  
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("SimpleEmitter: The format string \""+ format+
		      "\" requires "+ argc+ " args but supplied "+
		      args.length+ " :"+ tree);
    }
    int length = format.length();
    int j = 0;
    for (int i = 0; i < length; i++){
      if (format.charAt(i) == '%') {
	emitTree(out, args[j++]);
      } else {
	out.write(format.charAt(i));
      }
    }
  }
}




// The node :stringNode is created by method StringNode.gen .
SystemMixin StringNode {
  class Epp {
    extend void initEmitterTable() {
      original();
      defineEmitter(:stringNode, new StringNodeEmitter());
    }
  }
}

public class StringNode {
  public static Tree gen(String format, Tree[] args){
    return new Tree(:stringNode, new LiteralTree(:stringNodeFormat, format),
		    new Tree(:stringNodeArguments, args));
  }
  public static Tree gen(String format){
    Tree[] a = {}; return gen(format, a); }
  public static Tree gen(String format,Tree a1){
    Tree[] a = {a1}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2){
    Tree[] a = {a1,a2}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2,Tree a3){
    Tree[] a = {a1,a2,a3}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2,Tree a3,Tree a4){
    Tree[] a = {a1,a2,a3,a4}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2,Tree a3,Tree a4,
			 Tree a5){
    Tree[] a = {a1,a2,a3,a4,a5}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2,Tree a3,Tree a4,
			 Tree a5,Tree a6){
    Tree[] a = {a1,a2,a3,a4,a5,a6}; return gen(format, a); }
  public static Tree gen(String format,Tree a1,Tree a2,Tree a3,Tree a4,
			 Tree a5,Tree a6,Tree a7){
    Tree[] a = {a1,a2,a3,a4,a5,a6,a7}; return gen(format, a); }
}

class StringNodeEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    checkArgsLength(tree, 2);
    String format = tree.args()[0].literalToken().literalContents();
    Tree[] args = tree.args()[1].args();
    int argc = 0;
    int length = format.length();
    int i = 0;
    
    while (i < length){
      char c = format.charAt(i++);
      if (c == '%') {
	if (i < length){
	  c = format.charAt(i++);
	  if (c == 't'){
	    if (argc < args.length){
	      emitTree(out, args[argc++]);
	    } else {
	      throw Epp.fatal("StringNode: Less than "+ (argc + 1)+
			      " argument is specified for \""+
			      format+ "\"");
	    }
	  } else if (c == '%'){
	    out.write('%');
	  } else {
	    throw Epp.fatal("StringNode: Format string error: %"+ c);
	  }
	} else {
	  throw Epp.fatal("StringNode: Format string error: \""+ format+ "\"");
	}
      } else if (c == '\n' || c == '\r'){
	throw Epp.fatal("StringNode: format string error: "+
			"Line separaters are not allowed.");
      } else {
	out.write(c);
      }
    }
    if (argc < args.length){
      throw Epp.fatal("StringNode: More than "+ argc+
		      " argument is specified for \""+
		      format+ "\"");
    }
  }
}





SystemMixin EppVersion {
  class Epp {
    extend void initializationPass(){
      if (Opts.log) Opts.out.println("Start EPP "+ eppVersion());
      original();
    }

    extend void emitAdditionalHeader(Writer out){
      String str = "/* Generated by EPP "+ eppVersion()+ " */";
      for (int i = 0; i < str.length(); i++){
	try{
	  out.write(str.charAt(i));
	} catch (IOException e){
	  throw error(e.toString());
	}
      }
      original(out);
    }

    // This method returns the version of binary generated from this source.
    define default String eppVersion(){
      return eppSourceVersion()+
	" (by "+
	  Opts.eppTranslatorVersion+
	    ")"+ (Opts.sml ? " with -sml " : "");
    }

    define default String eppSourceVersion(){
      return Opts.eppSourceVersion;
    }

    extend void initInvokeStyleMacroTable() {
      original();
      defineInvokeStyleMacro(:EPP_VERSION, new EPP_VERSIONMacro());
    }
  }
}

// This is the difinition of the built-in macro, EPP_VERSION.
// If an expression EPP_VERSION() appears in a Java source code,
// it will be translated to a string
// which indicates version of EPP binary
// translating the Java source code.
class EPP_VERSIONMacro extends InvokeStyleMacro {
  public Tree call(Tree tree, Tree[] args){
    checkInvocationArgsLength(tree, 0);
    Obj epp = (Obj)Dynamic.get(:epp);
    return new LiteralTree(:string, epp!eppVersion());
  }
}
