/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote

package epp;
import SystemMixinRuntimes.*;
import java.util.Hashtable;
import java.util.Vector;

//--------------------------------------------------
//--------------------------------------------------


SystemMixin TypeSystem {
  
  class Epp {

    extend void initializationPass() {
      original();

      Dynamic.bind(:classTypeTable, ClassTypeTable.instance);
    }
    
    
    //--------------------------------------------------
    // Conformance checking methods.
    
    define implement boolean equals(Type t1, Type t2){
      Symbol s1 = t1.tag();
      Symbol s2 = t2.tag();
      if (s1 == s2){
	if (t1.isPrimitiveType()){
	  return true;
	} else if (s1 == :class){
	  return ((ClassType)t1).getName() == ((ClassType)t2).getName();
	} else if (s1 == :arrayOf){
	  return Type.equals(((ArrayType)t1).getComponentType(),
			     ((ArrayType)t2).getComponentType());
	} else if (s1 == :void){
	  return true;
	} else if (s1 == :null){
	  return true;
	} else {
	  throw Epp.fatal("Type.equals: Unknown type : "+
			  t1.getClass().getName()+ 
			  " : tag = "+ s1+ " : "+ t1);
	}
      } else {
	return false;
      }
    }
    
    // Confirm whether the tree is assignable to the type
    //(without implicit downward conversion).
    define void confirmType(Type type, Tree tree){
      if (! isSuperType(type, tree.type())){
	throw errorAt(tree,
		      "Can not convert "+ tree.type()+ " to "+ type+ " .");
      }
    }
    
    // Return true iff t1 is a super type or same type of t2.
    // If t1 is "unknown extended type", fatal error will be thrown.
    // Otherwise, if t2 is "unknown extended type", false will be returned.
    define implement boolean isSuperType(Type t1, Type t2){
      if (t1.isPrimitiveType()){
	Symbol s1 = t1.tag();
	Symbol s2 = t2.tag();
	// Shortcut.
	if (s1 == s2) return true;
	if (s1 == :boolean){
	  return s2 == :boolean;
	} else if (s1 == :double){
	  return s2 == :double || s2 == :float || s2 == :long
	    || s2 == :int || s2 == :char || s2 == :short || s2 == :byte;
	} else if (s1 == :float){
	  return s2 == :float || s2 == :long
	    || s2 == :int || s2 == :char || s2 == :short || s2 == :byte;
	} else if (s1 == :long){
	  return s2 == :long
	    || s2 == :int || s2 == :char || s2 == :short || s2 == :byte;
	} else if (s1 == :int){
	  return s2 == :int || s2 == :char || s2 == :short || s2 == :byte;
	} else if (s1 == :short){
	  return s2 == :short || s2 == :byte;
	} else if (s1 == :char){
	  return s2 == :char || s2 == :byte;
	} else if (s1 == :byte){
	  return s2 == :byte;
	} else {
	  throw Epp.fatal("Type.isSuperType: Unknown primitive type."+ t1);
	}
      } else if (t1.tag() == :void){
	return t2.tag() == :void;
      } else if (t1.tag() == :arrayOf){
	if (t2.tag() == :arrayOf){
	  return isSuperType(((ArrayType)t1).getComponentType(),
			     ((ArrayType)t2).getComponentType());
	} else {
	  return t2.tag() == :null;
	}
      } else if (t1.tag() == :class){
	if (t2.tag() == :class){
	  // Shortcut.
	  if (t1.classInfo().getName() == t2.classInfo().getName()) {
	    return true;
	  }
	  ClassInfo info1 = t1.classInfo();
	  ClassInfo info2 = t2.classInfo();
	  if (info1.isInterface()){
	    // info2 may be class or interface.
	    return doesImplement(info1, info2);
	  } else if (info2.isInterface()){
	    // info1 is class, info2 is interface.
	    return info1.getName() == :"java.lang.Object";
	  } else {
	    // Both info1 and info2 are classes.
	    return isAncestor(info1, info2);
	  }
	} else if (t2.tag() == :arrayOf){
	  // "array" extends Object implements Cloneable
	  ClassInfo info1 = t1.classInfo();
	  ClassTypeTable classTypeTable
	    = (ClassTypeTable)Dynamic.get(:classTypeTable);
	  ClassInfo arrayClassInfo = classTypeTable.getArrayClassInfo();
	  if (info1.isInterface()){
	    return doesImplement(info1, arrayClassInfo);
	  } else {
	    // Both info1 and info2 are classes.
	    return isAncestor(info1, arrayClassInfo);
	  }
	} else {
	  // If t1 is a reference type and t2 is a primitive type,
	  //return true iff t2 is a null type.
	  return t2.tag() == :null;
	}
      } else if (t1.tag() == :null) {
	return t2.tag() == :null;
      } else {
	throw Epp.fatal("Type.isSuperType: Unknown type : "+ t1+
			", typeCheckingTree = "+
			Dynamic.get(:typeCheckingTree));
      }
    }
    
    // Return true iff info1 is an ancestor of info2 or info1 equals info2.
    define implement boolean isAncestor(ClassInfo info1, ClassInfo info2){
      while (true){
	if (info1.getName() == info2.getName()) return true;
	Type superclassType = info2.getSuperclass();
	if (superclassType == null) return false;
	info2 = superclassType.classInfo();
      }
    }
    
    // Return true iff info1 equals info2
    //or a interface info1 is implemented by a class info2
    //or a interface info1 is extended by a interface info2 .
    define implement boolean doesImplement(ClassInfo info1, ClassInfo info2){
      if (info1.getName() == info2.getName()) return true;
      Type superClass = info2.getSuperclass();
      if (superClass != null){
	if (doesImplement(info1, superClass.classInfo())){
	  return true;
	}
      }
      Type[] interfaces = info2.getInterfaces();
      for (int i = 0; i < interfaces.length; i++){
	if (doesImplement(info1, interfaces[i].classInfo())){
	  return true;
	}
      }
      return false;  
    }
    
    //--------------------------------------------------
    // coercion

    // $B0z?t$N(B tree $B$,!"7?(B type $B$H$7$F;HMQ2DG=$+$r%A%'%C%/$7!"(B tree $B$rJV$9!#(B
    // $B;HMQIT2DG=$J>l9g$O!"%(%i!<$K$9$k!#(B
    // tree $B$N7?$O!"JQ99$9$kI,MW$O$J$$!#(B
    //$B!JNc$($P(B int $B7?$N(B tree $B$O(B double $B7?$H$7$F;H$($k$N$G(B
    // tree $B$O$=$N$^$^JV$7$F$b$h$$!#!K(B
    define implement Tree coerce(Type type, Tree tree){
      confirmType(type, tree);
      // $BI8=`$N(B Java $B$G$O!"$9$Y$F$N(B tree $B$O$=$N$^$^JV$;$P$h$$!#(B
      //$B$"$H$O(B javac $B$,JQ49$7$F$/$l$k!#(B
      return tree;
    }

    // Assignment conversion.  See JLS1.0 5.2 .
    // This implementation is not enough.
    // This method is called from SimpleAssignmentOperatorTypeChecker,
    // ReturnWithExpTypeChecker and coerceVariableInitializer.
    define implement Tree assignmentConversion(Type type, Tree tree){
      Type t1 = type;
      Type t2 = tree.type();
      Symbol s1 = t1.tag();
      Symbol s2 = t2.tag();
      if ((s1 == :byte || s1 == :short || s1 == :char) &&
	  (s2 == :int || s2 == :byte || s2 == :short || s2 == :char)){
	// $BK\Ev$O1&JU$NCM$,Dj?t<0$G$"$k>l9g$K$=$NCM$,!":8JU$N7?$K<}$^$k$+$r(B
	//$B%A%'%C%/$7$J$1$l$P$J$i$J$$!#(B
	return tree;
      } else {
	return coerce(type, tree);
      }
    }


    
    //--------------------------------------------------
    define implement FieldInfo selectField(Type targetType,
					   Symbol fieldName){
      ClassInfo targetClassInfo = getTargetClassInfo(targetType);

      FieldInfo field;
      try {
	field = targetClassInfo.getField(fieldName);
      } catch (NotFound e){
	throw new EppTypeError("Field \""+ fieldName+
			       "\" is not defined at "+
			       targetClassInfo.getName()+ " .");
      }
      // $B%"%/%;%98"$N%A%'%C%/>JN,!#(B
      return field;
    }	

    define implement ClassInfo getTargetClassInfo(Type targetType){
      if (targetType.tag() == :class){
	return targetType.classInfo();
      } else if (targetType.tag() == :arrayOf){
	ClassTypeTable classTypeTable
	  = (ClassTypeTable)Dynamic.get(:classTypeTable);
	return classTypeTable.getArrayClassInfo();
      } else {
	throw new EppTypeError("The type can not be used as a class : "+
			       targetType);
      }
    }


    //--------------------------------------------------
    // Method overloading.
    
    // $B7?%A%'%C%/$9$k$^$($N(B argumentList $B$rEO$9!#(B
    // $B7k2L$O!"7?%A%'%C%/$H(B coerce $B$:$_$N(B argumentList $B!#(B
    define implement Object[] typeCheckAndSelectMethod(Type targetType,
						       Symbol methodName,
						       Tree argumentList,
						       boolean findOuterClass
						       ){
      ClassInfo targetClassInfo = getTargetClassInfo(targetType);
      
      MethodInfo[] candidates = null;
      
      while (true){
	try {
	  candidates = targetClassInfo.getOverloadedMethods(methodName);
	  break;
	} catch (NotFound e){
	  if (findOuterClass){
	    Type outerClass = targetClassInfo.getDeclaringClass();
	    if (outerClass != null){
	      targetClassInfo = outerClass.classInfo();
	      continue;
	    }
	  }
	  // findOuterClass == false  or  outerClass == null
	  throw new EppTypeError("Method \""+ methodName+
				 "\" is not defined at "+
				 targetType+ " .");
	}
      }

      Tree newArgumentList = TypeChecker.typeCheckTree(argumentList);

      MethodInfo selectedMethod
	= selectMostSpecificMethod(methodName.toString(),
				   candidates,
				   targetType,
				   newArgumentList);
      return new Object[]{ selectedMethod,
			   coerceArgumentList(newArgumentList, selectedMethod)
			   };
    }

    // This method is called from typeCheckAndSelectMethod and NewTypeChecker.
    // # "methodName" and "targetType" are
    // # only used for generating error message.
    define implement MethodInfo selectMostSpecificMethod(String methodName,
							 MethodInfo[] methods,
							 Type targetType,
							 Tree argumentList){
      
      // Overload $B2r7h$N%"%k%4%j%:%`(B:
      //  $B$^$:!"%"%/%;%92DG=$G!"<B0z?t$KE,9g$9$k(B method $B$K8uJd$r9J$k!#$=$7$F(B
      // $B#1$D$E$D!"!V$=$N%a%=%C%I$,!"B>$N$9$Y$F$N8uJd$h$j$b(B specific $B$+!W$r(B
      // $BD4$Y$k!#$b$78+$D$+$l$P!"$=$l$K3NDj!##1$D$b$J$1$l$P%(%i!<!#(B
      Vector candidateVec = new Vector();
      for (int i = 0; i < methods.length; i++){
	// $B%"%/%;%92DG=$+$I$&$+$N%A%'%C%/$O!"$H$j$"$($:L5;k!#(B
	//$B%Q%C%1!<%8$rD4$Y$J$1$l$P$J$i$:!"$1$C$3$&LLE]!#(B
	if (confirmArgs(methods[i], argumentList)){
	  candidateVec.addElement(methods[i]);
	}
      }
      MethodInfo[] candidate = new MethodInfo[candidateVec.size()];
      candidateVec.copyInto(candidate);
      
      if (candidate.length == 0){
	throw new EppTypeError("No method matching "+
			       methodName+
			       argumentListToSignatureString(argumentList)+
			       " found in "+ targetType+ " .");
      }
      
      for (int i = 0; i < candidate.length; i++){
      checkNextCandidate:
	{
	  for (int j = 0; j < candidate.length; j++){
	    if (i != j &&
		! moreSpecificMethod(candidate[i], candidate[j])){
	      break checkNextCandidate;
	    }
	  }
	  // The most specific method is found.
	  return candidate[i];
	}
      }
      {
	String msg = "Reference to "+ methodName+ " is ambiguous. ";
	for (int i = 0; i < candidate.length; i++){
	  msg += methodName+ "(";
	  Type[] types = candidate[i].getParameterTypes();
	  if (types.length > 0){
	    msg += types[0];
	    for (int j = 1; j < types.length; j++){
	      msg += ", "+ types[j];
	    }
	  }
	  msg += ") ";
	}
	msg += "in "+ targetType+ " .";
	throw new EppTypeError(msg);
      }
    }
    
    define implement boolean confirmArgs(MethodInfo method, Tree argumentList){
      Tree[] args = argumentList.args();
      Type[] argTypes = method.getParameterTypes();
      if (args.length != argTypes.length) {
	return false;
      }
      for (int i = 0; i < args.length; i++){
	if (! isSuperType(argTypes[i], args[i].type())){
	  return false;
	}
      }
      return true;
    }
    
    // Return true iff m1 is more specific than m2. 
    // (In other words, if each m2''s parameter is super type of m1''s one.)
    define implement boolean moreSpecificMethod(MethodInfo m1, MethodInfo m2){
      Type[] a1 = m1.getParameterTypes();
      Type[] a2 = m2.getParameterTypes();
      if (a1.length != a2.length) return false;
      for (int i = 0; i < a1.length; i++){
	if (! Type.isSuperType(a2[i], a1[i])){
	  return false;
	}
      }
      return true;
    }
    
    define implement Tree coerceArgumentList(Tree argumentList,
					     MethodInfo selectedMethod){
      Tree[] args = argumentList.args();
      Tree[] newArgs = new Tree[args.length];
      Type[] argTypes = selectedMethod.getParameterTypes();
      if (args.length != argTypes.length) {
	throw Epp.fatal("coerceArgumentList");
      }
      for (int i = 0; i < args.length; i++){
	newArgs[i] = coerce(argTypes[i], args[i]);
      }
      return argumentList.modifyArgs(newArgs);
    }
    
    define implement String argumentListToSignatureString(Tree argumentList){
      StringBuffer buf = new StringBuffer();
      Tree[] args = argumentList.args();
      buf.append("(");
      if (args.length > 0){
	for (int i = 0; i < args.length - 1; i++){
	  buf.append(args[i].type().toString()+ ", ");
	}
	buf.append(args[args.length - 1].type().toString());
      }
      buf.append(")");
      return buf.toString();
    }
    
    //--------------------------------------------------

    define implement Type selectInnerClass(Type targetType,
					   Symbol innerClassName){
      ClassInfo targetClassInfo;
      if (targetType.tag() == :class){
	targetClassInfo = targetType.classInfo();
      } else if (targetType.tag() == :arrayOf){
	ClassTypeTable classTypeTable
	  = (ClassTypeTable)Dynamic.get(:classTypeTable);
	targetClassInfo = classTypeTable.getArrayClassInfo();
      } else {
	throw new EppTypeError("Illegal target type for innerClass access : "+
			       targetType);
      }

      Type innerClass;
      try {
	innerClass = targetClassInfo.getClass(innerClassName);
      } catch (NotFound e){
	throw new EppTypeError("Inner class \""+ innerClassName+
			       "\" is not defined at "+
			       targetClassInfo.getName()+ " .");
      }
      // $B%"%/%;%98"$N%A%'%C%/>JN,!#(B
      return innerClass;
    }	

    //--------------------------------------------------
    // Type checking of block.
    
    define implement void typeCheckBlockStatements(int i,
						   Tree[] args,
						   TreeVec newArgs){
      if (i == args.length) {
	return;
      } else {
	Dynamic.bind(:typeCheckingTree, args[i]);
	try {
	  typeCheckBlockStatement(args[i], i + 1, args, newArgs);
	} finally {
	  Dynamic.unbind();
	}
      }
    }
    
    // $B0z?t$N(B tree $B$O>iD9$@$,!"(B typeCheckBlockStatements $B$HJ6$i$o$7$$$N$G!"(B
    //$B$o$6$H(B signature $B$rJQ$($k$3$H$K$7$?!#(B
    define implement void typeCheckBlockStatement(Tree tree,
						  int i,
						  Tree[] args,
						  TreeVec newArgs){
      if (tree.tag() == :decl){
	// (decl (modifiers) type (vardecls ...))
	Tree[] declArgs = tree.args();
	Tree[] vardecls = declArgs[2].args();
	TreeVec newVardecls = new TreeVec();
	typeCheckVariableDeclarators(0, vardecls,
				     newVardecls,
				     tree,
				     declArgs[0],
				     TypeChecker.typeNameCheckTree(declArgs[1]),
				     i, args,
				     newArgs);
	return;

      } else if (tree.tag() == :class){

	// Make a ClassSignatureTree from the AST.
	Tree entry = normalizeClass(tree);
	Symbol simpleName = entry.args()[0].idName();
	Tree typeSig = entry.args()[1];
	if (Opts.printFileSignature) {
	  Opts.out.println("ClassSignatureTree of inner class:");
	  typeSig.print(Opts.out);
	}
	TypeNameTable typeNameTable
	  = (TypeNameTable)Dynamic.get(:typeNameTable);
	BlockTypeNameTable blockTypeNameTable =
	  new BlockTypeNameTable(simpleName,
				 typeNameTable);
	int innerClassCounter = Dynamic.getInt(:inneClassCounter);
	Dynamic.setInt(:inneClassCounter, innerClassCounter + 1);
	Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
	Symbol fullName = Symbol.intern(typeOfThis.classInfo().getName()+
					"$"+
					innerClassCounter+
					"$"+
					simpleName);
	
	Type t = new ClassType(fullName, typeSig, blockTypeNameTable,
			       typeOfThis,
			       null);
	blockTypeNameTable.setType(t);
	
	Dynamic.bind(:typeNameTable, blockTypeNameTable);
	try {
	  newArgs.add(TypeChecker.typeCheckTree(tree));
	  typeCheckBlockStatements(i, args, newArgs);
	} finally {
	  Dynamic.unbind();
	}

	return;

      } else {
	Tree typedStatement;
	if (Opts.nocatch){
	  typedStatement = TypeChecker.typeCheckTree(tree);
	} else {
	  try {
	    typedStatement = TypeChecker.typeCheckTree(tree);
	  } catch (EppUserError e){
	    if (Opts.log) Opts.out.println("An error is caught during type checking a block.");
	    typedStatement =  new Tree(:errorInBlock);
	  }
	}

	newArgs.add(typedStatement);
	typeCheckBlockStatements(i, args, newArgs);
	return;
      }
    }
    
    define implement void typeCheckVariableDeclarators(int vi, Tree[] vardecls,
						       TreeVec newVardecls,
						       Tree declTree,
						       Tree modifiers,
						       Tree typeTree,
						       int i, Tree[] args,
						       TreeVec newArgs){
      if (vi == vardecls.length) {
	// (decl (modifiers) type (vardecls ...))
	//                        ^ Modify this node''s type.
	Tree newVardeclsTree
	  = declTree.args()[2]
	    .modifyTypeAndArgsIfNotTyped(Type.Tvoid,
					 newVardecls.toArray());
	Tree[] newDeclArgs = {modifiers, typeTree, newVardeclsTree};
	newArgs.add(declTree.modifyTypeAndArgsIfNotTyped(Type.Tvoid,
							 newDeclArgs));
	typeCheckBlockStatements(i, args, newArgs);
	return;
      } else {
	typeCheckVariableDeclarator(vardecls[vi],
				    vi + 1, vardecls,
				    newVardecls,
				    declTree,
				    modifiers,
				    typeTree,
				    i,  args,
				    newArgs);
      }
    }
    
    define implement void typeCheckVariableDeclarator(Tree tree,
						      int vi, Tree[] vardecls,
						      TreeVec newVardecls,
						      Tree declTree,
						      Tree modifiers,
						      Tree typeTree,
						      int i, Tree[] args,
						      TreeVec newArgs){
      if (tree.tag() == :varInit){
	// (varInit VariableDeclaratorId VariableInitializer)
	Tree[] initArgs = tree.args();
	Tree varId = initArgs[0];
	Tree initializer = initArgs[1]; // expression or arrayInitializer
	Tree[] declaredVars = new Tree[1];
	Tree newVarId = checkVariableDeclaratorId(typeTree.type(),
						  varId,
						  declaredVars);
	Tree var = declaredVars[0];

	// $B=i4|CM$N7?%A%'%C%/!#(B
	Tree checkedVariableInitializer =
	  coerceVariableInitializer(var.type(),
				    TypeChecker.typeCheckTree(initializer));

	Tree[] newVarInitArgs = {newVarId,
				 checkedVariableInitializer};
	newVardecls.add(tree.modifyTypeAndArgsIfNotTyped(Type.Tvoid,
							 newVarInitArgs));
	Dynamic.bind(:varEnv,
		     new VarEnv(var.idName(),
				new VarInfo(modifiers.args(),
					    var.type()),
				(VarEnv)Dynamic.get(:varEnv)
				));
	try {
	  typeCheckVariableDeclarators(vi, vardecls, newVardecls,
				       declTree, modifiers, typeTree,
				       i, args, newArgs);
	  return;
	} finally {
	  Dynamic.unbind();
	}
      } else {
	Tree[] declaredVars = new Tree[1];
	Tree newTree = checkVariableDeclaratorId(typeTree.type(),
						 tree,
						 declaredVars);
	Tree var = declaredVars[0];
	newVardecls.add(newTree);
	Dynamic.bind(:varEnv,
		     new VarEnv(var.idName(),
				new VarInfo(modifiers.args(),
					    var.type()),
				(VarEnv)Dynamic.get(:varEnv)
				));
	try {
	  typeCheckVariableDeclarators(vi, vardecls, newVardecls,
				       declTree, modifiers, typeTree,
				       i, args, newArgs);
	  return;
	} finally {
	  Dynamic.unbind();
	}
      }
    }

    // $B=i4|CM$,7?@k8@$5$l$?7?$+$I$&$+$r%A%'%C%/$9$k!#(B
    define implement Tree coerceVariableInitializer(Type type,
						    Tree tree){
      Symbol tag = tree.tag();
      Symbol s1 = type.tag();
      Symbol s2 = tree.type().tag();
      if (tag == :arrayInitializer){
	if (s1 != :arrayOf){
	  throw errorAt(tree,
			"Array initializer is supplied but the declared type is not an array type : "+ type);
	} else {
	  Type componentType = ((ArrayType)type).getComponentType();
	  Tree[] args = tree.args();
	  Tree[] newArgs = new Tree[args.length];
	  for (int i = 0; i < args.length; i++){
	    newArgs[i] = coerceVariableInitializer(componentType, args[i]);
	  }
	  return tree.modifyArgs(newArgs);
	}

      } else {
	return assignmentConversion(type, tree);

      /* old
      } else if ((s1 == :short || s1 == :char || s1 == :byte) &&
		 (s2 == :int || s2 == :short || s2 == :char || s2 == :byte)){
	// Assignment conversion.  See JLS1.0 5.2 .
	// This implementation is not enough.
	return tree;
      } else {
	// It should be an expression.
	return coerce(type, tree);
      */

      }
    }


    // $B3HD%$5$l$?(B VariableDeclaratorId $B$r!V%^%/%mE83+!W$7$F!"JV$9!#(B
    //$BNc!'(B a[] -> a[], *a -> a[]
    // $B$^$?!"@k8@$5$l$?JQ?t$K7?$r$D$1$F!"(B declaredVars[0] $B$KF~$l$k!#(B
    define implement Tree checkVariableDeclaratorId(Type type,
						    Tree tree,
						    Tree[] declaredVars){
      if (tree.tag() == :id){
	declaredVars[0] = tree.modifyTypeAndArgsIfNotTyped(type, tree.args());
	return tree;
      } else if (tree.tag() == :arrayVar){
	Tree[] newArgs = { checkVariableDeclaratorId(new ArrayType(type),
						     tree.args()[0],
						     declaredVars) };
	return tree.modifyArgs(newArgs);
      } else {
	throw Epp.fatal("Illegal VariableDeclaratorId: "+ tree);
      }
    }


    define implement Tree typeCheckMethodBody(Tree body){
      return TypeChecker.typeCheckTree(body);
    }
  }
}

//--------------------------------------------------

public class EppTypeError extends Error {
  public EppTypeError(String s){ super(s); }
}



//--------------------------------------------------
//--------------------------------------------------
// Type

public abstract class Type implements Cloneable {

  public static Obj epp(){
    return (Obj)Dynamic.get(:epp);
  }
  
  // Delegation.
  public static boolean equals(Type type1, Type type2){
    return epp()!equals(type1, type2);
  }
  public static boolean isSuperType(Type type1, Type type2){
    return epp()!isSuperType(type1, type2);
  }
  public static Tree coerce(Type type, Tree tree){
    return epp()!coerce(type, tree);
  }
  public static FieldInfo selectField(Type targetType,
				      Symbol fieldName){
    return epp()!selectField(targetType, fieldName);
  }
  public static Object[] typeCheckAndSelectMethod(Type targetType,
						  Symbol methodName,
						  Tree argumentList,
						  boolean findOuterClass){
    return epp()!typeCheckAndSelectMethod(targetType,
					  methodName,
					  argumentList,
					  findOuterClass);
  }
  public static void typeCheckBlockStatements(int i,
					      Tree[] args,
					      TreeVec newArgs){
    epp()!typeCheckBlockStatements(i, args, newArgs);
  }



  // Type constants.
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tnull = new NullType();
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tvoid = new VoidType();
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tchar = new PrimitiveType(:char);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tbyte = new PrimitiveType(:byte);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tshort = new PrimitiveType(:short);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tint = new PrimitiveType(:int);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tlong = new PrimitiveType(:long);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tfloat = new PrimitiveType(:float);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tdouble = new PrimitiveType(:double);
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type Tboolean = new PrimitiveType(:boolean);

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type TString;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type TObject;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Type TClass;
  
  public static Hashtable primitiveTypeTable = new Hashtable();
  
  static {
    primitiveTypeTable.put(:char, Type.Tchar);
    primitiveTypeTable.put(:byte, Type.Tbyte);
    primitiveTypeTable.put(:short, Type.Tshort);
    primitiveTypeTable.put(:int, Type.Tint);
    primitiveTypeTable.put(:long, Type.Tlong);
    primitiveTypeTable.put(:float, Type.Tfloat);
    primitiveTypeTable.put(:double, Type.Tdouble);
    primitiveTypeTable.put(:boolean, Type.Tboolean);
    try {
      TString = ClassTypeTable.instance.get(:"java.lang.String");
      TObject = ClassTypeTable.instance.get(:"java.lang.Object");
      TClass = ClassTypeTable.instance.get(:"java.lang.Class");
    } catch (NotFound e){
      throw Epp.fatal("");
    }
  }




  public Symbol tag;		// :int, ... or :class or :arrayOf or ...
  public Type(Symbol tag){
    this.tag = tag;
  }

  public boolean isPrimitiveType(){ return false; }

  public Symbol tag(){ return tag; }

  // This method is overrided by ClassType .
  public ClassInfo classInfo(){
    throw Epp.fatal("A method classInfo() was invoked but "+
		    "this is not an instance of ClassType: "+
		    this);
  }

  public boolean isPublic() { return true; }

  public abstract Tree toTree();

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Type print(){
    Opts.out.println(this);
    return this;
  }

/*
  public Object property(Symbol key) {
    InfoList inf = property;
    while (inf != null){
      if (key == inf.key) return inf.val;
      inf = inf.next;
    }
    //throw new NotFound("Type.property: "+ key+ " not found.");
    return null;
  }
  public Type modifyInfo(Symbol key, Object val){
    Type newType = saftyClone();
    newType.property = new InfoList(key, val, property);
    return newType;
  }
  
  private Type saftyClone(){
    try {
      return (Type)clone();
    } catch (CloneNotSupportedException e){
      throw Epp.fatal("clone failed.");
    }
  }
  */
}



public class PrimitiveType extends Type {
  public PrimitiveType(Symbol tag){
    super(tag);
  }
  public boolean isPrimitiveType(){ return true; }
  public Tree toTree(){
    return `(name ,(new Identifier(tag)));
  }
  public String toString(){
    return tag.toString();
  }
}

public class NullType extends Type {
  public NullType(){
    super(:null);
  }
  public Tree toTree(){
    throw Epp.error("Can not convert null type to Java type expression.");
  }
  public String toString(){
    return "<null>";
  }
}

public class VoidType extends Type {
  public VoidType(){
    super(:void);
  }
  public Tree toTree(){
    return `(name (id void));
  }
  public String toString(){
    return tag.toString();
  }
}

public class ArrayType extends Type {
  Type componentType;
  public ArrayType(Type componentType){
    super(:arrayOf);
    this.componentType = componentType;
  }
  public Type getComponentType() { return componentType; }
  public Tree toTree(){
    return `(arrayOf ,(componentType.toTree()));
  }
  public String toString(){
    return componentType.toString()+ "[]";
  }
}
