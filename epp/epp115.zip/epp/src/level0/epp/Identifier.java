/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol


package epp;
import java.io.*;

public class Identifier extends Tree {
  private Symbol id;

  public Identifier(Symbol id){
    super(:id, zeroArgs);
    this.id = id;
  }

  public Symbol idName(){
    return id;
  }

  public void print(PrintWriter out, String indent){
    out.print(indent);
    out.print("(id");
    printProp(out);
    out.print(' ');
    if (id.maybeIdentifier()){
      out.print(id);
    } else {
      out.print(Tree.quoteString(id.toString()));
    }
    out.print(')');
  }
  
  public String toString(){
    if (id.maybeIdentifier()){
      return "(id "+ id+ ")";
    } else {
      return "(id "+ Tree.quoteString(id.toString())+ ")";
    }
  }
}
