/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


#epp Symbol

package epp;
import java.io.*;


public class Tree implements Cloneable, Serializable {
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static final Tree[] zeroArgs = {};

  // Test of Tree.
  public static void main(String[] argv){
    Dynamic.env = new DVenvArrayShallow();
    Dynamic.bindInt(:lineNumberOfThisNode, -1);
    Dynamic.bindInt(:beginningPointOfThisNode, -1);
    Dynamic.bindInt(:endPointOfThisNode, -1);
    //
    Symbol s = Symbol.intern("sym");
    System.out.println(s);
    Tree t = new Tree(s);
    System.out.println(t);
    Tree t1 = new Tree(s, t, t, t);
    System.out.println(t1);
    //
    Tree t2 = StringNode.gen("if (%t == \"sss\") %t;", t, t);
    System.out.println(t2);
    //
    System.out.println(Tree.readTree("(id int)"));
    System.out.println(Tree.readTree("(id \"int\")"));
    System.out.println(Tree.readTree("(id int )"));
    System.out.println(Tree.readTree("(id \"int\" )"));
    System.out.println(Tree.readTree("(literalTree string \"abc\")"));
    System.out.println(Tree.readTree("(literalTree string \"\\\\n\")"));
    System.out.println(Tree.readTree("(+ (id x) (id y))"));
    System.out.println(Tree.readTree("(+ (id x)(id y) )"));
    System.out.println(Tree.readTree("(if (== (id x) (id y)) (id z) (id w))"));
    String s1 = t1.toString();
    System.out.println(s1);
    System.out.println(Tree.readTree(s1));
    String s2 = t2.toString();
    System.out.println(s2);
    System.out.println(Tree.readTree(s2));
  }
  
  // Instance variables
  private Symbol tag;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  private Tree[] args;
  private int lineNumber = -1;
  private int beginningPoint = -1;
  private int endPoint = -1;
  private Type type = null;
  private AttributeList attribute = null;
  
  public Symbol tag() { return tag; }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree[] args() { return args; }
  public int lineNumber() { return lineNumber; }
  public int beginningPoint() { return beginningPoint; }
  public int endPoint() { return endPoint; }
  public Type type() {
    if (type == null){
      throw Epp.fatal("No type information in this tree: "+ this);
    }  else {
      return type;
    }
  }
  public Object attribute(Symbol key) {
    AttributeList p = attribute;
    while (p != null){
      if (key == p.key) return p.val;
      p = p.next;
    }
    //throw new NotFound("Tree.attribute: "+ key+ " not found.");
    return null;
  }
  public Symbol idName(){
    throw Epp.fatal("A method idName() was invoked but "+
		    "this is not an instance of Identifier: "+
		    this);
  }
  public LiteralToken literalToken(){
    throw Epp.fatal("A method literalToken() was invoked but "+
		    "this is not an instance of LiteralTree: "+
		    this);
  }

  // Constructor
  public Tree(Symbol tag, Tree[] args){
    this.tag = tag;
    this.args = args;
    init();
  }
  public Tree(Symbol tag, TreeVec args){
    this(tag, args.toArray());
  }
  public Tree(Symbol t){ tag = t; args = zeroArgs; init();}
  public Tree(Symbol t,Tree a1){
    Tree[] a = {a1}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2){
    Tree[] a = {a1,a2}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2,Tree a3){
    Tree[] a = {a1,a2,a3}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2,Tree a3,Tree a4){
    Tree[] a = {a1,a2,a3,a4}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2,Tree a3,Tree a4,Tree a5){
    Tree[] a = {a1,a2,a3,a4,a5}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2,Tree a3,Tree a4,Tree a5,Tree a6){
    Tree[] a = {a1,a2,a3,a4,a5,a6}; tag = t; args = a; init(); }
  public Tree(Symbol t,Tree a1,Tree a2,Tree a3,Tree a4,Tree a5,Tree a6,Tree a7){
    Tree[] a = {a1,a2,a3,a4,a5,a6,a7}; tag = t; args = a; init(); }


  
  // This method must be called from all constructors.
  private void init(){
    lineNumber = Dynamic.getInt(:lineNumberOfThisNode);
    beginningPoint = Dynamic.getInt(:beginningPointOfThisNode);
    endPoint = Dynamic.getInt(:endPointOfThisNode);
  }
  
  
  
  // Modification Methods
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyArgs(Tree[] args){
    Tree newTree = saftyClone();
    newTree.args = args;
    return newTree;
  }
  public boolean isTyped(){
    return type != null;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyTypeAndArgs(Type type, Tree[] args){
    if (this.type == null){
      Tree newTree = saftyClone();
      newTree.type = type;
      newTree.args = args;
      return newTree;
    } else {
      throw Epp.fatal("modifyTypeAndArgs is called twice : tree = "+ this+
		      ", current type = "+ this.type+ ", new type = "+ type);
    }
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyTypeAndArgsIfNotTyped(Type type, Tree[] args){
    if (this.type == null){
      return modifyTypeAndArgs(type, args);
    } else {
      return this;
    }
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree resetType(){
    Tree newTree = saftyClone();
    newTree.type = null;
    return newTree;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyArgsAndResetType(Tree[] args){
    Tree newTree = saftyClone();
    newTree.args = args;
    newTree.type = null;
    return newTree;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyAttribute(Symbol key, Object val){
    Tree newTree = saftyClone();
    newTree.attribute = new AttributeList(key, val, attribute);
    return newTree;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyLineNumber(int x){
    Tree newTree = saftyClone();
    newTree.lineNumber = x;
    return newTree;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyBeginningPoint(int x){
    Tree newTree = saftyClone();
    newTree.beginningPoint = x;
    return newTree;
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree modifyEndPoint(int x){
    Tree newTree = saftyClone();
    newTree.endPoint = x;
    return newTree;
  }

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  private Tree saftyClone(){
    try {
      return (Tree)clone();
    } catch (CloneNotSupportedException e){
      throw Epp.fatal("clone failed.");
    }
  }

  
  
  public static boolean nameEqual(Tree name1, Tree name2){
    // if (name1.tag() != :name || name2.tag() != :name) throw Epp.fatal("");
    Tree[] args1 = name1.args();
    Tree[] args2 = name2.args();
    if (args1.length != args2.length) return false;
    for (int i = args1.length - 1; i >= 0; i--){
      if (args1[i].idName() != args2[i].idName()) return false;
    }
    return true;
  }
  public String nameToString(){
    // if (this.tag() != :name) throw Epp.fatal("");
    StringBuffer buf = new StringBuffer();
    Tree[] elems = this.args();
    buf.append(elems[0].idName().toString());
    for (int i = 1; i < elems.length; i++){
      buf.append('.');
      buf.append(elems[i].idName().toString());
    }
    return buf.toString();
  }
  
  
  // Print tree with simple indentation.
  // The output can be used for BackQuote macro.
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree print(){
    return print(Opts.out);
  }
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Tree print(PrintWriter out){
    print(out, "");
    out.println();
    return this;
  }
  public void print(PrintWriter out, String indent){
    out.print(indent);
    if (args.length == 0){
      // Small subtrees such as "(modifiers)" is printed in one line.
      out.print("("+tag);
      printProp(out);
      out.print(')');
    } else {
      out.print("("+tag);
      printProp(out);
      out.println();
      for (int i = 0; i < args.length; i++) {
	String nextIndent;
	if (Opts.printTreeWithDots){
	  if (tag == :block){
	    nextIndent = indent+ '|';
	  } else {
	    nextIndent = indent+ '.';
	  }
	} else {
	  nextIndent = indent+ ' ';
	}
	args[i].print(out, nextIndent);
	// Do not print new-line if it is the last argument.
	if (i != args.length - 1) out.println();
      }
      out.print(')');
    }
  }
  public void printProp(PrintWriter out){
    if (Opts.printTreeWithLineNumber){
      out.print(" [");
      out.print(lineNumber);
      out.print("]");
    }
    if (Opts.printTreeWithType && type != null){
      out.print(" [");
      out.print(type);
      out.print("]");
    }
    if (Opts.printTreeWithString
	// && beginningPoint != -1 && endPoint != -1
	){
      out.print(" [");
      EppInputStream eppIn = (EppInputStream)Dynamic.get(:eppInputStream);
      
      String str;
      try {
	str = "\""+ eppIn.bufferSubString(beginningPoint, endPoint)+ "\"";
      } catch (StringIndexOutOfBoundsException e){
	str = beginningPoint+ ":"+ endPoint;
      }
      if (str.length() > 25){
	str = str.substring(0, 10)+ "\"...\""+
	  str.substring(str.length() - 10);
      }
      str = str.replace('\n', ' ').replace('\r', ' ');
      out.print(str);
      out.print("]");
    }
    if (Opts.printTreeWithAttribute){
      Symbol[] names = new Symbol[Opts.printTreeAttributeNames.size()];
      Opts.printTreeAttributeNames.copyInto(names);
      for (int i = 0; i < names.length; i++){
	out.print(" [");
	out.print(names[i].toString());
	out.print(":"+ attribute(names[i]));
	out.print("]");
      }
    }
  }
  
  // Convert tree to String without indentation.
  // (It is not efficient. It does log n times copy of total strings !)
  public String toString(){
    StringBuffer str = new StringBuffer();
    str = str.append("(").append(tag);
    
    //str.append(' ').append(lineNumber);
    
    for (int i = 0; i < args.length; i++){
      str = str.append(' ').append(args[i]);
    }
    str = str.append(')');
    return str.toString();
  }
  
  //--------------------------------------------------
  // Static methods.
  
  // This method is called by class Identifier and LiteralToken.
  // Examples:
  //	"foo" (3 chars) -> "\"foo\""  (5 chars)
  //	"\n"  (2 chars) -> "\"\\n\""  (4 chars)
  //	"\""  (1 char)  -> "\"\\\"\"" (4 chars)
  public static String quoteString(String in){
    return '\"'+ quoteStringContents(in)+ '\"';
  }

  // This method is called by quoteString.
  // Examples:
  //	"foo" (3 chars) -> "foo"  (3 chars)
  //	"\n"  (2 chars) -> "\\n"  (2 chars)
  //	"\""  (1 char)  -> "\\\"" (2 chars)
  public static String quoteStringContents(String in){
    StringBuffer out = new StringBuffer();
    for (int i = 0; i < in.length(); i++){
      char c = in.charAt(i);
      switch (c){
      case '\b':
	out.append("\\b"); break;
      case '\t':
	out.append("\\t"); break;
      case '\n':
	out.append("\\n"); break;
      case '\f':
	out.append("\\f"); break;
      case '\r':
	out.append("\\r"); break;
      case '\"':
	out.append("\\\""); break;
      case '\'':
	out.append("\\\'"); break;
      case '\\':
	out.append("\\\\"); break;
      default:
	out.append(c);
      }
    }
    return out.toString();
  }
  
  // "a.b.c" -> (name (id a) (id c) (id c))
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Tree stringToNameTree(String str){
    TreeVec tvec = new TreeVec();
    int from = 0;
    while (true){
      int dot = str.indexOf('.', from);
      if (dot == -1) {
	tvec.add(new Identifier(Symbol.intern(str.substring(from))));
	break;
      }
      tvec.add(new Identifier(Symbol.intern(str.substring(from,
							  dot))));
      from = dot + 1;
    }
    //return new Tree(:name, tvec);
    return new Tree(Symbol.intern("name"), tvec);
  }
  
  
  //--------------------------------------------------
  // Tree reader.
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Tree readTree(String s){
    return readTree(new EppInputStream(s.toCharArray()));
  }
  
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  private static Tree readTree(EppInputStream in){
    //System.err.println("\""+in.bufferSubString(in.pointer(), in.fileSize())+ "\"");

    skipWhiteSpace(in);
    char c = in.getc();
    if (c != '(') {
      throw Epp.fatal("readTree: The first char of S-exp is not a paren.");
    }
    Symbol tag = readIdentifier(in);
    if (tag == :id){
      Tree ret = new Identifier(readIdentifier(in));
      skipWhiteSpace(in);
      if (in.getc() != ')') throw Epp.fatal("");
      return ret;
    } else if (tag == :literalTree){
      Tree ret = new LiteralTree(readIdentifier(in),
				 readQuotedString(in));
      skipWhiteSpace(in);
      if (in.getc() != ')') throw Epp.fatal("");
      return ret;
    } else {
      TreeVec tvec = new TreeVec();
      while (true){
	skipWhiteSpace(in);
	c = in.getc();
	if (c == ')') break;
	in.ungetc(c);
	tvec.add(readTree(in));
      }
      return new Tree(tag, tvec);
    }
  }
  
  private static void skipWhiteSpace(EppInputStream in){
    char c;
    while (true) {
      c = in.getc();
      if (! Character.isWhitespace(c)) {
	in.ungetc(c);
	break;
      }
    }
  }
  
  private static Symbol readIdentifier(EppInputStream in){
    skipWhiteSpace(in);
    char c = in.getc();
    if (c == '\"'){
      in.ungetc(c);
      return Symbol.intern(readQuotedString(in));
    } else {
      StringBuffer buf = new StringBuffer();
      buf.append(c);
      while (true) {
	c = in.getc();
	if (c == ')' || Character.isWhitespace(c)) {
	  in.ungetc(c);
	  break;
	}
	buf.append(c);
      }
      return Symbol.intern(buf.toString());
    }
  }
  
  private static String readQuotedString(EppInputStream in){
    skipWhiteSpace(in);
    char c = in.getc();
    if (c != '\"'){
      throw Epp.fatal("readTree: String is expected.");
    }
    StringBuffer buf = new StringBuffer();
    while (true){
      c = in.getc();
      if (c == '\"'){
	break;
      } else if (c == '\\'){
	c = in.getc();
	buf.append(c);
      } else {
	buf.append(c);
      }
    }
    return buf.toString();
  }
}


class AttributeList {
  Symbol key;
  Object val;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  AttributeList next;
  public AttributeList(Symbol key, Object val, AttributeList next){
    this.key = key; this.val = val; this.next = next;
  }
}
