/*
*
* Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
*
* Permission to use, copy, modify and redistribution this software in
* whole and in part, for evaluation or research purposes and without fee
* is hereby granted provided this copyright notice.
* See CopyrightAndLicensing.txt for licensing condition.
*/

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros

     

package epp;   
import SystemMixinRuntimes.*;

SystemMixin PrimaryOtherwise {
  
  class Epp {
    // This method is redefined by FieldOrInvoke system mixin.
    define default Tree primaryOtherwise() {
      throw error("Primary is required here.");
    }
  }
}



//		  NonTerminal Name	Default Value
defineNonTerminal(primary,			primaryOtherwise());
defineNonTerminal(postfixExpression,		primary());
defineNonTerminal(unaryExpressionNotPlusMinus,	postfixExpression());
defineNonTerminal(unaryExpression, 		unaryExpressionNotPlusMinus());
defineNonTerminal(memberSectionExpression,	unaryExpression());
defineNonTerminal(multiplicativeExpression,	memberSectionExpression());
defineNonTerminal(additiveExpression,		multiplicativeExpression());
defineNonTerminal(shiftExpression,		additiveExpression());
defineNonTerminal(relationalExpression,		shiftExpression());
defineNonTerminal(equalityExpression,		relationalExpression());
defineNonTerminal(andExpression,		equalityExpression());
defineNonTerminal(exclusiveOrExpression,	andExpression());
defineNonTerminal(inclusiveOrExpression,	exclusiveOrExpression());
defineNonTerminal(conditionalAndExpression,	inclusiveOrExpression());
defineNonTerminal(conditionalOrExpression,	conditionalAndExpression());
defineNonTerminal(conditionalExpression,	conditionalOrExpression());
defineNonTerminal(assignmentExpression,		conditionalExpression());
defineNonTerminal(expressionNoComma,		assignmentExpression());
defineNonTerminal(commaExpression,		expressionNoComma());
defineNonTerminal(expression,			commaExpression());

