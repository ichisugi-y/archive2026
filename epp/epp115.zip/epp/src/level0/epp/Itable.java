/*
*
* Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
*
* Permission to use, copy, modify and redistribution this software in
* whole and in part, for evaluation or research purposes and without fee
* is hereby granted provided this copyright notice.
* See CopyrightAndLicensing.txt for licensing condition.
*/


/*

 An Integer table using a variation of flyweight pattern.

 Usage:
	Itable.get(123)

 It is same as "new Integer(123)",
but more efficient if the argument is a small positive integer.

*/


package epp;

class Itable {
  static final int EXTSIZE = 1024;
  static Integer[] table = new Integer[0];
  
  public static Integer get(int x){
    if (x < 0){
      return new Integer(x);
    } else if (x < table.length) {
      // 0 <= x < table.length
      return table[x];
    } else if (table.length + EXTSIZE <= x){
      return new Integer(x);
    } else {
      // table.length <= x < table.length + EXTSIZE
      extendTable(x);
      return table[x];
    }
  }

  private static void extendTable(int x){
    while (table.length <= x){
      Integer[] newTable = new Integer[table.length + EXTSIZE];
      for (int i = 0; i < table.length; i++){
	newTable[i] = table[i];
      }
      for (int i = table.length; i < newTable.length; i++){
	newTable[i] = new Integer(i);
      }
      table = newTable;
    }
  }

  //-----------------------------------------------------
  // Test.
  public static void main(String[] argv){
    int c = 1000;
    long t0;
    
    
    t0 = System.currentTimeMillis();
    for (int i = 0; i < c; i++){
      for (int j = 0; j < 1001; j++){
	Integer x = Itable.get(j);
      }
    }
    System.out.println(System.currentTimeMillis() - t0);
    
    t0 = System.currentTimeMillis();
    for (int i = 0; i < c; i++){
      for (int j = 0; j < 1001; j++){
	Integer x = new Integer(j);
      }
    }
    System.out.println(System.currentTimeMillis() - t0);
    
    t0 = System.currentTimeMillis();
    for (int i = 0; i < c; i++){
      for (int j = 0; j < 1001; j++){
	Integer x = Itable.get(j);
      }
    }
    System.out.println(System.currentTimeMillis() - t0);


    Integer i12 = Itable.get(12);
    Integer i1234 = Itable.get(1234);
    System.out.println(i12+ ", "+ i1234);
    System.out.println(i12 == Itable.get(12));
  }
}

/*
Bechmark result of current version (epp1.0.1) Itable.

*"JDK1.1.3/jws:1997.09.16" on 200MHz Ultra 1
186
2641
202
12, 1234
true

*SDK2.01 on 150MHz Pentium 48MB RAM
220
2360
160
12, 1234
true

*JDK1.1.2 on 150MHz Pentium 48MB RAM
1700
4450
1480
12, 1234
true


----
Bechmark result of OLD version (epp1.0.0) Itable.

*Visual J++ 1.0 on 150MHz Pentium 48MB RAM
7030
30100
7140
12, 1234
true


*JDK1.1.2 on 150MHz Pentium 48MB RAM
1540
4290
1480
12, 1234
true

*JDK1.1.4 on 200MHz Ultra 1
1570
2478
1591
12, 1234
true
*/

