/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles

/*
 The input stream is assumed be ended with newline.
 The class EppInputStream guarantees that.
*/


package epp;
import SystemMixinRuntimes.*;
import java.util.Stack;
import java.io.InputStream;


SystemMixin Lex {
  
  class Epp {
    
    implement Token readToken(EppInputStream in){
      char c;

      // Skip white spaces.
      while (true) {
	if (in.isEof()) return new LiteralToken(:eof, "");
	c = in.getc();
	if (! Character.isWhitespace(c)) {
	  if (c < ' ') {
	    System.err.println((String)Dynamic.get(:inputFileName)+ ":"+
			       Dynamic.getInt(:lineNumber)+ ": "+
			       "Warning: A control charactor ^"+
			       ((char)(c + '@'))+
			       " is containd in the input file."
			       );
	    continue;
	  } else {
	    break;
	  }
	}
      }
      in.ungetc(c);
      
      // The value of :lineNumber indicates the precise line number of
      //the beginning of the returned token.
      Dynamic.setInt(:lineNumber, in.lineNumber());
      Dynamic.setInt(:beginningPoint, in.pointer());
      
      return readTokenStart(in);
    }
    
    
    define implement Token readTokenStart(EppInputStream in){
      char c = in.peekc();
      if (Character.isJavaIdentifierStart(c)) {
	return readId(in);
      } else if (Character.isDigit(c)) {
	return readNumber(in);
      } else if (c < ' ') {
	throw Epp.fatal("controle charactor");
      } else {
	return readOperator(in);
      }
    }
    
    
    define implement Token readId(EppInputStream in){
      char c = in.getc();
      StringBuffer buf = new StringBuffer();
      while (Character.isJavaIdentifierPart(c)) {
	buf.append(c); c = in.getc();
      }
      in.ungetc(c);
      Symbol id = Symbol.intern(buf.toString());
      id.setMaybeIdentifierFlag();
      return id;
    }
    
    
    // Thanks for Suzuki Noriaki
    define implement Token readNumber(EppInputStream in){
      char c = in.getc();
      StringBuffer buf = new StringBuffer();
      int radix = 10;
      Symbol literalTag = null;
      boolean realFlag = false;
      // int part
      if (Character.isDigit(c)) {
	if (c == '0'){
	  buf.append(c); c = in.getc();
	  if (c == 'x' || c == 'X') {
	    buf.append(c); c = in.getc();
	    radix = 16;
	  } else {
	    // This lexical analyzer does not make distinction
	    // between Decimal and Octal numbers
	    // because it is impossible to detect that 009.0 is
	    // a decimal real number at this point.
	    // radix = 8;
	  }
	}
	while (Character.digit(c, radix) >= 0) {
	  buf.append(c); c = in.getc();
	}
      }
      if (c == '.'){
	buf.append(c); c = in.getc();
	realFlag = true;
	// frac part
	while (Character.isDigit(c)) {
	  buf.append(c); c = in.getc();
	}
      }
      // exp part
      if (c == 'e' || c == 'E'){
	realFlag = true;	// "1e1" is a real number.
	buf.append(c); c = in.getc();
	if (c == '+' || c == '-'){
	  buf.append(c); c = in.getc();
	}
	if (! Character.isDigit(c)) {
	  throw error("Illegal charactor in an exp part of a real number literal.");
	}
	while (Character.isDigit(c)) {
	  buf.append(c); c = in.getc();
	}
      }
      // suffix
      if (c == 'l' || c == 'L') {
	buf.append(c); c = in.getc();
	literalTag = :long;
	if (realFlag) {
	  throw error("Illegal suffix after a real number literal.");
	}
      } else if (c == 'f' || c == 'F') {
	buf.append(c); c = in.getc();
	literalTag = :float;
      } else if (c == 'd' || c == 'D') {
	buf.append(c); c = in.getc();
	literalTag = :double;
      }
      in.ungetc(c);
      if (literalTag == null){
	if (realFlag) {
	  literalTag = :double;
	} else {
	  literalTag = :int;
	}
      }
      if (radix == 16 && (literalTag == :double || literalTag == :float)) {
	throw error("Illegal number literal.");
      }
      return new LiteralToken(literalTag, buf.toString());
    }
    
    
    define implement Token readOperator(EppInputStream in){
      char c = in.getc();
      switch (c){
      case '!':
	switch ((c = in.getc())) {
	case '=':
	  return :"!=";
	default:
	  in.ungetc(c); return :"!";
	}
      case '\"': {
	in.ungetc(c);
	return readStringLiteral(in);
      }
      case '#':
	return readSharp(in);
      case '$':
	// In Java language, '$' is considered as a Letter.
	throw Epp.fatal("");
      case '%':
	switch ((c = in.getc())) {
	case '=':
	  return :"%=";
	default:
	  in.ungetc(c); return :"%";
	}
      case '&':
	switch ((c = in.getc())) {
	case '&':
	  return :"&&";
	case '=':
	  return :"&=";
	default:
	  in.ungetc(c); return :"&";
	}
      case '\'': {
	in.ungetc(c);
	return readCharLiteral(in);
      }
      case '(':
	return :"(";
      case ')':
	return :")";
      case '*':
	switch ((c = in.getc())) {
	case '=':
	  return :"*=";
	case '/': {
	  if (Opts.commentColon) return readToken(in);
	  in.ungetc(c); return :"*";
	}
	default:
	  in.ungetc(c); return :"*";
	}
      case '+':
	switch ((c = in.getc())) {
	case '+':
	  return :"++";
	case '=':
	  return :"+=";
	default:
	  in.ungetc(c); return :"+";
	}
      case ',':
	return :",";
      case '-':
	switch ((c = in.getc())) {
	case '-':
	  return :"--";
	case '=':
	  return :"-=";
	default:
	  in.ungetc(c); return :"-";
	}
      case '.': {
	char c2 = in.peekc();
	if (Character.isDigit(c2)) {
	  in.ungetc(c);
	  return readNumber(in);
	} else if (c2 == '*'){
	  in.getc();
	  // This token is used in declarations like "import a.b.*;" .
	  return :".*";
	} else {
	  return :".";
	}
      }
      case '/':
	switch ((c = in.getc())) {
	case '/':
	  return readEndOfLineComment(in);
	case '*':
	  return readTraditionalComment(in);
	case '=':
	  return :"/=";
	default:
	  in.ungetc(c); return :"/";
	}
      case ':':
	switch ((c = in.getc())) {
	case ':':
	  return :"::";
	default:
	  in.ungetc(c); return :":";
	}
      case ';':
	return :";";
      case '<':
	switch ((c = in.getc())) {
	case '=':
	  return :"<=";
	case '<':
	  switch ((c = in.getc())) {
	  case '=':
	    return :"<<=";
	  case '<':
	    switch ((c = in.getc())) {
	    case '=':
	      return :"<<<=";
	    default:
	      in.ungetc(c); return :"<<<";
	    }
	  default:
	    in.ungetc(c); return :"<<";
	  }
	default:
	  in.ungetc(c); return :"<";
	}
      case '=':
	switch ((c = in.getc())) {
	case '=':
	  return :"==";
	default:
	  in.ungetc(c); return :"=";
	}
      case '>':
	switch ((c = in.getc())) {
	case '=':
	  return :">=";
	case '>':
	  switch ((c = in.getc())) {
	  case '=':
	    return :">>=";
	  case '>':
	    switch ((c = in.getc())) {
	    case '=':
	      return :">>>=";
	    default:
	      in.ungetc(c); return :">>>";
	    }
	  default:
	    in.ungetc(c); return :">>";
	  }
	default:
	  in.ungetc(c); return :">";
	}
      case '?':
	return :"?";
      case '@':
	return :"@";
      case '[':
	return :"[";
      case '\\':
	return :"\\";
      case ']':
	return :"]";
      case '^':
	switch ((c = in.getc())) {
	case '=':
	  return :"^=";
	default:
	  in.ungetc(c); return :"^";
	}
      case '`':
	return :"`";
      case '{':
	return :"{";
      case '|':
	switch ((c = in.getc())) {
	case '|':
	  return :"||";
	case '=':
	  return :"|=";
	default:
	  in.ungetc(c); return :"|";
	}
      case '}':
	return :"}";
      case '~':
	return :"~";
      default:
	throw Epp.fatal("");
      }
    }
    
    
    define implement Token readStringLiteral(EppInputStream in){
      char c = in.getc();
      if (c != '\"') throw Epp.fatal("readStringLiteral is called but the first charactor is not a double quote.");
      StringBuffer buf = new StringBuffer();
      while (true) {
	c = in.getc();
	if (c == '\"') break;
	if (c == '\\') {
	  readEscapedChar(in, buf, c);
	} else {
	  buf.append(c);
	}
      }
      return new LiteralToken(:string, buf.toString());
    }
    
    
    define implement Token readCharLiteral(EppInputStream in){
      char c = in.getc();
      if (c != '\'') throw Epp.fatal("readCharLiteral is called but the first charactor is not a single quote.");
      StringBuffer buf = new StringBuffer();
      while (true) {
	c = in.getc();
	if (c == '\'') break;
	if (c == '\\') {
	  readEscapedChar(in, buf, c);
	} else {
	  buf.append(c);
	}
      }
      return new LiteralToken(:char, buf.toString());
    }
    

    define implement void readEscapedChar(EppInputStream in,
					  StringBuffer buf, char c){
      buf.append(c);
      buf.append(in.getc());
    }

    
    define implement Token readTraditionalComment(EppInputStream in){
      char c = in.getc();
      if (Opts.commentColon && c == ':'){
	return readToken(in);
      }
      while (true) {
	if (c == '*') {
	  c = in.getc();
	  if (c == '/') break;
	} else {
	  c = in.getc();
	}
      }
      // Read next token.
      return readToken(in);
    }
    

    define implement Token readEndOfLineComment(EppInputStream in){
      char c = in.peekc();
      if (Opts.commentColon && c == ':'){
	in.getc();
	return readToken(in);
      }
      return readTokenAtNextLine(in);
    }

    
    define implement Token readSharp(EppInputStream in){
      // Discard #epp commands.
      return readTokenAtNextLine(in);
    }

    
    define implement Token readTokenAtNextLine(EppInputStream in){
      char c = in.getc();
      while (true) {
	if (c == '\n' || c == '\r') break;
	c = in.getc();
      }
      // Read next token.
      return readToken(in);
    }
  }
}
