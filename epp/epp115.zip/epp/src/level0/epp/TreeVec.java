/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

/*

 NOTE:
 This file can not be processed by lisp-epp1.0.

*/



/*
 Usage:

	TreeVec tvec = new TreeVec();
	while (...) {
	  tvec.add(tree);
	}
	Tree[] treeArray = tvec.toArray()
*/


package epp;
import java.util.Vector;

/*
// This version of implementation is slower. (In IBM JDK1.1.8 )  Why?
public class TreeVec{
  static final int initialCapacity = 10;
  int size = 0;
  Tree[] rep = new Tree[initialCapacity];

  public TreeVec add(Tree x){
    if (rep.length == size){
      Tree[] newRep = new Tree[size * 2];
      //System.arraycopy(rep, 0, newRep, 0, size);
      for (int i = 0; i < size; i++){
	newRep[i] = rep[i];
      }
      rep = newRep;
    }
    rep[size++] = x;
    return this;
  }
  
  public TreeVec push(Tree t){
    return add(t);
  }

  public TreeVec addA(TreeVec tvec){
    return addA(tvec.toArray());
  }

  public TreeVec addA(Tree[] trees){
    for (int i = 0; i < trees.length; i++){
      add(trees[i]);
    }
    return this;
  }

  public Tree[] toArray(){
    Tree[] a = new Tree[size];
    //System.arraycopy(rep, 0, a, 0, size);
    for (int i = 0; i < size; i++){
      a[i] = rep[i];
    }
    return a;
  }
}
*/

public class TreeVec{
       
  Vector vec = new Vector();
  
  public TreeVec add(Tree t){
    vec.addElement(t);
    return this;
  }
  
  public TreeVec push(Tree t){
    vec.addElement(t);
    return this;
  }

  public TreeVec addA(TreeVec tvec){
    return addA(tvec.toArray());
  }

  public TreeVec addA(Tree[] trees){
    for (int i = 0; i < trees.length; i++){
      vec.addElement(trees[i]);
    }
    return this;
  }

  public Tree[] toArray(){
    Tree[] a = new Tree[vec.size()];
    vec.copyInto(a);
    return a;
  }
}
