/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package epp;
import java.io.*;
import java.util.Vector;

public class Opts {

  public static String eppSourceVersion = "1.1.5";

  // EPP_VERSION() is a built-in macro of EPP.
  // However, because of a bug of SystemMixin plug-in on lisp-epp,
  //this macro will not be expanded if it is used in SystemMixin definitions.
  public static String eppTranslatorVersion = EPP_VERSION();
  // Output stream for log.
  public static PrintWriter out
    = new PrintWriter(new BufferedWriter(new FileWriter(FileDescriptor.err)),
		      true);
  public static boolean log = false;
  public static boolean forceTranslation = false;
  public static boolean global = false;
  public static java.util.Vector extraPlugIns = new java.util.Vector();
  public static boolean printToken = false;
  public static boolean printClassInfo = false;
  public static boolean printFileSignature = false;
  public static boolean printTree = false;
  public static boolean printTreeWithLineNumber = false;
  public static boolean printTreeWithType = false;
  public static boolean printTreeWithDots = false;
  public static boolean printTreeWithString = false;
  public static boolean printTreeWithAttribute = false;
  public static Vector printTreeAttributeNames = new Vector();
  public static boolean newlineForReadability = false;
  public static boolean recursive = false;
  public static boolean nocatch = false;
  public static boolean nocatchFatal = false;
  public static boolean printErrorLine = false; // Currently not used.
  public static boolean forceNextPass = false;
  public static int errorCounter = 0;
  public static boolean commentColon = false;
  public static boolean repeatTypeCheck = false; // Currently not used.
  public static boolean noTypeChecking = true;
  public static boolean noCodeEmitting = false;
  public static boolean fastParser = false; // Currently not used.
  public static boolean sml = false;
  public static boolean readableTree = false;
  public static String encoding = null;
  public static String targetClasspath = null;
  public static String plugInPackagePrefix = null;
  
  public static String lineSeparator = System.getProperty("line.separator");
}
