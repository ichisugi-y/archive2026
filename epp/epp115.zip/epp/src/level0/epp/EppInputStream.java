/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package epp;
import java.io.*;
import java.util.Vector;
import java.util.Stack;
import java.util.Enumeration;

/*
 NOTE:

 In order to make the implementation simpler, 
the border of each line is defined as follows.
(Beginning of line is '\n' for Unix and Win, '\r' for Mac.)

 Unix:	...\n...
           ^
 Mac:   ...\r...
           ^
 Win    ...\r\n...
             ^
*/

public class EppInputStream {
  protected char buf[];
  protected int bufp;
  protected int lineNumber;
  protected String filename;
  protected int fileSize;
  // Size of default and extesion of the buffer.
  protected final int BUFSIZE = 32000;

  protected void expandBuf(){
    // if (Opts.log) Opts.out.println("expandBuf");
    
    char[] newbuf = new char[buf.length + BUFSIZE];
    for (int i = 0; i < buf.length; i++){
      newbuf[i] = buf[i];
    }
    buf = newbuf;
  }

  // This constructor is used by Tree.readTree() .
  public EppInputStream(char[] buf) {
    filename = "String";
    bufp = 0;
    this.buf = buf;
    lineNumber = 0;
    fileSize = buf.length;
  }


  public EppInputStream(String filename) {
    this.filename = filename;
    InputStreamReader in;
    try {
      if (Opts.encoding == null){
	in = new FileReader(filename);
      } else {
	in = new InputStreamReader(new FileInputStream(filename),
				   Opts.encoding);
      }
    } catch (UnsupportedEncodingException e){
      System.err.println(e);
      throw Epp.error(e.toString());
    } catch (FileNotFoundException e){
      System.err.println(e);
      throw Epp.fatal("Specified Input file is not found.");
    }

    if (Opts.log) Opts.out.println("Encoding = "+ in.getEncoding());
    
    // Read whole source code into the buffer.
    buf = new char[BUFSIZE];
    fileSize = 0;
    
  eof:
    while (true) {
      while (buf.length > fileSize) {
	int size;
	try {
	  size = in.read(buf, fileSize, buf.length - fileSize);
	} catch (java.io.IOException e) {
	  throw Epp.fatal(""+ e);
	}
	if (size == -1) break eof;
	fileSize += size;
      }
      expandBuf();
    }
    // Add new-line code at the end of the file if it does not exist.
    if (fileSize == 0 ||
	(buf[fileSize - 1] != '\n' && buf[fileSize - 1] != '\r')) {
      if (buf.length == fileSize) expandBuf();
      // To avoid a bug of JDK, I should cast the constnat expression.
      // The assignment "b = 'c'" is translated to "b = ('c')" by EPP,
      //and JDK seems not to recognize ('c') as a constant expression.
      // See the section 5.2 and 15.27 .
      buf[fileSize++] = (char)'\n';
      //buf[fileSize++] = '\n';
    }
    
    try {
      in.close();
    } catch (IOException e){
      System.err.println(e);
      throw Epp.fatal("Input file could not be closed.");
    }
    
    bufp = 0;
    lineNumber = 1;
  }

  public char peekc(){
    if (bufp >= fileSize) {
      throw Epp.fatal("EppInputStream: peekc was attemted after EOF.");
    }
    return buf[bufp];
  }

  public char getc(){
    if (bufp >= fileSize) {
      throw Epp.fatal("EppInputStream: getc was attemted after EOF.");
    }
    char c = buf[bufp++];
    if (c == '\n'
	|| (c == '\r' && bufp < fileSize && buf[bufp] != '\n')){
      lineNumber++;
    }
    return c;
  }
  
  public void ungetc(char c){
    if (c == '\n'
	|| (c == '\r' && bufp > fileSize && buf[bufp] != '\n')){
      lineNumber--;
    }
    if (buf[--bufp] != c){
      throw Epp.fatal("EppInputStream: ungetc: cannot pushback the char: " + c);
    }
  }

  public boolean isEof(){
    return fileSize == bufp;
  }

  public int pointer() { return bufp; }

  public int lineNumber(){ return lineNumber; }

  public String fileName() { return filename; }

  public int fileSize() { return fileSize; }

  public String bufferSubString(int begin, int end){
    return new String(buf, begin, end - begin);
  }

  // This method rewinds bufp to newp.
  //   cXXXXXXXXXX
  //    ^newp     ^bufp
  public void backtrack(int newp){
    lineNumber -= countLineNumber(newp, bufp);
    bufp = newp;
  }

  // This method counts borders of lines contained in XXXXXXXX.
  //   cXXXXXXXXXX
  //    ^from     ^to
  protected int countLineNumber(int from, int to){
    int n = 0;
    int i = from;
    while (i < to){
      char c = buf[i++];
      if (c == '\n'
	  || (c == '\r' && i < fileSize && buf[i] != '\n')){
	n++;
      }
    }
    return n;
  }


  public String errorPointIndicator(int begin, int end){
    //if ((begin < 0) || (fileSize < end) || (begin >= end)) return "";
    if (begin < 0 || fileSize <= begin ) return "";

    int beginningOfLine = begin;
    while (true){
      if (beginningOfLine == 0) break;
      if (buf[beginningOfLine - 1] == '\n' ||
	  buf[beginningOfLine - 1] == '\r') break;
      beginningOfLine--;
    }

    int endOfLine = begin;
    while (true){
      if (endOfLine == fileSize ||
	  buf[endOfLine] == '\n' ||
	  buf[endOfLine] == '\r') break;
      endOfLine++;
    }

    StringBuffer buf = new StringBuffer();
    String line = bufferSubString(beginningOfLine, endOfLine);
    int numTabs = 0;
    for (int i = 0; i < line.length(); i++){
      if (line.charAt(i) == '\t'){
	String eightSpaces = "        ";
	buf.append(eightSpaces);
	numTabs++;
      } else {
	buf.append(line.charAt(i));
      }
    }
    buf.append(Opts.lineSeparator);
    int spaceLength = begin - beginningOfLine + numTabs * 8 - numTabs;
    while (spaceLength-- > 0) buf.append(' ');
    buf.append("^");

    return buf.toString();
  }
}
