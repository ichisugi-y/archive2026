/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package epp;
import java.util.Hashtable;

public class Symbol extends Token {

  private static Hashtable table = new Hashtable();

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static Symbol intern(String name){
    Symbol s = (Symbol)table.get(name);
    if (s == null){
      s = new Symbol(name);
      table.put(name, s);
    }
    return s;
  }

  private String name;

  // Private constructor.
  private Symbol(String name){
    this.name = name;
  }

  public String toString() {
    return name;
  }

  // The following method are defined for EPP.
  public boolean isSymbol(){
    return true;
  }

  // See Dynamic.java
  public int dvid = -1;
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Symbol dvType = null;


  private boolean maybeIdentifier = false;
  public void setMaybeIdentifierFlag(){
    maybeIdentifier = true;
  }
  public boolean maybeIdentifier(){
    return maybeIdentifier;
  }
  

  // test
  public static void main(String[] argv){
    long t0;

    int sn = 10000;
    String[] sa = new String[sn];
    for (int i = 0; i < sn; i++){
      sa[i] = "longhead"+i;
    }
    t0 = System.currentTimeMillis();
    for (int i = 0; i < sn; i++){
      Symbol.intern(sa[i]);
    }
    System.out.println(System.currentTimeMillis() - t0);

    Symbol s1 = intern("foo");
    Symbol s2 = intern("foo");
    Symbol s3 = intern("bar");
    System.out.println(s1);
    System.out.println(s1 == s1);
    System.out.println(s1 == s2);
    System.out.println(s1 == s3);

    int c = 100000; //1000000;
    Hashtable t;

    t = new Hashtable();
    String lstr = "longstring";
    t.put(lstr, "val");
    System.out.println("lstr");
    t0 = System.currentTimeMillis();
    for (int i = 0; i < c; i++){
      t.get(lstr);
    }
    System.out.println(System.currentTimeMillis() - t0);

    t = new Hashtable();
    Symbol lsym = intern("longstring");
    t.put(lsym, "val");
    System.out.println("Symbol");
    t0 = System.currentTimeMillis();
    for (int i = 0; i < c; i++){
      t.get(lsym);
    }
    System.out.println(System.currentTimeMillis() - t0);
  }
}

/*
* 200MHz Ultra1

1097
foo
true
true
false
lstr
2807
Symbol
704

*/
