/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package epp;

public class LiteralToken extends Token {
  Symbol tag;
  String contents;

  public LiteralToken(Symbol tag, String contents){
    this.tag = tag;
    this.contents = contents;
  }

  public boolean isLiteralToken(){
    return true;
  }

  public Symbol literalTag() { return tag; }

  public String literalContents() { return contents; }

  public String toString() {
    return "("+ tag+ " "+ Tree.quoteString(contents)+ ")";
  }
}
