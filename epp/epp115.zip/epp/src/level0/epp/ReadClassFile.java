/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


/*
 This file was originally written by Furukawa at Duo Systems Co., Ltd.
 Then, re-written by Ichisugi.

 The development of this part was partially sponsored by the PRESTO program
(Sakigake Kenkyu 21) of Japan Science and Technology Corporation.


 This part depends on JavaClass API (Version3.3.2),
developed by Markus Dahm.
 You can obtain the source code and documents of JavaClass API
from the following URL:

	http://www.inf.fu-berlin.de/~dahm/JavaClass/index.html

*/

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote

package epp;
import SystemMixinRuntimes.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

import de.fub.bytecode.*;
import de.fub.bytecode.classfile.*;


SystemMixin ReadClassFile {
  
  class Epp {
    extend void initializationPass() {
      original();
      Dynamic.bind(:classFileReader, makeClassFileReader());
    }

    define implement ClassFileReader makeClassFileReader(){
      return JavaClassAPIClassFileReader.instance;
    }

    // This method find a class file from CLASSPATH and read.
    //If the specified class is not found, null is returned.
    // If format error of class file is found, EppUserError is thrown.
    define implement Object readClassFile(Symbol fullName){
      ClassFileReader reader = (ClassFileReader)Dynamic.get(:classFileReader);
      return reader.readClassFile(fullName.toString());
    }

    // This method reads a encoded ClassSignatureTable from the class file.
    define implement Tree getEncodedClassSignatureTable(Object classFile){
      ClassFileReader reader = (ClassFileReader)Dynamic.get(:classFileReader);
      return reader.getEncodedClassSignatureTable(classFile);
    }

    // This method converts the class file to a ClassData.
    define implement ClassData classFileToClassData(Object classFile,
						    Type declaringClass){
      ClassFileReader reader = (ClassFileReader)Dynamic.get(:classFileReader);
      return reader.classFileToClassData(classFile, declaringClass);
    }
  }
}


public abstract class ClassFileReader {
  public abstract Object readClassFile(String className);
  public abstract Tree getEncodedClassSignatureTable(Object classFile);
  public abstract ClassData classFileToClassData(Object classFile,
						 Type declaringClass);
}



public class JavaClassAPIClassFileReader extends ClassFileReader {
  // Because this class uses a lot of file descripters
  //(for zip files in CLASSPATH), I use singleton pattern.

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public static JavaClassAPIClassFileReader instance
    = new JavaClassAPIClassFileReader();

  Object[] classPathDirs;
  
  public JavaClassAPIClassFileReader(){
    String classPath = getClassPath();
    if (Opts.log) Opts.out.println("target classpath = "+ classPath);
    classPathDirs = initClassPath(classPath);
    
    // Test if findClassFile works.
    if (findClassFile("java.lang.Object") == null){
      System.err.println();
      System.err.println("**************************************************");
      System.err.println("EPP could not read the class file of java.lang.Object .");
      System.err.println("Please add classes.zip to your CLASSPATH.");
      System.err.println("(Current \"java.class.path\" property is \""+
			 System.getProperty("java.class.path")+
			 "\")");
      System.err.println("**************************************************");
      System.err.println();
      throw Epp.fatal("");
    }
  }
  
  public String getClassPath(){
    if (Opts.targetClasspath != null){
      return Opts.targetClasspath;

    } else {
      StringBuffer buf = new StringBuffer();
      char sep = File.pathSeparatorChar;

      String bootclasspath = System.getProperty("sun.boot.class.path");
      if (bootclasspath != null && bootclasspath.length() > 0){
	buf.append(bootclasspath);
	buf.append(sep);
      }

      String extdirs = System.getProperty("java.ext.dirs");
      if (extdirs != null && extdirs.length() > 0) {
	int begin = 0;
	while (true){
	  int end = extdirs.indexOf(sep, begin);
	  if (end == -1){
	    appendJarFiles(buf, extdirs.substring(begin));
	    break;
	  }
	  appendJarFiles(buf, extdirs.substring(begin, end));
	  begin = end + 1;
	}
      }

      String classpath = System.getProperty("java.class.path");
      if (classpath != null && classpath.length() > 0) {
	buf.append(classpath);
	buf.append(sep);
      }
      
      String str = buf.toString();
      // Remove the last sep char.
      if (str.length() > 0){
	str = str.substring(0, str.length() - 1);
      }
      return str;
    }
  }

  public void appendJarFiles(StringBuffer buf, String dirName){
    File dir = new File(dirName);
    if (! dir.isDirectory()) return;
    String[] fileList = dir.list();
    for (int i = 0; i < fileList.length; i++){
      if (fileList[i].endsWith(".jar")){
	buf.append(dirName+ File.separatorChar + fileList[i]);
	buf.append(File.pathSeparatorChar);
      }
    }
  }

  
  public Object[] initClassPath(String classPath){
    Vector vec = new Vector();
    int begin = 0;
    while (true){
      int end = classPath.indexOf(File.pathSeparatorChar, begin);
      if (end == -1){
	checkZip(vec, classPath.substring(begin));
	break;
      }
      checkZip(vec, classPath.substring(begin, end));
      begin = end + 1;
    }
    Object[] classPathDirs = new Object[vec.size()];
    vec.copyInto(classPathDirs);
    return classPathDirs;
  }
  
  public void checkZip(Vector vec, String str){
    //System.out.println("checkZip: "+ str);
    if (str.endsWith(".zip") || str.endsWith(".jar")) {
      try {
	vec.addElement(new ZipFile(str));
      } catch (IOException e) {
	// If the zip file does not exists, or format error occured,
	// do nothing.
      }
    } else {
      vec.addElement(str);
    }
  }

  //--------------------------------------------------

  public Object readClassFile(String className) {
    InputStream in = findClassFile(className);

    if (in == null) return null;

    try {
      // The second argument, file_name, seems to only be used for
      //error messages.
      ClassParser classParser = new ClassParser(in, "<Unknown>");
      return classParser.parse();
    } catch (IOException e){
      throw Epp.error(""+ e);
    } catch (ClassFormatError e){
      throw Epp.error(""+ e);
    } finally {
      try {
	in.close();
      } catch (IOException e){
	throw Epp.error(""+ e);
      }
    }
  }

  public InputStream findClassFile(String className) {
    // Do not use File.separatorChar instead of '/',
    //because zip file always use '/' as a separator.
    String classFileName = className.replace('.', '/')+ ".class";
    
    for (int i = 0; i < classPathDirs.length; i++){
      Object dir = classPathDirs[i];
      if (dir instanceof ZipFile) {
	// in case of archive file
	ZipFile zf = (ZipFile)dir;
	ZipEntry ze = zf.getEntry(classFileName);
	if (ze != null) {
	  try {
	    return zf.getInputStream(ze);
	  } catch (IOException e){
	    throw Epp.fatal(""+ e);
	  }
	}
      } else if (dir instanceof String) {
	File f = new File((String)dir+ File.separatorChar+ classFileName);
	if (f.exists()) {
	  try {
	    return new FileInputStream(f);
	  } catch (IOException e){
	    throw Epp.fatal(""+ e);
	  }
	}
      } else {
	throw Epp.fatal("");
      }
    }
    return null;
  }

  //--------------------------------------------------

  public Tree getEncodedClassSignatureTable(Object classFile){
    // Not implemented.
    JavaClass cf = (JavaClass)classFile;
    return null;
  }



  //--------------------------------------------------

  public ClassData classFileToClassData(Object classFile,
					Type declaringClass){
    JavaClass cf = (JavaClass)classFile;

    ClassTypeTable classTypeTable 
	= (ClassTypeTable)Dynamic.get(:classTypeTable);

    Tree[] modifiers = javaClassAccessFlagToTrees(cf);
    
    Symbol fullName = Symbol.intern(cf.getClassName());
    
    boolean isInterface = cf.isInterface();
    
    Type superclassType;
    String superclassName = cf.getSuperclassName();
    if (superclassName == null){
      // JavaClass API never return null as a superclass.
      throw Epp.fatal("");
    } else {
      Symbol s = Symbol.intern(superclassName);
      if (s == :"java.lang.Object" &&
	  (isInterface || fullName == :"java.lang.Object")){
	superclassType = null;
      } else {
	try {
	  superclassType = classTypeTable.get(s);
	} catch (NotFound e){
	  superclassType = new NotFoundClassType(s, declaringClass.toString());
	}
      }
    }
    
    String[] interfaceNames = cf.getInterfaceNames();
    Type[] interfaceTypes = new Type[interfaceNames.length];
    for (int i = 0; i < interfaceNames.length; i++) {
      Symbol s = Symbol.intern(interfaceNames[i]);
      try {
	interfaceTypes[i] = classTypeTable.get(s);
      } catch (NotFound e){
	interfaceTypes[i] = new NotFoundClassType(s, declaringClass.toString());
      }
    }
    
    Field[] javaClassFields = cf.getFields();
    Hashtable fieldTable = new Hashtable();
    for (int i = 0; i < javaClassFields.length; i++){
      FieldInfo f = javaClassFieldToFieldInfo(declaringClass,
					      javaClassFields[i]);
      fieldTable.put(f.getName(), f);
    }
    
    Method[] javaClassMethods = cf.getMethods();
    // key : Symbol, val : MethodInfo[]
    Hashtable methodTable = new Hashtable();
    // distinguish constructors from other methods
    Vector vc = new Vector();
    for (int i = 0; i < javaClassMethods.length; i++) {
      MethodInfo m = javaClassMethodToMethodInfo(declaringClass,
						 javaClassMethods[i]);
      Symbol name = m.getName();
      if (javaClassMethods[i].getName().equals("<clinit>")){
	// Do nothing.
      } else if (javaClassMethods[i].getName().equals("<init>")){
	vc.addElement(m);
      } else {
	MethodInfo[] a = (MethodInfo[])methodTable.get(name);
	if (a == null){
	  methodTable.put(name, new MethodInfo[]{ m });
	} else {
	  // Add an overloaded method.
	  MethodInfo[] newA = new MethodInfo[a.length + 1];
	  for (int j = 0; j < a.length; j++){
	    newA[j] = a[j];
	  }
	  newA[a.length] = m;
	  methodTable.put(name, newA);
	}
      }
    }
    MethodInfo[] constructorInfos = new MethodInfo[vc.size()];
    vc.copyInto(constructorInfos);
    

    Type outerClass = getOuterClassType(cf);
    Hashtable innerClassTable = getInnerClassTable(cf);
    
    return new ClassData(outerClass,
			 declaringClass,
			 modifiers,
			 isInterface,
			 fullName,
			 superclassType,
			 interfaceTypes,
			 constructorInfos,
			 fieldTable,
			 methodTable,
			 innerClassTable,
			 new Hashtable()
			 );
  }


  public Tree[] javaClassAccessFlagToTrees(AccessFlags af) {
    TreeVec tv = new TreeVec();
    if (af.isPublic()) tv.add(new Identifier(:public));
    if (af.isPrivate()) tv.add(new Identifier(:private));
    if (af.isProtected()) tv.add(new Identifier(:protected));
    if (af.isStatic()) tv.add(new Identifier(:static));
    if (af.isFinal()) tv.add(new Identifier(:final));
    if (af.isSynchronized()) tv.add(new Identifier(:synchronized));
    if (af.isVolatile()) tv.add(new Identifier(:volatile));
    if (af.isTransient()) tv.add(new Identifier(:transient));
    if (af.isNative()) tv.add(new Identifier(:native));
    if (af.isInterface()) tv.add(new Identifier(:interface));
    if (af.isAbstract()) tv.add(new Identifier(:abstract));

    int accessFlags = af.getAccessFlags();
    if ((accessFlags & 0x0800) != 0) tv.add(new Identifier(:strictfp));

    return tv.toArray();
  }

  public FieldInfo javaClassFieldToFieldInfo(Type declaringClass,
					     Field fi) {
    return new FieldInfo(declaringClass,
			 javaClassAccessFlagToTrees(fi),
			 new SignatureParser(fi.getSignature(),
					     declaringClass)
			 .parseDataType(),
			 Symbol.intern(fi.getName()));
  }

  public MethodInfo javaClassMethodToMethodInfo(Type declaringClass,
						Method mi) {
    Object[] parsedSignature =
      new SignatureParser(mi.getSignature(), declaringClass)
	.parseMethodDescriptor();
    
    ClassTypeTable classTypeTable 
      = (ClassTypeTable)Dynamic.get(:classTypeTable);
    ExceptionTable exceptionTable = mi.getExceptionTable();
    String[] exceptionNames;
    if (exceptionTable == null){
      exceptionNames = new String[]{};
    } else {
      exceptionNames = exceptionTable.getExceptionNames();
    }
    Type[] exceptions = new Type[exceptionNames.length];
    for (int i = 0; i < exceptionNames.length; i++){
      Symbol s = Symbol.intern(exceptionNames[i]);
      try {
	exceptions[i] = classTypeTable.get(s);
      } catch (NotFound e){
	exceptions[i] = new NotFoundClassType(s, declaringClass.toString());
      }
    }

    return new MethodInfo(declaringClass,
			  javaClassAccessFlagToTrees(mi),
			  (Type)parsedSignature[1],
			  Symbol.intern(mi.getName()),
			  (Type[])parsedSignature[0],
			  exceptions);
  }

  public Type getOuterClassType(JavaClass cf){
    String thisClassName = cf.getClassName().replace('.', '/');
    //System.out.println("getOuterClass: thisClassName = "+ thisClassName);

    ClassTypeTable classTypeTable 
	= (ClassTypeTable)Dynamic.get(:classTypeTable);

    Attribute[] attributes = cf.getAttributes();
    for (int i = 0; i < attributes.length; i++){
      if (attributes[i] instanceof InnerClasses){
	InnerClass[] innerClasses
	  = ((InnerClasses)attributes[i]).getInnerClasses();
	for (int j = 0; j < innerClasses.length; j++){
	  ConstantPool cp = cf.getConstantPool();
	  int innerClassIndex = innerClasses[j].getInnerClassIndex();
	  int outerClassIndex = innerClasses[j].getOuterClassIndex();
	  
	  if (innerClassIndex != 0 && outerClassIndex != 0){
	    String innerClassName
	      = cp.getConstantString(innerClassIndex,
				     Constants.CONSTANT_Class);
	    String outerClassName
	      = cp.getConstantString(outerClassIndex,
				     Constants.CONSTANT_Class);
	    
	    if (thisClassName.equals(innerClassName)){
	      Symbol dotName = Symbol.intern(outerClassName.replace('/', '.'));
	      try {
		return classTypeTable.get(dotName);
	      } catch (NotFound e){
		return new NotFoundClassType(dotName, thisClassName);
	      }
	    }
	  }
	}
      }
    }
    return null;
  }

  public Hashtable getInnerClassTable(JavaClass cf){
    String thisClassName = cf.getClassName().replace('.', '/');
    //System.out.println("getInnerClasses: thisClassName = "+ thisClassName);

    ClassTypeTable classTypeTable 
	= (ClassTypeTable)Dynamic.get(:classTypeTable);

    Hashtable innerClassTable = new Hashtable();

    Attribute[] attributes = cf.getAttributes();
    for (int i = 0; i < attributes.length; i++){
      if (attributes[i] instanceof InnerClasses){
	InnerClass[] innerClasses
	  = ((InnerClasses)attributes[i]).getInnerClasses();
	for (int j = 0; j < innerClasses.length; j++){
	  ConstantPool cp = cf.getConstantPool();
	  int innerClassIndex = innerClasses[j].getInnerClassIndex();
	  int outerClassIndex = innerClasses[j].getOuterClassIndex();
	  int simpleInnerNameIndex = innerClasses[j].getInnerNameIndex();
	  
	  if (innerClassIndex != 0 && outerClassIndex != 0
	      && simpleInnerNameIndex != 0){
	    String innerClassName
	      = cp.getConstantString(innerClassIndex,
				     Constants.CONSTANT_Class);
	    String outerClassName
	      = cp.getConstantString(outerClassIndex,
				     Constants.CONSTANT_Class);
	    String simpleInnerName
	      = ((ConstantUtf8)cp
		 .getConstant(simpleInnerNameIndex,
			      Constants.CONSTANT_Utf8)).getBytes();
	    
	    //System.out.println("getInnerClasses:inner = "+ innerClassName);
	    //System.out.println("getInnerClasses:outer = "+ outerClassName);
	    //System.out.println("getInnerClasses:simple = "+ simpleInnerName);
	    
	    if (thisClassName.equals(outerClassName)){
	      Symbol dotName = Symbol.intern(innerClassName.replace('/', '.'));
	      Type t;
	      try {
		t = classTypeTable.get(dotName);
	      } catch (NotFound e){
		t = new NotFoundClassType(dotName, thisClassName);
	      }
	      innerClassTable.put(Symbol.intern(simpleInnerName), t);
	    }
	  }
	}
      }
    }
    return innerClassTable;
  }
}


public class SignatureParser {
  int index = 0;
  String signature;
  Type declaringClass;
  SignatureParser(String signature, Type declaringClass){
    this.signature = signature;
    this.declaringClass = declaringClass;
  }
  Type parseDataType(){
    if (index >= signature.length()){
      throw Epp.error("Illegal signature: "+ signature);
    }

    //System.out.println("SignatureParser:"+ signature.charAt(index));
    
    switch (signature.charAt(index++)) {
    case 'B':
      return Type.Tbyte;
    case 'C':
      return Type.Tchar;
    case 'D':
      return Type.Tdouble;
    case 'F':
      return Type.Tfloat;
    case 'I':
      return Type.Tint;
    case 'J':
      return Type.Tlong;
    case 'S':
      return Type.Tshort;
    case 'Z':
      return Type.Tboolean;
    case 'L':
      ClassTypeTable classTypeTable 
	= (ClassTypeTable)Dynamic.get(:classTypeTable);
      int end = signature.indexOf(';', index);
      String name = signature.substring(index, end).replace('/', '.');
      index = end + 1;
      Symbol s = Symbol.intern(name);
      try {
	return classTypeTable.get(s);
      } catch (NotFound e){
	return new NotFoundClassType(s, declaringClass.toString());
      }
    case 'V':
      return Type.Tvoid;
    case '[':
      return new ArrayType(parseDataType());
    default:
      throw Epp.fatal("javaClassSignatureToType: Unknown type : "+ signature+
		      " in the class file of "+ declaringClass);
    }
  }

  // Returns { {paramType1, paramType2, ...}, retType }
  Object[] parseMethodDescriptor(){
    if (index >= signature.length() || signature.charAt(index++) != '('){
      throw Epp.fatal("Illegal signature : "+ signature+
		      " in the class file of "+ declaringClass);
    }
    Vector vec = new Vector();
    while (signature.charAt(index) != ')'){
      vec.addElement(parseDataType());
    }
    Type[] params = new Type[vec.size()];
    vec.copyInto(params);
    index++;

    Type retType = parseDataType();

    return new Object[]{ params, retType };
  }
}
