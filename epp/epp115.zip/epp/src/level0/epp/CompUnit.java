/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros

package epp;
import SystemMixinRuntimes.*;
import java.io.Writer;
import java.io.IOException;



SystemMixin CompilationUnitElements {
  
  class Epp {

    extend void initializationPass(){
      original();
      // Does not call "unbound".
      Dynamic.bind(:extraImportDeclarations, new TreeVec());
      initExtraImportDeclarations();
    }
    
    define implement void initExtraImportDeclarations(){
    }

    define implement void addExtraImportDeclaration(Tree tree){
      ((TreeVec)Dynamic.get(:extraImportDeclarations)).add(tree);
    }

    
    define Tree packageDeclarationBody() {
      if (lookahead() == :package) {
	matchAny();
	Tree name = name();
	match(:";");
	return new Tree(:packageDeclaration, name);
      } else {
	return new Tree(:packageDeclaration);
      }
    }
    
    define Tree importDeclarationsBody() {
      TreeVec tvec = new TreeVec();
      while (lookahead() == :import) {
	tvec.add(importDeclaration());
      }
      return new Tree(:importDeclarations, tvec);
    }
    
    define Tree importDeclarationBody() {
      match(:import);
      Tree name = name();
      if (lookahead() == :".*") {
	matchAny();
	match(:";");
	return new Tree(:importOnDemand, name);
      } else {
	match(:";");
	return new Tree(:importSingle, name);
      }
    }
    
    define Tree typeDeclarationsBody() {
      TreeVec tvec = new TreeVec();
      while(true) {
	if (lookahead().isLiteralToken() &&
	    lookahead().literalTag() == :eof){
	  break;
	} else {
	  tvec.add(typeDeclaration());
	}
      }
      return new Tree(:typeDeclarations, tvec);
    }
    
    extend void initMacroTable() {
      original();
      defineMacro(:compilationUnit, new CompilationUnitMacro());
      defineMacro(:typeDeclarations, new TypeDeclarationsMacro());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:compilationUnit, new SimpleEmitter("%%%"));
      defineEmitter(:importSingle, new SimpleEmitter("import %;"));
      defineEmitter(:importOnDemand, new SimpleEmitter("import %.*;"));
      defineEmitter(:packageDeclaration, new PackageDeclarationEmitter());
      defineEmitter(:importDeclarations, new ImportDeclarationsEmitter());
      defineEmitter(:typeDeclarations, new TypeDeclarationsEmitter());
      defineEmitter(:errorInCompilationUnit,
		    new SimpleEmitter("{ <errorInCompilationUnit> }"));
    }
  }
}

class CompilationUnitMacro extends Macro {
  public Tree call(Tree tree){
    Tree[] args = macroExpandArray(tree.args());
    
    if (args[1].tag() != :importDeclarations){
      throw Epp.fatal("");
    }
    TreeVec imports = new TreeVec();
    imports.addA(args[1].args());
    imports.addA((TreeVec)Dynamic.get(:extraImportDeclarations));
    
    // The array args is newly created by the macroExpandArray method call.
    // In other words, the array is not owned by any Trees.
    // So, I can destructively change its element.
    args[1] = args[1].modifyArgs(imports.toArray());
    return tree.modifyArgs(args);
  }
}

class TypeDeclarationsMacro extends Macro {
  public Tree call(Tree tree){
    Dynamic.bind(:beforeCurrentTypeDeclaration, null);
    Dynamic.bind(:afterCurrentTypeDeclaration, null);
    try {
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();
      
      for (int i = 0; i < args.length; i++){
      	Dynamic.set(:beforeCurrentTypeDeclaration, new TreeVec());
	Dynamic.set(:afterCurrentTypeDeclaration, new TreeVec());
	
        Tree earg = macroExpandTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentTypeDeclaration));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentTypeDeclaration));
      }
      return tree.modifyArgs(tvec.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}

class PackageDeclarationEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitString(out, "package ");
      emitTree(out, args[0]);
      out.write(';');
    }
  }
}

class ImportDeclarationsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    for (int i = 0; i < args.length; i++) {
      emitTree(out, args[i]);
    }
  }
}

class TypeDeclarationsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    for (int i = 0; i < args.length; i++) {
      outputNewlineForReadability(out);
      outputNewlineForReadability(out);
      emitTree(out, args[i]);
    }
  }
}



defineNonTerminal(typeDeclarations,	typeDeclarationsBody());
defineNonTerminal(importDeclaration,	importDeclarationBody());
defineNonTerminal(importDeclarations,	importDeclarationsBody());
defineNonTerminal(packageDeclaration,	packageDeclarationBody());


     
SystemMixin CompilationUnit {
  
  class Epp {
    define Tree compilationUnit() {
      return new Tree(:compilationUnit,
		      packageDeclaration(),
		      importDeclarations(),
		      typeDeclarations());
    }
  }
}




SystemMixin StartByCompilationUnit {
  
  class Epp {
    default Tree start() {
      return compilationUnit();
    }
  }
}
