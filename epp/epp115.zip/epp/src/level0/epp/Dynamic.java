/*
*
* Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
*
* Permission to use, copy, modify and redistribution this software in
* whole and in part, for evaluation or research purposes and without fee
* is hereby granted provided this copyright notice.
* See CopyrightAndLicensing.txt for licensing condition.
*/

#epp AutoSplitFiles
#epp Symbol

/*

Example
-------

void foo(){
  ...;
  Dynamic.bind(:sym1, "abc");
  Dynamic.bindInt(:sym2, 123);
  try {				// Do try immediatly after bind.
    ...; bar(); ...;
    return;
  } finally {			// Do unbind same times as you did bind.
    Dynamic.unbindInt();	// Use unbindInt if you used bindInt.
    Dynamic.unbind();
  }
}

void bar(){
  String s = (String)Dynamic.get(:sym1);
  Dynamic.setInt(:sym2, Dynamic.getInt(:sym2) + 1);
}


*/


package epp;
import java.util.Stack;


public abstract class Dynamic {
  // This variable is initialized by EPP main routine.
  public static DVenv env = null;

  public static void bind(Symbol var, Object val){ env.bind(var, val); }
  public static void bindInt(Symbol var, int val){ env.bindInt(var, val); }
  public static void unbind(){ env.unbind(); }
  public static void unbindInt(){ env.unbindInt(); }
  public static Object get(Symbol var){ return env.get(var); }
  public static int getInt(Symbol var){ return env.getInt(var); }
  public static void set(Symbol var, Object val){ env.set(var, val); }
  public static void setInt(Symbol var, int val){ env.setInt(var, val); }
}

public abstract class DVenv {
  public abstract void bind(Symbol var, Object val);
  public abstract void bindInt(Symbol var, int val);
  public abstract void unbind();
  public abstract void unbindInt();
  public abstract Object get(Symbol var);
  public abstract int getInt(Symbol var);
  public abstract void set(Symbol var, Object val);
  public abstract void setInt(Symbol var, int val);
}


/*
 The value of a dynamic scope variable is either UNBOUND value or normal value.
 Unlike lisp, dynamic scope variable should be bound before
being set some value.
This rule increases probability of detecting miss spelling of variable names.

Thread-safe is guaranteed if and only if each threads has it's own DVenv.

 DVID is small integer which is allocated globally to a Symbol
if the Symbol is firstly bound by some thread.
If the value of DVID is -1, it indicates no threads allocated DVID
to the Symbol.
Once a DVID is allocated to a Symbol, the DVID will never reclaimed
unless the JavaVM quits its execution.
Whether the Symbol's DVID is allocated or not is invisible from 
the user of dynamic scope variables.

*/

public class DVenvArrayShallow extends DVenv {
  static final int EXTSIZE = 100;
  public Object[] vals = new Object[0];
  public int[] valsInt = new int[0];

  static int[] currentDVIDcontainer = new int[1];

  Stack varStack = new Stack();
  Stack valStack = new Stack();
  StackInt valStackInt = new StackInt();

  // Special unique value used as a value of unbound variables.
  public static final Object[] UNBOUND = {"unbound"};

  // I'm not sure if this code is correct.
  public void allocateDVID(Symbol var){
    synchronized(var){
      synchronized(currentDVIDcontainer){
	if (var.dvid == -1){
	  var.dvid = currentDVIDcontainer[0]++;
	} else {
	  // Some other thread have already allocated dvid.
	  // Do nothing.
	  ;
	}
      }
    }
  }

  //--------------------------------------------------
  // For Object.
  public void bind(Symbol var, Object val){
    int dvid = var.dvid;
    if (dvid == -1){
      allocateDVID(var);
      dvid = var.dvid;
    }
    if (dvid >= vals.length){
      int newSize = vals.length;
      while (newSize <= dvid) newSize += EXTSIZE;
      Object[] newVals = new Object[newSize];
      for (int i = 0; i < vals.length; i++){
	newVals[i] = vals[i];
      }
      for (int i = vals.length; i < newVals.length; i++){
	newVals[i] = UNBOUND;
      }
      vals = newVals;
    }

    if (var.dvType == null){
      var.dvType = :Object;
    }
    checkDVType(var, :Object);
    varStack.push(var);
    valStack.push(vals[dvid]);
    vals[dvid] = val;
  }

  public void unbind(){
    Symbol var = (Symbol)varStack.pop();
    checkDVType(var, :Object);
    int dvid = var.dvid;
    vals[dvid] = valStack.pop();
  }

  public Object get(Symbol var){
    checkDVType(var, :Object);
    try {
      Object val = vals[var.dvid];
      if (val == UNBOUND) {
	throw unboundVariableAccess(var);
      } else {
	return val;
      }

      // If this variable is bound by another thread,
      //this exception may be throwed by above array access.
    } catch (ArrayIndexOutOfBoundsException e){
      throw unboundVariableAccess(var);
    }
  }
  
  public void set(Symbol var, Object val){
    checkDVType(var, :Object);
    try {
      int dvid = var.dvid;
      if (vals[dvid] == UNBOUND) {
	throw unboundVariableAccess(var);
      } else {
	vals[dvid] = val;
      }
    } catch (ArrayIndexOutOfBoundsException e){
      throw unboundVariableAccess(var);
    }
  }

  //--------------------------------------------------
  // For int. 
  public void bindInt(Symbol var, int val){
    int dvid = var.dvid;
    if (dvid == -1){
      allocateDVID(var);
      dvid = var.dvid;
    }
    if (dvid >= valsInt.length){
      int newSize = valsInt.length;
      while (newSize <= dvid) newSize += EXTSIZE;
      int[] newVals = new int[newSize];
      for (int i = 0; i < valsInt.length; i++){
	newVals[i] = valsInt[i];
      }
      for (int i = valsInt.length; i < newVals.length; i++){
	newVals[i] = -9999;	// unbound value.
      }
      valsInt = newVals;
    }

    if (var.dvType == null){
      var.dvType = :int;
    }
    checkDVType(var, :int);
    varStack.push(var);
    valStackInt.push(valsInt[dvid]);
    valsInt[dvid] = val;
  }

  public void unbindInt(){
    Symbol var = (Symbol)varStack.pop();
    checkDVType(var, :int);
    int dvid = var.dvid;
    valsInt[dvid] = valStackInt.pop();
  }

  public int getInt(Symbol var){
    checkDVType(var, :int);
    try {
      int val = valsInt[var.dvid];
      // It's impossible to check if the value is unbound.
      return val;
    } catch (ArrayIndexOutOfBoundsException e){
      throw unboundVariableAccess(var);
    }
  }
  
  public void setInt(Symbol var, int val){
    checkDVType(var, :int);
    try {
      int dvid = var.dvid;
      // It's impossible to check if the value is unbound.
      valsInt[dvid] = val;
    } catch (ArrayIndexOutOfBoundsException e){
      throw unboundVariableAccess(var);
    }
  }

  //--------------------------------------------------

  public RuntimeException unboundVariableAccess(Symbol var){
    return new UnboundDynamicVariableAccessException
      ("Dynamic : Unbound dynamic scope variable : "+ var);
  }
  
  public void checkDVType(Symbol var, Symbol type){
    if (var.dvType != type){
      if (var.dvType == null){
	throw unboundVariableAccess(var);
      } else {
	throw new IllegalTypeDynamicVariableAccessException
	  ("Dynamic : "+ var.dvType+
	   " type dynamic scope variable is requied but "+
	   type+ " type variable was supplied: "+ var);
      }
    }
  }
}


public class StackInt {
  int i;
  static final int EXTEND = 256;
  int p = 0;
  int[] a = new int[0];
  public void push(int x){
    if (p >= a.length){
      int size = a.length + EXTEND;
      int[] newA = new int[size];
      for (int i = 0; i < a.length; i++){
	newA[i] = a[i];
      }
      a = newA;
    }
    a[p++] = x;
  }
  public int pop(){
    if (p <= 0) {
      throw Epp.fatal("StackInt: Empty stack.");
    }
    return a[--p];
  }
}



public class UnboundDynamicVariableAccessException extends RuntimeException {
  public UnboundDynamicVariableAccessException(String s){
    super(s);
  }
}

public class IllegalTypeDynamicVariableAccessException
extends RuntimeException {
  public IllegalTypeDynamicVariableAccessException(String s){
    super(s);
  }
}


//--------------------------------------------------
// 
// Currently, not used.

public interface DVenvContainer {
  public abstract DVenv getDVenv();
}

public class ThreadWithDVenv extends Thread implements DVenvContainer {
  DVenv env;

  public ThreadWithDVenv(DVenv env){
    this.env = env;
  }

  public DVenv getDVenv() {
    return env;
  }
}

public class DVenvForThread extends DVenv {
  public static DVenv env(){
    return ((DVenvContainer)Thread.currentThread()).getDVenv();
  }
  public void bind(Symbol var, Object val){
    env().bind(var, val);
  }
  public void unbind(){
    env().unbind();
  }
  public Object get(Symbol var){
    return env().get(var);
  }
  public void set(Symbol var, Object val){
    env().set(var, val);
  }
  public void bindInt(Symbol var, int val){
    env().bindInt(var, val);
  }
  public void unbindInt(){
    env().unbindInt();
  }
  public int getInt(Symbol var){
    return env().getInt(var);
  }
  public void setInt(Symbol var, int val){
    env().setInt(var, val);
  }
}
