/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package epp;

public abstract class Token {

  public boolean isLiteralToken(){
    return false;
  }

  public boolean isSymbol(){
    return false;
  }
  
  public Symbol literalTag(){
    throw Epp.fatal("A method literalTag() was invoked but "+
		    "this is not an instance of LiteralToken: "+
		    this);
  }
  
  public String literalContents(){
    throw Epp.fatal("A method literalContents() was invoked but "+
		    "this is not an instance of LiteralToken: "+
		    this);
  }

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Token print(){
    Opts.out.println(this);
    return this;
  }
}
