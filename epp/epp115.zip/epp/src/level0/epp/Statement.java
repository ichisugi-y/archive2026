/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */
     
#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros


package epp;
import SystemMixinRuntimes.*;
import java.io.Writer;
import java.io.IOException;




defineNonTerminal(statement, statementOtherwise());
     
     
SystemMixin StatementExpression {
  
  class Epp {
    define Tree statementOtherwise() {
      int p = inputPointer();
      Tree tree = expression();
      Token nextToken = lookahead();
      if (nextToken == :";") {
	matchAny();
	return new Tree(:expressionStatement, tree);
      } else {
	backtrack(p);
      }
      return statementOtherwise2(tree, nextToken);
    }
      
    define Tree statementOtherwise2(Tree tree, Token nextToken) {
      if (nextToken == :":") {
	tree = expression();
	match(:":");
	return labeled(tree);
      } else {
	// The input is regarded as a localVariableDecl
	//in the following situations:
	//	a.b.c x;
	//	a.b[] x;
	//   modifier a.b x;
	//  modifier1 modifier2 ...
	//      class InnerClassName ...
	//   modifier class InnerClassName ...
	//	      ^ nextToken
	//
	// NOTE: Type or Modifier was parsed as an expression
	//to find "nextToken".
	return localVariableDecl();
      }
    }
    
    define default Tree labeled(Tree tree) {
      if (tree.tag() == :id) {
	return new Tree(:labeled, tree, statement());
      } else {
	throw error("\":\" appeared after an expression.");
      }
    }

    // This method is redefined at below.
    define default Tree localVariableDecl() {
      throw Epp.fatal("No localVariableDecl implementation.");
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:expressionStatement, new ExpressionStatementEmitter());
      defineEmitter(:labeled, new SimpleEmitter("%: %"));
    }
  }
}
  
class ExpressionStatementEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    checkArgsLength(tree, 1);
    Tree exp = removeIllegalStatementExpression(tree.args()[0]);
    emitTree(out, exp);
    if (exp.tag() != :block){
      out.write(';');
    }
  }

  // In order to make deveropping plug-in easy,
  // the emitter removes cast which causes Java compiler error.
  //     (T)exp;   ->   exp;
  Tree removeIllegalStatementExpression(Tree tree){
    Symbol tag = tree.tag();
    if (tag == :cast){
      return removeIllegalStatementExpression(tree.args()[1]);
    } else {
      return tree;
    }
  }
}



defineNonTerminal(block, blockOtherwise());
     
     
     
SystemMixin BlockOtherwise {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :"{") {
	return block();
      } else {
	return original();
      }
    }
    
    define Tree blockOtherwise() {
      match(:"{");
      if (Opts.nocatch){
	return blockRest();
      } else {
	try {
	  return blockRest();
	} catch (EppUserError e){
	  if (Opts.log) Opts.out.println("An error is caught during parsing a block. Skipping until the end of the block.");
	  int level = 1;
	  while (level > 0){
	    Token token = matchAny();
	    if (token == :"{") {
	      level++;
	    } else if (token == :"}"){
	      level--;
	    } else if (token.isLiteralToken() &&
		       token.literalTag() == :eof){
	      throw error("Unexpected EOF.");
	    }
	  }
	  return new Tree(:errorInBlock);
	}
      }
    }

    define Tree blockRest() {
      TreeVec tvec = new TreeVec();
      while (lookahead() != :"}") {
	tvec.add(statement());
      }
      match(:"}");
      return new Tree(:block, tvec);
    }
    
    extend void initMacroTable() {
      original();
      defineMacro(:block, new BlockMacro());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:block, new BlockEmitter());
      defineEmitter(:errorInBlock, new SimpleEmitter("{ <errorInBlock> }"));
    }
  }
}


class BlockMacro extends Macro {
  public Tree call(Tree tree){
    Dynamic.bind(:beforeCurrentBlockStatement, null);
    Dynamic.bind(:afterCurrentBlockStatement, null);
    try{
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();
      
      for (int i = 0; i < args.length; i++) {
	Dynamic.set(:beforeCurrentBlockStatement, new TreeVec());
	Dynamic.set(:afterCurrentBlockStatement, new TreeVec());
	
        Tree earg = macroExpandTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentBlockStatement));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentBlockStatement));
      }
      return tree.modifyArgs(tvec.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}
  
class BlockEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    out.write('{');
    
    Dynamic.bindInt(:outputIndent,
		    Dynamic.getInt(:outputIndent) + 2);
    try {
      outputNewlineForReadability(out);
      Tree[] args = tree.args();
      for (int i = 0; i < args.length; i++) {
	// In order to avoid strict "unreachable statement" checking.
	if (args[i].tag() == :emptyStatement){
	  out.write("/* empty statement */");
	} else {
	  emitTree(out, args[i]);
	  out.write(' ');
	  outputNewlineForReadability(out);
	}
      }
      out.write('}');
    } finally {
      Dynamic.unbindInt();
    }
  }
}



SystemMixin EmptyStatement {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :";") {
	matchAny();
	return new Tree(:emptyStatement);
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:emptyStatement, new SimpleEmitter(";"));
    }
  }
}



SystemMixin Switch {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :switch) {
	matchAny();
	match(:"(");
	Tree exp = expression();
	match(:")");
	return new Tree(:switch, exp, block());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:switch, new SimpleEmitter("switch (%) %"));
    }
  }
}



SystemMixin Case {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :case) {
	matchAny();
	Tree exp = expression();
	match(:":");
	return new Tree(:case, exp);
      } else if (lookahead() == :default) {
	matchAny();
	match(:":");
	return new Tree(:default);
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:case, new SimpleEmitter("case % : "));
      defineEmitter(:default, new SimpleEmitter("default : "));
    }
  }
}



SystemMixin Do {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :do) {
	matchAny();
	Tree body = statement();
	match(:while);
	match(:"(");
	Tree cond = expression();
	match(:")");
	match(:";");
	return new Tree(:do, body, cond);
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:do, new SimpleEmitter("do % while (%);"));
    }
  }
}



SystemMixin Break {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :break) {
	matchAny();
	if (lookahead() == :";") {
	  matchAny();
	  return new Tree(:break);
	} else {
	  Tree id = identifier();
	  match(:";");
	  return new Tree(:breakWithLabel, id);
	}
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:break, new SimpleEmitter("break;"));
      defineEmitter(:breakWithLabel, new SimpleEmitter("break %;"));
    }
  }
}



SystemMixin Continue {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :continue) {
	matchAny();
	if (lookahead() == :";") {
	  matchAny();
	  return new Tree(:continue);
	} else {
	  Tree id = identifier();
	  match(:";");
	  return new Tree(:continueWithLabel, id);
	}
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:continue, new SimpleEmitter("continue;"));
      defineEmitter(:continueWithLabel, new SimpleEmitter("continue %;"));
    }
  }
}



SystemMixin Return {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :return) {
	matchAny();
	if (lookahead() == :";") {
	  matchAny();
	  return new Tree(:return);
	} else {
	  Tree exp = expression();
	  match(:";");
	  return new Tree(:returnWithExp, exp);
	}
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:return, new SimpleEmitter("return;"));
      defineEmitter(:returnWithExp, new SimpleEmitter("return %;"));
    }
  }
}



SystemMixin Synchronized {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :synchronized) {
	matchAny();
	match(:"(");
	Tree exp = expression();
	match(:")");
	return new Tree(:synchronized, exp, block());
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:synchronized, new SimpleEmitter("synchronized (%) %"));
    }
  }
}



SystemMixin Throw {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :throw) {
	matchAny();
	Tree exp = expression();
	match(:";");
	return new Tree(:throw, exp);
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:throw, new SimpleEmitter("throw %;"));
    }
  }
}



SystemMixin Try {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :try) {
	TreeVec tvec = new TreeVec();
	matchAny();
	tvec.add(block());
	while(true) {
	  if (lookahead() == :catch) {
	    tvec.add(catchClause());
	  } else {
	    break;
	  }
	}
	if (lookahead() == :finally) {
	  tvec.add(finallyClause());
	}
	return new Tree(:try, tvec);
      } else {
	return original();
      }
    }
    
    define Tree catchClause() {
      Tree param;
      match(:catch);
      match(:"(");
      param = formalParameter();
      match(:")");
      return new Tree(:catch, param, block());
    }
    
    define Tree finallyClause() {
      match(:finally);
      return new Tree(:finally, block());
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:try, new TryEmitter());
      defineEmitter(:catch, new SimpleEmitter("catch (%) %"));
      defineEmitter(:finally, new SimpleEmitter("finally %"));
    }
  }
}

class TryEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    emitString(out, "try");
    Tree[] args = tree.args();
    for (int i = 0; i < args.length; i++) {
      out.write(' ');
      emitTree(out, args[i]);
    }
  }
}


SystemMixin If {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :if) {
	matchAny();
	match(:"(");
	Tree condTree = expression();
	match(:")");
	Tree thenTree = statement();
	Tree elseTree;
	if (lookahead() == :else) {
	  matchAny();
	  elseTree = statement();
	} else {
	  elseTree = new Tree(:emptyStatement);
	}
	return new Tree(:if, condTree, thenTree, elseTree);
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:if, new SimpleEmitter("if (%) % else %"));
    }
  }
}



SystemMixin While {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :while) {
	matchAny();
	match(:"(");
	Tree cond = expression();
	match(:")");
	return new Tree(:while, cond, statement());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:while, new SimpleEmitter("while (%) %"));
    }
  }
}



SystemMixin For {
  
  class Epp {
    extend Tree statementTop() {
      if (lookahead() == :for) {
	Tree init;
	Tree end;
	Tree next;
	Tree body;
	matchAny();
	match(:"(");
	init = statement();
	if (init.tag() == :expressionStatement){
	  TreeVec tvec = new TreeVec();
	  commmaSeparetedExpsToTreeVec(init.args()[0], tvec);
	  init = new Tree(:forArg, tvec);
	} else if (init.tag() == :decl){
	  // do nothing
	} else if (init.tag() == :emptyStatement) {
	  init = new Tree(:forArg);
	} else {
	  throw error(init+ " is not a ForInit.");
	}
	if (lookahead() == :";") {
	  end = new Tree(:forArg);
	} else {
	  end = new Tree(:forArg, expression());
	}
	match(:";");
	if (lookahead() == :")") {
	  next = new Tree(:forArg);
	} else {
	  TreeVec tvec = new TreeVec();
	  commmaSeparetedExpsToTreeVec(expression(), tvec);
	  next = new Tree(:forArg, tvec);
	}
	match(:")");
	body = statement();
	return new Tree(:for, init, end, next, body);
      } else {
	return original();
      }
    }
    
    define void commmaSeparetedExpsToTreeVec(Tree tree, TreeVec tvec) {
      if (tree.tag() == :",") {
	Tree[] args = tree.args();
	commmaSeparetedExpsToTreeVec(args[0], tvec);
	commmaSeparetedExpsToTreeVec(args[1], tvec);
      } else {
	tvec.add(tree);
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:forArg,  new ForArgEmitter());
      defineEmitter(:for, new ForEmitter());
    }
  }
}

class ForArgEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++) {
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
    }
  }
}

class ForEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    emitString(out, "for (");
    Tree[] args = tree.args();
    Symbol tag = args[0].tag();
    if (tag == :decl){
      emitTree(out, args[0]);
    } else if (tag == :forArg){
      emitTree(out, args[0]);
      out.write(';');
    } else {
      throw Epp.fatal(""+ tag+ " is illegal as ForInit.");
    }
    out.write(' ');
    emitTree(out, args[1]);
    out.write(';');
    out.write(' ');
    emitTree(out, args[2]);
    out.write(')');
    out.write(' ');
    emitTree(out, args[3]);
  }
}



defineNonTerminal(modifiers, modifiersOtherwise());
defineNonTerminal(modifier, null);
     


SystemMixin LocalVariableDecl {
  
  class Epp {
    implement Tree localVariableDecl() {
      Tree modifiers = modifiers();
      if (lookahead() == :class || lookahead() == :interface){
	// An inner class at the toplevel of a Block.
	return classDeclaration(modifiers);
      } else {
	Tree type = type();
	Tree vardecls = variableDeclarators();
	match(:";");
	return new Tree(:decl, modifiers, type, vardecls);
      }
    }
    
    define implement Tree modifiersOtherwise() {
      TreeVec modifiers = new TreeVec();
      while (true) {
	Tree m = modifier();
	if (m == null) break;
	modifiers.add(m);
      }
      return new Tree(:modifiers, modifiers);
    }
    
    extend Tree modifierTop() {
      Token token = lookahead();
      if (token == :public || token == :protected || token == :private ||
	  token == :static || token == :abstract || token == :final ||
	  token == :native || token == :synchronized ||
	  token == :transient || token == :volatile ||
	  token == :strictfp) {
	return identifier();
      } else {
	return original();
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:decl, new SimpleEmitter("%% %;"));
      defineEmitter(:modifiers, new ModifiersEmitter()); 
    }
  }
}

class ModifiersEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    for (int i = 0; i < args.length; i++){
      emitTree(out, args[i]);
      out.write(' ');
    }
  }
}



SystemMixin VariableDeclarators {
  
  class Epp {
    define implement Tree variableDeclarators() {
      TreeVec vardecls = new TreeVec();
      vardecls.add(variableDeclarator());
      while(true) {
	if (lookahead() == :",") {
	  matchAny();
	  vardecls.add(variableDeclarator());
	} else {
	  break;
	}
      }
      return new Tree(:vardecls, vardecls);
    }
    
    define implement Tree variableDeclarator() {
      Tree vdi = variableDeclaratorId();
      if (lookahead() == :"=") {
	matchAny();
	return new Tree(:varInit, vdi, variableInitializer());
      } else {
	return vdi;
      }
    }
    
    define implement Tree variableInitializer() {
      if (lookahead() == :"{") {
	return arrayInitializer();
      } else {
	return expressionNoComma();
      }
    }
    
    define implement Tree arrayInitializer() {
      match(:"{");
      TreeVec tvec = new TreeVec();
      if (lookahead() == :",") {
	// {,}
	matchAny();
      } else if (lookahead() == :"}") {
	// {}
      } else {
	// {a ... }
	while(true) {
	  tvec.add(variableInitializer());
	  if (lookahead() == :",") {
	    matchAny();
	  } 
	  if (lookahead() == :"}") {
	    break;
	  }
	}
      }
      
      match(:"}");
      return new Tree(:arrayInitializer, tvec);
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:varInit, new SimpleEmitter("% = %"));
      defineEmitter(:vardecls,  new VardeclsEmitter());
      defineEmitter(:arrayInitializer, new ArrayInitializerEmitter());
    }
  }
}

class VardeclsEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++){
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
    } else {
      throw Epp.fatal("The length of arg of (vardecls ...) is 0.");
    }
  }
}

class ArrayInitializerEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    out.write('{');
    Tree[] args = tree.args();
    for (int i = 0; i < args.length; i++){
      emitTree(out, args[i]);
      out.write(',');
      out.write(' ');
    }
    out.write('}');
  }
}



defineNonTerminal(variableDeclaratorId, identifier());
     
     
SystemMixin ArrayVar {
  
  class Epp {
    extend Tree variableDeclaratorIdLeft(Tree tree) {
      if (lookahead() == :"[") {
	matchAny();
	match(:"]"); 
	return new Tree(:arrayVar, tree);
      } else {
	return original(tree);
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:arrayVar, new SimpleEmitter("%[]"));
    }
  }
}


SystemMixin StartByStatement {
  
  class Epp {
    default Tree start() {
      return statement();
    }
  }
}
