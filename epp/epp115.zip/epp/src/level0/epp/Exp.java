/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros

     
package epp;
import SystemMixinRuntimes.*;
import java.io.Writer;
import java.io.IOException;



SystemMixin Name {
  
  class Epp {
    define Tree identifier() {
      Token token = lookahead();
      if (token.isSymbol()) {
	Symbol sym = (Symbol)token;

	Dynamic.bindInt(:lineNumberOfThisNode, Dynamic.getInt(:lineNumber));
	Dynamic.bindInt(:beginningPointOfThisNode,
			Dynamic.getInt(:beginningPoint));
	try {
	  if (sym.maybeIdentifier()) {
	    matchAny();
	    return new Identifier(sym);
	  } else {
	    throw error("\""+ sym+
			"\" appeared but an identifier is expected.");
	  }
	} finally {
	  Dynamic.unbindInt();
	  Dynamic.unbindInt();
	}
      } else {
	throw error("Identifier is expected here.");
      }
    }
    
    define Tree name() {
      TreeVec tvec = new TreeVec();
      tvec.add(identifier());
      while (lookahead() == :".") {
	matchAny();
	tvec.add(identifier());
      }
      return new Tree(:name, tvec);
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:id, new IdEmitter());
      defineEmitter(:name, new NameEmitter());
    }
  }
}


class IdEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    String str = tree.idName().toString();
    for (int i = 0; i < str.length(); i++){
      out.write(str.charAt(i));
    }
  }
}

class NameEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    emitTree(out, args[0]);
    for (int i = 1; i < args.length; i++){
      out.write('.');
      emitTree(out, args[i]);
    }
  }
}



SystemMixin FieldOrInvoke {
  
  class Epp {

    // This method is called in the following situations:
    //		a.b.c.new T...
    //		a.b.c.class
    //		a(args, ...)
    //		a
    //		a.b.c.x(args, ...)
    //		a.b.c.x
    // Since JLS2
    //		a.b.c.this
    //		a.b.c.super.f
    //		a.b.c.super()
    redefine Tree primaryOtherwise() {
      TreeVec tvec = new TreeVec();
      
      Tree last = identifier();

      while(true) {
	if (lookahead() != :".") break;
	matchAny();
	
	if (lookahead() == :new){
	  // a.b.c.new T...
	  Tree[] butlast = tvec.toArray();
	  Tree exp;
	  if (butlast.length == 0){
	    exp = last;
	  } else {
	    exp = new Tree(:fieldLong, new Tree(:name, tvec), last);
	  }
	  return new Tree(:newEnclosingInstance, exp, instanceCreation());
	} else if (lookahead() == :class){
	  // a.b.c.class
	  matchAny();
	  tvec.add(last);
	  return new Tree(:classLiteral, new Tree(:name, tvec));
	} else if (lookahead() == :this){
	  matchAny();
	  tvec.add(last);
	  // a.b.c.this
	  return new Tree(:qualifiedThis, new Tree(:name, tvec));
	} else if (lookahead() == :super){
	  matchAny();
	  if (lookahead() == :"."){
	    matchAny();
	    tvec.add(last);
	    Tree name = new Tree(:name, tvec);
	    Tree id = identifier();
	    if (lookahead() == :"("){
	      // a.b.c.super.m()
	      return new Tree(:qualifiedInvokeSuper, name, id, argumentList());
	    } else {
	      // a.b.c.super.f
	      return new Tree(:qualifiedFieldSuper, name, id);
	    }
	  } else if (lookahead() == :"("){
	    // a.b.c.super()
	    Tree enclosing;
	    Tree[] butlast = tvec.toArray();
	    if (butlast.length == 0){
	      enclosing = last;
	    } else {
	      enclosing = new Tree(:fieldLong, new Tree(:name, butlast),
				   last);
	    }
	    return new Tree(:qualifiedInvokeSuperConstructor,
			    enclosing,
			    argumentList());
	  } else {
	    throw error("\".\" or \"(\" is required after "+
			"\"Name.super\"");
	  }
	}

	tvec.add(last);
	last = identifier();
      }
      
      Tree[] butlast = tvec.toArray();
      if (butlast.length == 0){
	//		a(args, ...)
	//		a
	if (lookahead() == :"("){
	  Tree args = argumentList();
	  return new Tree(:invoke1, last, args);
	} else {
	  return last;
	}
      } else {
	//		a.b.c.x(args, ...)
	//		a.b.c.x
	//		      ^ last token
	if (lookahead() == :"("){
	  Tree args = argumentList();
	  return new Tree(:invokeLong, new Tree(:name, butlast), last, args);
	} else {
	  return new Tree(:fieldLong, new Tree(:name, butlast), last);
	}
      }
    }
    
    // This method is called after "Primary" is parsed.
    // For example,
    //		(exp).new T...
    //		a.b[].class
    //		(exp).a()
    //		(exp).a
    //		     ^ current token
    //
    // See also the following method definitions,
    //name(), primaryOtherwise(), type(), statementOtherwise() .
    extend Tree primaryLeft(Tree tree) {
      if (lookahead() == :".") {
	matchAny();
	if (lookahead() == :new){
	  return new Tree(:newEnclosingInstance, tree, instanceCreation());
	} else if (lookahead() == :class){
	  matchAny();
	  return new Tree(:classLiteral, convertExpressionToType(tree));
	} else if (lookahead() == :super){
	  matchAny();
	  Tree argumentList = argumentList();
	  return new Tree(:qualifiedInvokeSuperConstructor, tree, argumentList);
	} else {
	  Tree id = identifier();
	  if (lookahead() == :"("){
	    Tree args = argumentList();
	    return new Tree(:invokeExp, tree, id, args);
	  } else {
	    return new Tree(:fieldExp, tree, id);
	  }
	}
      } else {
	return original(tree);
      }
    }

    define implement Tree convertExpressionToType(Tree exp){
      Symbol tag = exp.tag();
      if (tag == :name){
	return exp;
      } else if (tag == :id){
	//old return new Tree(:name, exp);
	Tree newTree = new Tree(:name, exp);
	return TypeChecker.remakeTree(newTree, exp);
      } else if (tag == :arrayOf){
	Tree[] newArgs = { convertExpressionToType(exp.args()[0]) };
	return exp.modifyArgs(newArgs);
      } else if (tag == :fieldLong){
	//     (fieldLong (name (id a) (id b)) (id c))
	// --> (name (id a) (id b) (id c))
	Tree name = exp.args()[0];
	if (name.tag() != :name){
	  throw Epp.fatal("The first arg of fieldLong is not a Name: "+ exp);
	}
	Tree[] nameArgs = name.args();
	Tree[] newNameArgs = new Tree[nameArgs.length + 1];
	for (int i = 0; i < nameArgs.length; i++){
	  newNameArgs[i] = nameArgs[i];
	}
	newNameArgs[nameArgs.length] = exp.args()[1];
	return name.modifyArgs(newNameArgs);
      } else {
	throw error("Illegal expression was appeared but Type is expected.");
      }
    }

    // This method is called only from LocalVariableDecl. 
    define implement Tree type(){
      return convertExpressionToType(primary());
    }

    
    extend void initEmitterTable() {
      original();
      defineEmitter(:invoke1, new SimpleEmitter("%(%)"));
      defineEmitter(:newEnclosingInstance, new SimpleEmitter("(%).%"));
      defineEmitter(:classLiteral, new SimpleEmitter("%.class"));
      defineEmitter(:invokeLong, new SimpleEmitter("%.%(%)"));
      defineEmitter(:fieldLong, new SimpleEmitter("%.%"));
      defineEmitter(:invokeExp, new SimpleEmitter("(%).%(%)"));
      defineEmitter(:fieldExp, new FieldExpEmitter());

      defineEmitter(:qualifiedThis, new SimpleEmitter("%.this"));
      defineEmitter(:qualifiedFieldSuper, new SimpleEmitter("%.super.%"));
      defineEmitter(:qualifiedInvokeSuper, new SimpleEmitter("%.super.%(%)"));
      defineEmitter(:qualifiedInvokeSuperConstructor,
		    new SimpleEmitter("(%).super(%)"));


      // These nodes will not be created by parser but by TypeCheckers.
      defineEmitter(:invokeStatic, new SimpleEmitter("%.%(%)"));
      defineEmitter(:fieldStatic, new SimpleEmitter("%.%"));
      defineEmitter(:innerClassStatic, new SimpleEmitter("%.%"));
      defineEmitter(:innerClassExp, new SimpleEmitter("(%).%"));
    }
  }
}

class FieldExpEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    // JDK1.1.7 javac does not recognize "(this).f = val;"
    //as a initialization of final instance variable.
    Tree[] args = tree.args();
    if (args[0].tag() == :this){
      // "this.f"
      emitString(out, "this.");
      emitTree(out, args[1]);
    } else {
      // "(exp).f"
      emitTree(out, args[0]);
      out.write('.');
      emitTree(out, args[1]);
    }
  }
}



defineNonTerminal(argumentList,		argumentListOtherwise());
defineNonTerminal(argument,		expressionNoComma());



SystemMixin ArgumentListOtherwise {
  
  class Epp {
    extend Tree argumentListTop(){
      if (lookahead() == :"("){
	TreeVec args = new TreeVec();
	matchAny();
	if (lookahead() != :")") {
	  args.add(argument());
	  while(true) {
	    if (lookahead() == :")") break;
	    match(:",");
	    args.add(argument());
	  }
	}
	match(:")");
	return new Tree(:argumentList, args);
      } else {
	return original();
      }
    }

    define Tree argumentListOtherwise() {
      throw error("ArgumentList is expected here.");
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:argumentList, new argumentListEmitter()); 
    }
  }
}

class argumentListEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    if (args.length > 0) {
      emitTree(out, args[0]);
      for (int i = 1; i < args.length; i++){
	out.write(',');
	out.write(' ');
	emitTree(out, args[i]);
      }
    }
  }
}



SystemMixin Literals {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead().isLiteralToken()) {
	return new LiteralTree((LiteralToken)matchAny());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:literalTree, new LiteralEmitter());
    }
  }
}

class LiteralEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException  {
    LiteralToken token = tree.literalToken();
    Symbol tag = token.literalTag();
    String contents = token.literalContents();
    if (tag == :int || tag == :long || tag == :float || tag == :double){
      emitString(out, contents);
    } else if (tag == :string){
      out.write('\"');
      emitString(out, contents);
      out.write('\"');
    } else if (tag == :char){
      out.write('\'');
      emitString(out, contents);
      out.write('\'');
    } else {
      throw Epp.fatal("");
    }
  }
}



SystemMixin This {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :this) {
	matchAny();
	if (lookahead() == :"(") {
	  Tree args = argumentList();
	  return new Tree(:invokeThisConstructor, args);
	} else {
	  return new Tree(:this);
	}
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:this, new SimpleEmitter("this"));
      defineEmitter(:invokeThisConstructor, new SimpleEmitter("this(%)"));
    }
  }
}



SystemMixin Super {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :super) {
	matchAny();
	if (lookahead() == :"(") {
	  Tree args;
	  args = argumentList();
	  return new Tree(:invokeSuperConstructor, args);
	} else if (lookahead() == :".") {
	  matchAny();
	  Tree id = identifier();
	  Tree args;
	  if (lookahead() == :"(") {
	    args = argumentList();
	    return new Tree(:invokeSuper, id, args);
	  } else {
	    return new Tree(:fieldSuper, id);
	  }
	} else {
	  throw error("Keyword super is not followed by '.' or '(' . ");
	}
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:invokeSuperConstructor, new SimpleEmitter("super(%)"));
      defineEmitter(:invokeSuper, new SimpleEmitter("super.%(%)"));
      defineEmitter(:fieldSuper, new SimpleEmitter("super.%"));
    }
  }
}



SystemMixin Paren {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :"(") {
	matchAny();
	Token token = lookahead();
	if (token == :byte || token == :short || token == :int ||
	    token == :long || token == :char ||
	    token == :float || token == :double ||
	    token == :boolean){
	  Tree exp = expression();
	  match(:")");
	  return new Tree(:cast,
			  convertExpressionToType(exp),
			  unaryExpression());
	} else {
	  Tree exp = expression();
	  match(:")");
	  if (isCast(exp)) {
	    return new Tree(:cast,
			    convertExpressionToType(exp),
			    unaryExpressionNotPlusMinus());
	  } else {
	    return makeParenNode(exp);
	  }
	}
      } else {
	return original();
      }
    }
    define Tree makeParenNode(Tree tree){
      return tree;
    }
    define boolean isCast(Tree exp) {
      Token token = lookahead();
      if (token.isLiteralToken() ||
	  token == :"(" || token == :"~" || token == :"!"){
	// (Type)"str", (Type)(exp), (Type)~exp, (Type)~exp
	return true;
      } else if (token == :instanceof) {
	// (exp) instanceof Type
	return false;
      } else if (token.isSymbol()) {
	// (exp)var, (exp)TypeName.field, ...
	return ((Symbol)token).maybeIdentifier();
      } else {
	throw error("Unexpected token "+ token+
		    " is appeared after an expression enclosed by parenthesises.");
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:cast, new SimpleEmitter("(/*cast*/(%)(%))"));
      // This node is not created by the standard parser.
      defineEmitter(:paren, new SimpleEmitter("(%)"));
    }
  }
}



SystemMixin New {
  
  class Epp {
    extend Tree primaryTop() {
      if (lookahead() == :new) {
	return instanceCreation();
      } else {
	return original();
      }
    }
    
    define implement Tree instanceCreation() {
      match(:new);
      if (lookahead() == :"(") {
	throw error("The syntax \"new (...) ...\" is not suppoted.");
      } else {
	// The function type() should not be called at here.
	// Consider the following case:
	//	new a[10][]
	Tree name = name();
	if (lookahead() == :"(") {
	  Tree args = argumentList();
	  if (lookahead() == :"{") {
	    return new Tree(:anonymousClass, name, args, classBody());
	  } else {
	    return new Tree(:new, name, args);
	  }
	} else if (lookahead() == :"[") {
	  return arrayCreation(name);
	} else {
	  throw error(""+ lookahead()+
		      " appeared after \"new Name\".");
	}
      }
    }
    
    define implement Tree arrayCreation(Tree name) {
      Tree dimExpr = dimExpr(name);
      if (lookahead() == :"{") {
	return new Tree(:anonymousArray, dimExpr, arrayInitializer());
      } else {
	return new Tree(:newArray, dimExpr);
      }
    }
    
    // int[5][10][] -> (dimExpr (dimExpr (arrayOf (name (id int))) <10>) <5>)
    define implement Tree dimExpr(Tree tree) {
      // [exp] or []
      if (lookahead() == :"[") {
	matchAny();
	if (lookahead() == :"]") {
	  matchAny();
	  return new Tree(:arrayOf, dimExpr(tree));
	} else {
	  Tree exp = expression();
	  match(:"]");
	  return new Tree(:dimExpr, dimExpr(tree), exp);
	}
      } else {
	return tree;
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:new, new SimpleEmitter("new %(%)"));
      defineEmitter(:anonymousClass, new SimpleEmitter("new %(%)%"));
      defineEmitter(:newArray, new NewArrayEmitter());
      defineEmitter(:anonymousArray, new NewArrayEmitter());
    }
  }
}

class NewArrayEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    emitString(out, "new ");
    if (tree.tag() == :newArray){
      checkArgsLength(tree, 1);
      emitName(out, args[0]);
      emitDim(out, args[0]);
    } else if (tree.tag() == :anonymousArray){
      checkArgsLength(tree, 2);
      emitName(out, args[0]);
      emitDim(out, args[0]);
      emitTree(out, args[1]);
    } else {
      throw Epp.fatal("NewArrayEmitter: "+ tree);
    }
  }
  public void emitName(Writer out, Tree tree) throws IOException {
    Symbol tag = tree.tag();
    if (tag == :name){
      emitTree(out, tree);
    } else if (tag == :arrayOf || tag == :dimExpr){
      emitName(out, tree.args()[0]);
    } else {
      throw Epp.fatal("emitName: "+ tree);
    }
  }
  public void emitDim(Writer out, Tree tree) throws IOException {
    Symbol tag = tree.tag();
    if (tag == :name){
      // Do nothing.
    } else if (tag == :arrayOf) {
      checkArgsLength(tree, 1);
      out.write('[');
      out.write(']');
      emitDim(out, tree.args()[0]);
    } else if (tag == :dimExpr){
      checkArgsLength(tree, 2);
      out.write('[');
      emitTree(out, tree.args()[1]);
      out.write(']');
      emitDim(out, tree.args()[0]);
    } else {
      throw Epp.fatal("emitName: "+ tree);
    }
  }
}



SystemMixin Array {
  
  class Epp {
    extend Tree primaryLeft(Tree tree) {
      if (lookahead() == :"[") {
	matchAny();
	if (lookahead() == :"]") {
	  matchAny();
	  return new Tree(:arrayOf, tree);
	} else {
	  Tree index = expression();
	  match(:"]");
	  return new Tree(:array, tree, index);
	}
      } else {
	return original(tree);
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:array, new SimpleEmitter("(%)[%]"));
      defineEmitter(:arrayOf, new SimpleEmitter("%[]"));
    }
  }
}



SystemMixin PostIncDec {
  
  class Epp {
    extend Tree postfixExpressionLeft(Tree tree) {
      if (lookahead() == :"++") {
	matchAny();
	return new Tree(:postInc, tree);
      } else if (lookahead() == :"--") {
	matchAny();
	return new Tree(:postDec, tree);
      } else {
	return original(tree);
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:postInc, new SimpleEmitter("% ++"));
      defineEmitter(:postDec, new SimpleEmitter("% --"));
    }
  }
}



SystemMixin BitwiseNot {
  
  class Epp {
    extend Tree unaryExpressionNotPlusMinusTop() {
      if (lookahead() == :"~") {
	return new Tree(((Symbol)matchAny()), unaryExpression());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:"~", new SimpleEmitter("~(%)"));
    }
  }
}



SystemMixin LogicalNot {
  
  class Epp {
    extend Tree unaryExpressionNotPlusMinusTop() {
      if (lookahead() == :"!") {
	return new Tree(((Symbol)matchAny()), unaryExpression());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:"!", new SimpleEmitter("!(%)"));
    }
  }
}



SystemMixin PreIncDec {
  
  class Epp {
    extend Tree unaryExpressionTop() {
      if (lookahead() == :"++") {
	matchAny();
	return new Tree(:preInc, unaryExpression());
      } else if (lookahead() == :"--") {
	matchAny();
	return new Tree(:preDec, unaryExpression());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:preInc, new SimpleEmitter("++ %"));
      defineEmitter(:preDec, new SimpleEmitter("-- %"));
    }
  }
}



SystemMixin UnaryPlusMinus {
  
  class Epp {
    extend Tree unaryExpressionTop() {
      if (lookahead() == :"+") {
	matchAny();
	return new Tree(:unaryPlus, unaryExpression());
      } else if (lookahead() == :"-") {
	matchAny();
	return new Tree(:unaryMinus, unaryExpression());
      } else {
	return original();
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:unaryPlus, new SimpleEmitter(" +(%)"));
      defineEmitter(:unaryMinus, new SimpleEmitter(" -(%)"));
    }
  }
}


/*
SystemMixin AddressAndReference {
  
  class Epp {
    extend Tree unaryExpressionTop() {
      if (lookahead() == :"*") {
	matchAny();
	return new Tree(:unaryAsta, unaryExpression());
      } else {
	if (lookahead() == :"&") {
	  matchAny();
	  return new Tree(:unaryAnd, unaryExpression());
	} else {
	  return original();
	}
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:unaryAsta, new SimpleEmitter("*(%)"));
      defineEmitter(:unaryAnd, new SimpleEmitter("&(%)"));
    }
  }
}
*/


SystemMixin Instanceof {
  
  class Epp {
    extend Tree relationalExpressionLeft(Tree tree) {
      if (lookahead() == :instanceof) {
	return new Tree(((Symbol)matchAny()), tree, type());
      } else {
	return original(tree);
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:instanceof, new SimpleEmitter("(%) instanceof %"));
    }
  }
}


SystemMixin BinaryPercent {
  
  class Epp {
    extend Tree multiplicativeExpressionLeft(Tree tree) {
      if (lookahead() == :"%") {
	return new Tree(((Symbol)matchAny()), tree, multiplicativeExpression1());
      } else {
	return original(tree);
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:"%", new BinaryPercentEmitter());
    }
  }
}

class BinaryPercentEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    checkArgsLength(tree, 2);
    out.write('(');
    emitTree(out, args[0]);
    emitString(out, ") % (");
    emitTree(out, args[1]);
    out.write(')');
  }
}




//	 SystemMixin-NAME,	TOKEN,	PRECEDENCE
////defineBinaryOperator(DotAsta,:".*",	memberSectionExpression);
defineBinaryOperator(Mul,	:"*",	multiplicativeExpression);
defineBinaryOperator(Div,	:"/",	multiplicativeExpression);
//defineBinaryOperator(Percent,	:"%",	multiplicativeExpression);
defineBinaryOperator(Plus,	:"+",	additiveExpression);
defineBinaryOperator(Minus,	:"-",	additiveExpression);
defineBinaryOperator(RShift,	:"<<",	shiftExpression);
defineBinaryOperator(LShift,	:">>",	shiftExpression);
defineBinaryOperator(ULShift,	:">>>",	shiftExpression);
defineBinaryOperator(LT,	:"<",	relationalExpression);
defineBinaryOperator(GT,	:">",	relationalExpression);
defineBinaryOperator(LE,	:"<=",	relationalExpression);
defineBinaryOperator(GE,	:">=",	relationalExpression);
defineBinaryOperator(EQ,	:"==",	equalityExpression);
defineBinaryOperator(NE,	:"!=",	equalityExpression);
defineBinaryOperator(And,	:"&",	andExpression);
defineBinaryOperator(Eor,	:"^",	exclusiveOrExpression);
defineBinaryOperator(Or,	:"|",	inclusiveOrExpression);
defineBinaryOperator(AndAnd,	:"&&",	conditionalAndExpression);
defineBinaryOperator(OrOr,	:"||",	conditionalOrExpression);
     
     

SystemMixin ConditionalExpressionOperator {
  
  class Epp {
    extend Tree conditionalExpressionRight(Tree tree) {
      if (lookahead() == :"?") {
	matchAny();
	Tree then = expression();
	match(:":");
	return new Tree(:conditionalExpression, tree, then,
			conditionalExpression());
      } else {
	return original(tree);
      }
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:conditionalExpression, new SimpleEmitter("(%)?(%):(%)"));
    }
  }
}



SystemMixin Assign {
  
  class Epp {
    extend Tree assignmentExpressionRight(Tree tree) {
      Token token = lookahead();
      if (token == :"=" || token == :"*=" || token == :"/=" || token == :"%="
	  || token == :"+=" || token == :"-=" || token == :"<<="
	  || token == :">>=" || token == :">>>=" || token == :"&="
	  || token == :"^=" || token == :"|=") {
	return new Tree(((Symbol)matchAny()), tree, assignmentExpression());
      }
      return original(tree);
    }
    
    extend void initEmitterTable() {
      original();
      defineEmitter(:"=", new EqualEmitter());
      defineEmitter(:"*=", new SimpleEmitter("% *= (%)"));
      defineEmitter(:"/=", new SimpleEmitter("% /= (%)"));
      defineEmitter(:"%=", new PercentEqualEmitter());
      defineEmitter(:"+=", new SimpleEmitter("% += (%)"));
      defineEmitter(:"-=", new SimpleEmitter("% -= (%)"));
      defineEmitter(:"<<=", new SimpleEmitter("% <<= (%)"));
      defineEmitter(:">>=", new SimpleEmitter("% >>= (%)"));
      defineEmitter(:">>>=", new SimpleEmitter("% >>>= (%)"));
      defineEmitter(:"&=", new SimpleEmitter("% &= (%)"));
      defineEmitter(:"^=", new SimpleEmitter("% ^= (%)"));
      defineEmitter(:"|=", new SimpleEmitter("% |= (%)"));
    }
  }
}

class EqualEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    checkArgsLength(tree, 2);
    Symbol tag = args[1].tag();
    if (tag == :literalTree){
      // To avoid a bug of JDK (at least 1.1.3).
      // If an assignment "b = 'c'" is translated to "b = ('c')" by EPP,
      //JDK seems not to recognize "('c')" as a constant char expression.
      // (But "('c' + 1)" is recognize as a constant char expression.)
      // See the section 5.2 and 15.27 .
      // To avoid this bug, when the second argument of assignment is
      //literal, parenthesis will not be printed.
      emitTree(out, args[0]);
      emitString(out, " = ");
      emitTree(out, args[1]);
    } else {
      emitTree(out, args[0]);
      emitString(out, " = (");
      emitTree(out, args[1]);
      out.write(')');
    }
  }
}

class PercentEqualEmitter extends Emitter {
  public void call(Writer out, Tree tree) throws IOException {
    Tree[] args = tree.args();
    checkArgsLength(tree, 2);
    emitTree(out, args[0]);
    emitString(out, " %= (");
    emitTree(out, args[1]);
    out.write(')');
  }
}



// Actually, comma operator is not defined by Java.
// Currently, this grammar rule is used for parsing "for statement".
// In the future, this SystemMixin will be removed.
SystemMixin Comma {
  
  class Epp {
    extend Tree commaExpressionLeft(Tree tree) {
      if (lookahead() == :",") {
	return new Tree(((Symbol)matchAny()), tree, commaExpression1()); 
      } else {
	return original(tree);
      }
    }
    extend void initEmitterTable() {
      original();
      defineEmitter(:",", new SimpleEmitter("(/*comma*/(%), (%))"));
    }
  }
}



SystemMixin StartByExpression {
  
  class Epp {
    default Tree start() {
      return expression();
    }
  }
}
