/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol


package epp;
import java.io.*;

public class LiteralTree extends Tree {
  LiteralToken literalToken;

  public LiteralTree(LiteralToken literalToken){
    super(:literalTree, zeroArgs);
    this.literalToken = literalToken;
  }

  public LiteralTree(Symbol tag, String contents){
    super(:literalTree, zeroArgs);
    literalToken = new LiteralToken(tag, contents);
  }

  public LiteralToken literalToken(){
    return literalToken;
  }

  public void print(PrintWriter out, String indent){
    out.print(indent);
    out.print("(literalTree");
    printProp(out);
    out.print(' ');
    out.print(literalToken.literalTag());
    out.print(' ');
    out.print(Tree.quoteString(literalToken.literalContents()));
    out.print(')');
  }

  public String toString() {
    return "(literalTree "+ literalToken.literalTag()+
      " "+ Tree.quoteString(literalToken.literalContents())+ ")";
  }
}
