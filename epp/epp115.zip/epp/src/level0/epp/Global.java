/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles


package epp;
import SystemMixinRuntimes.*;
import java.util.*;


SystemMixin Global {
  class Epp {
    FileInfo[] allFileInfo;
    
    define implement void initGlobalProcessor() {

      // $B>l9g$K$h$C$F$O(B plug-in $B$+$i4V@\E*$K;2>H$5$l$k!#(B
      Dynamic.bind(:classTypeTable, ClassTypeTable.instance);
      Dynamic.bind(:classFileReader, makeClassFileReader());

    }
    
    define implement void globalProcessAfterParsingPass() {
    }
    
    define implement void globalProcessAfterMacroExpansionPass() {
    }
    
    define implement void globalProcessAfterTypeCheckingPass() {
    }
  }
}



public class FileInfo {
  protected String inputFileName;
  public String getInputFileName() { return inputFileName; }
  public void  setInputFileName(String inputFileName) {
    this.inputFileName = inputFileName; }
  
  protected Obj preprocessor;
  public Obj getPreprocessor() { return preprocessor; }
  public void setPreprocessor(Obj preprocessor) {
    this.preprocessor = preprocessor; }

  protected Tree tree;
  public Tree getTree() { return tree; }
  public void setTree(Tree tree) {
    this.tree = tree; }

  protected Hashtable classTable;
  public Hashtable getClassTable() { return classTable; }
  public void setClassTable(Hashtable classTable) {
    this.classTable = classTable; }

  protected DVenv env;
  public DVenv getDVenv() { return env; }
  public void setDVenv(DVenv env) {
    this.env = env; }


  // This constructor is called from Epp#makeEppPreProcessor
  public FileInfo(String inputFileName,
		  Obj preprocessor,
		  Hashtable classTable,
		  DVenv env){
    this.inputFileName = inputFileName;
    this.preprocessor = preprocessor;
    this.classTable = classTable;
    this.env = env;
    tree = null;
  }

  public void saveContext(){
    classTable = SystemMixin.classTable;
    env = Dynamic.env;
    tree = preprocessor!tree;
  }

  public void restoreContext(){
    SystemMixin.classTable = classTable;
    Dynamic.env = env;
    preprocessor!tree = tree;
  }

  public void initializationPass(){
    restoreContext();
    preprocessor!initializationPass();
    saveContext();
  }

  public void doParsingPass(){
    restoreContext();
    preprocessor!doParsingPass();
    saveContext();
  }

  public void doMacroExpansionPass(){
    restoreContext();
    preprocessor!doMacroExpansionPass();
    saveContext();
  }

  public Tree makeFileSignature(){
    restoreContext();
    Tree ret = preprocessor!makeFileSignature();
    saveContext();
    return ret;
  }

  public void doTypeCheckingPass(){
    restoreContext();
    preprocessor!doTypeCheckingPass();
    saveContext();
  }

  public void doTranslationPass(){
    restoreContext();
    preprocessor!doTranslationPass();
    saveContext();
  }

  public void doCodeEmittingPass(){
    restoreContext();
    preprocessor!doCodeEmittingPass();
    saveContext();
  }


  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public FileInfo[] initGlobalProcessor(FileInfo[] allFileInfo){
    restoreContext();
    preprocessor!allFileInfo = allFileInfo;
    preprocessor!initGlobalProcessor();
    FileInfo[] ret = preprocessor!allFileInfo;
    saveContext();
    return ret;
  }

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public FileInfo[] globalProcessAfterParsingPass(FileInfo[] allFileInfo){
    restoreContext();
    preprocessor!allFileInfo = allFileInfo;
    preprocessor!globalProcessAfterParsingPass();
    FileInfo[] ret = preprocessor!allFileInfo;
    saveContext();
    return ret;
  }

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public FileInfo[] globalProcessAfterMacroExpansionPass(FileInfo[] allFileInfo){
    restoreContext();
    preprocessor!allFileInfo = allFileInfo;
    preprocessor!globalProcessAfterMacroExpansionPass();
    FileInfo[] ret = preprocessor!allFileInfo;
    saveContext();
    return ret;
  }

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public FileInfo[] globalProcessAfterTypeCheckingPass(FileInfo[] allFileInfo){
    restoreContext();
    preprocessor!allFileInfo = allFileInfo;
    preprocessor!globalProcessAfterTypeCheckingPass();
    FileInfo[] ret = preprocessor!allFileInfo;
    saveContext();
    return ret;
  }
}
