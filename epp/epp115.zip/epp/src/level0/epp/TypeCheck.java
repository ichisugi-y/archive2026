/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp BackQuote


package epp;
import SystemMixinRuntimes.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Stack;


SystemMixin TypeCheck {
  
  class Epp {

    extend void initializationPass() {
      original();
      Dynamic.bind(:typeCheckerTable, new Hashtable());
      Dynamic.bind(:typeNameCheckerTable, new Hashtable());
      Dynamic.bind(:typeCheckingTree, null);
      initTypeCheckerTable();
      initTypeNameCheckerTable();
    }
    
    define void initTypeCheckerTable() {
    }

    define void defineTypeChecker(Symbol tag , TypeChecker func) {
      Hashtable typeCheckerTable = (Hashtable)Dynamic.get(:typeCheckerTable);
      if (typeCheckerTable.get(tag) != null){
	throw Epp.fatal("FATAL: TypeChecker for :"+ tag+
			" is already defined.");
      }
      typeCheckerTable.put(tag, func);
    }

    define implement void extendTypeChecker(Symbol tag, TypeChecker func) {
      Hashtable typeCheckerTable = (Hashtable)Dynamic.get(:typeCheckerTable);
      TypeChecker orig = (TypeChecker)typeCheckerTable.get(tag);
      if (orig == null){
	throw Epp.fatal("TypeChecker for :"+ tag+ " is not defined.");
      }
      func.orig = orig;
      typeCheckerTable.put(tag, func);
    }

    
    define implement void initTypeNameCheckerTable() {
    }

    define implement void defineTypeNameChecker(Symbol tag, TypeNameChecker func) {
      Hashtable typeNameCheckerTable
	= (Hashtable)Dynamic.get(:typeNameCheckerTable);
      if (typeNameCheckerTable.get(tag) != null){
	throw Epp.fatal("TypeNameChecker for :"+ tag+ " is already defined.");
      }
      typeNameCheckerTable.put(tag, func);
    }

    define implement void extendTypeNameChecker(Symbol tag, TypeNameChecker func) {
      Hashtable typeNameCheckerTable
	= (Hashtable)Dynamic.get(:typeNameCheckerTable);
      TypeNameChecker orig = (TypeNameChecker)typeNameCheckerTable.get(tag);
      if (orig == null){
	throw Epp.fatal("TypeNameChecker for :"+ tag+ " is not defined.");
      }
      func.orig = orig;
      typeNameCheckerTable.put(tag, func);
    }


    implement void doTypeCheckingPass() {
      beforeTypeCheckingPass();

      if (Opts.log) Opts.out.println("Start type checking "+ (String)Dynamic.get(:inputFileName)+ " .");
      typeCheckingPass();
      if (Opts.log) Opts.out.println("End type checking "+ (String)Dynamic.get(:inputFileName)+ " .");

      if (Opts.printTree) {
	Opts.out.println();
	Opts.out.println("TypeChecked Tree:");
	self!tree.print(Opts.out);
      }

      /*old
      if (! Opts.forceNextPass && Dynamic.getInt(:errorCounter) > 0){
	throw error(""+ Dynamic.getInt(:errorCounter)+ " errors");
      }
      */

      afterTypeCheckingPass();
    }
    
    define implement void beforeTypeCheckingPass(){}
    
    define implement void typeCheckingPass(){
      Dynamic.bind(:typeNameTable, generateTypeNameTable());
      Dynamic.bind(:varEnv, defaultVarEnv());
      try {
	if (Opts.nocatch){
	  self!tree = TypeChecker.typeCheckTree(self!tree);
	} else {
	  try {
	    self!tree = TypeChecker.typeCheckTree(self!tree);
	  } catch (EppUserError e){
	    if (Opts.log) Opts.out.println("An error is caught by typeCheckingPass().");
	    self!tree
	      = TypeChecker.typeCheckTree(new Tree(:errorInCompilationUnit));
	  }
	}
      } finally {
	Dynamic.unbind();
	Dynamic.unbind();
      }
    }

    // factory method.
    define implement TypeNameTable generateTypeNameTable(){
      return new GlobalTypeNameTable(self!tree);
    }

    define implement void afterTypeCheckingPass(){}

    define implement VarEnv defaultVarEnv(){
      Tree[] modifiers = {};
      VarEnv varEnv = null;
      varEnv = new VarEnv(:null,
			  new VarInfo(modifiers, Type.Tnull),
			  varEnv);
      varEnv = new VarEnv(:true,
			  new VarInfo(modifiers, Type.Tboolean),
			  varEnv);
      varEnv = new VarEnv(:false,
			  new VarInfo(modifiers, Type.Tboolean),
			  varEnv);
      return varEnv;
    }

    //--------------------------------------------------


    // See JLS1.0 Section 6.5.2 .
    define implement Tree resolveAmbiguousName(Tree tree){
      if (tree.tag() != :name){
	throw Epp.fatal("");
      }
      Tree[] args = tree.args();
      if (args.length == 1){
	return resolveAmbiguousName1(tree);
      } else if (args.length > 1){
	return resolveAmbiguousName2(tree);
      } else {
	// args.length <= 0
	throw Epp.fatal("");
      }
    }
  
    define implement Tree resolveAmbiguousName1(Tree tree){
      // args.length == 1
      Tree[] args = tree.args();
      VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
      if (varEnv != null){
	try {
	  VarInfo info = varEnv.lookup(args[0].idName());
	  // If NofFound is not thrown, it is a local variable or
	  //a method parameter or a class field.
	  // Anyway, it is an expression. Returns (id xxx).
	  return TypeChecker.typeCheckTree(args[0]);
	} catch (NotFound e){
	  // Do nothing. Go to next step.
	}
      }
      TypeNameTable typeNameTable
	= (TypeNameTable)Dynamic.get(:typeNameTable);
      try {
	Type t = typeNameTable.get(tree);
	// It is type name. Returns (name ...) .
	return tree.modifyTypeAndArgs(t, args);
      } catch (NotFound e){
	// Do nothing. Go to next step.
      }
      // Returns null which indicates the name might be PackageName .
      return null;
    }
  
    define implement Tree resolveAmbiguousName2(Tree tree){
      // args.length > 1
      Tree[] args = tree.args();
      Tree[] left = new Tree[args.length - 1];
      for (int i = 0; i < left.length; i++){
	left[i] = args[i];
      }
      Tree right = args[args.length - 1];
      //`(name ,@left)
      Tree leftTree = TypeChecker.remakeTree(:name, left, left);
      Tree resolved = resolveAmbiguousName(leftTree);
      if (resolved == null){
	TypeNameTable typeNameTable
	  = (TypeNameTable)Dynamic.get(:typeNameTable);
	try {
	  Type t = typeNameTable.get(tree);
	  // It is type name. Returns (name ...) .
	  return tree.modifyTypeAndArgs(t, args);
	} catch (NotFound e){
	  return null;
	}
      } else if (resolved.tag() == :name
		 || resolved.tag() == :innerClassExp
		 || resolved.tag() == :innerClassStatic
		 ){
	ClassInfo classInfo = resolved.type().classInfo();
	try {
	  classInfo.getClass(right.idName());
	  //`(innerClassStatic ,resolved ,right)
	  Tree newTree = TypeChecker.remakeTree(:innerClassStatic,
						new Tree[]{ resolved, right },
						args);
	  return TypeChecker.typeNameCheckTree(newTree);
	} catch (NotFound e){
	  //`(fieldStatic ,resolved ,right)
	  Tree newTree = TypeChecker.remakeTree(:fieldStatic,
						new Tree[]{ resolved, right },
						args);
	  return TypeChecker.typeCheckTree(newTree);
	}
      } else {
	return resolveAmbiguousName2Otherwise(right, args, resolved);
      }
    }

    // $B!V$=$NB>!W$N>l9g$O(B resolved $B$O(B expression $B$G!"7?$O(B :class $B$H2>Dj!#(B
    define implement Tree resolveAmbiguousName2Otherwise(Tree right,
							 Tree[] args,
							 Tree resolved){
      //if (resolved.tag() == :id || resolved.tag() == :fieldExp
      // || resolved.tag() == :fieldStatic)
      ClassInfo classInfo = getTargetClassInfo(resolved.type());
      try {
	classInfo.getClass(right.idName());
	//`(innerClassExp ,resolved ,right)
	Tree newTree = TypeChecker.remakeTree(:innerClassExp,
					      new Tree[]{ resolved, right },
					      args);
	return TypeChecker.typeNameCheckTree(newTree);
      } catch (NotFound e){
	//`(fieldExp ,resolved ,right)
	Tree newTree = TypeChecker.remakeTree(:fieldExp,
					      new Tree[]{ resolved, right },
					      args);
	return TypeChecker.typeCheckTree(newTree);
      }
    }

	/*old
      } else if (resolved.tag() == :id || resolved.tag() == :fieldExp
		 || resolved.tag() == :fieldStatic){
	ClassInfo classInfo = resolved.type().classInfo();
	try {
	  classInfo.getClass(right.idName());
	  //`(innerClassExp ,resolved ,right)
	  Tree newTree = TypeChecker.remakeTree(:innerClassExp,
						new Tree[]{ resolved, right },
						args);
	  return TypeChecker.typeNameCheckTree(newTree);
	} catch (NotFound e){
	  //`(fieldExp ,resolved ,right)
	  Tree newTree = TypeChecker.remakeTree(:fieldExp,
						new Tree[]{ resolved, right },
						args);
	  return TypeChecker.typeCheckTree(newTree);
	}
      } else {
	throw Epp.fatal("resolveAmbiguousName2");
      }
      */

    //--------------------------------------------------

    extend void printErrorMessage(String str){
      Tree tree = (Tree)Dynamic.get(:typeCheckingTree);
      if (tree != null){
	if (Opts.log) {
	  Opts.out.println("Type-checking tree: "+ tree);
	  Opts.out.println("tree.beginningPoint =  "+ tree.beginningPoint());
	  Opts.out.println("tree.endPoint "+ tree.endPoint());
	}
	printErrorMessageWithPointIndicator(tree.lineNumber(),
					    tree.beginningPoint(),
					    tree.endPoint(),
					    str);
      } else {
	original(str);
      }
    }

    /* old
    extend Error error(String str){
      Tree tree = (Tree)Dynamic.get(:typeCheckingTree);
      if (tree != null){
	System.err.print((String)Dynamic.get(:inputFileName)+ ":"+
			 tree.lineNumber()+ ": "
			 );
	if (Opts.log) {
	  Opts.out.println("Type-checking tree: "+ tree);
	  Opts.out.println("tree.beginningPoint =  "+ tree.beginningPoint());
	  Opts.out.println("tree.endPoint "+ tree.endPoint());
	}
      }
      return original(str);
    }
    */

    define implement Error errorAt(Tree tree, String str){
      Dynamic.bind(:typeCheckingTree, tree);
      try {
	return error(str);
      } finally {
	Dynamic.unbind();
      }
    }
  }
}

public abstract class TypeChecker extends Macro {

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public TypeChecker orig = null;
  
  public abstract Tree call(Tree tree);
  
  public static Tree typeCheckTree(Tree tree){
    Hashtable typeCheckerTable = (Hashtable)Dynamic.get(:typeCheckerTable);

    Dynamic.bind(:typeCheckingTree, tree);
    try {
      Symbol lastTag = null;
      while(true) {
	if (tree.isTyped()) break;
	Symbol tag = tree.tag();
	if (tag == lastTag) break;
	lastTag = tag;
	TypeChecker func = (TypeChecker)typeCheckerTable.get(tag);
	if (func != null) {

	  try {
	    tree = func.call(tree);
	  } catch (EppTypeError e){
	    if (Opts.log) e.printStackTrace(Opts.out);
	    throw errorAt(tree, e.getMessage());
	  }

	} else {
	  throw Epp.fatal("TypeChecker for "+ tag+ " is not defined.");
	}
      }
      return tree;
    } finally {
      Dynamic.unbind();
    }
  }
  
  public static Tree typeCheck1(Tree tree){
    Hashtable typeCheckerTable = (Hashtable)Dynamic.get(:typeCheckerTable);
    TypeChecker func = (TypeChecker)typeCheckerTable.get(tree.tag());
    if (func == null) {
      throw Epp.fatal("TypeChecker for "+ tree.tag()+ " is not defined.");
    } else {
      return func.call(tree);
    }
  }
  
  // This method returns a newly created array.
  // The caller is allowed to modify the return value.
  public static Tree[] typeCheckArgs(Tree tree){
    Tree[] args = tree.args();
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){
      newArgs[i] = typeCheckTree(args[i]); 
    }
    return newArgs;
  }
  
  public static Tree typeNameCheckTree(Tree tree){
    return TypeNameChecker.typeNameCheckTree(tree);
  }
  
  public static void checkArgsLength(Tree tree, int argc){
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("FATAL: The TypeChecker requires "+ argc+
		      " args but supplied "+ args.length+ " :"+ tree);
    }
  }
  
  public static Tree checkVariableDeclaratorId(Type type,
					       Tree tree,
					       Tree[] declaredVars){
    Obj epp = (Obj)Dynamic.get(:epp);
    return epp!checkVariableDeclaratorId(type, tree, declaredVars);
  }
  
  public static Tree resolveAmbiguousName(Tree tree){
    Obj epp = (Obj)Dynamic.get(:epp);
    return epp!resolveAmbiguousName(tree);
  }
  
  public static Tree remakeTree(Symbol tag, Tree[] newArgs, Tree[] oldArgs){
    Dynamic.bindInt(:lineNumberOfThisNode, oldArgs[0].lineNumber());
    Dynamic.bindInt(:beginningPointOfThisNode, oldArgs[0].beginningPoint());
    Dynamic.bindInt(:endPointOfThisNode,
		    oldArgs[oldArgs.length - 1].endPoint());
    try{
      return new Tree(tag, newArgs);
    } finally {
      Dynamic.unbindInt();
      Dynamic.unbindInt();
      Dynamic.unbindInt();
    }
  }
  
  public static Tree remakeTree(Tree newTree, Tree oldTree){
    Dynamic.bindInt(:lineNumberOfThisNode, oldTree.lineNumber());
    Dynamic.bindInt(:beginningPointOfThisNode, oldTree.beginningPoint());
    Dynamic.bindInt(:endPointOfThisNode, oldTree.endPoint());
    try{
      return new Tree(newTree.tag(), newTree.args());
    } finally {
      Dynamic.unbindInt();
      Dynamic.unbindInt();
      Dynamic.unbindInt();
    }
  }
					   

  // See JLS1.0 5.6.1 .
  public static Tree unaryNumericPromotion(Tree tree){
    Type t = tree.type();
    Symbol s = t.tag();
    if (s == :double || s == :float || s == :long){
      return tree;
    } else {
      return Type.coerce(Type.Tint, tree);
    }
  }


  public static Error errorAt(Tree tree, String str){
    Obj epp = (Obj)Dynamic.get(:epp);
    return epp!errorAt(tree, str);
  }
}


//--------------------------------------------------

public class VarEnv {
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  private VarEnv next;
  private Symbol name;
  private VarInfo info;
  public VarEnv(Symbol name, VarInfo info, VarEnv next){
    this.name = name; this.info = info; this.next = next;
  }
  public VarInfo lookup(Symbol name) throws NotFound {
    if (name == this.name) {
      return info;
    } else if (next == null) {
      throw NotFound.instance;
    } else {
      return next.lookup(name);
    }
  }
}

public class VarInfo {
  private Type type;
  private Tree[] modifiers;
  public VarInfo(Tree[] modifiers, Type type) {
    this.modifiers = modifiers; this.type = type;
  }
  public Type type() { return type; }
  public Tree[] modifiers() { return modifiers; }
}

//--------------------------------------------------


public abstract class TypeNameChecker extends Macro {
  
  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public TypeNameChecker orig = null;
  
  public abstract Tree call(Tree tree);
  
  public static Tree typeNameCheckTree(Tree tree){
    Hashtable typeNameCheckerTable
      = (Hashtable)Dynamic.get(:typeNameCheckerTable);
    Dynamic.bind(:typeCheckingTree, tree);
    try {
      Symbol lastTag = null;
      while(true) {
	if (tree.isTyped()) break;
	Symbol tag = tree.tag();
	if (tag == lastTag) break;
	lastTag = tag;
	TypeNameChecker func = (TypeNameChecker)typeNameCheckerTable.get(tag);
	if (func != null) {
	  tree = func.call(tree);
	} else {
	  throw Epp.fatal("TypeNameChecker for "+ tag+ " is not defined.");
	}
      }
      return tree;
    } finally {
      Dynamic.unbind();
    }
  }

  public static void checkArgsLength(Tree tree, int argc){
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("The TypeNameChecker requires "+ argc+
		      " args but supplied "+ args.length+ " :"+ tree);
    }
  }
  
  public static Tree resolveAmbiguousTypeName(Tree tree){
    Dynamic.bind(:varEnv, null);
    try {
      return TypeChecker.resolveAmbiguousName(tree);
    } finally {
      Dynamic.unbind();
    }
  }
}


SystemMixin InitTypeNameCheckerTable {
  class Epp {
    extend void initTypeNameCheckerTable () {
      original();

      defineTypeNameChecker(:name,	new NameTypeNameChecker());
      defineTypeNameChecker(:arrayOf,	new ArrayOfTypeNameChecker());
      defineTypeNameChecker(:dimExpr,	new DimExprTypeNameChecker());
      defineTypeNameChecker(:innerClassExp,
			    new InnerClassExpTypeNameChecker());
      defineTypeNameChecker(:innerClassStatic,
			    new InnerClassStaticTypeNameChecker());
    }
  }
}


class NameTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    Tree resolved = resolveAmbiguousTypeName(tree);
    if (resolved == null){
      throw error("Undefined type name: "+ tree.nameToString());
    } else if (resolved.tag() == :name
	       || resolved.tag() == :innerClassStatic){
      return resolved;
    } else if (resolved.tag() == :id || resolved.tag() == :fieldExp
	       || resolved.tag() == :fieldStatic
	       || resolved.tag() == :innerClassExp) {
      throw Epp.error("Inner class access to expression is not allowed in this context : "+ tree.nameToString());
    } else {
      throw Epp.fatal("");
    }

  }
}

class ArrayOfTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = { typeNameCheckTree(tree.args()[0]) };
    return tree.modifyTypeAndArgs(new ArrayType(newArgs[0].type()), newArgs);
  }
}

class DimExprTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = { typeNameCheckTree(tree.args()[0]),
		       TypeChecker.
			 unaryNumericPromotion(TypeChecker.
					       typeCheckTree(tree.args()[1]))
		       };
    return tree.modifyTypeAndArgs(new ArrayType(newArgs[0].type()), newArgs);
  }
}

class InnerClassExpTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree exp = TypeChecker.typeCheckTree(tree.args()[0]);
    Tree name = tree.args()[1];
    Tree[] newArgs = { exp, name };
    Obj epp = (Obj)Dynamic.get(:epp);
    Type t = epp!selectInnerClass(exp.type(), name.idName());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

class InnerClassStaticTypeNameChecker extends TypeNameChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree typeName = typeNameCheckTree(tree.args()[0]);
    Tree name = tree.args()[1];
    Tree[] newArgs = { typeName, name };
    Obj epp = (Obj)Dynamic.get(:epp);
    Type t = epp!selectInnerClass(typeName.type(), name.idName());
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}



//--------------------------------------------------


SystemMixin InitTypeCheckerTable {
  class Epp {
    extend void initTypeCheckerTable () {
      original();

      defineTypeChecker(:postInc,	new IncDecOperatorTypeChecker());
      defineTypeChecker(:postDec,	new IncDecOperatorTypeChecker());
      defineTypeChecker(:preInc,	new IncDecOperatorTypeChecker());
      defineTypeChecker(:preDec,	new IncDecOperatorTypeChecker());
      defineTypeChecker(:"~",		new UnaryIntOperatorTypeChecker());
      defineTypeChecker(:"!",		new UnaryBooleanOperatorTypeChecker());
      defineTypeChecker(:unaryPlus,	new UnaryNumberOperatorTypeChecker());
      defineTypeChecker(:unaryMinus,	new UnaryNumberOperatorTypeChecker());
      defineTypeChecker(:instanceof,	new InstanceOfOperatorTypeChecker());
      defineTypeChecker(:conditionalExpression,
			new ConditionalExpressionTypeChecker());
      defineTypeChecker(:"=",	new SimpleAssignmentOperatorTypeChecker());
      defineTypeChecker(:"*=",	new AssignmentOperatorTypeChecker(:"*"));
      defineTypeChecker(:"/=",	new AssignmentOperatorTypeChecker(:"/"));
      defineTypeChecker(:"%=",	new AssignmentOperatorTypeChecker(:"%"));
      defineTypeChecker(:"+=",	new AssignmentOperatorTypeChecker(:"+"));
      defineTypeChecker(:"-=",	new AssignmentOperatorTypeChecker(:"-"));
      defineTypeChecker(:"<<=",	new AssignmentOperatorTypeChecker(:"<<"));
      defineTypeChecker(:">>=",	new AssignmentOperatorTypeChecker(:">>"));
      defineTypeChecker(:">>>=",new AssignmentOperatorTypeChecker(:">>>"));
      defineTypeChecker(:"&=",	new AssignmentOperatorTypeChecker(:"&"));
      defineTypeChecker(:"^=",	new AssignmentOperatorTypeChecker(:"^"));
      defineTypeChecker(:"|=",	new AssignmentOperatorTypeChecker(:"|"));

      defineTypeChecker(:"+",		new DoubleOperatorTypeChecker());
      extendTypeChecker(:"+",		new StringPlusOperatorTypeChecker());

      defineTypeChecker(:"%",		new DoubleOperatorTypeChecker());
      defineTypeChecker(:"-",		new DoubleOperatorTypeChecker());
      defineTypeChecker(:"*",		new DoubleOperatorTypeChecker());
      defineTypeChecker(:"/",		new DoubleOperatorTypeChecker());
      defineTypeChecker(:"==",		new EqualOperatorTypeChecker());
      defineTypeChecker(:"!=",		new EqualOperatorTypeChecker());
      defineTypeChecker(:"<",		new EqualOperatorTypeChecker());
      defineTypeChecker(:">",		new EqualOperatorTypeChecker());
      defineTypeChecker(:"<=",		new EqualOperatorTypeChecker());
      defineTypeChecker(:">=",		new EqualOperatorTypeChecker());
      defineTypeChecker(:"<<",		new ShiftOperatorTypeChecker());
      defineTypeChecker(:">>",		new ShiftOperatorTypeChecker());
      defineTypeChecker(:">>>",		new ShiftOperatorTypeChecker());
      defineTypeChecker(:"&",		new IntOrBooleanOperatorTypeChecker());
      defineTypeChecker(:"^",		new IntOrBooleanOperatorTypeChecker());
      defineTypeChecker(:"|",		new IntOrBooleanOperatorTypeChecker());
      defineTypeChecker(:"&&",		new BooleanOperatorTypeChecker());
      defineTypeChecker(:"||",		new BooleanOperatorTypeChecker());

      defineTypeChecker(:invoke1,	new Invoke1TypeChecker());
      defineTypeChecker(:invokeLong,	new InvokeLongTypeChecker());
      defineTypeChecker(:invokeExp,	new InvokeExpTypeChecker());
      defineTypeChecker(:invokeStatic,	new InvokeStaticTypeChecker());
      defineTypeChecker(:invokeSuper,	new InvokeSuperTypeChecker());
      defineTypeChecker(:fieldLong,	new FieldLongTypeChecker());
      defineTypeChecker(:fieldExp,	new FieldExpTypeChecker());
      defineTypeChecker(:fieldSuper,	new FieldSuperTypeChecker());
      defineTypeChecker(:fieldStatic,	new FieldStaticTypeChecker());
      defineTypeChecker(:new,		new NewTypeChecker());
      defineTypeChecker(:newEnclosingInstance,
			new NewEnclosingInstanceTypeChecker());
      defineTypeChecker(:classLiteral,	new ClassLiteralTypeChecker());

      defineTypeChecker(:qualifiedThis,
			new QualifiedThisTypeChecker());
      defineTypeChecker(:qualifiedFieldSuper,
			new QualifiedFieldSuperTypeChecker());
      defineTypeChecker(:qualifiedInvokeSuper,
			new QualifiedInvokeSuperTypeChecker());
      defineTypeChecker(:qualifiedInvokeSuperConstructor,
			new VoidTypeChecker());

      defineTypeChecker(:anonymousClass,new AnonymousClassTypeChecker());
      defineTypeChecker(:newArray,	new NewArrayTypeChecker());
      defineTypeChecker(:anonymousArray,new AnonymousArrayTypeChecker());
      defineTypeChecker(:array,		new ArrayTypeChecker());
      defineTypeChecker(:literalTree,	new LiteralTreeTypeChecker());
      defineTypeChecker(:id,		new VariableTypeChecker());
      defineTypeChecker(:cast,		new CastTypeChecker());
      defineTypeChecker(:paren,		new ParenTypeChecker());
      defineTypeChecker(:name,		new NameTypeChecker());
      defineTypeChecker(:this,		new ThisTypeChecker());

      defineTypeChecker(:block,		new BlockTypeChecker());
      defineTypeChecker(:for,		new BlockTypeChecker());
      defineTypeChecker(:catch,		new CatchTypeChecker());
      defineTypeChecker(:decl,		new DeclTypeChecker());
      defineTypeChecker(:labeled,	new LabeledTypeChecker());
      defineTypeChecker(:breakWithLabel,new BreakWithLabelTypeChecker());
      defineTypeChecker(:continueWithLabel,new BreakWithLabelTypeChecker());
      defineTypeChecker(:if,		new VoidTypeChecker());
      defineTypeChecker(:while,		new VoidTypeChecker());
      defineTypeChecker(:do,		new VoidTypeChecker());
      defineTypeChecker(:switch,	new VoidTypeChecker());
      defineTypeChecker(:case,		new VoidTypeChecker());
      defineTypeChecker(:default,	new VoidTypeChecker());
      defineTypeChecker(:break,		new VoidTypeChecker());
      defineTypeChecker(:continue,	new VoidTypeChecker());
      defineTypeChecker(:return,	new ReturnTypeChecker());
      defineTypeChecker(:returnWithExp,	new ReturnWithExpTypeChecker());
      defineTypeChecker(:synchronized,	new VoidTypeChecker());
      defineTypeChecker(:throw,		new VoidTypeChecker());
      defineTypeChecker(:try,		new VoidTypeChecker());
      defineTypeChecker(:finally,	new VoidTypeChecker());
      defineTypeChecker(:forArg,	new VoidTypeChecker());
      defineTypeChecker(:arrayInitializer,	new VoidTypeChecker());
      defineTypeChecker(:expressionStatement,	new VoidTypeChecker());
      defineTypeChecker(:emptyStatement,	new VoidTypeChecker());
      defineTypeChecker(:argumentList,		new VoidTypeChecker());
      defineTypeChecker(:invokeSuperConstructor,new VoidTypeChecker());
      defineTypeChecker(:invokeThisConstructor,	new VoidTypeChecker());

      defineTypeChecker(:pdecl,		new PdeclTypeChecker());
      defineTypeChecker(:constructor,	new ConstructorAndMethodTypeChecker());
      defineTypeChecker(:method,	new ConstructorAndMethodTypeChecker());
      defineTypeChecker(:instanceInitializer,	new VoidTypeChecker());
      defineTypeChecker(:staticInitializer,	new VoidTypeChecker());
      defineTypeChecker(:emptyClassBodyDeclaration,	new VoidTypeChecker());
      defineTypeChecker(:classBody,		new ClassBodyTypeChecker());
      defineTypeChecker(:throws,		new NameDeclTypeChecker());
      defineTypeChecker(:extends,		new NameDeclTypeChecker());
      defineTypeChecker(:implements,		new NameDeclTypeChecker());
      defineTypeChecker(:class,			new ClassTypeChecker());
      defineTypeChecker(:emptyTypeDeclaration,	new VoidTypeChecker());
      
      defineTypeChecker(:importDeclarations,	new Void1TypeChecker());
      defineTypeChecker(:packageDeclaration,	new Void1TypeChecker());
      defineTypeChecker(:typeDeclarations, new TypeDeclarationsTypeChecker());
      defineTypeChecker(:compilationUnit,	new VoidTypeChecker());

      defineTypeChecker(:errorInCompilationUnit,	new VoidTypeChecker());
      defineTypeChecker(:errorInClassBody,	new VoidTypeChecker());
      defineTypeChecker(:errorInBlock,		new VoidTypeChecker());
    }
  }
}



//--------------------------------------------------
// Operators


// a++, a--, --a, --a
class IncDecOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = typeCheckArgs(tree);
    // Actually, I should confirm the arg is a Number.
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}

// ~
class UnaryIntOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = typeCheckArgs(tree);
    Symbol s1 = newArgs[0].type().tag();
    Type t;
    if (s1 == :long){
      t = newArgs[0].type();
    } else {
      newArgs[0] = Type.coerce(Type.Tint, newArgs[0]);
      t = Type.Tint;
    }
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// !
class UnaryBooleanOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = typeCheckArgs(tree);
    newArgs[0] = Type.coerce(Type.Tboolean, newArgs[0]);
    return tree.modifyTypeAndArgs(Type.Tboolean, newArgs);
  }
}

// -a, -b
class UnaryNumberOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = typeCheckArgs(tree);
    Symbol s1 = newArgs[0].type().tag();
    Type t;
    if (s1 == :double || s1 == :float || s1 == :long){
      t = newArgs[0].type();
    } else {
      newArgs[0] = Type.coerce(Type.Tint, newArgs[0]);
      t = Type.Tint;
    }
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// a instanceof t
class InstanceOfOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree[] newArgs = { typeCheckTree(args[0]),
		       typeNameCheckTree(args[1]) };
    return tree.modifyTypeAndArgs(Type.Tboolean, newArgs);
  }
}

// a ? b : c
//
// Because current EPP does not understand "constant expression",
//it is impossible to determine the type of this expression accurately.
// For example, if the type of b is byte,  x ? b : 127  is byte,
//but  x ? b : 1000 should be int .
// See JLS1.0 15.24 .
class ConditionalExpressionTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree[] newArgs = typeCheckArgs(tree);
    newArgs[0] = Type.coerce(Type.Tboolean, newArgs[0]);
    Type t1 = newArgs[1].type();
    Type t2 = newArgs[2].type();
    Symbol s1 = t1.tag();
    Symbol s2 = t2.tag();
    Type t;
    if (s1 == :byte && s2 == :short){
      newArgs[1] = Type.coerce(Type.Tshort, newArgs[1]);
      t = Type.Tshort;
    } else if (s1 == :short && s2 == :byte){
      newArgs[2] = Type.coerce(Type.Tshort, newArgs[2]);
      t = Type.Tshort;
    } else if (Type.isSuperType(t1, t2)){
      newArgs[2] = Type.coerce(t1, newArgs[2]);
      t = t1;
    } else if (Type.isSuperType(t2, t1)){
      newArgs[1] = Type.coerce(t2, newArgs[1]);
      t = t1;
    } else {
      throw error("The type of ConditionalExpression could not determined."+
		  " Second operand : "+ t1+
		  " Third operand : "+ t2);
    }
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// =
class SimpleAssignmentOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);

    Obj epp = (Obj)Dynamic.get(:epp);
    newArgs[1] = epp!assignmentConversion(newArgs[0].type(),
					  newArgs[1]);
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);


    /* old
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    Symbol s1 = t1.tag();
    Symbol s2 = t2.tag();
    if ((s1 == :short || s1 == :char || s1 == :byte) &&
	(s2 == :int || s2 == :short || s2 == :char || s2 == :byte)){
      // Assignment conversion.  See JLS1.0 5.2 .
      // This implementation is not enough.
      return tree.modifyTypeAndArgs(t1, newArgs);
    } else {
      newArgs[1] = Type.coerce(t1, newArgs[1]);
      return tree.modifyTypeAndArgs(t1, newArgs);
    }
    */
  }
}

// *=, /=, %=, +=, -=, <<=, >>=, >>>=, &=, ^=, |=
class AssignmentOperatorTypeChecker extends TypeChecker {
  Symbol op;
  AssignmentOperatorTypeChecker(Symbol op){
    this.op = op;
  }
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    // See JLS1.0 15.25.2 .
    // a += b   ===  a = (T)(a + b)
    //
    // If s is a String and i is an int,  s += i  is String
    //and  i += s  should be an error.
    // This is not enough implementation.
    Tree[] newArgs  = typeCheckArgs(new Tree(op, args[0], args[1]));
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}

// +, -, *, /
class DoubleOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    Symbol s1 = newArgs[0].type().tag();
    Symbol s2 = newArgs[1].type().tag();
    Type t;
    if (s1 == :double || s2 == :double){
      newArgs[0] = Type.coerce(Type.Tdouble, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tdouble, newArgs[1]);
      t = Type.Tdouble;
    } else if (s1 == :float || s2 == :float){
      newArgs[0] = Type.coerce(Type.Tfloat, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tfloat, newArgs[1]);
      t = Type.Tfloat;
    } else if (s1 == :long || s2 == :long){
      newArgs[0] = Type.coerce(Type.Tlong, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tlong, newArgs[1]);
      t = Type.Tlong;
    } else {
      newArgs[0] = Type.coerce(Type.Tint, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tint, newArgs[1]);
      t = Type.Tint;
    }
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// This is an example of TypeChecker extension using Decorator pattern.
// +
class StringPlusOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    if ((t1.tag() == :class &&
	 t1.classInfo().getName() == :"java.lang.String")
	|| (t2.tag() == :class &&
	    t2.classInfo().getName() == :"java.lang.String")){
      // The hook method coerceToString is not implemented yet.
      //newArgs[0] = Type.coerceToString(newArgs[0]);
      //newArgs[1] = Type.coerceToString(newArgs[1]);
      return tree.modifyTypeAndArgs(Type.TString,
				    newArgs);
    } else {
      //return orig.call(tree);
      return orig.call(tree.modifyArgs(newArgs));
    }
  }
}

// ==, !=, <, >, <=, >=
class EqualOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    Type t2 = newArgs[1].type();
    Type t;
    // Actually, I should check arguments types using
    // binary numeric promotion. See JLS1.0 5.6.2 .
    t = Type.Tboolean;
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// <<, >>, >>>
class ShiftOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    // Actually, I should check argument types.
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}

// &, ^, |
class IntOrBooleanOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    Symbol s1 = newArgs[0].type().tag();
    Symbol s2 = newArgs[1].type().tag();
    Type t;
    if (s1 == :boolean || s2 == :boolean){
      newArgs[0] = Type.coerce(Type.Tboolean, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tboolean, newArgs[1]);
      t = Type.Tboolean;
    } else if (s1 == :long || s2 == :long){
      newArgs[0] = Type.coerce(Type.Tlong, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tlong, newArgs[1]);
      t = Type.Tlong;
    } else {
      newArgs[0] = Type.coerce(Type.Tint, newArgs[0]);
      newArgs[1] = Type.coerce(Type.Tint, newArgs[1]);
      t = Type.Tint;
    }
    return tree.modifyTypeAndArgs(t, newArgs);
  }
}

// &&, ||
class BooleanOperatorTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    newArgs[0] = Type.coerce(Type.Tboolean, newArgs[0]);
    newArgs[1] = Type.coerce(Type.Tboolean, newArgs[1]);
    return tree.modifyTypeAndArgs(Type.Tboolean, newArgs);
  }
}


//--------------------------------------------------
// Expressions

class Invoke1TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :class){
      throw error("The type of this is not a class: "+ typeOfThis);
    }
    Type targetType = typeOfThis;
    Tree methodName = args[0];
    Tree methodArgs = args[1];
    Object[] pair;
    try {
      pair = Type.typeCheckAndSelectMethod(targetType,
					   methodName.idName(),
					   methodArgs,
					   true); // findOuterClass
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MethodInfo selectedMethod = (MethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];
    Tree[] newArgs = { methodName, newMethodArgs };
    return tree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				  newArgs);
  }
}


class InvokeLongTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree resolved = resolveAmbiguousName(args[0]);
    if (resolved == null){
      throw error("Undefined variable or type name: "+ args[0].nameToString());
    } else if (resolved.tag() == :name
	       || resolved.tag() == :innerClassExp
	       || resolved.tag() == :innerClassStatic
	       ){
      //`(invokeStatic ,resolved ,(args[1]) ,(args[2]))
      return remakeTree(:invokeStatic,
			new Tree[]{ resolved, args[1], args[2] },
			args);

      // } else if (resolved.tag() == :id || resolved.tag() == :fieldExp
      //   || resolved.tag() == :fieldStatic) {
    } else {
      //`(invokeExp ,resolved ,(args[1]) ,(args[2]))
      return remakeTree(:invokeExp,
			new Tree[]{ resolved, args[1], args[2] },
			args);
    }
  }
}


class InvokeExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    Tree methodName = args[1];
    Tree methodArgs = args[2];
    Object[] pair;
    try {
      pair = Type.typeCheckAndSelectMethod(targetType,
					   methodName.idName(),
					   methodArgs,
					   false);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MethodInfo selectedMethod = (MethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];
    Tree[] newArgs = { exp, methodName, newMethodArgs };
    return tree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				  newArgs);
  }
}


class InvokeStaticTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Type targetType = typeTree.type();
    Tree methodName = args[1];
    Tree methodArgs = args[2];
    Object[] pair;
    try {
      pair = Type.typeCheckAndSelectMethod(targetType,
					   methodName.idName(),
					   methodArgs,
					   false);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MethodInfo selectedMethod = (MethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];
    Tree[] newArgs = { typeTree, methodName, newMethodArgs };
    return tree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				  newArgs);
  }
}


class InvokeSuperTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :class){
      throw error("The type of this is not a class: "+ typeOfThis);
    }
    Type targetType = typeOfThis.classInfo().getSuperclass();
    Tree methodName = args[0];
    Tree methodArgs = args[1];
    Object[] pair;
    try {
      pair = Type.typeCheckAndSelectMethod(targetType,
					   methodName.idName(),
					   methodArgs,
					   false);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MethodInfo selectedMethod = (MethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];
    Tree[] newArgs = { methodName, newMethodArgs };
    return tree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				  newArgs);
  }
}


class FieldLongTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree resolved = resolveAmbiguousName(args[0]);
    if (resolved == null){
      throw error("Undefined variable or type name: "+ args[0].nameToString());
    } else if (resolved.tag() == :name
	       || resolved.tag() == :innerClassExp
	       || resolved.tag() == :innerClassStatic
	       ){
      //`(fieldStatic ,resolved ,(args[1]))
      return remakeTree(:fieldStatic,
			new Tree[]{ resolved, args[1] },
			args);

      //} else if (resolved.tag() == :id || resolved.tag() == :fieldExp
      //  || resolved.tag() == :fieldStatic) {
    } else {
      //`(fieldExp ,resolved ,(args[1]))
      return remakeTree(:fieldExp,
			new Tree[]{ resolved, args[1] },
			args);
    }
  }
}


class FieldExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    FieldInfo fieldInfo = Type.selectField(targetType, args[1].idName());
    Tree[] newArgs = { exp, args[1] };
    return tree.modifyTypeAndArgs(fieldInfo.getType(), newArgs);
  }
}


class FieldSuperTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    if (typeOfThis.tag() != :class){
      throw error("The type of this is not a class: "+ typeOfThis);
    }
    Type targetType = typeOfThis.classInfo().getSuperclass();
    FieldInfo fieldInfo = Type.selectField(targetType, args[0].idName());
    return tree.modifyTypeAndArgs(fieldInfo.getType(), args);
  }
}


class FieldStaticTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree targetTree = typeNameCheckTree(args[0]);
    Type targetType = targetTree.type();
    Symbol fieldName = args[1].idName();
    if (fieldName == :this){
      // ClassName.this
      Tree[] newArgs = { targetTree, args[1] };
      return tree.modifyTypeAndArgs(targetType, newArgs);
    } else {
      FieldInfo fieldInfo = Type.selectField(targetType, fieldName);
      Tree[] newArgs = { targetTree, args[1] };
      return tree.modifyTypeAndArgs(fieldInfo.getType(), newArgs);
    }
  }
}


// Actually, I should call selectMostSpecificMethod
//and coerceArgumentList.
class NewTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree argumentList = typeCheckTree(args[1]);
    Type targetType = typeTree.type();

    Obj epp = (Obj)Dynamic.get(:epp);
    ClassInfo targetClassInfo = epp!getTargetClassInfo(targetType);
    MethodInfo selectedMethod
      = epp!selectMostSpecificMethod("<init>",
				     targetClassInfo.getConstructors(),
				     targetType,
				     argumentList);
    Tree[] newArgs = { typeTree,
		       epp!coerceArgumentList(argumentList,
					      selectedMethod)};
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}


// Actually, I should call selectMostSpecificMethod
//and coerceArgumentList.
class NewEnclosingInstanceTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    // (newEnclosingInstance Expression (new Type ArgumentList))
    Tree[] args = tree.args();
    Tree exp = typeCheckTree(args[0]);
    Type targetType = exp.type();
    if (targetType.tag() != :class){
      throw error("The type is not a class: "+ targetType);
    }
    TypeNameTable typeNameTable
      = (TypeNameTable)Dynamic.get(:typeNameTable);
    Dynamic.bind(:typeNameTable, new MemberTypeNameTable(targetType,
							 typeNameTable));
    Tree creation;
    try {
      creation = typeCheckTree(args[1]);
    } finally {
      Dynamic.unbind();
    }
    Tree[] newArgs = { exp, creation };
    return tree.modifyTypeAndArgs(creation.type(), newArgs);
  }
}


class ClassLiteralTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree[] newArgs = { typeNameCheckTree(args[0]) };
    return tree.modifyTypeAndArgs(Type.TClass, newArgs);
  }
}

//
class QualifiedThisTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] args = tree.args();
    Tree newName = typeNameCheckTree(args[0]);
    Tree[] newArgs = { newName };
    return tree.modifyTypeAndArgs(newName.type(), newArgs);
  }
}
class QualifiedFieldSuperTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree newName = typeNameCheckTree(args[0]);
    Type targetType = newName.type();
    FieldInfo fieldInfo = Type.selectField(targetType, args[1].idName());
    Tree[] newArgs = { newName, args[1]};
    return tree.modifyTypeAndArgs(fieldInfo.getType(), newArgs);
  }
}
class QualifiedInvokeSuperTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    Tree[] args = tree.args();
    Tree newName = typeNameCheckTree(args[0]);
    Type targetType = newName.type();
    Tree methodName = args[1];
    Tree methodArgs = args[2];
    Object[] pair;
    try {
      pair = Type.typeCheckAndSelectMethod(targetType,
					   methodName.idName(),
					   methodArgs,
					   false);
    } catch (EppTypeError e){
      if (Opts.log) e.printStackTrace(Opts.out);
      throw errorAt(tree, e.getMessage());
    }
    MethodInfo selectedMethod = (MethodInfo)pair[0];
    Tree newMethodArgs = (Tree)pair[1];
    Tree[] newArgs = { newName, methodName, newMethodArgs };
    return tree.modifyTypeAndArgs(selectedMethod.getReturnType(),
				  newArgs);
  }
}


class AnonymousClassTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 3);
    //(anonymousClass Name ArgumentList (classBody ClassBodyDeclaration*))
    Tree newName	= TypeNameChecker.typeNameCheckTree(tree.args()[0]);
    Tree newArgumentList = typeCheckTree(tree.args()[1]);
    Tree classBody	= tree.args()[2];

    int innerClassCounter = Dynamic.getInt(:inneClassCounter);
    Dynamic.setInt(:inneClassCounter, innerClassCounter + 1);
    Type typeOfThis = (Type)Dynamic.get(:typeOfThis);
    Symbol fullName = Symbol.intern(typeOfThis.classInfo().getName()+
				    "$"+
				    innerClassCounter);
    Tree superClass;
    Tree interfaces;
    if (newName.type().classInfo().isInterface()){
      superClass = `(extends);
      interfaces = `(implements ,newName);
    } else {
      superClass = `(extends ,newName);
      interfaces = `(implements);
    }
    
    Obj epp = (Obj)Dynamic.get(:epp);
    Tree entry = epp!normalizeClass(`(class (modifiers (id public))
				      (id class)
				      ,(new Identifier(fullName))
				      ,superClass
				      ,interfaces
				      ,classBody));
    Tree typeSig = entry.args()[1];
    if (Opts.printFileSignature) {
      Opts.out.println("ClassSignatureTree of anonymous class:");
      typeSig.print(Opts.out);
    }
    TypeNameTable typeNameTable
      = (TypeNameTable)Dynamic.get(:typeNameTable);

    Type type = new ClassType(fullName, typeSig,
			   typeNameTable, // Use the original name space.
			   typeOfThis,
			   null);

    Tree newClassBody;
    Dynamic.bind(:typeOfThis, type);
    try {
      newClassBody = typeCheckTree(classBody);
    } finally {
      Dynamic.unbind();
    }
    return tree.modifyTypeAndArgs(type, new Tree[]{ newName,
						    newArgumentList,
						    newClassBody});

  }
}


class NewArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = { typeNameCheckTree(tree.args()[0]) };
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}


class AnonymousArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Obj epp = (Obj)Dynamic.get(:epp);
    Tree typeName = typeNameCheckTree(tree.args()[0]);
    Tree initializer =
      epp!coerceVariableInitializer(typeName.type(),
				    typeCheckTree(tree.args()[1]));
    Tree[] newArgs = { typeName, initializer };
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}


class ArrayTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] newArgs = typeCheckArgs(tree);
    Type t1 = newArgs[0].type();
    if (t1.tag() != :arrayOf){
      throw error("The type is not an array: "+ t1);
    }
    newArgs[1] = unaryNumericPromotion(newArgs[1]);
    return tree.modifyTypeAndArgs(((ArrayType)t1).getComponentType(),
				  newArgs);
  }
}


class LiteralTreeTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Type t;
    Symbol literalTag = tree.literalToken().literalTag();
    if (literalTag == :int) {
      t = Type.Tint;
    } else if (literalTag == :long) {
      t = Type.Tlong;
    } else if (literalTag == :float) {
      t = Type.Tfloat;
    } else if (literalTag == :double) {
      t = Type.Tdouble;
    } else if (literalTag == :string) {
      t = Type.TString;
    } else if (literalTag == :char) {
      t = Type.Tchar;
    } else {
      throw error("LiteralTreeTypeChecker: Unknown literalTag : "+ literalTag);
    }
    return tree.modifyTypeAndArgs(t, tree.args());
  }
}

class VariableTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
    try {
      VarInfo info = varEnv.lookup(tree.idName());
      Type t = info.type();
      return tree.modifyTypeAndArgs(t, tree.args());
    } catch (NotFound e){
      throw error("Undefined variable: "+ tree.idName());
    }
  }
}


class CastTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 2);
    Tree[] args = tree.args();
    Tree typeTree = typeNameCheckTree(args[0]);
    Tree[] newArgs = {typeTree, typeCheckTree(args[1])};
    // narrowing cast $B$9$k$3$H$b$"$k$N$G!"(B coerce $B$7$F$O$$$1$J$$!#(B
    //Tree[] newArgs = {typeTree, Type.coerce(typeTree.type(),
    // typeCheckTree(args[1]))};
    return tree.modifyTypeAndArgs(typeTree.type(), newArgs);
  }
}


class ParenTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    checkArgsLength(tree, 1);
    Tree[] newArgs = typeCheckArgs(tree);
    return tree.modifyTypeAndArgs(newArgs[0].type(), newArgs);
  }
}


class NameTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw Epp.fatal(":name is appeared in the context of expression : "+ tree);
  }
}


class ThisTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Type t = (Type)Dynamic.get(:typeOfThis);
    return tree.modifyTypeAndArgs(t, tree.args());
  }
}


//--------------------------------------------------
// Statements and the others.


// This TypeChecker is used for "for" statement too.
class BlockTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    TreeVec newArgs = new TreeVec();
    
    if (Opts.nocatch){
      Type.typeCheckBlockStatements(0, args, newArgs);
      return tree.modifyTypeAndArgs(Type.Tvoid, newArgs.toArray());
    } else {
      try {
	Type.typeCheckBlockStatements(0, args, newArgs);
	return tree.modifyTypeAndArgs(Type.Tvoid, newArgs.toArray());
      } catch (EppUserError e){
	if (Opts.log) Opts.out.println("An error is caught during type checking a block.");
	return new Tree(:errorInBlock);
      }
    }
  }
}


class CatchTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree pdecl = args[0];
    Tree[] pargs = pdecl.args();
    Tree typeTree = typeNameCheckTree(pargs[1]);
    VarEnv varEnv = new VarEnv(pargs[2].idName(),
			       new VarInfo(pargs[0].args(),
					   typeTree.type()),
			       (VarEnv)Dynamic.get(:varEnv));
    Tree[] newPargs = { pargs[0], typeTree, pargs[2] };
    Tree newPdecl = pdecl.modifyTypeAndArgs(Type.Tvoid, newPargs);
    Dynamic.bind(:varEnv, varEnv);
    try {
      Tree[] newArgs = {newPdecl, typeCheckTree(args[1])};
      return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
    } finally {
      Dynamic.unbind();
    }
  }
}


// This TypeChecker simply checks subtrees recursively.
public class VoidTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    return tree.modifyTypeAndArgs(Type.Tvoid, typeCheckArgs(tree));
  }
}


// This TypeChecker is simillar to the above one, VoidTypeChecker,
//but does not check subtrees recursively.
public class Void1TypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    return tree.modifyTypeAndArgs(Type.Tvoid, tree.args());
  }
}


class DeclTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    throw error("decl appeared non-toplevel of block.");
  }
}


class LabeledTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree[] newArgs = {args[0], typeCheckTree(args[1])};
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}


// :breakWithLabel, :continueWithLabel
class BreakWithLabelTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    // Actually, I had better to make a label environment.
    return tree.modifyTypeAndArgs(Type.Tvoid, tree.args());
  }
}


class ReturnTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Type retType = (Type)Dynamic.get(:returnValueType);
    if (retType.tag() != :void){
      throw errorAt(tree, "Return value is required.");
    }
    return tree.modifyTypeAndArgs(Type.Tvoid, tree.args());
  }
}


class ReturnWithExpTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Type retType = (Type)Dynamic.get(:returnValueType);
    Obj epp = (Obj)Dynamic.get(:epp);
    Tree retValue = epp!assignmentConversion(retType, typeCheckTree(args[0]));
    //old Tree retValue = Type.coerce(retType, typeCheckTree(args[0]));
    return tree.modifyTypeAndArgs(Type.Tvoid, new Tree[]{retValue});
  }
}


class PdeclTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree[] newArgs = {args[0],
		      typeNameCheckTree(args[1]),
		      args[2]};
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}


class ConstructorAndMethodTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    if (! (tree.tag() == :constructor || tree.tag() == :method)){
      throw Epp.fatal(""+ tree);
    }
    Tree[] args = tree.args();
    Tree retType = typeNameCheckTree(args[1]);
    Tree name = args[2];
    Tree formalParameters = args[3];
    Tree[] params = formalParameters.args();
    Tree body = args[5];

    VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);
    Tree[] newParams = new Tree[params.length];
    for (int i = 0; i < params.length; i++){
      // (pdecl (modifiers Modifier*) Type Identifier)
      Tree[] pargs = params[i].args();

      Tree paramTypeTree = typeNameCheckTree(pargs[1]);
      Tree[] declaredVars = new Tree[1];
      Tree newVarId = checkVariableDeclaratorId(paramTypeTree.type(),
						pargs[2],
						declaredVars);
      Tree var = declaredVars[0];
      varEnv =  new VarEnv(var.idName(),
			   new VarInfo(pargs[0].args(),
				       var.type()),
			   varEnv);
      Tree[] newPargs = { pargs[0], paramTypeTree, newVarId };
      newParams[i] = params[i].modifyTypeAndArgs(Type.Tvoid, newPargs);
    }
    
    Tree thrs = typeCheckTree(args[4]);

    Obj epp = (Obj)Dynamic.get(:epp);
    Tree newBody;
    
    Dynamic.bind(:currentMethod, tree);
    Dynamic.bind(:varEnv, varEnv);
    Dynamic.bind(:returnValueType, retType.type());
    try {
      newBody = epp!typeCheckMethodBody(body);
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
      Dynamic.unbind();
    }
    Tree[] newArgs = {args[0], retType, name,
		      formalParameters.modifyTypeAndArgs(Type.Tvoid,
							 newParams),
		      thrs,
		      newBody};
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}


// I should implement addTree hook.
class ClassBodyTypeChecker extends TypeChecker {
  // $BF10l%/%i%9Fb$G$NL>A0$N>WFM$O%(%i!<!#(B
  // this,super $B$NL>A06u4V$bCm0U!#(B
  // $B=i4|2=$N=g=x$J$I$K$bCm0U!#(B

  public Tree call(Tree tree) {
    
    if (Opts.nocatch){
      return typeCheckClassBody(tree);
    } else {
      try {
	return typeCheckClassBody(tree);
      } catch (EppUserError e){
	if (Opts.log) Opts.out.println("An error is caught during type checking a class body.");
	return new Tree(:errorInClassBody);
      }
    }
  }


  // This is a prototype implementation !
  // (decl ...) $B$N=hM}$KCm0U!#(B DeclTypeChecker $B$O!"$=$N$^$^8F$V$H%(%i!<!#(B
  // BlockTypeChecker $B$,=hM}$9$k$3$H$K$J$C$F$$$k!#(B
  public Tree typeCheckClassBody(Tree tree) {
    Tree[] args = tree.args();
    int[] map = new int[args.length];
    int p = 0;
    TreeVec tvec = new TreeVec();
    
    // $B$H$j$"$($:(B super $B$N%a%s%P!<$K%"%/%;%9$G$-$k$h$&$K$7$?$+$C$?$N$G!"(B
    // $BA4BN$r(B this $B$NL>A06u4V$G0O$`!#(B
    Dynamic.bind(:varEnv, makeVarEnvFromTypeOfThis());
    // This counter is used to make temporary names of inner classes.
    Dynamic.bindInt(:inneClassCounter, 1);
    try {
      
      // Collect static fields and static initializers.
      for (int i = 0; i < args.length; i++){
	if (args[i].tag() == :staticInitializer ||
	    (args[i].tag() == :decl && isStaticMember(args[i]))){
	  tvec.add(args[i]); map[p++] = i;
	}
      }
      // Collect non-static fields and instanceInitializer
      for (int i = 0; i < args.length; i++){
	if (args[i].tag() == :instanceInitializer ||
	    (args[i].tag() == :decl && ! isStaticMember(args[i]))){
	  tvec.add(args[i]); map[p++] = i;
	}
      }
      
      // $B$3$&$$$&=hM}$OITMW!)(B
      // Type check fields.
      TreeVec tmpArgsVec = new TreeVec();
      Type.typeCheckBlockStatements(0, tvec.toArray(), tmpArgsVec);
      Tree[] tmpArgs = tmpArgsVec.toArray();
      if (tmpArgs.length != p){
	// Actually, some macro expansion may add new ClassBody members,
	//but it is not supported in this version.
	throw Epp.fatal("Result of type checking fields:"+
			`(classBody ,@tmpArgs));
      }
      
      // Type check other members.
      TreeVec newArgsVec = new TreeVec();
    nextMember:
      for (int i = 0; i < args.length; i++){
	for (int j = 0; j < p; j++){
	  if (i == map[j]){
	    newArgsVec.add(tmpArgs[j]);
	    continue nextMember;
	  }
	}
	newArgsVec.add(typeCheckTree(args[i]));
      }
      return tree.modifyTypeAndArgs(Type.Tvoid, newArgsVec.toArray());
    } finally {
      Dynamic.unbindInt();
      Dynamic.unbind();
    }
  }
  
  public boolean isStaticMember(Tree member){
    Tree[] modifiers = member.args()[0].args();
    for (int i = 0; i < modifiers.length; i++){
      if (modifiers[i].tag() == :id &&
	  modifiers[i].idName() == :static){
	return true;
      }
    }
    return false;
  }
  
  public VarEnv makeVarEnvFromTypeOfThis(){
    Type t = (Type)Dynamic.get(:typeOfThis);
    FieldInfo[] fields = t.classInfo().getFields();
    VarEnv varEnv = (VarEnv)Dynamic.get(:varEnv);

    for (int i = 0; i < fields.length; i++){
      if (! fields[i].isAmbiguousField()){
	varEnv =  new VarEnv(fields[i].getName(),
			     new VarInfo(fields[i].getModifiers(),
					 fields[i].getType()
					 ),
			     varEnv);
      }
    }
    return varEnv;
  }
}

// throws, extends, implements $B$N7?%A%'%C%/!#(B
class NameDeclTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){
      newArgs[i] = (typeNameCheckTree(args[i])); 
    }
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}

class ClassTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    
    TypeNameTable typeNameTable
      = (TypeNameTable)Dynamic.get(:typeNameTable);
    Type typeOfThis;
    try {
      // $B<+J,$NL>A0!JC1=cL>!K$O!"$3$N4D6-$KEPO?$5$l$F$$$k$b$N$H2>Dj!#(B
      typeOfThis = typeNameTable.get(`(name ,(args[2])));
    } catch (NotFound e){
      throw error("EPP BUG: Could not found the type of \"this\" : "+
		  args[2].idName());
      // throw Epp.fatal(""+ args[2].idName());
    }

    Tree extds = typeCheckTree(args[3]);
    Tree impls = typeCheckTree(args[4]);
    
    Dynamic.bind(:typeNameTable, new MemberTypeNameTable(typeOfThis,
							 typeNameTable));
    Dynamic.bind(:typeOfThis, typeOfThis);
    try {
      Tree newClassBody;
      newClassBody = typeCheckTree(args[5]);

      Tree[] newArgs = {args[0], args[1], args[2], extds, impls,
			newClassBody}; 

      return tree.modifyTypeAndArgs(typeOfThis, newArgs);
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}


class TypeDeclarationsTypeChecker extends TypeChecker {
  public Tree call(Tree tree) {
    Tree[] args = tree.args();
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){

      // I should implement addTree hook.
      newArgs[i] = typeCheckTree(args[i]);
    }
    return tree.modifyTypeAndArgs(Type.Tvoid, newArgs);
  }
}
