/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package epp;
import SystemMixinRuntimes.*;
import java.util.*;
import java.io.*;

public class Epp {

  //--------------------------------------------------
  // main

  public static void main(String[] argv){
    new Epp().eppMain(argv);
  }

  public void eppMain(String[] argv){

    if (argv.length < 1){
      printUsage();
    }
    
    int argp = 0;
    while (argp < argv.length && argv[argp].length() > 1
	   && argv[argp].charAt(0) == '-'){
      argp += parseOption(argv, argp);
    }

    if (Opts.log) {
      Opts.out.println("EPP main routine "+ Opts.eppSourceVersion+
		       " translated by "+ Opts.eppTranslatorVersion);
    }

    checkEppoutDirectory();

    if (! Opts.noTypeChecking && ! Opts.global) {
      throw eppMainRoutineError("Currently, -type-check option for separate compilation is not supported. Use -global with -type-check option.");
    }
    if (Opts.printTreeWithType && Opts.noTypeChecking) {
      throw eppMainRoutineError(" -print-tree-with-type is specified but -type-check is not specified.");
    }

    if (Opts.nocatch || Opts.nocatchFatal){
      processFilesAndCatchEppUserError(argv, argp);
    } else {
      try {
	processFilesAndCatchEppUserError(argv, argp);
      } catch (Throwable e){
	if (Opts.log) {
	  Opts.out.println("Unexpected exception is caught by the EPP main routine: "+ e);
	}
	System.err.println(e);
	System.exit(1);
      }
    }
  }

  public String makeOutputFileName(String inputFileName){
    return "eppout"+ File.separator+ inputFileName;
  }

  //--------------------------------------------------
  // Options
  
  public int parseOption(String[] argv, int argp){
    String opt = argv[argp];
  optionError:
    {
      if (opt.equals("-log")){
	Opts.log = true;
	return 1;
      } else if (opt.equals("-logfile")){
	if (argv.length <= argp + 1) break optionError;
	Opts.log = true;
	try {
	  Opts.out = new PrintWriter
	    (new BufferedWriter(new FileWriter(argv[argp + 1])),
	     true);
	} catch (java.io.IOException e) {
	  throw eppMainRoutineError(""+e);
	}
	return 2;
      } else if (opt.equals("-f")){
	Opts.forceTranslation = true;
	return 1;
      } else if (opt.equals("-r")){
	Opts.recursive = true;
	return 1;
      } else if (opt.equals("-clear")){
	ClearEppout.main(null);
	return 1;
      } else if (opt.equals("-plug-in")){
	if (argv.length <= argp + 1) break optionError;
	Opts.extraPlugIns.addElement(argv[argp + 1]);
	return 2;
      } else if (opt.equals("-global")){
	Opts.global = true;
	return 1;
      } else if (opt.equals("-token")){
	Opts.printToken = true;
	return 1;
      } else if (opt.equals("-class-info")){
	Opts.printClassInfo = true;
	return 1;
      } else if (opt.equals("-file-signature")){
	Opts.printFileSignature = true;
	return 1;
      } else if (opt.equals("-tree")){
	Opts.printTree = true;
	return 1;
      } else if (opt.equals("-tree-with-line-number")){
	Opts.printTree = true;
	Opts.printTreeWithLineNumber = true;
	return 1;
      } else if (opt.equals("-tree-with-type")){
	Opts.printTree = true;
	Opts.printTreeWithType = true;
	return 1;
      } else if (opt.equals("-tree-with-dots")){
	Opts.printTree = true;
	Opts.printTreeWithDots = true;
	return 1;
      } else if (opt.equals("-tree-with-string")){
	Opts.printTree = true;
	Opts.printTreeWithString = true;
	return 1;
      } else if (opt.equals("-tree-with-attribute")){
	if (argv.length <= argp + 1) {
	  System.err.println("An attribute name is not specified after "+
			     "-tree-with-attribute option.");
	  break optionError;
	} else {
	  Opts.printTree = true;
	  Opts.printTreeWithAttribute = true;
	  Opts.printTreeAttributeNames.addElement(Symbol.intern(argv[argp + 1]));
	  return 2;
	}
      } else if (opt.equals("-readable")){
	Opts.newlineForReadability = true;
	return 1;
      } else if (opt.equals("-nocatch")){
	Opts.nocatch = true;
	return 1;
      } else if (opt.equals("-nocatch-fatal")){
	Opts.nocatchFatal = true;
	return 1;
      } else if (opt.equals("-print-error-line")){
	Opts.printErrorLine = true;
	return 1;
      } else if (opt.equals("-force-next-pass")){
	Opts.forceNextPass = true;
	return 1;
      } else if (opt.equals("-system-mixin-log")){
	SystemMixin.debug = true;
	return 1;
      } else if (opt.equals("-help-all")){
	printAllOptions();
	return 1;
      } else if (opt.equals("-help") || opt.equals("-?") || opt.equals("/?")){
	printUsage();
	return 1;
      } else if (opt.equals("-v")){
	Opts.log = true;
	return 1;
      } else if (opt.equals("-comment-colon")){
	Opts.commentColon = true;
	return 1;
      } else if (opt.startsWith("-D")){
	if (opt.length() == 2){
	  throw eppMainRoutineError("Usage of -D option: -Dkey=val or -Dkey ");
	}
	java.util.Properties prop = System.getProperties();
	int eq = opt.indexOf('=', 2);
	String key;
	String val;
	if (eq == -1){
	  key = opt.substring(2);
	  val = "true";
	} else {
	  key = opt.substring(2, eq);
	  val = opt.substring(eq + 1);
	}
	prop.put(key, val);
	if (Opts.log){
	  val = System.getProperty(key);
	  Opts.out.println("Property "+ key+ " = "+ val);
	}
	return 1;
      } else if (opt.equals("-sml")){
	Opts.sml = true;
	return 1;
      } else if (opt.equals("-repeat-type-check")){
	Opts.repeatTypeCheck = true;
	return 1;
      } else if (opt.equals("-type-check")){
	Opts.noTypeChecking = false;
	return 1;
      } else if (opt.equals("-no-type-checking")){
	Opts.noTypeChecking = true;
	return 1;
      } else if (opt.equals("-no-code-emitting")){
	Opts.noCodeEmitting = true;
	return 1;
      } else if (opt.equals("-fast-parser")){
	Opts.fastParser = true;
	return 1;
      } else if (opt.equals("-encoding")){
	if (argv.length <= argp + 1) break optionError;
	Opts.encoding = argv[argp + 1];
	return 2;
      } else if (opt.equals("-target-classpath")){
	if (argv.length <= argp + 1) break optionError;
	Opts.targetClasspath = argv[argp + 1];
	return 2;
      } else if (opt.equals("-plug-in-package-prefix")){
	if (argv.length <= argp + 1) break optionError;
	Opts.plugInPackagePrefix = argv[argp + 1];
	return 2;
      } else {
	System.err.println("Unknown option: "+ opt);
	break optionError;
      }
    }
    // break optionError; was executed.
    System.err.println();
    printUsage();
    // Never reaches.
    return 1;
  }
  
  
  public void printUsage(){
    String[] m = importantOptions();
    for (int i = 0; i < m.length; i++){
      System.err.println(m[i]);
    }
    System.exit(1);
  }

  public void printAllOptions(){
    String[] m = importantOptions();
    for (int i = 0; i < m.length; i++){
      System.err.println(m[i]);
    }
    m = allOptions();
    for (int i = 0; i < m.length; i++){
      System.err.println(m[i]);
    }
    System.exit(1);
  }

  public String[] importantOptions(){
    String[] m = {
      "Usage: epp [options] file1.java file2.java...",
      "   or  epp [options] -r .",
      "",
      "Options:",
      "	-f		Force translation. (without time stamp checking)",
      "	-r dir		Translate Java files under the specified directories.",
      "	-clear		Clear files under eppout before translation.",
      "	-plug-in name	Add an extra plug-in at the end of the setup list.",
      "	-global		Exectute EPP in global translation mode.",
      "	-Dname[=val]	Set a system property.",
      "	-comment-colon	Skip \"//:\", \"/*:\" and \"*/\" .",
      "	-help-all	Explain all options.",
      "	-help,-?,/?	Print this message.",
      "",
    };
    return m;
  }

  public String[] allOptions(){
    String[] m = {
      "	-v		Print log to the standard error output.",
      "	-log		Same as -v.",
      "	-logfile file	Print log to the file.",
      "	-token		Print tokens.",
      "	-class-info	Print ClassInfo.",
      "	-file-signature	Print FileSignature.",
      "	-tree		Print abstract syntax tree during translation.",
      "	-tree-with-line-number	Print tree with line number infomation.",
      "	-tree-with-type		Print tree with type information.",
      "	-tree-with-dots		Print tree with readable indentation using dots.",
      "	-tree-with-string	Print tree with string of each node.",
      "	-tree-with-attribute name   Print tree with specified attribute value.",
      "	-readable	Emit human readable source code.",
      "	-nocatch	Print stack trace if an user or a fatal error occurs.",
      "	-nocatch-fatal	Print stack trace if a fatal error occurs.",
      //"	-print-error-line	Currently not used.",
      "	-force-next-pass	Proceed to next pass even if errors occur.",
      "	-system-mixin-log	Print system mixin log to \"SystemMixin.log\".",
      "	-type-check		Force type-checking.",
      "	-no-type-checking	Do not do type-checking pass. (default)",
      "	-no-code-emitting	Do not do code-emitting pass.",
      //"	-fast-parser		Currently not used.",
      //"	-repeat-type-check	Currently not used.",
      "	-encoding ENC		Specify character encoding.",
      "	-target-classpath CLASSPATH		Specify CLASSPATH for target.",
      "	-plug-in-package-prefix	PREFIX		Add PREFIX to plug-in names.",
      "",
    };
    return m;
  }
  
  public void checkEppoutDirectory(){
    if (! new File("eppout").isDirectory()){
      throw eppMainRoutineError("Please make a directory \"eppout\" before starting epp.");
    }
  }


  //--------------------------------------------------
  // Process files
  
  public void processFilesAndCatchEppUserError(String[] argv, int argp){
    if (Opts.nocatch){
      processFiles(argv, argp);
    } else {
      try {
	processFiles(argv, argp);
      } catch (EppUserError e){
	if (Opts.log) {
	  Opts.out.println("EppUserError is caught by the EPP main routine: "+ e);
	  Opts.out.println("EPP exits silently.");
	}
	System.exit(1);
      }
    }
  }
  
  public void processFiles(String argv[], int argp){
    String[] inputFileNames = makeInputFileNameList(argv, argp);
    if (Opts.global){
      globalEpp(inputFileNames);
    } else {
      separateEpp(inputFileNames);
    }
    if (Opts.log) Opts.out.println("End of all processes.");
  }
  
  public String[] makeInputFileNameList(String[] argv, int argp){
    
    Vector names = new Vector();
    for (int i = argp; i < argv.length; i++){

      // gnu-win32 bash uses '/' as file separators.
      String inputFileName = argv[i].replace('/', File.separatorChar);

      File in = new File(inputFileName);

      if (inputFileName.indexOf("..") != -1){
	throw eppMainRoutineError("\"..\" is contained in this path name: "+
				  inputFileName);
      }
      
      if (in.isAbsolute()){
	throw eppMainRoutineError("Epp can not accept absolute path name: "+
				  inputFileName);
      }
      
      if (! in.exists()){
	throw eppMainRoutineError("Input file \""+ inputFileName+
				  "\" does not exists.");
      }
      collectInputFileNames(inputFileName, names);
    }
    String[] inputFileNames = new String[names.size()];
    names.copyInto(inputFileNames);
    
    return inputFileNames;
  }
  
  public void collectInputFileNames(String inputFileName, Vector names){
    File in = new File(inputFileName);
    
    if (in.isDirectory()){
      if (Opts.recursive) {
	if (in.getName().equals("eppout")){
	  if (Opts.log) Opts.out.println("Skip processing "+ inputFileName);
	  return;
	} else {
	  String[] list = in.list();
	  for (int i = 0; i < list.length; i++){
	    collectInputFileNames(inputFileName+
				  File.separator+
				  list[i],
				  names);
	  }
	}
      } else {
	throw eppMainRoutineError("\""+ inputFileName+
				  "\" is a directory. Use -r option.");
      }
    } else if (inputFileName.endsWith(".java")) {
      names.addElement(inputFileName);
    } else if (Opts.recursive) {
      // If -r option is specified, epp will ignore non-java files.
      return;
    } else {
      throw eppMainRoutineError("The input file name \""+ inputFileName+
				"\" does not end with \".java\" .");
    }
  }

  

  //--------------------------------------------------
  // Gloabl EPP
  
  public void globalEpp(String[] inputFileNames){

    FileInfo globalProcessor = makeEppGlobalProcessor();
    
    FileInfo[] allFileInfo = new FileInfo[inputFileNames.length];
    for (int i = 0; i < inputFileNames.length; i++){
      if (Opts.log) Opts.out.println("Input file name: "+ inputFileNames[i]);

      //old String outputFileName ="eppout"+ File.separator+ inputFileNames[i];
      String outputFileName = makeOutputFileName(inputFileNames[i]);
      allFileInfo[i] = makeEppPreProcessor(inputFileNames[i], outputFileName);
    }
    if (Opts.log) Opts.out.println("Initialization pass.");
    for (int i = 0; i < allFileInfo.length; i++){
      allFileInfo[i].initializationPass();
    }
    checkErrorCounter();
    if (Opts.log) Opts.out.println("Initialize the EPP global processor.");
    allFileInfo = globalProcessor.initGlobalProcessor(allFileInfo);
    
    if (Opts.log) Opts.out.println("Parsing pass.");
    for (int i = 0; i < allFileInfo.length; i++){
      allFileInfo[i].doParsingPass();
    }
    checkErrorCounter();
    if (Opts.log) Opts.out.println("Start globalProcessAfterParsingPass");
    allFileInfo = globalProcessor.globalProcessAfterParsingPass(allFileInfo);
    if (Opts.log) Opts.out.println("End globalProcessAfterParsingPass");
    
    if (Opts.log) Opts.out.println("Macro expansion pass.");
    for (int i = 0; i < allFileInfo.length; i++){
      allFileInfo[i].doMacroExpansionPass();
    }
    checkErrorCounter();
    if (Opts.log) Opts.out.println("Start globalProcessAfterMacroExpansionPass");
    allFileInfo =
      globalProcessor.globalProcessAfterMacroExpansionPass(allFileInfo);
    if (Opts.log) Opts.out.println("End globalProcessAfterMacroExpansionPass");
    
    if (! Opts.noTypeChecking){

      if (Opts.log) Opts.out.println("Making FileSignatures.");
      for (int i = 0; i < allFileInfo.length; i++){
	Tree sig = allFileInfo[i].makeFileSignature();
	// addFileSignature may depend on DVenv.
	// (The DVenv set by allFileInfo[i] still remains at present.)
	ClassTypeTable.instance.addFileSignature(sig);
      }
      checkErrorCounter();

      if (Opts.log) Opts.out.println("Type checking pass.");
      for (int i = 0; i < allFileInfo.length; i++){
	allFileInfo[i].doTypeCheckingPass();
      }
      checkErrorCounter();
      if (Opts.log) Opts.out.println("Start globalProcessAfterTypeCheckingPass");
      allFileInfo =
	globalProcessor.globalProcessAfterTypeCheckingPass(allFileInfo);
      if (Opts.log) Opts.out.println("End globalProcessAfterTypeCheckingPass");
    }
    
    if (! Opts.noCodeEmitting){
      if (Opts.log) Opts.out.println("Translation pass.");
      for (int i = 0; i < allFileInfo.length; i++){
	allFileInfo[i].doTranslationPass();
      }
      checkErrorCounter();

      if (Opts.log) Opts.out.println("Code emitting pass.");
      for (int i = 0; i < allFileInfo.length; i++){
	allFileInfo[i].doCodeEmittingPass();
      }
    }
    if (Opts.log) Opts.out.println("End of all global processes.");
  }


  public FileInfo makeEppGlobalProcessor(){

    if (Opts.log) Opts.out.println("Making an EPP global processor.");
    Object[][] eppCommands = {};
    return makeEppObject(null, null, eppCommands);
  }


  //--------------------------------------------------
  // Separate EPP
  
  public void separateEpp(String[] inputFileNames){
    // This is a hashtable of files which is already processed phase1.
    Hashtable processedFiles = new Hashtable();	// key:String, val:FileInfo
    Stack processedFilesStack = new Stack();
    
    for (int i = 0; i < inputFileNames.length; i++){
      String inputFileName = inputFileNames[i];
      File in = new File(inputFileName);
      
      //old String outputFileName = "eppout"+ File.separator+ inputFileName;
      String outputFileName = makeOutputFileName(inputFileName);
      File out = new File(outputFileName);
      
      // Check time stamp.
      if (! Opts.forceTranslation &&
	  out.exists() &&
	  in.lastModified() < out.lastModified()){
	// Do nothing.
      } else {
	FileInfo fileInfo = makeEppPreProcessor(inputFileName, outputFileName);
	// Phase1 for updated files.
	processPhase1(fileInfo);
	processedFiles.put(inputFileName, fileInfo);
	processedFilesStack.push(fileInfo);
      }
    }
    checkErrorCounter();
    for (int i = 0; i < inputFileNames.length; i++){
      // Phase1 for files which depend on updated files.
      // (Not implemented.)
      //processPhase1(fileInfo);
      //processedFiles.put(inputFileName, fileInfo);
      //processedFilesStack.push(fileInfo);
    }

    while (! processedFilesStack.isEmpty()){
      FileInfo fileInfo = (FileInfo)processedFilesStack.pop();
      processPhase2(fileInfo);
    }

    Opts.out.println((processedFiles.size() == 0 ?
		      "No" :
		      (""+ processedFiles.size()))+
		     " Java files were translated.");
  }

  public FileInfo makeEppPreProcessor(String inputFileName,
				      String outputFileName){

    if (Opts.log) Opts.out.println("Making an EPP pre-processor for "+
				   inputFileName);
    
    // Scan input file and collect #epp commands.
    if (Opts.log) Opts.out.println("Collect epp commands.");
    Object[][] eppCommands = collectEppCommands(inputFileName);
    // Print specified Plug-ins.
    for (int i = 0; i < eppCommands.length; i++){
      String plugInName = (String)eppCommands[i][0];
      String[] comArgs =  (String[])eppCommands[i][1];
      if (Opts.log) Opts.out.println(" Specified \""+
				     plugInName+
				     "\" with "+
				     comArgs.length+
				     " args.");
      for (int j = 0; j < comArgs.length; j++){
	if (Opts.log) Opts.out.println("  arg "+ j+ ": \""+ comArgs[j]+ "\"");
      }
    }
    return makeEppObject(inputFileName, outputFileName, eppCommands);
  }


  public void processPhase1(FileInfo fileInfo){
    Opts.out.println("Phase1 for "+ fileInfo.getInputFileName());
    fileInfo.initializationPass();
    fileInfo.doParsingPass();
    fileInfo.doMacroExpansionPass();
  }

  public void processPhase2(FileInfo fileInfo){
    Opts.out.println("Phase2 for "+ fileInfo.getInputFileName());
    if (! Opts.noTypeChecking) {
      throw Epp.fatal("-type-check for separate compilation is not supported.");
      //fileInfo.doTypeCheckingPass();
    }
    if (! Opts.noCodeEmitting) fileInfo.doCodeEmittingPass();
  }


  //--------------------------------------------------
  // EPP pre-processor.

  public FileInfo makeEppObject(String inputFileName,
				String outputFileName,
				Object[][] eppCommands){

    // Initialize the Setup List of system mixins.
    if (Opts.log) Opts.out.println("Init Setup List.");
    SystemMixin.initSetupList();
    
    // Prepare default configuration.
    if (Opts.log) Opts.out.println("Load default configuration.");
    loadDefaultConfiguration();

    // Load Plug-ins.
    if (Opts.log) Opts.out.println("Load plug-ins.");
    for (int i = 0; i < eppCommands.length; i++){
      String plugInName = (String)eppCommands[i][0]+ ".PlugIn";
      if (Opts.plugInPackagePrefix != null){
	plugInName = Opts.plugInPackagePrefix+ "."+ plugInName;
      }
      String[] comArgs =  (String[])eppCommands[i][1];
      PlugInLoader.requirePlugIn(plugInName, comArgs);
    }

    if (Opts.extraPlugIns.size() > 0){
      if (Opts.log) Opts.out.println("Load plug-ins specified by option.");
      String[] plugIns = new String[Opts.extraPlugIns.size()];
      Opts.extraPlugIns.copyInto(plugIns);
      for (int i = 0; i < plugIns.length; i++){
	String plugInName = plugIns[i]+ ".PlugIn";
	String[] comArgs = {};
	PlugInLoader.requirePlugIn(plugInName, comArgs);
      }
    }
    
    // Setup. Combine all system mixins and generate one pre-processor system.
    if (Opts.log) Opts.out.println("Set up.");
    SystemMixin.setup();
    
    // Generate and initialize the pre-processor.
    if (Opts.log) Opts.out.println("Generate and initialize "+
				   inputFileName+ " .");
    Dynamic.env = new DVenvArrayShallow();
    Obj preprocessor =  C_Epp.generateAndInit(inputFileName, outputFileName);
    return makeFileInfo(inputFileName,
			preprocessor,
			SystemMixin.classTable,
			Dynamic.env);
  }
  
  // Factory method pattern
  public FileInfo makeFileInfo(String inputFileName,
			       Obj preprocessor,
			       Hashtable classTable,
			       DVenv env){
    return new FileInfo(inputFileName, preprocessor, classTable, env);
  }
  
  
  public void loadDefaultConfiguration(){
    String[] args = {};
    new EppCore().require(args);
    new Lex().require(args);
    new ExpNonTerm().require(args);
    new Exp().require(args);
    new Statement().require(args);
    new TypeDecl().require(args);
    new CompUnit().require(args);
    new TypeSystem().require(args);
    new TypeCheck().require(args);
    new FileSig().require(args);
    new ReadClassFile().require(args);
    new Global().require(args);
    new LsLo().require(args);
  }
  
  

  //--------------------------------------------------
  // Scan #epp lines.
  
  public Object[][] collectEppCommands(String inputFileName){
    EppInputStream in = new EppInputStream(inputFileName);
    char c;
    Vector commands = new Vector();
  scanFile:
    while (true){
      if (in.isEof()) break scanFile;
      c = in.getc();
      if ((c == '#' &&
	   (c = in.getc()) == 'e' &&
	   (c = in.getc()) == 'p' &&
	   (c = in.getc()) == 'p')
	  ||
	  (Opts.commentColon &&
	   (c == '/') &&
	   (c = in.getc()) == '/' &&
	   (c = in.getc()) == ':' &&
	   (c = in.getc()) == '#' &&
	   (c = in.getc()) == 'e' &&
	   (c = in.getc()) == 'p' &&
	   (c = in.getc()) == 'p')
	  ) {
	skipSpace(in);
	parseEppCommand(in, commands);
      } else {
	in.ungetc(c);
	// Skip this line.
	while ((c = in.getc()) != '\n' && c != '\r'){
	  /*
	    if (c == '/'){
	      if ((c = in.getc()) == '*'){
		skipComment(in);
	      } else {
		in.ungetc(c);
	      }
	    }
	  */
	}
	in.ungetc(c);
	// Skip to the beginning of the line of the next non-empty line.
	while (c == '\n' || c == '\r') {
	  if (in.isEof()) break scanFile;
	  c = in.getc();
	}
	in.ungetc(c);
      }
    }
    // Finished scanning input file.
    Object[][] objs = new Object[commands.size()][];
    commands.copyInto(objs);
    return objs;
  }
  
  
  public void parseEppCommand(EppInputStream in, Vector commands){
    
    // Read the Plug-in file name.
    char c;
    boolean doubleQuoted = false;
    if (in.peekc() == '\"'){
      doubleQuoted = true;
      in.getc();
    }
    int begin = in.pointer();
    while ((c = in.getc()) != '\"' &&
	   c != ' ' && c != '\t' && c != '\n' && c != '\r');
    if (doubleQuoted ^ c == '\"'){
      System.err.println("Double quote");
      throw eppCommandUsage(in);
    }
    String com;
    com = in.bufferSubString(begin, in.pointer() - 1);
    if (c != '\"') {
      in.ungetc(c);
    }

    // Read arguments.
    Vector strings = new Vector();
  readArgs:
    while (true) {
      skipSpace(in);
      if ((c = in.getc()) == '\n' || c == '\r') break readArgs;
      begin = in.pointer() - 1;
      while ((c = in.getc()) != ' ' && c != '\t' && c != '\n' && c != '\r');
      in.ungetc(c);
      strings.addElement(in.bufferSubString(begin, in.pointer()));
    }
    
    String[] strs = new String[strings.size()];
    strings.copyInto(strs);
    Object[] arr = {com, strs};
    commands.addElement(arr);
  }
  
  
  public Error eppCommandUsage(EppInputStream in){
    return eppMainRoutineError(in.fileName()+
			       ":"+
			       in.lineNumber()+
			       ":Epp command Syntax Error. "+
			       "Usage: #epp \"PlugInName\" [args ...]");
  }
  
  
  public void skipSpace(EppInputStream in) {
    char c;
    while (true){
      c = in.getc();
      if (c != ' ' && c != '\t') {
	in.ungetc(c);
	return;
      }
    }
  }

  // Not used.
  public void skipComment(EppInputStream in) {
    char c;
    while (true){
      c = in.getc();
      if (c == '*'){
	if ((c = in.getc()) == '/'){
	  return;
	} else {
	  in.ungetc(c);
	}
      }
    }
  }


  public Error eppMainRoutineError(String str){
    String mes = "Epp main routine: "+ str;
    if (Opts.nocatch){
      return new Error(mes);
    } else {
      System.err.println(mes);
      System.exit(1);
      throw Epp.fatal("never reached");
    }
  }
  

  //--------------------------------------------------
  // Utility functions.

  public static String getClassNameFromFileName(String inputFileName){
    // Example: "foo/bar/File.java" -> "File"
    
    int lastdot = -1;
    int lastslash = -1;
    for (int i = inputFileName.length() - 1; 0 <= i ; i--){
      if (inputFileName.charAt(i) == '.'){
	lastdot = i;
	break;
      }
    }
    if (lastdot == -1){
      throw Epp.fatal("\".\" is not contained in the input file name.");
    }
    for (int i = lastdot - 1; 0 <= i ; i--){
      if (inputFileName.charAt(i) == File.separatorChar){
	lastslash = i;
	break;
      }
    }
    return inputFileName.substring(lastslash + 1, lastdot);
  }
  
  public static final String generatedHeader = "/* Generated by EPP";
  
  public static boolean isGeneratedFile(String path){
    boolean ret;
    
    // The pathname should starts with "eppout/".
    if (! path.startsWith("eppout"+ File.separator)) {
      ret = false;
    } else {
      
      // The pathname should end with ".java" or ".class"
      if (path.endsWith(".class")) {
	ret = true;
      } else if (path.endsWith(".java")) {
	// The file begins with generatedHeader if it is .java file.
      checkContents:
	try{
	  ret = false;		// To avoid Java WorkShop2.0 fastjavac BUG.
	  FileInputStream in = new FileInputStream(new File(path));
	  try {
	    byte[] buf = new byte[generatedHeader.length()];
	    int offset = 0;
	    while (offset < buf.length){
	      int size = in.read(buf, offset, buf.length - offset);
	      if (size == -1){	// EOF
		ret = false;
		break checkContents;
	      }
	      offset += size;
	    }
	    ret = generatedHeader.equals(new String(buf, 0, buf.length));
	  } finally {
	    in.close();
	  }
	} catch (Exception e){
	  System.err.println(e);
	  System.err.println("Error occured during checking "+ path);
	  System.exit(1);
	  throw new Error("never reached");
	}
      } else {
	ret = false;
      }
    }
    //System.err.println(""+ ret+ " == isGeneratedFile("+ path+ ")");
    return ret;
  }

  public static Error error(String str){
    return new EppUserError(str);
  }

  public static Error fatal(String str){
    return new Error("EPP FATAL: "+ str);
  }

  public static void checkErrorCounter(){
    if (! Opts.forceNextPass && Opts.errorCounter > 0){
      String str = ""+ Opts.errorCounter+ " errors";
      if (Opts.log) Opts.out.println(str);
      System.err.println(str);
      throw Epp.error(str);
    }
  }

}
