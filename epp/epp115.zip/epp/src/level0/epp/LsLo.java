/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

     
#epp Symbol
#epp SystemMixin
#epp AutoSplitFiles
#epp EppMacros


package epp;
import SystemMixinRuntimes.*;
import java.io.*;
import java.util.*;



SystemMixin LsLo {
  class Epp {

    extend void initializationPass() {
      original();
      Dynamic.bind(:translatorTable, new Hashtable());
      Dynamic.bind(:translatingTree, null);
      initTranslatorTable();
    }

    // EPP main routine $B$+$iD>@\8F$V$h$&$K$7$?!#(B
    /* old
    extend void beforeCodeEmittingPass(){
      if (! Opts.noTypeChecking) {
	doTranslationPass();
      }
    }
    */
    
    define void initTranslatorTable() {
    }

    define void defineTranslator(Symbol tag , Translator func) {
      Hashtable translatorTable = (Hashtable)Dynamic.get(:translatorTable);
      if (translatorTable.get(tag) != null){
	throw Epp.fatal("FATAL: Translator for :"+ tag+
			" is already defined.");
      }
      translatorTable.put(tag, func);
    }

    define implement void extendTranslator(Symbol tag, Translator func) {
      Hashtable translatorTable = (Hashtable)Dynamic.get(:translatorTable);
      Translator orig = (Translator)translatorTable.get(tag);
      if (orig == null){
	throw Epp.fatal("Translator for :"+ tag+ " is not defined.");
      }
      func.orig = orig;
      translatorTable.put(tag, func);
    }


    define implement void doTranslationPass() {
      beforeTranslationPass();

      if (Opts.log) Opts.out.println("Start Ls to Lo translation "+ (String)Dynamic.get(:inputFileName)+ " .");
      translationPass();
      if (Opts.log) Opts.out.println("End Ls to Lo translation "+ (String)Dynamic.get(:inputFileName)+ " .");

      if (Opts.printTree) {
	Opts.out.println("Translated Tree:");
	Opts.out.println();
	self!tree.print(Opts.out);
      }

      /*old
      if (Dynamic.getInt(:errorCounter) > 0){
	throw error(""+ Dynamic.getInt(:errorCounter)+ " errors");
      }
      */

      afterTranslationPass();
    }
    
    define implement void beforeTranslationPass(){}

    define implement void translationPass(){
      self!tree = Translator.translateTree(self!tree);
    }

    define implement void afterTranslationPass(){}
  }
}


public abstract class Translator extends Macro {

  //lisp-epp THIS_IS_NOT_A_CONSTRUCTOR
  public Translator orig = null;
  
  public abstract Tree call(Tree tree);
  
  public static Tree translateTree(Tree tree){
    Hashtable translatorTable = (Hashtable)Dynamic.get(:translatorTable);

    Dynamic.bind(:translatingTree, tree);
    try {
      Symbol tag = tree.tag();
      Translator func = (Translator)translatorTable.get(tag);
      if (func != null) {
	tree = func.call(tree);
      } else {
	throw Epp.fatal("Translator for "+ tag+ " is not defined.");
      }
      return tree;
    } finally {
      Dynamic.unbind();
    }
  }
  
  public static Tree translate1(Tree tree){
    Hashtable translatorTable = (Hashtable)Dynamic.get(:translatorTable);
    Translator func = (Translator)translatorTable.get(tree.tag());
    if (func == null) {
      throw Epp.fatal("TypeChecker for "+ tree.tag()+ " is not defined.");
    } else {
      return func.call(tree);
    }
  }
  
  // This method returns a newly created array.
  // The caller is allowed to modify the return value.
  public static Tree[] translateArgs(Tree tree){
    Tree[] args = tree.args();
    Tree[] newArgs = new Tree[args.length];
    for (int i = 0; i < args.length; i++){
      newArgs[i] = translateTree(args[i]); 
    }
    return newArgs;
  }
  
  public static void checkArgsLength(Tree tree, int argc){
    Tree[] args = tree.args();
    if (args.length != argc){
      throw Epp.fatal("FATAL: The Translator requires "+ argc+
		      " args but supplied "+ args.length+ " :"+ tree);
    }
  }
}




SystemMixin InitTranslatorTable {
  class Epp {
    extend void initTranslatorTable () {
      original();
      Symbol[] tags = JavaAST.standardJavaNodes;
      for (int i = 0; i < tags.length; i++){
	defineTranslator(tags[i], new DefaultTranslator());
      }

      extendTranslator(:typeDeclarations, new TypeDeclarationsTranslator());
      extendTranslator(:classBody, new ClassBodyTranslator());
      extendTranslator(:block, new BlockTranslator());
    }
  }
}

public class JavaAST {
  public static Symbol[] standardJavaNodes = {
    :postInc,
      :postDec,
      :preInc,
      :preDec,
      :"~",
      :"!",
      :unaryPlus,
      :unaryMinus,
      :instanceof,
      :conditionalExpression,
      :"=",
      :"*=",
      :"/=",
      :"%=",
      :"+=",
      :"-=",
      :"<<=",
      :">>=",
      :">>>=",
      :"&=",
      :"^=",
      :"|=",
      :"%",
      :"+",
      :"-",
      :"*",
      :"/",
      :"==",
      :"!=",
      :"<",
      :">",
      :"<=",
      :">=",
      :"<<",
      :">>",
      :">>>",
      :"&",
      :"^",
      :"|",
      :"&&",
      :"||",
      :invoke1,
      :invokeLong,
      :invokeExp,
      :invokeStatic,
      :invokeSuper,
      :fieldLong,
      :fieldExp,
      :fieldSuper,
      :fieldStatic,
      :new,
      :newEnclosingInstance,
      :classLiteral,

      :qualifiedThis,
      :qualifiedFieldSuper,
      :qualifiedInvokeSuper,
      :qualifiedInvokeSuperConstructor,

      :anonymousClass,
      :newArray,
      :anonymousArray,
      :array,
      :literalTree,
      :id,
      :cast,
      :paren,
      :name,
      :this,
      :block,
      :for,
      :catch,
      :decl,
      :labeled,
      :breakWithLabel,
      :continueWithLabel,
      :if,
      :while,
      :do,
      :switch,
      :case,
      :default,
      :break,
      :continue,
      :return,
      :returnWithExp,
      :synchronized,
      :throw,
      :try,
      :finally,
      :forArg,
      :arrayInitializer,
      :expressionStatement,
      :emptyStatement,
      :argumentList,
      :invokeSuperConstructor,
      :invokeThisConstructor,
      :pdecl,
      :constructor,
      :method,
      :instanceInitializer,
      :staticInitializer,
      :emptyClassBodyDeclaration,
      :classBody,
      :class,
      :emptyTypeDeclaration,
      :importDeclarations,
      :packageDeclaration,
      :typeDeclarations,
      :compilationUnit,

      // pseudo nodes
      :modifiers,
      :extends,
      :implements,
      :importOnDemand,
      :importSingle,
      :formalParameters,
      :throws,
      :vardecls,
      :varInit,
      :arrayVar,

      // type names
      :arrayOf,
      :dimExpr,
      :innerClassExp,
      :innerClassStatic,

      // special node
      :stringNode,
      :stringNodeArguments,
      
      // comment node defined at ParseComment plug-in.
      :javadocComment,
      :traditionalComment,
      :endOfLineComment,
    
      // Because of bug of error handling mechanism, 
      //these node sometimes passed to translationPass .
      // In order to avoid fatal error, I added these nodes to this list.
      :errorInBlock,
      :errorInClassBody,
      :errorInCompilationUnit,

    };

  public static Hashtable standardJavaNodesTable;
  static {
    standardJavaNodesTable = new Hashtable();
    Symbol[] tags = standardJavaNodes;
    for (int i = 0; i < tags.length; i++){
      standardJavaNodesTable.put(tags[i], :standardJavaNode);
    }
  }

  public static boolean isStandardJavaNode(Symbol tag){
    return (standardJavaNodesTable.get(tag) != null);
  }
}



// $B7?>pJs$r:F5"E*$K$O$:$9$@$1!#(B
// $B$?$@$70LCV>pJs$=$NB>$O;D$9!#(B
public class DefaultTranslator extends Translator {
  public Tree call(Tree tree){
    return tree.modifyArgsAndResetType(translateArgs(tree));
  }
}



public class TypeDeclarationsTranslator extends Translator {
  public Tree call(Tree tree){
    Dynamic.bind(:beforeCurrentTypeDeclaration, null);
    Dynamic.bind(:afterCurrentTypeDeclaration, null);
    try {
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();
      
      for (int i = 0; i < args.length; i++){
      	Dynamic.set(:beforeCurrentTypeDeclaration, new TreeVec());
	Dynamic.set(:afterCurrentTypeDeclaration, new TreeVec());
	
        Tree earg = translateTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentTypeDeclaration));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentTypeDeclaration));
      }
      return tree.modifyArgsAndResetType(tvec.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}

public class ClassBodyTranslator extends Translator {
  public Tree call(Tree tree){
    Dynamic.bind(:beginningOfClassBody, new TreeVec());
    Dynamic.bind(:beforeCurrentClassBodyDeclaration, null);
    Dynamic.bind(:afterCurrentClassBodyDeclaration, null);
    try{
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();

      for (int i = 0; i < args.length; i++){
	Dynamic.set(:beforeCurrentClassBodyDeclaration, new TreeVec());
	Dynamic.set(:afterCurrentClassBodyDeclaration, new TreeVec());

        Tree earg = translateTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentClassBodyDeclaration));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentClassBodyDeclaration));
      }
      
      TreeVec beginning = (TreeVec)Dynamic.get(:beginningOfClassBody);
      beginning.addA(tvec);
      
      return tree.modifyArgsAndResetType(beginning.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}

public class BlockTranslator extends Translator {
  public Tree call(Tree tree){
    Dynamic.bind(:beforeCurrentBlockStatement, null);
    Dynamic.bind(:afterCurrentBlockStatement, null);
    try{
      Tree[] args = tree.args();
      TreeVec tvec = new TreeVec();
      
      for (int i = 0; i < args.length; i++) {
	Dynamic.set(:beforeCurrentBlockStatement, new TreeVec());
	Dynamic.set(:afterCurrentBlockStatement, new TreeVec());
	
        Tree earg = translateTree(args[i]);
	
	tvec.addA((TreeVec)Dynamic.get(:beforeCurrentBlockStatement));
	tvec.add(earg);
	tvec.addA((TreeVec)Dynamic.get(:afterCurrentBlockStatement));
      }
      return tree.modifyArgsAndResetType(tvec.toArray());
    } finally {
      Dynamic.unbind();
      Dynamic.unbind();
    }
  }
}
