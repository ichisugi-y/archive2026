/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */



// Runtime routines for SystemMixins.

package SystemMixinRuntimes;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.io.*;
import java.lang.reflect.*;

//--------------------------------------------------


public class SystemMixin {
  // Static member definitions.
  public static boolean debug = false;
  public static boolean light;
  public static boolean instanceCreated; // Used by light version.
  

  static PrintWriter logfile
    = new PrintWriter(new BufferedWriter(new FileWriter(FileDescriptor.err)),
		      true);

  public static Vector setupList; // Vector of SystemMixin

  public static Hashtable classTable = null; // key = name, value = ObjClass

  public static Hashtable loadedPlugIns; // key = plug-in name, value = args

  //--------------------------------------------------
  
  public static void initSetupList(){
    if (debug){
      try {
	logfile
	  = new PrintWriter
	    (new BufferedWriter(new FileWriter("SystemMixin.log")),
	     true); //  autoflush
      } catch (java.io.IOException e) {
	throw systemMixinFatalError("log open.");
      }
    }
    setupList = new Vector();
    light = false;
    instanceCreated = false;
    loadedPlugIns = new Hashtable();
  }

  /* not used
  public static void require(SystemMixin s){
    // I assumed SystemMixins can be identified by == operator. 
    if (! setupList.contains(s)) {
      setupList.addElement(s);
    }
  }
  */
  public static void addToSetupList(SystemMixin s){
    setupList.addElement(s);
  }
  

  
  public static Obj generate(Object name){
    if (debug) {
      //logfile.println("SystemMixin.generate: name = " + name);
    }
    if (light){
      if (instanceCreated){
	throw systemMixinError("Light: More than one instance are created: "+
			       name);
      }
      instanceCreated = true;
    }
    ObjClass objClass = ((ObjClass)classTable.get(name));
    return new Obj(objClass);
  }
  

  //--------------------------------------------------
  
  public static void setup() {
    if (debug) {
      logfile.println("Start SystemMixin.setup() .");
      listSetupList();
    }

    // Set the light flag true if all system mixins are light version.
    checkWhetherSetupListIsLight();
    if (debug) { logfile.println("SystemMixin.light becomes "+ light); }

    // Stage 1:
    //  Make Hashtable of Vector of ClassMixin
    //  from Vector of SystemMixin.
    Hashtable ct = collectClasses(setupList);
    // Stage 2:
    //  Make array of array of ClassMixin.
    ClassMixin[][] classMixinsArray = expandInheritanceGraph(ct);
    // Stage 3:
    //  Make Hashtable of ObjClass.
    classTable = makeClassTable(classMixinsArray);

    if (debug) {
      logfile.println("End SystemMixin.setup() .");
      logfile.println();
      listClassTable();
    }
    if (light) {
      if (debug) logfile.println("Start special setup for SystemMixin Light.");
      setupSystemMixinLight(classTable);
      if (debug) logfile.println("End special setup for SystemMixin Light.");
    }
  }
  
  
  private static Hashtable collectClasses(Vector setupList){
    // key=name, value=Vector of ClassMixin
    Hashtable ct = new Hashtable();
    for (Enumeration e = setupList.elements(); e.hasMoreElements();){
      SystemMixin s = (SystemMixin)e.nextElement();
      ClassMixin[] classMixins = s.classMixins;
      for (int i = 0; i < classMixins.length; i++){
	ClassMixin c = classMixins[i];
	Vector classVec = (Vector)ct.get(c.name);
	if (classVec == null){
	  classVec = new Vector();
	  ct.put(c.name, classVec);
	  if (! c.defp) {
	    throw systemMixinError("ClassMixin Order Error: "
				   + c.name + " in " + s.getClass().getName()
				   + " should be a \"define\" class."
				   );
	  }
	} else {
	  if (c.defp) {
	    throw systemMixinError("ClassMixin Order Error: "
				   + c.name + " in " + s.getClass().getName()
				   + " should not be a \"define\" class."
				   );
	  }
	}
	classVec.addElement(c);
      }
    }
    return ct;
  }
  
  private static ClassMixin[][] expandInheritanceGraph(Hashtable ct){
    ClassMixin[][] classMixinsArray = new ClassMixin[ct.size()][];
    int classIndex = 0;
    for (Enumeration e = ct.elements(); e.hasMoreElements();){
      // classMixins is a Vector of ClassMixin.
      Vector classMixins = (Vector)e.nextElement();
      // classes is a reverse ordered Vector of Vector of ClassMixin.
      Vector classes = new Vector();
      classes.addElement(classMixins);
      Object nextClassName;
      // The type of nextClassMixins is Vector of ClassMixin
      Vector nextClassMixins = classMixins;
      while ((nextClassName = ((ClassMixin)nextClassMixins.elementAt(0)).orig)
	     != null){
	nextClassMixins = (Vector)ct.get(nextClassName);
	classes.addElement(nextClassMixins);
      }
      
      // Connect the chain of inheritance.
      ClassMixin[] combinedClassMixins;
      {
	int numMixins = 0;
	for (int i = 0; i < classes.size(); i++){
	  numMixins += ((Vector)classes.elementAt(i)).size();
	}
	combinedClassMixins = new ClassMixin[numMixins];
      }
      {
	int index = 0;
	for (int i = classes.size() - 1; i >= 0 ; i--){
	  Vector v = (Vector)classes.elementAt(i);
	  for (int j = 0; j < v.size(); j++){
	    combinedClassMixins[index++] = (ClassMixin)v.elementAt(j);
	  }
	}
      }
      
      classMixinsArray[classIndex++] = combinedClassMixins;
    }
    return classMixinsArray;
  }
  
  private static Hashtable makeClassTable(ClassMixin[][] classMixinsArray){
    Hashtable ct = new Hashtable();
    int classIndex;
    for (classIndex = 0; classIndex < classMixinsArray.length; classIndex++){
      ClassMixin[] cms = classMixinsArray[classIndex];

      Object className = cms[cms.length - 1].name;

      ObjFieldAllocator[] fieldAllocators = makeFieldAllocators(cms);

      Hashtable methods = collectMethodTable(cms);

      Hashtable methodTable = makeMethodTable(className, methods);
      
      ct.put(className,
	     new ObjClass(className, fieldAllocators, methodTable));
    }
    return ct;
  }
  
  
  private static ObjFieldAllocator[] makeFieldAllocators(ClassMixin[] cms){
    Vector fv = new Vector();
    for (int i = 0; i < cms.length; i++){
      if (cms[i].fieldAllocator != null) fv.addElement(cms[i].fieldAllocator);
    }
    ObjFieldAllocator[] fieldAllocators = new ObjFieldAllocator[fv.size()];
    fv.copyInto(fieldAllocators);
    return fieldAllocators;
  }
  
  
  private static Hashtable collectMethodTable(ClassMixin[] cms){
    Hashtable methods = new Hashtable(); // key=name, value=MethodMixin vec
    for (int i = 0; i < cms.length; i++){
      MethodMixin[] methodMixins = cms[i].methodMixins;
      for (int j = 0; j < methodMixins.length; j++){
	MethodMixin m = methodMixins[j];
	Vector mixins = (Vector)methods.get(m.name);
	if (mixins == null){
	  mixins = new Vector();
	  methods.put(m.name, mixins);
	}
	mixins.addElement(m);
      }
    }
    return methods;
  }
  
  
  private static Hashtable makeMethodTable(Object className,
					   Hashtable methods){
    Hashtable methodTable = new Hashtable();
    for (Enumeration e = methods.keys(); e.hasMoreElements();){
      Object methodName = e.nextElement();
      Vector mv = (Vector)methods.get(methodName);
      MethodMixin[] methodMixins = new MethodMixin[mv.size()];
      mv.copyInto(methodMixins);
      methodTable.put(methodName, makeMethodBodies(methodMixins));
    }
    return methodTable;
  }
  
  
  private static Object[] makeMethodBodies(MethodMixin[] methodMixins){
    if (methodMixins.length < 1){
      throw systemMixinFatalError("???");
    }
    
    // Checking method order constraint.
    {
      boolean eflag = false;
      if (! methodMixins[0].defp){
	logfile.println("The first method mixin should be \"define\".");
	eflag = true;
      }
      for (int i = 1; i < methodMixins.length; i++){
	if (methodMixins[i].defp){
	  logfile.println("Only the first method mixin should be \"define\".");
	  eflag = true;
	}
      }
      
      // I should check method role. But currently not implemented.
      {
      }
      if (eflag) {
	logfile.println("Illegal sequence of method mixins is listed bellow:");
	for (int i = 0; i < methodMixins.length; i++){
	  MethodMixin m = methodMixins[i];
	  String role = m.methodRole.toString();
	  if (role.length() <= 11) {
	    role = role+ "           ".substring(role.length());
	  }
	  logfile.println("    "+
			  (m.defp ? "define " : "       ")+
			  role+
			  " "+
			  m.body.getClass().getName());
	}
	throw systemMixinError("Method mixins order error during setup.");
      }
    }
    
    // Make methodBodies.
    Object[] methodBodies= new Object[methodMixins.length];
    for (int i = 0; i < methodMixins.length; i++){
      methodBodies[i] = methodMixins[i].body;
    }
    return methodBodies;
  }


  //--------------------------------------------------
  
  private static void checkWhetherSetupListIsLight(){
    SystemMixin[] systemMixins = new SystemMixin[setupList.size()];
    setupList.copyInto(systemMixins);
    if (systemMixins.length == 0){
      throw systemMixinError("The setup list contains no system mixins.");
    }
    light = systemMixins[0].lightFlag;
    for (int i = 0; i < systemMixins.length; i++){
      if (systemMixins[i].lightFlag != light){
	logfile.println("Light and non-light version of system mixins are mixed: ");
	for (int j = 0; j < systemMixins.length; j++){
	  logfile.println(systemMixins[j].name.toString()+
			  " is "+
			  (systemMixins[j].lightFlag ? "light" : "non-light"));
	}
	throw systemMixinError("");
      }
    }
  }
  
  private static void setupSystemMixinLight(Hashtable classTable){
    ObjClass c = null;
    for (Enumeration e = classTable.keys(); e.hasMoreElements();){
      if (c != null){
	throw systemMixinError("setupSystemMixinLight: "+
			       "More than one Ld class is defined.");
      }
      c = (ObjClass)classTable.get(e.nextElement());
    }
    try {
      for (Enumeration e = c.methodTable.keys(); e.hasMoreElements();){
	Object methodName = e.nextElement();
	Object[] ms = (Object[])c.methodTable.get(methodName);
	
	// Setup original chain.
	// (ms[0] is the most original method.)
	for (int i = ms.length - 1; i >= 1 ; i--){
	  Field originalField = ms[i].getClass().getField("_original");
	  // (ms_i)._original = (ms_i-1);
	  originalField.set(ms[i], ms[i - 1]);
	}
	
	Class methodClass;
	try {
	  // Get a fully qualified name of the super class of methods.
	  String fqMethodName = ms[0].getClass().getSuperclass().getName();
	  methodClass = Class.forName(fqMethodName);
	} catch (ClassNotFoundException e0){
	  throw systemMixinFatalError(e0.toString());
	}
	// M_foo.m = ms[ms.length - 1];
	methodClass.getField("m").set(null, ms[ms.length - 1]);
      }
    } catch (NoSuchFieldException e){
      logfile.println(e.toString());
      throw systemMixinError("setupSystemMixinLight: "+
			     "Field m or _original is not found. "+
			     "Some PlugIn is translated without light option.");
    } catch (IllegalAccessException e){
      throw systemMixinFatalError(e.toString());
    }
  }


  //--------------------------------------------------

  public static Error systemMixinError(String s){
    String mes = "SystemMixinRuntime: error: " + s;
    logfile.println(mes);
    return new Error(mes);
  }
  public static Error systemMixinFatalError(String s){
    String mes = "SystemMixinRuntime fatal error: " + s;
    logfile.println(mes);
    return new Error(mes);
  }

  public static void listSetupList(){
    logfile.println("Start listing setupList.");
    for (Enumeration e = setupList.elements(); e.hasMoreElements();){
      ((SystemMixin)e.nextElement()).listSystemMixin();
    }
    logfile.println("End listing setupList.");
    logfile.println();
  }
  public static void listClassTable(){
    logfile.println("Start listing SystemMixin.classTable .");
    for (Enumeration e = classTable.keys(); e.hasMoreElements();){
      Object name = e.nextElement();
      logfile.println();
      logfile.println("ObjClass " +  name + ":");
      ObjClass oc = (ObjClass)classTable.get(name);
      oc.listObjClass();
    }
    logfile.println();
    logfile.println("End listing SystemMixin.classTable .");
    logfile.println();
    logfile.println();
  }
  

  //--------------------------------------------------
  // Instance member definitions.
  public Object name;
  public ClassMixin[] classMixins;
  public boolean lightFlag = false;
  /* not used
  public void require(){
    SystemMixin.require(this);
  }
  */
  public void listSystemMixin(){
      logfile.println("  SystemMixin: " + this.getClass().getName());
      for (int i = 0; i < classMixins.length; i++){
	classMixins[i].listClassMixin();
      }
  }
}
