/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package SystemMixinRuntimes;

public class MethodMixin {
  Object name;
  boolean defp;
  Object methodRole;
  Object body;
  
  public MethodMixin(Object name, boolean defp, Object methodRole,
		     Object body){
    this.name = name; this.defp = defp; this.methodRole = methodRole;
    this.body = body;
  }
  
  public void listMethodMixin(){
    SystemMixin.logfile.println("      "
				+ (defp ? "define " : "       ")
				+ methodRole 
				+ " " + name
				+ " : " + body.getClass().getName());

  }
}
