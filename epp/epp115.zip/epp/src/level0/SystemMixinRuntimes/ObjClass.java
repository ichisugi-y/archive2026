/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package SystemMixinRuntimes;
import java.util.Hashtable;

class ObjClass {
  Object name;			// Not used.
  Hashtable methodTable;
  ObjFieldAllocator[] fieldAllocators;

  ObjClass(Object name, ObjFieldAllocator[] fieldAllocators,
	   Hashtable methodTable){
    this.name = name;
    this.fieldAllocators = fieldAllocators;
    this.methodTable = methodTable;
  }

  public Hashtable initFieldTable(){
    Hashtable fieldTable = new Hashtable();
    for (int i = 0; i < fieldAllocators.length; i++){
      fieldAllocators[i].allocate(fieldTable);
    }
    return fieldTable;
  }
  
  public void listObjClass(){
    for (int i = 0; i < fieldAllocators.length; i++){
      SystemMixin.logfile.println("  " + 
				  fieldAllocators[i].getClass().getName());
    }
    for (java.util.Enumeration e = methodTable.keys(); e.hasMoreElements();){
      Object name = e.nextElement();
      Object[] ms = (Object[])methodTable.get(name);
      SystemMixin.logfile.println("  method " + name + ":");
      for (int i = 0; i < ms.length; i++){
	SystemMixin.logfile.println("        " + 
				    ms[i].getClass().getName());
      }
    }
  }
}
