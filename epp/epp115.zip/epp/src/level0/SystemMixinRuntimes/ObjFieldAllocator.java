/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package SystemMixinRuntimes;
import java.util.Hashtable;

/**
 The subclasses of this class are defined at system mixin files
and instantiated at a subclass of the SystemMixin class.
The method allocate is called when an Obj is instantiated.
*/

abstract public class ObjFieldAllocator {
  public abstract void allocate(Hashtable h);
}
