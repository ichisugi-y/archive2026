/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package SystemMixinRuntimes;
import java.util.*;
import java.lang.reflect.*;


public class PlugInLoader {
  public SystemMixin[] mixins;
  
  public SystemMixin[] mixins(){
    return mixins;
  }
  
  public void require(String[] args){
    String plugInName = getClass().getName();
    
    // Check Loop.
    String[] callers = new String[requireStack.size()];
    requireStack.copyInto(callers);
    for (int i = 0; i < callers.length; i++){
      if (plugInName.equals(callers[i])){
	System.err.println("PlugInLoader: require loop detected.");
	System.err.println("    "+ plugInName);
	for (int j = callers.length - 1; j >= 0 ; j--){
	  System.err.println("is required by "+ callers[j]);
	}
	throw SystemMixin.systemMixinError("require loop detected.");
      }
    }
    
    if (SystemMixin.loadedPlugIns.get(plugInName) == null) {
      if (SystemMixin.debug) {
	SystemMixin.logfile.println(" Loading plug-in "+ plugInName);
	if (! requireStack.isEmpty()){
	  SystemMixin.logfile.println("   required by "+ requireStack.peek());
	}
      }
      try {
	requireStack.push(plugInName);
	loadPlugIn(args);
	SystemMixin.loadedPlugIns.put(plugInName, args);
      } finally {
	requireStack.pop();
      }
    } else {
      if (SystemMixin.debug) {
	SystemMixin.logfile.println(" Skip loading plug-in "+ plugInName);
	if (! requireStack.isEmpty()){
	  SystemMixin.logfile.println("   required by "+ requireStack.peek());
	}
	SystemMixin.logfile.println(" because it is already loaded.");
      }
    }
  }
  
  private void loadPlugIn(String[] args){
    plugInArgs = args;
    beforeLoadingPlugIn();
    for (int i = 0; i < mixins.length; i++){
      SystemMixin.addToSetupList(mixins[i]);
    }
  }

  // This method is redefined by subclasses
  //and they may requires other plug-ins.
  public void beforeLoadingPlugIn(){}


  //--------------------------------------------------
  // Static methods.

  // This method is called from main method of subclasses.
  public static void doMain(PlugInLoader plugIn, String[] args){
    SystemMixin.initSetupList();
    plugIn.require(args);
    SystemMixin.setup();

    //
    String plugInName = plugIn.getClass().getName();
    int lastDot = plugInName.lastIndexOf('.');
    String packagePrefix;
    if (lastDot == -1){
      packagePrefix = "";
    } else {
      packagePrefix = plugInName.substring(0, lastDot + 1);
    }
    String startupClassName = packagePrefix+ "C_Startup";
    
    //C_Startup.generateAndInit(args);
    try {
      Class startup = Class.forName(startupClassName);
      Class[] paramTypes = {args.getClass()}; // String[]
      Method m = startup.getMethod("generateAndInit", paramTypes);
      Object[] methodArgs = {args};
      m.invoke(null, methodArgs);
    } catch (Exception e){
      System.err.println("PlugInLoader: doMain: Could not generate the Startup class.");
      System.err.println("Please define a Ld class \""+
			 packagePrefix+ "Startup"+
			 "\" and a constructor "+
			 "Startup(String[]) .");
      throw new Error(e.toString());
    }
  }

  // This stack is used for detecting require loop.
  public static Stack requireStack = new Stack();

  // This method can be called from beforeLoadingPlugIn and plug-in program.
  private static String[] plugInArgs = null;
  public static String[] plugInArgs() { return plugInArgs; }
  
  public static void requirePlugIn(String plugInName){
    String[] args = {};
    requirePlugIn(plugInName, args);
  }
  
  public static void requirePlugIn(String plugInName, String[] args){
    PlugInLoader plugIn;
    try {
      plugIn = (PlugInLoader)Class.forName(plugInName).newInstance();
    } catch (ClassNotFoundException e){
      System.err.println(e);
      throw SystemMixin.systemMixinError("Plug-in class "+ plugInName+
					 " not found.");
    } catch (IllegalAccessException e){
      System.err.println(e);
      throw SystemMixin.systemMixinError("Plug-in class "+ plugInName+
					 " cause IllegalAccessException.");
    } catch (InstantiationException e){
      System.err.println(e);
      throw SystemMixin.systemMixinError("Plug-in class "+ plugInName+
					 " cause InstantiationException");
    }
    plugIn.require(args);
  }
}
