/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */

package SystemMixinRuntimes;

public class ClassMixin {
  Object name;
  boolean defp;
  Object orig;
  ObjFieldAllocator fieldAllocator;
  MethodMixin[] methodMixins;
  
  public ClassMixin(Object name, boolean defp, Object orig,
	     ObjFieldAllocator fieldAllocator,
	     MethodMixin[] methodMixins){
    this.name = name; this.defp = defp; this.orig = orig;
    this.fieldAllocator = fieldAllocator;
    this.methodMixins = methodMixins;
  }
  
  public void listClassMixin(){
    // fieldAllocator $B$O$H$j$"$($:L5;k!#(B
    SystemMixin.logfile.println("    ClassMixin: " + (defp ? "define" : "")
				+ " " + name + ", "
				+ "orig = " + orig);
    for (int j = 0; j < methodMixins.length; j++){
      methodMixins[j].listMethodMixin();
    }
  }
}
