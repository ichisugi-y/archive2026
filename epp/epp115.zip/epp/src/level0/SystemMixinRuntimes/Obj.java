/*
 *
 * Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002 Yuuji ICHISUGI
 *
 * Permission to use, copy, modify and redistribution this software in
 * whole and in part, for evaluation or research purposes and without fee
 * is hereby granted provided this copyright notice.
 * See CopyrightAndLicensing.txt for licensing condition.
 */


package SystemMixinRuntimes;
import java.util.Hashtable;

public class Obj {
  // Static member definitions
  // used at arguments of "call" methods.
  public static Obj calleeself = null;
  public static Object[] calleemb = null;
  public static int calleembi = 0;
  
  // Instance member definitions.
  ObjClass objClass;
  Hashtable fieldTable;
  
  Obj(ObjClass c){
    objClass = c;
    fieldTable = c.initFieldTable();
  }
  
  // The argument is Symbol or String.
  public Object findMethod(Object name){
    calleeself = this;
    calleemb = (Object[])objClass.methodTable.get(name);
    if (calleemb == null){
      throw SystemMixin.systemMixinError("Method \""+
					 name+
					 "\" not found in ObjClass \""+
					 objClass.name+
					 "\".");
    }
    int lastindex = calleemb.length - 1;
    calleembi = lastindex - 1;
    return calleemb[lastindex];
  }
  
  public Object findField(Object name){
    Object f = fieldTable.get(name);
    if (f == null){
      throw SystemMixin.systemMixinError("Field \""+
					 name+
					 "\" not found in ObjClass \""+
					 objClass.name+
					 "\".");
    }
    return f;
  }
}
