/*
 $@$3$N%U%!%$%k$O!"(J PlugIn.java $@$N%F%s%W%l!<%H$H$7$F$*;H$$$/$@$5$$!#(J

 $@;HMQ<j=g!'(J

 $@0J2<!"Dj5A$7$?$$(J plug-in $@$NL>A0$r(J "MyPlugIn" $@$H$7$^$9!#(J

 Sample $@$r(J MyPlugIn $@$K!"(J sample $@$r(J myPlugIn $@$KCV49$7$F$/$@$5$$!#(J

 <fill-here> $@$H=q$$$F$"$k>l=j$r$9$Y$FKd$a$F$/$@$5$$!#(J

 $@ITMW$J%3%a%s%H$r<h$C$F$/$@$5$$!#(J

*/


/*
Summry:
	<fill-here>
Syntax:
	Sample <fill-here>
Features:
	<fill-here>
Auther:
	<fill-here>
*/


#epp jp.go.etl.epp.EppLibLevel0

package Sample;

SystemMixin Sample {
  class Epp {

    extend Tree statementTop() {
      if (lookahead() == :"Sample") {
	<fill-here>
	return new Tree(:sample, <fill-here>);
      } else {
	return original();
      }
    }

    extend void initMacroTable() {
      original();
      defineMacro(:sample, new SampleMacro());
    }
  }
}


class SampleMacro extends Macro {
  public Tree call(Tree tree){
    checkArgsLength(tree, <fill-here>);
    Tree[] args = tree.args();
    <fill-here>
    return <fill-here>;
  }
}
