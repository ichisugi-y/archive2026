package de.fub.bytecode.generic;

/** 
 * DREM - Remainder of doubles
 * <PRE>Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 -&gt;</PRE>
 *        ..., result.word1, result.word2
 *
 * @version $Id: DREM.java,v 1.5 2000/04/19 08:47:04 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DREM extends ArithmeticInstruction {
  /** Remainder of doubles
   */
  public DREM() {
    super(DREM);
  }
}

