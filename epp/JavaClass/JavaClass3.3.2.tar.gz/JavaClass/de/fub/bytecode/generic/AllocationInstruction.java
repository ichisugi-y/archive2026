package de.fub.bytecode.generic;

/**
 * Denotes the NEW, NEWARRAY, ANEWARRAY and MULTIANEWARRAY
 * family of instructions.
 *
 * @version $Id: AllocationInstruction.java,v 1.2 1999/05/04 13:12:39 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public interface AllocationInstruction {}

