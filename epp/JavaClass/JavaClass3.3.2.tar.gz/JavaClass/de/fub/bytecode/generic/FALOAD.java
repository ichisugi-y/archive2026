package de.fub.bytecode.generic;

/** 
 * FALOAD - Load float from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value</PRE>
 *
 * @version $Id: FALOAD.java,v 1.5 2000/04/19 08:47:06 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FALOAD extends ArrayInstruction {
  /** Load float from array
   */
  public FALOAD() {
    super(FALOAD);
  }
}

