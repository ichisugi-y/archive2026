package de.fub.bytecode.generic;

/** 
 * FRETURN -  Return float from method
 * <PRE>Stack: ..., value -&gt; &lt;empty&gt;</PRE>
 *
 * @version $Id: FRETURN.java,v 1.6 2000/04/19 08:47:07 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FRETURN extends ReturnInstruction {
  /** Return float from method
   */
  public FRETURN() {
    super(FRETURN);
  }
}

