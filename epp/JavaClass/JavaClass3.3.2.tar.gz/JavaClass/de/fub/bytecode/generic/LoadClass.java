package de.fub.bytecode.generic;

/**
 * Denotes that an instruction may start the process of loading and resolving 
 * the referenced class in the Virtual Machine.
 *
 * @version $Id: LoadClass.java,v 1.2 1999/05/04 13:14:35 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public interface LoadClass {}

