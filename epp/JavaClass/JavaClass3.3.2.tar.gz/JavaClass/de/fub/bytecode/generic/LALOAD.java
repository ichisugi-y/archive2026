package de.fub.bytecode.generic;

/** 
 * LALOAD - Load long from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value1, value2</PRE>
 *
 * @version $Id: LALOAD.java,v 1.5 2000/04/19 08:47:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LALOAD extends ArrayInstruction {
  /** Load long from array
   */
  public LALOAD() {
    super(LALOAD);
  }
}

