package de.fub.bytecode.generic;

/** 
 * AALOAD - Load reference from array
 * Stack ..., arrayref, index -> value
 *
 * @version $Id: AALOAD.java,v 1.4 2000/04/19 08:46:59 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class AALOAD extends ArrayInstruction {
  /** Load reference from array
   */
  public AALOAD() {
    super(AALOAD);
  }
}

