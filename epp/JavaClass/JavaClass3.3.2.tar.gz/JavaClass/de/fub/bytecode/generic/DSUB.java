package de.fub.bytecode.generic;

/** 
 * DSUB - Substract doubles
 * <PRE>Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 -&gt;</PRE>
 *        ..., result.word1, result.word2
 *
 * @version $Id: DSUB.java,v 1.5 2000/04/19 08:47:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DSUB extends ArithmeticInstruction {
  /** Substract doubles
   */
  public DSUB() {
    super(DSUB);
  }
}

