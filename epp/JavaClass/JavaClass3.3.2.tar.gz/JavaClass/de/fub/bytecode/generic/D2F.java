package de.fub.bytecode.generic;

/** 
 * D2F - Convert double to float
 * <PRE>Stack: ..., value.word1, value.word2 -&gt; ..., result</PRE>
 *
 * @version $Id: D2F.java,v 1.5 2000/04/19 08:47:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class D2F extends ConversionInstruction {
  /** Convert double to float
   */
  public D2F() {
    super(D2F);
  }
}

