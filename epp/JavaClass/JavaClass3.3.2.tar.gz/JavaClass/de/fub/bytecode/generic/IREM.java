package de.fub.bytecode.generic;

/**
 * IREM - Remainder of int
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: IREM.java,v 1.6 2000/04/19 08:47:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IREM extends ArithmeticInstruction implements ExceptionThrower {
  /** Remainder of ints
   */
  public IREM() {
    super(IREM);
  }

  /** @return exceptions this instruction may cause
   */
  public Class[] getExceptions() { return new Class[] { ARITHMETIC_EXCEPTION }; }
}

