package de.fub.bytecode.generic;

/** 
 * I2C - Convert int to char
 * <PRE>Stack: ..., value -&gt; ..., result</PRE>
 *
 * @version $Id: I2C.java,v 1.5 2000/04/19 08:47:07 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2C extends ConversionInstruction {
  /** Convert int to char
   */
  public I2C() {
    super(I2C);
  }
}

