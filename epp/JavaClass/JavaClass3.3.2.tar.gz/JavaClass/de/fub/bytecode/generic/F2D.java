package de.fub.bytecode.generic;

/** 
 * F2D - Convert float to double
 * <PRE>Stack: ..., value -&gt; ..., result.word1, result.word2</PRE>
 *
 * @version $Id: F2D.java,v 1.5 2000/04/19 08:47:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class F2D extends ConversionInstruction {
  /** Convert float to double
   */
  public F2D() {
    super(F2D);
  }
}

