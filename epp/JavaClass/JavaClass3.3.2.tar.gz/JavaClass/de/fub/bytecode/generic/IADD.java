package de.fub.bytecode.generic;

/** 
 * IADD - Add ints
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: IADD.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IADD extends ArithmeticInstruction {
  /** Add ints
   */
  public IADD() {
    super(IADD);
  }
}

