package de.fub.bytecode.generic;

/** 
 * LUSHR - Logical shift right long
 * <PRE>Stack: ..., value1, value2 -&gt; ..., result</PRE>
 *
 * @version $Id: LUSHR.java,v 1.4 1999/05/04 13:14:33 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LUSHR extends ArithmeticInstruction {
  public LUSHR() {
    super(LUSHR);
  }
}

