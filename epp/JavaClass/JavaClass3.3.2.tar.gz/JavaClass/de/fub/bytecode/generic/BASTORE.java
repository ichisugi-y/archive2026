package de.fub.bytecode.generic;

/** 
 * BASTORE -  Store into byte or boolean array
 * <PRE>Stack: ..., arrayref, index, value -&gt; ...</PRE>
 *
 * @version $Id: BASTORE.java,v 1.5 2000/04/19 08:47:01 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class BASTORE extends ArrayInstruction {
  /** Store byte or boolean into array
   */
  public BASTORE() {
    super(BASTORE);
  }
}

