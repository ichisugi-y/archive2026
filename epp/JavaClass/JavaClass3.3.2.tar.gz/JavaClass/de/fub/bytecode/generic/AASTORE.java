package de.fub.bytecode.generic;

/** 
 * AASTORE -  Store into reference array
 * <PRE>Stack: ..., arrayref, index, value -&gt; ...</PRE>
 *
 * @version $Id: AASTORE.java,v 1.5 2000/04/19 08:47:00 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class AASTORE extends ArrayInstruction {
  /** Store into reference array
   */
  public AASTORE() {
    super(AASTORE);
  }
}

