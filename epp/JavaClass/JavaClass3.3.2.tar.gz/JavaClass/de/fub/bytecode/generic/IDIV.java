package de.fub.bytecode.generic;

/**
 * IDIV - Divide ints
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: IDIV.java,v 1.6 2000/04/19 08:47:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IDIV extends ArithmeticInstruction implements ExceptionThrower {
  /** Divide ints
   */
  public IDIV() {
    super(IDIV);
  }

  /** @return exceptions this instruction may cause
   */
  public Class[] getExceptions() { return new Class[] { ARITHMETIC_EXCEPTION }; }
}

