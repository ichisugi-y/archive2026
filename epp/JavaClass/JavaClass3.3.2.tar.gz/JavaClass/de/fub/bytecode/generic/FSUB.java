package de.fub.bytecode.generic;

/**
 * FSUB - Substract floats
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: FSUB.java,v 1.5 2000/04/19 08:47:07 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FSUB extends ArithmeticInstruction {
  /** Substract floats
   */
  public FSUB() {
    super(FSUB);
  }
}

