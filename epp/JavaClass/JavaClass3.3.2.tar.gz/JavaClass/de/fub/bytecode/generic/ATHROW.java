package de.fub.bytecode.generic;

/** 
 * ATHROW -  Throw exception
 * <PRE>Stack: ..., objectref -&gt; objectref</PRE>
 *
 * @version $Id: ATHROW.java,v 1.6 2000/04/19 08:47:01 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ATHROW extends Instruction implements UnconditionalBranch, ExceptionThrower {
  /** 
   *  Throw exception
   */
  public ATHROW() {
    super(ATHROW, (short)1);
  }

  /** @return exceptions this instruction may cause
   */
  public Class[] getExceptions() { return new Class[] { THROWABLE }; }
}

