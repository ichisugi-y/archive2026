package de.fub.bytecode.generic;

/** 
 * I2F - Convert int to float
 * <PRE>Stack: ..., value -&gt; ..., result</PRE>
 *
 * @version $Id: I2F.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2F extends ConversionInstruction {
  /** Convert int to float
   */
  public I2F() {
    super(I2F);
  }
}

