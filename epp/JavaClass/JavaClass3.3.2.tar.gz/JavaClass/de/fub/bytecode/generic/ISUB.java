package de.fub.bytecode.generic;

/** 
 * ISUB - Substract ints
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: ISUB.java,v 1.5 2000/04/19 08:47:10 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ISUB extends ArithmeticInstruction {
  /** Substract ints
   */
  public ISUB() {
    super(ISUB);
  }
}

