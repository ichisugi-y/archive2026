package de.fub.bytecode.generic;

/** 
 * D2I - Convert double to int
 * <PRE>Stack: ..., value.word1, value.word2 -&gt; ..., result</PRE>
 *
 * @version $Id: D2I.java,v 1.5 2000/04/19 08:47:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class D2I extends ConversionInstruction {
  /** Convert double to int
   */
  public D2I() {
    super(D2I);
  }
}

