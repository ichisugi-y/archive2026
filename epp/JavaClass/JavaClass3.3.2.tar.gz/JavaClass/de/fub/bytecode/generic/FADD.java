package de.fub.bytecode.generic;

/** 
 * FADD - Add floats
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: FADD.java,v 1.5 2000/04/19 08:47:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FADD extends ArithmeticInstruction {
  /** Add floats
   */
  public FADD() {
    super(FADD);
  }
}

