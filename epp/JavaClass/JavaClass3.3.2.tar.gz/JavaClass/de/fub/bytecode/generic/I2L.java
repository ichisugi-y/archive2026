package de.fub.bytecode.generic;

/**
 * I2L - Convert int to long
 * <PRE>Stack: ..., value -&gt; ..., result.word1, result.word2</PRE>
 *
 * @version $Id: I2L.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2L extends ConversionInstruction {
  /** Convert int to long
   */
  public I2L() {
    super(I2L);
  }
}

