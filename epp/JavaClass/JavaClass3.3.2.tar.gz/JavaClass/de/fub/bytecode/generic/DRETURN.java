package de.fub.bytecode.generic;

/** 
 * DRETURN -  Return double from method
 * <PRE>Stack: ..., value.word1, value.word2 -&gt; &lt;empty&gt;</PRE>
 *
 * @version $Id: DRETURN.java,v 1.6 2000/04/19 08:47:04 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DRETURN extends ReturnInstruction {
  /** Return double from method
   */
  public DRETURN() {
    super(DRETURN);
  }
}

