package de.fub.bytecode.generic;

/** 
 * ACONST_NULL - Push null reference
 * <PRE>Stack: ... -&gt; ..., null</PRE>
 *
 * @version $Id: ACONST_NULL.java,v 1.5 2000/04/19 08:47:00 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ACONST_NULL extends Instruction implements PushInstruction {
  /** 
   * Push null reference
   */
  public ACONST_NULL() {
    super(ACONST_NULL, (short)1);
  }
}

