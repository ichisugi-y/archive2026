package de.fub.bytecode.generic;

/** 
 * BALOAD - Load byte or boolean from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value</PRE>
 *
 * @version $Id: BALOAD.java,v 1.5 2000/04/19 08:47:01 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class BALOAD extends ArrayInstruction {
  /** Load byte or boolean from array
   */
  public BALOAD() {
    super(BALOAD);
  }
}

