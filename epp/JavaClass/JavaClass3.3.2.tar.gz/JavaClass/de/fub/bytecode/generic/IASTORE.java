package de.fub.bytecode.generic;

/** 
 * IASTORE -  Store into int array
 * <PRE>Stack: ..., arrayref, index, value -&gt; ...</PRE>
 *
 * @version $Id: IASTORE.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IASTORE extends ArrayInstruction {
  /** 
   * Store into int array
   */
  public IASTORE() {
    super(IASTORE);
  }
}

