package de.fub.bytecode.generic;

/** 
 * ARETURN -  Return reference from method
 * <PRE>Stack: ..., objectref -&gt; &lt;empty&gt;</PRE>
 *
 * @version $Id: ARETURN.java,v 1.6 2000/04/19 08:47:00 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class ARETURN extends ReturnInstruction {
  /** 
   * Return reference from method
   */
  public ARETURN() {
    super(ARETURN);
  }
}

