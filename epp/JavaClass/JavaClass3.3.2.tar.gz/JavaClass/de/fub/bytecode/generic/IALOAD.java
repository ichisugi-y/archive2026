package de.fub.bytecode.generic;

/** 
 * IALOAD - Load int from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value</PRE>
 *
 * @version $Id: IALOAD.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IALOAD extends ArrayInstruction {
  /** 
   * Load int from array
   */
  public IALOAD() {
    super(IALOAD);
  }
}

