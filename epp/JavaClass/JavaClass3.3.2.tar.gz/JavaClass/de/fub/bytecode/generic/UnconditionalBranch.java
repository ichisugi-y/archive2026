package de.fub.bytecode.generic;

/**
 * Denotes an instruction to perform an unconditional branch, i.e., GOTO, JSR.
 *
 * @version $Id: UnconditionalBranch.java,v 1.4 2000/08/10 08:36:24 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>

 * @see GOTO
 * @see JSR
 */
public interface UnconditionalBranch {}

