package de.fub.bytecode.generic;

/** 
 * CALOAD - Load char from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value</PRE>
 *
 * @version $Id: CALOAD.java,v 1.5 2000/04/19 08:47:02 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class CALOAD extends ArrayInstruction {
  /** Load char from array
   */
  public CALOAD() {
    super(CALOAD);
  }
}

