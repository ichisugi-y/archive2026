package de.fub.bytecode.generic;

/** 
 * DLOAD - Load double from local variable
 * Stack ... -> ..., result.word1, result.word2
 *
 * @version $Id: DLOAD.java,v 1.5 2000/04/19 08:47:04 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DLOAD extends LocalVariableInstruction implements PushInstruction {
  /**
   * Empty constructor needed for the Class.newInstance() statement in
   * Instruction.readInstruction(). Not to be used otherwise.
   */
  DLOAD() {
    super(DLOAD, DLOAD_0);
  }

  /** Load double from local variable
   * @param n index of local variable
   */
  public DLOAD(int n) {
    super(DLOAD, DLOAD_0, n);
  }
}

