package de.fub.bytecode.generic;

/** 
 * DALOAD - Load double from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., result.word1, result.word2</PRE>
 *
 * @version $Id: DALOAD.java,v 1.5 2000/04/19 08:47:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DALOAD extends ArrayInstruction {
  /** Load double from array
   */
  public DALOAD() {
    super(DALOAD);
  }
}

