package de.fub.bytecode.generic;

/** 
 * DASTORE -  Store into double array
 * <PRE>Stack: ..., arrayref, index, value.word1, value.word2 -&gt; ...</PRE>
 *
 * @version $Id: DASTORE.java,v 1.5 2000/04/19 08:47:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DASTORE extends ArrayInstruction {
  /** Store double into array
   */
  public DASTORE() {
    super(DASTORE);
  }
}

