package de.fub.bytecode.generic;

/**
 * FMUL - Multiply floats
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: FMUL.java,v 1.5 2000/04/19 08:47:06 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FMUL extends ArithmeticInstruction {
  /** Multiply floats
   */
  public FMUL() {
    super(FMUL);
  }
}

