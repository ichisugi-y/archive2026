package de.fub.bytecode.generic;

/**
 * SASTORE - Store into short array
 * <PRE>Stack: ..., arrayref, index, value -&gt; ...</PRE>
 *
 * @version $Id: SASTORE.java,v 1.4 1999/05/04 13:14:52 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class SASTORE extends ArrayInstruction {
  public SASTORE() {
    super(SASTORE);
  }
}

