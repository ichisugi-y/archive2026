package de.fub.bytecode.generic;

/** 
 * DADD - Add doubles
 * <PRE>Stack: ..., value1.word1, value1.word2, value2.word1, value2.word2 -&gt;</PRE>
 *        ..., result.word1, result1.word2
 *
 * @version $Id: DADD.java,v 1.5 2000/04/19 08:47:03 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class DADD extends ArithmeticInstruction {
  /** Add doubles
   */
  public DADD() {
    super(DADD);
  }
}

