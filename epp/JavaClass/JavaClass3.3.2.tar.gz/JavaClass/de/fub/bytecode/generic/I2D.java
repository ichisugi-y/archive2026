package de.fub.bytecode.generic;

/**
 * I2D - Convert int to double
 * <PRE>Stack: ..., value -&gt; ..., result.word1, result.word2</PRE>
 *
 * @version $Id: I2D.java,v 1.5 2000/04/19 08:47:08 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class I2D extends ConversionInstruction {
  /** Convert int to double
   */
  public I2D() {
    super(I2D);
  }
}

