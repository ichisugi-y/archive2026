package de.fub.bytecode.generic;

/** 
 * F2I - Convert float to int
 * <PRE>Stack: ..., value -&gt; ..., result</PRE>
 *
 * @version $Id: F2I.java,v 1.5 2000/04/19 08:47:05 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class F2I extends ConversionInstruction {
  /** Convert float to int
   */
  public F2I() {
    super(F2I);
  }
}

