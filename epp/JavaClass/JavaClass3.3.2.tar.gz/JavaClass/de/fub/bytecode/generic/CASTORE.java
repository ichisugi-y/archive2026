package de.fub.bytecode.generic;

/** 
 * CASTORE -  Store into char array
 * <PRE>Stack: ..., arrayref, index, value -&gt; ...</PRE>
 *
 * @version $Id: CASTORE.java,v 1.5 2000/04/19 08:47:02 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class CASTORE extends ArrayInstruction {
  /** Store char into array
   */
  public CASTORE() {
    super(CASTORE);
  }
}

