package de.fub.bytecode.generic;

/** 
 * IRETURN -  Return int from method
 * <PRE>Stack: ..., value -&gt; &lt;empty&gt;</PRE>
 *
 * @version $Id: IRETURN.java,v 1.6 2000/04/19 08:47:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IRETURN extends ReturnInstruction {
  /** Return int from method
   */
  public IRETURN() {
    super(IRETURN);
  }
}

