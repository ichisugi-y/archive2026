package de.fub.bytecode.generic;

/** 
 * SALOAD - Load short from array
 * <PRE>Stack: ..., arrayref, index -&gt; ..., value</PRE>
 *
 * @version $Id: SALOAD.java,v 1.4 1999/05/04 13:14:51 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class SALOAD extends ArrayInstruction {
  public SALOAD() {
    super(SALOAD);
  }
}

