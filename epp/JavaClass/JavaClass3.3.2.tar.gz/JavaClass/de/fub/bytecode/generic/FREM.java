package de.fub.bytecode.generic;

/**
 * FREM - Remainder of floats
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: FREM.java,v 1.5 2000/04/19 08:47:06 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class FREM extends ArithmeticInstruction {
  /** Remainder of floats
   */
  public FREM() {
    super(FREM);
  }
}

