package de.fub.bytecode.generic;

/** 
 * IMUL - Multiply ints
 * <PRE>Stack: ..., value1, value2 -&gt; result</PRE>
 *
 * @version $Id: IMUL.java,v 1.5 2000/04/19 08:47:09 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class IMUL extends ArithmeticInstruction {
  /** Multiply ints
   */
  public IMUL() {
    super(IMUL);
  }
}

