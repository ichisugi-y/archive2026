package de.fub.bytecode.generic;

/** 
 * LASTORE -  Store into long array
 * <PRE>Stack: ..., arrayref, index, value.word1, value.word2 -&gt; ...</PRE>
 *
 * @version $Id: LASTORE.java,v 1.5 2000/04/19 08:47:11 dahm Exp $
 * @author  <A HREF="http://www.inf.fu-berlin.de/~dahm">M. Dahm</A>
 */
public class LASTORE extends ArrayInstruction {
  /** Store long into array
   */
  public LASTORE() {
    super(LASTORE);
  }
}

